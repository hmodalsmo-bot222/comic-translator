package com.comictrans.model

data class SettingsData(
    // 🔍 (تبسيط لاحق بطلب المستخدم) حُذف حقل "نموذج كشف مناطق النص" المنفصل
    // (textDetectionModel: كان يقبل craft_mobile/det_east_320/640/1280) — كل محرك OCR أدناه
    // (ocrEngine) عنده كاشف صناديق مدمج خاص به فعلياً (PaddleOCR/ML Kit/EasyOCR/OCR.space/
    // Cloud)، فلا حاجة لقائمة منفصلة. المحرك الوحيد اللي كان بلا كاشف (Tesseract) أصبح يدمج
    // كاشف EAST-640 داخلياً وتلقائياً بدل الاعتماد على اختيار يدوي منفصل — راجع
    // OCREngine.recognizeTesseract بموديول feature_ai.
    val ocrEngine: String = "mlkit",
    val erasureMode: String = "fill",
    val translateEngine: String = "google",
    val sourceLang: String = "en",
    val targetLang: String = "ar",
    val useMemory: Boolean = true,
    val enhanceImage: Boolean = true, // افتراضي مفعّل الآن — يحسّن دقة قراءة OCR لخطوط الكوميك بدون أي نموذج إضافي (راجع الشرح في index.html)
    val enhanceMethod: String = "opencv",
    // 🔍 (استبدال OCR.space بمحرك محلي) خيار "OCR.space (سحابي)" بمحرك OCR استُبدل بمحرك
    // محلي متوافق مع OpenAI Vision API (Ollama/LM Studio/أي سيرفر يدعم صور بتنسيق
    // chat/completions) — نفس نمط حقول الترجمة المحلية (customApiUrl/customApiKey/
    // customModel) أدناه، لكن مستقلة لأن محرك OCR ومحرك الترجمة قد يختلفان (نموذج رؤية
    // محلي منفصل عن نموذج نص). راجع OCREngine.recognizeLocalLlm بموديول feature_ai.
    val ocrLocalApiUrl: String = "",
    val ocrLocalApiKey: String = "",
    val ocrLocalModel: String = "",
    val cloudApiUrl: String = "",
    val geminiKey: String = "",
    val geminiModel: String = "gemini-2.0-flash",
    val openaiKey: String = "",
    val openaiModel: String = "gpt-4o-mini",
    val openrouterKey: String = "",
    val openrouterModel: String = "openai/gpt-4o-mini",
    val deeplKey: String = "",
    // بند 8: Local LLM (Ollama / LM Studio / أي سيرفر متوافق مع OpenAI API). translateEngine
    // = "custom" يستخدم هذه الحقول. مثال customApiUrl لـOllama محلي:
    // "http://127.0.0.1:11434/v1/chat/completions" — والـcustomApiKey يُترَك فارغاً غالباً
    // (Ollama/LM Studio لا يتطلبان مفتاحاً افتراضياً).
    val customApiUrl: String = "",
    val customApiKey: String = "",
    // 🔍 (2026-08-19) مفتاح API ثانٍ اختياري لنفس السيرفر المحلي + مفتاح تفعيل "تقسيم
    // الترجمة بين المفتاحين" — عند التفعيل تُوزَّع الصفحات بالتناوب: الصفحات ذات الفهرس
    // الزوجي بالمفتاح الأول والفردي بالثاني (راجع AppInterface.translatePageBlocks).
    val customApiKey2: String = "",
    val customDualKeyEnabled: Boolean = false,
    val customModel: String = "",
    // 🔍 (2026-08-19) حُذف حقلا comicType/seriesName نهائياً بطلب المستخدم (مع حذف حقولهما
    // من الواجهة وقاموس المصطلحات) — Gson يتجاهل مفاتيح JSON القديمة المحفوظة بصمت، فلا
    // حاجة لأي ترحيل. الـsystem prompt صار عاماً (لغة الهدف فقط) — راجع PromptManager.kt.
    // بند 3: كشف فقاعات الكلام — لو true (افتراضي false)، وضع الطمس "opencv" يحاول قناع
    // طمس بحدود الفقاعة الفعلية (Imgproc.findContours) بدل مستطيل النص الخام. راجع
    // BubbleDetector.kt وErasureEngine.inpaintOpenCV للتفاصيل. افتراضي false عمداً حتى
    // يبقى سلوك "opencv" كما كان تماماً ما لم يُفعَّل المستخدم هذا صراحة من الإعدادات.
    val bubbleAwareErasure: Boolean = false,
    // ⚠️ توضيح (2026-08-15): هذا الحقل يُحفَظ/يُقرأ من الإعدادات فقط — لا يوجد أي كود
    // Kotlin آخر بالمشروع يقرأ قيمته (تحقّقت بـgrep على كامل app/ وfeature_ai/، صفر
    // نتائج غير هذا التعريف). القيمتان "freetype_harfbuzz"/"skia" مُدرَجتان بواجهة
    // index.html كخيارات مستقبلية (تحتاج كوداً أصلياً NDK لم يُكتب بعد) — اختيارهما لا
    // يُغيّر أي سلوك رسم فعلي حالياً، يبقى الرسم دائماً عبر Android Canvas بصمت.
    //
    // ✅ تحديث (هذه الدفعة): "android_canvas" صار فعلياً مُفعَّلاً — راجع TextRenderer.kt
    // الجديد. لأوضاع "fill"/"opencv"/"aot_gan"/"migan" فقط (راجع التعليق أعلى TextRenderer
    // لتفاصيل لماذا Android Canvas كافٍ فعلياً بدون FreeType+HarfBuzz منفصل — باختصار: محرك
    // تخطيط النص الداخلي لأندرويد يستخدم أصلاً HarfBuzz/FreeType، بلا اعتمادية جديدة). وضع
    // "blur" لا يزال يُرسَم عبر JS Canvas بمتصفح WebView تحديداً (لم يُنقَل هذه الدفعة).
    val textRendererEngine: String = "android_canvas",

    // ⚠️ اكتشاف بهذه الدفعة: الحقول السبعة التالية كانت تُرسَل فعلياً من JS بكل استدعاء
    // (راجع getSettings() بـindex.html — fontFamily/smartFontSize/fontSizeScale/
    // lineSpacingScale/textWidthRatio/textColor/textBackground كلها موجودة هناك منذ فترة)
    // لكن Gson كان يتجاهلها بصمت عند فك تشفير JSON لهذا الكلاس لأنها لم تكن مُعرَّفة هنا
    // إطلاقاً — لم تكن مشكلة سابقاً لأن Kotlin لم يكن يرسم أي نص أصلاً (كل الرسم JS-only)،
    // لكنها صارت حرجة الآن مع TextRenderer.kt الجديد الذي يحتاج هذه القيم فعلياً لمطابقة
    // تفضيلات المستخدم المحفوظة بالإعدادات. القيم الافتراضية هنا مطابقة حرفياً لقيم JS
    // الافتراضية (fontSizeScale 100%→1، lineSpacingScale 100%→1، textWidthRatio 90%→0.9).
    val fontFamily: String = "system-ui, sans-serif",
    val smartFontSize: Boolean = true,
    val fontSizeScale: Float = 1f,
    val lineSpacingScale: Float = 1f,
    val textWidthRatio: Float = 0.9f,
    val textColor: String = "#000000",
    val textBackground: String = "none" // "none" | "box"
)
