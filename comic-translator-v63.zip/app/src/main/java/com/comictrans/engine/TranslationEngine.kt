package com.comictrans.engine

import android.content.Context
import android.util.Log
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class TranslationEngine(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    // *** ملاحظة مهمة حول كل دوال الترجمة أدناه ***
    // سابقاً كانت كل دالة تلتقط أي استثناء وترجع النص الأصلي بصمت (`return text`)، بدون أي
    // أثر يصل للمستخدم. هذا يعني أنه لو مفتاح API خاطئ، أو الحصة (quota) انتهت، أو اسم
    // الموديل غير موجود، أو الشبكة فشلت — كانت النتيجة "الترجمة لم تتغيّر" بدون أي تفسير،
    // ما يجعل أي محرك يبدو "معطّلاً" عند اختباره دون معرفة السبب الحقيقي. الآن كل دالة
    // ترمي استثناءً واضح الرسالة عند الفشل، ويلتقطه AppInterface.processPage ليعرض تحذيراً
    // فعلياً في سجل الواجهة (⚠️) قبل الرجوع للنص الأصلي كحل احتياطي — بدل فشل صامت تماماً.

    // 1. ML Kit Translation (works offline after model download)
    suspend fun translateMLKit(text: String, source: String, target: String): String = withContext(Dispatchers.IO) {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.fromLanguageTag(source) ?: TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.fromLanguageTag(target) ?: TranslateLanguage.ARABIC)
            .build()
        val translator = Translation.getClient(options)

        // Ensure model is downloaded
        suspendCancellableCoroutine { continuation ->
            val conditions = DownloadConditions.Builder().build()
            translator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener { continuation.resume(Unit) }
                .addOnFailureListener { continuation.resumeWithException(
                    IllegalStateException("ML Kit: تعذر تنزيل نموذج اللغة (تأكد من الاتصال بالإنترنت أول مرة): ${it.message}", it)
                ) }
        }

        suspendCancellableCoroutine { continuation ->
            translator.translate(text)
                .addOnSuccessListener { continuation.resume(it) }
                .addOnFailureListener { continuation.resumeWithException(
                    IllegalStateException("ML Kit: فشلت الترجمة: ${it.message}", it)
                ) }
        }
    }

    // 2. Google Translate (free, no key)
    suspend fun translateGoogle(text: String, source: String, target: String): String = withContext(Dispatchers.IO) {
        val src = if (source == "auto") "auto" else source
        val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=${src}&tl=${target}&dt=t&q=${URLEncoder.encode(text, "UTF-8")}"
        val request = Request.Builder().url(url)
            // بعض الشبكات/المناطق ترفض الطلب بدون User-Agent شبيه بمتصفح فعلي — عميل OkHttp
            // الافتراضي (okhttp/x.x) أحياناً يُرفض من هذا الـendpoint غير الرسمي.
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36")
            .build()
        val response = client.newCall(request).execute()
        if (!response.isSuccessful) {
            throw IllegalStateException("Google Translate: HTTP ${response.code}")
        }
        val body = response.body?.string() ?: throw IllegalStateException("Google Translate: استجابة فارغة")

        // Parse JSON array response
        val jsonArray = org.json.JSONArray(body)
        val sentences = jsonArray.getJSONArray(0)
        val sb = StringBuilder()
        for (i in 0 until sentences.length()) {
            val sentence = sentences.getJSONArray(i)
            sb.append(sentence.getString(0))
        }
        sb.toString()
    }

    // 3. Gemini
    suspend fun translateGemini(text: String, source: String, target: String, apiKey: String, model: String, systemPrompt: String? = null): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) throw IllegalArgumentException("Gemini: مفتاح API فارغ")
        val targetName = if (target == "ar") "Arabic" else target
        val userPrompt = "Translate this comic text into $targetName naturally. Return only the translation:\n\n$text"
        val prompt = if (systemPrompt.isNullOrBlank()) userPrompt else "$systemPrompt\n\n$userPrompt"
        val jsonBody = JSONObject().apply {
            put("contents", org.json.JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", org.json.JSONArray().apply {
                        put(JSONObject().put("text", prompt))
                    })
                })
            })
        }
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .build()
        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: throw IllegalStateException("Gemini: استجابة فارغة")
        if (!response.isSuccessful) {
            throw IllegalStateException("Gemini: HTTP ${response.code}: ${body.take(200)}")
        }
        val json = JSONObject(body)
        json.getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
            .getString("text").trim()
    }

    // 4. OpenAI — https://api.openai.com/v1/chat/completions
    suspend fun translateOpenAI(text: String, source: String, target: String, apiKey: String, model: String, systemPrompt: String? = null): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) throw IllegalArgumentException("OpenAI: مفتاح API فارغ")
        val targetName = if (target == "ar") "Arabic" else target
        val prompt = "Translate this comic text into $targetName naturally. Return only the translation:\n\n$text"
        val jsonBody = JSONObject().apply {
            put("model", model)
            put("messages", org.json.JSONArray().apply {
                if (!systemPrompt.isNullOrBlank()) {
                    put(JSONObject().apply { put("role", "system"); put("content", systemPrompt) })
                }
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", prompt)
                })
            })
            put("temperature", 0.3)
        }
        val request = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .header("Authorization", "Bearer $apiKey")
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .build()
        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: throw IllegalStateException("OpenAI: استجابة فارغة")
        if (!response.isSuccessful) {
            throw IllegalStateException("OpenAI: HTTP ${response.code}: ${body.take(200)}")
        }
        val json = JSONObject(body)
        json.getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content").trim()
    }

    // بند 8: Local LLM — أي سيرفر متوافق مع تنسيق OpenAI Chat Completions API، بما فيه
    // Ollama (عادة على http://127.0.0.1:11434/v1/chat/completions) وLM Studio (عادة على
    // http://127.0.0.1:1234/v1/chat/completions) وأي سيرفر محلي/شبكي آخر بنفس التنسيق.
    // بعكس translateOpenAI، customApiKey اختياري (Ollama/LM Studio عادة لا يتطلبان مفتاحاً)
    // — يُرسَل رأس Authorization فقط لو المفتاح غير فارغ، حتى لا يرفض بعض السيرفرات المحلية
    // الطلب بسبب رأس غير متوقّع.
    suspend fun translateCustom(
        text: String,
        source: String,
        target: String,
        apiUrl: String,
        apiKey: String,
        model: String,
        systemPrompt: String? = null
    ): String = withContext(Dispatchers.IO) {
        if (apiUrl.isBlank()) throw IllegalArgumentException("Local LLM: رابط API فارغ — أدخل عنوان السيرفر (Ollama/LM Studio) في الإعدادات أولاً")
        if (model.isBlank()) throw IllegalArgumentException("Local LLM: اسم النموذج فارغ")
        val targetName = if (target == "ar") "Arabic" else target
        val userPrompt = "Translate this comic text into $targetName naturally. Return only the translation, with no explanation:\n\n$text"
        val messages = org.json.JSONArray()
        if (!systemPrompt.isNullOrBlank()) {
            messages.put(JSONObject().apply { put("role", "system"); put("content", systemPrompt) })
        }
        messages.put(JSONObject().apply { put("role", "user"); put("content", userPrompt) })
        // 🔍 (2026-08-20، إصلاح بطلب المستخدم) "تكرار تنكسي" (degenerate repetition) — عطل
        // معروف بنماذج LLM المحلية الصغيرة (خصوصاً عبر Ollama/LM Studio) حين لا يوجد سقف
        // صريح لعدد التوكنز: النموذج يستمر بإعادة نفس الجملة عشرات المرات بدل التوقف عند
        // نهاية طبيعية (خصوصاً بـtemperature منخفضة كالمستخدمة هنا 0.3 بدون عقوبة تكرار).
        // الأثر الملحوظ عند المستخدم فعلياً: نص مترجم ضخم يجبر
        // TextRenderer.fitTextToBox على تصغير الخط للحد الأدنى (8px) محاولاً إدخاله
        // بالفقاعة — يظهر كـ"خط صغير جداً ومكرر كثيراً". max_tokens هنا يمنع أغلب الحالات
        // عند المصدر (فقاعة كوميك واحدة لا تحتاج فعلياً أكثر من هذا بأي لغة). راجع أيضاً
        // collapseDegenerateRepetition أسفل كحارس إضافي لخوادم تتجاهل max_tokens فعلياً.
        val jsonBody = JSONObject().apply {
            put("model", model)
            put("messages", messages)
            put("temperature", 0.3)
            put("max_tokens", 500)
        }
        val reqBuilder = Request.Builder()
            .url(apiUrl)
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
        if (apiKey.isNotBlank()) reqBuilder.header("Authorization", "Bearer $apiKey")
        val response = client.newCall(reqBuilder.build()).execute()
        val body = response.body?.string() ?: throw IllegalStateException("Local LLM: استجابة فارغة من السيرفر")
        if (!response.isSuccessful) {
            throw IllegalStateException("Local LLM: HTTP ${response.code}: ${body.take(200)}")
        }
        val json = JSONObject(body)
        val raw = json.getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content").trim()
        collapseDegenerateRepetition(raw)
    }

    // 5. OpenRouter — OpenAI-compatible chat completions endpoint.
    // The model is a provider/model slug such as "openai/gpt-4o-mini" or a :free variant.
    suspend fun translateOpenRouter(text: String, source: String, target: String, apiKey: String, model: String, systemPrompt: String? = null): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) throw IllegalArgumentException("OpenRouter: مفتاح API فارغ")
        val targetName = when (target.lowercase()) {
            "ar" -> "Arabic"
            "en" -> "English"
            else -> target
        }
        val prompt = "Translate this comic text into $targetName naturally. Preserve names, tone, and line meaning. Return only the translation, with no explanation:\n\n$text"
        val jsonBody = JSONObject().apply {
            put("model", model.ifBlank { "openai/gpt-4o-mini" })
            put("messages", org.json.JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "system")
                    put("content", systemPrompt?.takeIf { it.isNotBlank() }
                        ?: "You are a professional comic/manga translator. Translate naturally and concisely.")
                })
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", prompt)
                })
            })
            put("temperature", 0.3)
        }
        val request = Request.Builder()
            .url("https://openrouter.ai/api/v1/chat/completions")
            .header("Authorization", "Bearer $apiKey")
            .header("Content-Type", "application/json")
            .header("X-Title", "Comic Translator")
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .build()
        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: throw IllegalStateException("OpenRouter: استجابة فارغة")
        if (!response.isSuccessful) {
            throw IllegalStateException("OpenRouter: HTTP ${response.code}: ${body.take(200)}")
        }
        val json = JSONObject(body)
        json.getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content").trim()
    }

    // 6. DeepL
    // *** إصلاح: اختيار الـhost كان ثابتاً دائماً على api-free.deepl.com ***
    // مفاتيح DeepL Free تنتهي بـ ":fx" وتعمل فقط مع api-free.deepl.com؛ مفاتيح DeepL Pro لا
    // تحمل هذا اللاحقة وتعمل فقط مع api.deepl.com — استخدام الـhost الخاطئ يرجع 403 Forbidden
    // دائماً لمستخدمي الحسابات المدفوعة (Pro)، فيبدو DeepL "لا يعمل" رغم أن المفتاح صحيح.
    suspend fun translateDeepL(text: String, source: String, target: String, apiKey: String): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) throw IllegalArgumentException("DeepL: مفتاح API فارغ")
        val host = if (apiKey.trim().endsWith(":fx")) "api-free.deepl.com" else "api.deepl.com"
        // DeepL يرفض "EN" المجرّد كـ target_lang منذ فترة (يتطلب EN-US/EN-GB)، لكنه يقبل
        // اللغات الأخرى (مثل AR) بصيغتها المجرّدة بشكل طبيعي.
        val targetLang = if (target.equals("en", ignoreCase = true)) "EN-US" else target.uppercase()
        val body = java.net.URLEncoder.encode("text", "UTF-8") + "=" + java.net.URLEncoder.encode(text, "UTF-8") +
                "&" + java.net.URLEncoder.encode("target_lang", "UTF-8") + "=" + java.net.URLEncoder.encode(targetLang, "UTF-8")
        val request = Request.Builder()
            .url("https://$host/v2/translate")
            .header("Authorization", "DeepL-Auth-Key $apiKey")
            .header("Content-Type", "application/x-www-form-urlencoded")
            .post(body.toRequestBody("application/x-www-form-urlencoded".toMediaType()))
            .build()
        val response = client.newCall(request).execute()
        val resBody = response.body?.string() ?: throw IllegalStateException("DeepL: استجابة فارغة")
        if (!response.isSuccessful) {
            throw IllegalStateException("DeepL: HTTP ${response.code}: ${resBody.take(200)}")
        }
        val json = JSONObject(resBody)
        json.getJSONArray("translations").getJSONObject(0).getString("text")
    }

    // ================= بند 6: ترجمة دفعة كاملة (سياق الصفحة/Batch) =================
    // بدل طلب منفصل لكل فقاعة نص، نرسل كل فقاعات الصفحة المعلّقة بطلب واحد (JSON array
    // نصوص → JSON array ترجمات بنفس الترتيب والعدد بالضبط) — يعطي النموذج سياق الصفحة
    // كاملة (حوار متبادل بين الفقاعات) فيترجم أدق من كل فقاعة بمعزل عن البقية، ويقلّل
    // الطلبات الشبكية من N إلى 1 لكل صفحة. AppInterface.translatePageBlocks يتولى الرجوع
    // التلقائي لفقاعة-فقاعة لو فشل الـbatch (استثناء، أو عدد عناصر الرد لا يطابق المُرسَل).

    /** حارس دفاعي ضد "التكرار التنكسي" (degenerate repetition) — راجع تعليق max_tokens بأعلى
     * translateCustom لسياق العطل الكامل. يبحث عن جملة/سطر واحد يتكرر متتالياً 3 مرات أو
     * أكثر (بعد تقسيم النص على حدود الجمل/الأسطر) ويُبقي نسخة واحدة فقط منه. نصوص قصيرة
     * (أقل من 80 حرفاً — أطول من أي فقاعة كوميك طبيعية تقريباً) تُعاد كما هي بدون فحص، حتى
     * لا نكسر ترجمات مشروعة قصيرة تحتوي تكراراً مقصوداً (مثلاً "لا! لا! لا!" بالأصل). */
    private fun collapseDegenerateRepetition(text: String): String {
        val trimmed = text.trim()
        if (trimmed.length < 80) return trimmed

        val parts = trimmed.split(Regex("(?<=[.!؟?\\n])\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.size < 3) return trimmed

        val result = StringBuilder()
        var i = 0
        while (i < parts.size) {
            var repeatCount = 1
            while (i + repeatCount < parts.size && parts[i + repeatCount] == parts[i]) repeatCount++
            result.append(parts[i])
            if (i + repeatCount < parts.size) result.append(" ")
            i += if (repeatCount >= 3) repeatCount else 1 // تكرار تنكسي واضح (3+) — نتجاوز الباقي، وإلا نتقدم بشكل طبيعي
        }
        return result.toString().trim()
    }

    private fun buildBatchUserPrompt(texts: List<String>, targetName: String): String {
        val itemsJson = org.json.JSONArray(texts).toString()
        return "Translate each string in this JSON array into $targetName naturally, preserving the " +
            "exact original order and array length (${texts.size} items in, ${texts.size} items out). " +
            "These are consecutive text bubbles from the same comic page — use them as context for each " +
            "other (who is speaking to whom, tone continuity across the page) but translate each bubble " +
            "as one separate array item; do not merge bubbles. Return ONLY a raw JSON array of exactly " +
            "${texts.size} translated strings, no markdown fences, no explanation, no extra keys:\n\n$itemsJson"
    }

    /** يفسّر رد النموذج كمصفوفة JSON من الترجمات. يرمي استثناء لو الرد ليس JSON صالحاً أو
     * لو عدد العناصر لا يطابق [expectedSize] بالضبط — الحالتان تعنيان أن الـbatch لم يُطع
     * التعليمات، فالمتصل (AppInterface) يرجع تلقائياً للترجمة فقاعة-فقاعة بدل قبول نتيجة
     * غير موثوقة (مثلاً ترجمات مدمجة في سطر واحد أو بترتيب مختلف). */
    private fun parseBatchResponse(raw: String, expectedSize: Int): List<String> {
        // بعض النماذج تلف الرد بـ```json ... ```رغم التعليمات الصريحة بعدم فعل ذلك.
        var cleaned = raw.trim()
        if (cleaned.startsWith("```")) {
            cleaned = cleaned.removePrefix("```json").removePrefix("```").trim()
            if (cleaned.endsWith("```")) cleaned = cleaned.removeSuffix("```").trim()
        }
        val arr = org.json.JSONArray(cleaned)
        if (arr.length() != expectedSize) {
            throw IllegalStateException("Batch: عدد الترجمات (${arr.length()}) لا يطابق عدد النصوص المُرسَلة ($expectedSize)")
        }
        // نطبّق نفس حارس التكرار التنكسي (راجع collapseDegenerateRepetition) على كل عنصر
        // على حِدة — لو نموذج محلي كرّر فقاعة واحدة بالدفعة، لا نريد أن يفسد ذلك بقية
        // الفقاعات الصحيحة الأخرى بنفس الاستجابة.
        return (0 until arr.length()).map { collapseDegenerateRepetition(arr.getString(it)) }
    }

    /**
     * بند 6: دفعة واحدة لمحركات متوافقة مع تنسيق OpenAI Chat Completions — يشمل هذا openai
     * وopenrouter وcustom (Local LLM) لأن الثلاثة يستخدمون نفس بنية الطلب/الرد بالضبط،
     * ويختلفون فقط بالـendpoint/المفتاح/الرؤوس الإضافية.
     */
    suspend fun translateBatchOpenAIStyle(
        texts: List<String>,
        target: String,
        systemPrompt: String,
        endpointUrl: String,
        apiKey: String,
        model: String,
        extraHeaders: Map<String, String> = emptyMap()
    ): List<String> = withContext(Dispatchers.IO) {
        if (texts.isEmpty()) return@withContext emptyList()
        val targetName = if (target == "ar") "Arabic" else target
        val userPrompt = buildBatchUserPrompt(texts, targetName)
        val messages = org.json.JSONArray().apply {
            put(JSONObject().apply { put("role", "system"); put("content", systemPrompt) })
            put(JSONObject().apply { put("role", "user"); put("content", userPrompt) })
        }
        // max_tokens يتناسب مع عدد الفقاعات بالدفعة (راجع تعليق collapseDegenerateRepetition/
        // max_tokens بـtranslateCustom لسياق مشكلة التكرار التنكسي الكاملة) — ~250 توكن لكل
        // فقاعة كافٍ لأي ترجمة طبيعية، بحد أقصى معقول حتى لا يُقطَع رد مشروع لصفحة كبيرة جداً.
        val maxTokensForBatch = (texts.size * 250).coerceIn(500, 6000)
        val jsonBody = JSONObject().apply {
            put("model", model)
            put("messages", messages)
            put("temperature", 0.3)
            put("max_tokens", maxTokensForBatch)
        }
        val reqBuilder = Request.Builder()
            .url(endpointUrl)
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
        if (apiKey.isNotBlank()) reqBuilder.header("Authorization", "Bearer $apiKey")
        extraHeaders.forEach { (k, v) -> reqBuilder.header(k, v) }
        val response = client.newCall(reqBuilder.build()).execute()
        val body = response.body?.string() ?: throw IllegalStateException("Batch: استجابة فارغة")
        if (!response.isSuccessful) throw IllegalStateException("Batch: HTTP ${response.code}: ${body.take(200)}")
        val json = JSONObject(body)
        val content = json.getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content").trim()
        parseBatchResponse(content, texts.size)
    }

    /** بند 6: دفعة واحدة لـGemini — تنسيق طلب/رد مختلف عن OpenAI (contents/parts بدل
     * messages)، فيحتاج دالة منفصلة بدل إعادة استخدام translateBatchOpenAIStyle. */
    suspend fun translateBatchGemini(
        texts: List<String>,
        target: String,
        systemPrompt: String,
        apiKey: String,
        model: String
    ): List<String> = withContext(Dispatchers.IO) {
        if (texts.isEmpty()) return@withContext emptyList()
        if (apiKey.isBlank()) throw IllegalArgumentException("Gemini: مفتاح API فارغ")
        val targetName = if (target == "ar") "Arabic" else target
        val fullPrompt = "$systemPrompt\n\n${buildBatchUserPrompt(texts, targetName)}"
        val jsonBody = JSONObject().apply {
            put("contents", org.json.JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", org.json.JSONArray().apply { put(JSONObject().put("text", fullPrompt)) })
                })
            })
        }
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .build()
        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: throw IllegalStateException("Gemini Batch: استجابة فارغة")
        if (!response.isSuccessful) throw IllegalStateException("Gemini Batch: HTTP ${response.code}: ${body.take(200)}")
        val json = JSONObject(body)
        val content = json.getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
            .getString("text").trim()
        parseBatchResponse(content, texts.size)
    }
}
