# Comic Translator V14

## إصلاحات رئيسية

### 1. CBZ/ZIP Native
- نقل فك CBZ/ZIP من JavaScript إلى Kotlin باستخدام `ZipInputStream`.
- استخراج الصور فقط إلى `cacheDir/comic_pages`.
- ترتيب طبيعي لأسماء الصفحات.
- حماية من المسارات داخل الأرشيف وعدم السماح بكتابة ملفات خارج cache.
- حد إجمالي 512MB للصور المستخرجة لتجنب استهلاك ذاكرة/مساحة غير منطقي.
- إزالة `cbz-unzip.js` من مسار تطبيق Android وعدم تحميله في `index.html`.

### 2. إزالة Base64 من مدخل OCR
- `startProcessing()` أصبح يستقبل `pageIndex + settingsJson` فقط.
- Android يقرأ ملف الصفحة مباشرة من cache.
- WebView يعرض الصور عبر `https://comic.local/page/<index>` ويخدمها `WebViewClient` من ملفات cache، بدون طلب شبكة حقيقي.

> ملاحظة: Base64 الذي قد يظهر في نتائج `OpenCV/AI` هو ناتج صورة الصفحة المعالجة، وليس مدخل CBZ/OCR.

### 3. OpenRouter
- إضافة محرك ترجمة `openrouter`.
- إضافة حقل مفتاح OpenRouter في الإعدادات.
- إضافة حقل model slug.
- استخدام `POST https://openrouter.ai/api/v1/chat/completions` مع Bearer token.
- الإعداد الافتراضي: `openai/gpt-4o-mini`.

### 4. الإصدار
- versionCode: 13
- versionName: 1.3.0

## التحقق المحلي
- JavaScript syntax: OK.
- Android XML parsing: OK.
- Structural checks لـ AppInterface: OK.
- لا يمكن تنفيذ Gradle/Android SDK داخل بيئة العمل الحالية لعدم توفر SDK/Gradle المحليين.


## V14 completion pass

- Removed the remaining `imageBase64` full-page result path from Native erasure.
- `ErasureEngine.processBitmap()` now returns `Bitmap?`; `AppInterface` caches it and sends `processedUrl`.
- `MainActivity` serves processed pages through `comic.local/processed/<index>`.
- `index.html` now renders `processedUrl`.
- Removed all Android-app references to `CBZUnzip` / `cbz-unzip.js`.
- Fixed the Paddle dependency: `paddleocr4android:v1.2.0` is the Paddle-Lite artifact; v1.2.9 belongs to the separate FastDeploy artifact.
- GitHub Actions now prepares real official Paddle-Lite `.nb` models and the matching PaddleOCR dictionary before Gradle build.
- Added Paddle DET/REC/CLS entries to the models UI as bundled components.
