package com.comictrans.model

data class SettingsData(
    val ocrEngine: String = "mlkit",
    val erasureMode: String = "opencv",
    val translateEngine: String = "google",
    val sourceLang: String = "auto",  // "auto" for auto-detect
    val targetLang: String = "ar",
    val useMemory: Boolean = true,
    val enhanceImage: Boolean = false,
    val enhanceMethod: String = "opencv",
    val ocrSpaceKey: String = "",
    val cloudApiUrl: String = "",
    val geminiKey: String = "",
    val geminiModel: String = "gemini-2.0-flash",
    val openaiKey: String = "",
    val openaiModel: String = "gpt-4o-mini",
    val deeplKey: String = "",
    val fontFamily: String = "system-ui, sans-serif",
    val fontSizeScale: Float = 1.0f,
    val lineSpacingScale: Float = 1.0f,
    val textWidthRatio: Float = 0.9f,
    val textColor: String = "#000000",
    val textBackground: String = "none",
    val smartSizing: Boolean = true,  // Auto-fit font to bubble
    val useCommunityTranslations: Boolean = true  // Share/find community translations
)
