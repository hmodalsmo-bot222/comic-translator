package com.comictrans.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.util.Log
import com.comictrans.model.BlockData
import org.json.JSONObject
import org.opencv.android.Utils
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import org.tensorflow.lite.Interpreter
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

class ErasureEngine(private val context: Context) {

    private val TAG = "ErasureEngine"

    // ====== 1. OpenCV Inpaint — سريع وخفيف (الافتراضي) ======
    fun inpaintOpenCV(bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        return try {
            val srcMat = Mat()
            Utils.bitmapToMat(bitmap, srcMat)

            val maskMat = Mat.zeros(srcMat.size(), CvType.CV_8UC1)
            for (block in blocks) {
                val x1 = (block.x - 3).coerceIn(0, bitmap.width - 1)
                val y1 = (block.y - 3).coerceIn(0, bitmap.height - 1)
                val x2 = (block.x + block.width + 3).coerceIn(0, bitmap.width)
                val y2 = (block.y + block.height + 3).coerceIn(0, bitmap.height)
                Imgproc.rectangle(maskMat, Point(x1.toDouble(), y1.toDouble()), 
                    Point(x2.toDouble(), y2.toDouble()), Scalar(255.0), -1)
            }

            val dilatedMask = Mat()
            Imgproc.dilate(maskMat, dilatedMask, Mat(), Point(-1.0, -1.0), 2)

            val resultMat = Mat()
            Photo.inpaint(srcMat, dilatedMask, resultMat, 3.0, Photo.INPAINT_TELEA)

            val result = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(resultMat, result)

            srcMat.release(); maskMat.release(); dilatedMask.release(); resultMat.release()
            result
        } catch (e: Exception) {
            Log.e(TAG, "OpenCV inpaint failed", e)
            fallbackErase(bitmap, blocks)
        }
    }

    // ====== 2. LaMa ONNX — أفضل جودة ======
    fun inpaintLaMa(bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val modelFile = File(context.getExternalFilesDir(null), "models/lama.onnx")
        if (!modelFile.exists()) {
            Log.w(TAG, "LaMa model not found at ${modelFile.absolutePath} — falling back to OpenCV")
            return inpaintOpenCV(bitmap, blocks)
        }

        var env: OrtEnvironment? = null
        var session: OrtSession? = null
        return try {
            env = OrtEnvironment.getEnvironment()
            val sessionOptions = OrtSession.SessionOptions().apply {
                setIntraOpNumThreads(2)
                setInterOpNumThreads(2)
            }
            session = env.createSession(modelFile.absolutePath, sessionOptions)

            val modelInputSize = 512
            val inputBitmap = Bitmap.createScaledBitmap(bitmap, modelInputSize, modelInputSize, true)

            // Image [1, 3, H, W] NCHW
            val imgBuffer = ByteBuffer.allocateDirect(4 * 3 * modelInputSize * modelInputSize)
                .order(ByteOrder.nativeOrder())
            val pixels = IntArray(modelInputSize * modelInputSize)
            inputBitmap.getPixels(pixels, 0, modelInputSize, 0, 0, modelInputSize, modelInputSize)
            for (c in 0 until 3) {
                for (y in 0 until modelInputSize) {
                    for (x in 0 until modelInputSize) {
                        val p = pixels[y * modelInputSize + x]
                        val v = when (c) {
                            0 -> ((p shr 16) and 0xFF) / 255f
                            1 -> ((p shr 8) and 0xFF) / 255f
                            2 -> (p and 0xFF) / 255f
                            else -> 0f
                        }
                        imgBuffer.putFloat(v)
                    }
                }
            }
            imgBuffer.rewind()

            // Mask [1, 1, H, W]
            val maskBuffer = ByteBuffer.allocateDirect(4 * 1 * modelInputSize * modelInputSize)
                .order(ByteOrder.nativeOrder())
            val scaleX = modelInputSize.toFloat() / bitmap.width
            val scaleY = modelInputSize.toFloat() / bitmap.height
            for (y in 0 until modelInputSize) {
                for (x in 0 until modelInputSize) {
                    var inMask = false
                    for (block in blocks) {
                        val bx1 = (block.x * scaleX).toInt()
                        val by1 = (block.y * scaleY).toInt()
                        val bx2 = ((block.x + block.width) * scaleX).toInt()
                        val by2 = ((block.y + block.height) * scaleY).toInt()
                        if (x in bx1..bx2 && y in by1..by2) { inMask = true; break }
                    }
                    maskBuffer.putFloat(if (inMask) 1f else 0f)
                }
            }
            maskBuffer.rewind()

            val imgShape = longArrayOf(1, 3, modelInputSize.toLong(), modelInputSize.toLong())
            val maskShape = longArrayOf(1, 1, modelInputSize.toLong(), modelInputSize.toLong())
            val imgTensor = OnnxTensor.createTensor(env, imgBuffer, imgShape)
            val maskTensor = OnnxTensor.createTensor(env, maskBuffer, maskShape)

            val inputs = mapOf("image" to imgTensor, "mask" to maskTensor)
            val results = session.run(inputs)
            val outputTensor = results[0]
            val outputBuffer = outputTensor.value as java.nio.FloatBuffer

            val outPixels = IntArray(modelInputSize * modelInputSize)
            for (y in 0 until modelInputSize) {
                for (x in 0 until modelInputSize) {
                    val idx = y * modelInputSize + x
                    val r = (outputBuffer.get(idx) * 255f).toInt().coerceIn(0, 255)
                    val g = (outputBuffer.get(idx + modelInputSize * modelInputSize) * 255f).toInt().coerceIn(0, 255)
                    val b = (outputBuffer.get(idx + 2 * modelInputSize * modelInputSize) * 255f).toInt().coerceIn(0, 255)
                    outPixels[y * modelInputSize + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                }
            }

            val resultBitmap = Bitmap.createBitmap(modelInputSize, modelInputSize, Bitmap.Config.ARGB_8888)
            resultBitmap.setPixels(outPixels, 0, modelInputSize, 0, 0, modelInputSize, modelInputSize)
            val finalBitmap = Bitmap.createScaledBitmap(resultBitmap, bitmap.width, bitmap.height, true)

            imgTensor.close(); maskTensor.close(); results.close()
            Log.d(TAG, "LaMa inpaint completed: ${bitmap.width}x${bitmap.height}")
            finalBitmap
        } catch (e: Exception) {
            Log.e(TAG, "LaMa inpaint failed", e)
            inpaintOpenCV(bitmap, blocks)
        } finally {
            session?.close(); env?.close()
        }
    }

    // ====== 3. AOT-GAN TFLite — خفيف وسريع ======
    fun inpaintAOTGAN(bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val modelFile = File(context.getExternalFilesDir(null), "models/aotgan.tflite")
        if (!modelFile.exists()) {
            Log.w(TAG, "AOT-GAN model not found at ${modelFile.absolutePath} — falling back to OpenCV")
            return inpaintOpenCV(bitmap, blocks)
        }

        var interpreter: Interpreter? = null
        return try {
            interpreter = Interpreter(loadModelFile(modelFile))

            val modelInputSize = 256
            val inputBitmap = Bitmap.createScaledBitmap(bitmap, modelInputSize, modelInputSize, true)

            // Image [1, H, W, 3] NHWC
            val imgBuffer = ByteBuffer.allocateDirect(4 * modelInputSize * modelInputSize * 3)
                .order(ByteOrder.nativeOrder())
            val pixels = IntArray(modelInputSize * modelInputSize)
            inputBitmap.getPixels(pixels, 0, modelInputSize, 0, 0, modelInputSize, modelInputSize)
            for (p in pixels) {
                imgBuffer.putFloat(((p shr 16) and 0xFF) / 255f)
                imgBuffer.putFloat(((p shr 8) and 0xFF) / 255f)
                imgBuffer.putFloat((p and 0xFF) / 255f)
            }
            imgBuffer.rewind()

            // Mask [1, H, W, 1]
            val maskBuffer = ByteBuffer.allocateDirect(4 * modelInputSize * modelInputSize * 1)
                .order(ByteOrder.nativeOrder())
            val scaleX = modelInputSize.toFloat() / bitmap.width
            val scaleY = modelInputSize.toFloat() / bitmap.height
            for (y in 0 until modelInputSize) {
                for (x in 0 until modelInputSize) {
                    var inMask = false
                    for (block in blocks) {
                        val bx1 = (block.x * scaleX).toInt()
                        val by1 = (block.y * scaleY).toInt()
                        val bx2 = ((block.x + block.width) * scaleX).toInt()
                        val by2 = ((block.y + block.height) * scaleY).toInt()
                        if (x in bx1..bx2 && y in by1..by2) { inMask = true; break }
                    }
                    maskBuffer.putFloat(if (inMask) 1f else 0f)
                }
            }
            maskBuffer.rewind()

            interpreter.resizeInput(0, intArrayOf(1, modelInputSize, modelInputSize, 3))
            interpreter.resizeInput(1, intArrayOf(1, modelInputSize, modelInputSize, 1))
            interpreter.allocateTensors()

            val outputBuffer = ByteBuffer.allocateDirect(4 * modelInputSize * modelInputSize * 3)
                .order(ByteOrder.nativeOrder())

            interpreter.runForMultipleInputsOutputs(
                arrayOf(imgBuffer, maskBuffer),
                mapOf(0 to outputBuffer)
            )

            outputBuffer.rewind()
            val outPixels = IntArray(modelInputSize * modelInputSize)
            for (i in outPixels.indices) {
                val r = (outputBuffer.float * 255f).toInt().coerceIn(0, 255)
                val g = (outputBuffer.float * 255f).toInt().coerceIn(0, 255)
                val b = (outputBuffer.float * 255f).toInt().coerceIn(0, 255)
                outPixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
            val resultBitmap = Bitmap.createBitmap(modelInputSize, modelInputSize, Bitmap.Config.ARGB_8888)
            resultBitmap.setPixels(outPixels, 0, modelInputSize, 0, 0, modelInputSize, modelInputSize)
            val finalBitmap = Bitmap.createScaledBitmap(resultBitmap, bitmap.width, bitmap.height, true)

            Log.d(TAG, "AOT-GAN inpaint completed: ${bitmap.width}x${bitmap.height}")
            finalBitmap
        } catch (e: Exception) {
            Log.e(TAG, "AOT-GAN inpaint failed", e)
            inpaintOpenCV(bitmap, blocks)
        } finally {
            try { interpreter?.close() } catch (_: Exception) {}
        }
    }

    // Main entry point — supports 3 models
    fun processBlocks(bitmap: Bitmap, blocks: List<BlockData>, mode: String): List<JSONObject> {
        val resultBitmap = when (mode) {
            "lama" -> inpaintLaMa(bitmap, blocks)
            "aotgan" -> inpaintAOTGAN(bitmap, blocks)
            "opencv" -> inpaintOpenCV(bitmap, blocks)
            else -> inpaintOpenCV(bitmap, blocks)
        }
        return listOf(JSONObject().apply {
            put("mode", mode)
            put("type", "full_page")
            put("imageBase64", bitmapToBase64(resultBitmap))
        })
    }

    private fun fallbackErase(bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val result = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)
        val paint = Paint().apply { color = Color.WHITE }
        for (block in blocks) {
            canvas.drawRect(Rect(block.x, block.y, block.x + block.width, block.y + block.height), paint)
        }
        return result
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val stream = java.io.ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 92, stream)
        val bytes = stream.toByteArray()
        return "data:image/jpeg;base64," + android.util.Base64.encodeToString(bytes, android.util.Base64.DEFAULT)
    }

    private fun loadModelFile(file: File): MappedByteBuffer {
        val stream = FileInputStream(file)
        val channel = stream.channel
        return channel.map(FileChannel.MapMode.READ_ONLY, 0, file.length())
    }
}
