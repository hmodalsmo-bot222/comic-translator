package com.comictrans.engine

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import org.opencv.android.Utils
import org.opencv.core.Mat
import org.opencv.imgproc.Imgproc
import org.tensorflow.lite.Interpreter
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

/**
 * محرك تعزيز الصورة قبل OCR.
 *
 * وضعان:
 *  - "opencv": تحسين كلاسيكي (CLAHE + شحذ خفيف) — يعمل فوراً.
 *  - "ai": Real-ESRGAN x2 عبر TFLite — يحتاج ملف النموذج.
 */
class ImageEnhanceEngine(private val context: Context) {

    private val TAG = "ImageEnhance"

    data class EnhanceResult(val bitmap: Bitmap, val scale: Float)

    fun enhance(bitmap: Bitmap, method: String): EnhanceResult {
        return when (method) {
            "ai" -> tryAIEnhance(bitmap) ?: run {
                Log.w(TAG, "نموذج Real-ESRGAN غير موجود — رجوع لتحسين OpenCV")
                EnhanceResult(enhanceOpenCV(bitmap), 1f)
            }
            else -> EnhanceResult(enhanceOpenCV(bitmap), 1f)
        }
    }

    // ====== تحسين OpenCV كلاسيكي ======
    private fun enhanceOpenCV(bitmap: Bitmap): Bitmap {
        return try {
            val src = Mat()
            Utils.bitmapToMat(bitmap, src)

            val lab = Mat()
            Imgproc.cvtColor(src, lab, Imgproc.COLOR_RGBA2RGB)
            Imgproc.cvtColor(lab, lab, Imgproc.COLOR_RGB2Lab)

            val channels = ArrayList<Mat>()
            org.opencv.core.Core.split(lab, channels)

            val clahe = Imgproc.createCLAHE(2.5, org.opencv.core.Size(8.0, 8.0))
            val enhancedL = Mat()
            clahe.apply(channels[0], enhancedL)
            enhancedL.copyTo(channels[0])

            org.opencv.core.Core.merge(channels, lab)
            val enhancedRgb = Mat()
            Imgproc.cvtColor(lab, enhancedRgb, Imgproc.COLOR_Lab2RGB)

            val blurred = Mat()
            Imgproc.GaussianBlur(enhancedRgb, blurred, org.opencv.core.Size(0.0, 0.0), 3.0)
            val sharpened = Mat()
            org.opencv.core.Core.addWeighted(enhancedRgb, 1.5, blurred, -0.5, 0.0, sharpened)

            val result = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(sharpened, result)

            src.release(); lab.release(); enhancedL.release(); enhancedRgb.release()
            blurred.release(); sharpened.release()
            channels.forEach { it.release() }

            result
        } catch (e: Exception) {
            Log.e(TAG, "فشل تحسين OpenCV — رجعنا الصورة الأصلية", e)
            bitmap
        }
    }

    // ====== Real-ESRGAN x2 عبر TFLite ======
    private val MODEL_SCALE = 2

    private fun modelFile(): File =
        File(context.getExternalFilesDir(null), "models/realesrgan-x2.tflite")

    private fun tryAIEnhance(bitmap: Bitmap): EnhanceResult? {
        val file = modelFile()
        if (!file.exists()) return null

        var interpreter: Interpreter? = null
        return try {
            interpreter = Interpreter(loadModelFile(file))

            val w = bitmap.width; val h = bitmap.height
            interpreter.resizeInput(0, intArrayOf(1, h, w, 3))
            interpreter.allocateTensors()

            val inputBuffer = ByteBuffer.allocateDirect(4 * h * w * 3).order(ByteOrder.nativeOrder())
            val pixels = IntArray(w * h)
            bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
            for (p in pixels) {
                inputBuffer.putFloat(((p shr 16) and 0xFF).toFloat())
                inputBuffer.putFloat(((p shr 8) and 0xFF).toFloat())
                inputBuffer.putFloat((p and 0xFF).toFloat())
            }
            inputBuffer.rewind()

            val outW = w * MODEL_SCALE; val outH = h * MODEL_SCALE
            val outputBuffer = ByteBuffer.allocateDirect(4 * outH * outW * 3).order(ByteOrder.nativeOrder())

            interpreter.run(inputBuffer, outputBuffer)

            outputBuffer.rewind()
            val outPixels = IntArray(outW * outH)
            for (i in outPixels.indices) {
                val r = outputBuffer.float.coerceIn(0f, 255f).toInt()
                val g = outputBuffer.float.coerceIn(0f, 255f).toInt()
                val b = outputBuffer.float.coerceIn(0f, 255f).toInt()
                outPixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
            val outBitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
            outBitmap.setPixels(outPixels, 0, outW, 0, 0, outW, outH)

            Log.d(TAG, "Real-ESRGAN: ${w}x${h} → ${outW}x${outH}")
            EnhanceResult(outBitmap, MODEL_SCALE.toFloat())
        } catch (e: Exception) {
            Log.e(TAG, "فشل Real-ESRGAN — رجوع لتحسين OpenCV", e)
            null
        } finally {
            // FIX: Always close interpreter
            try { interpreter?.close() } catch (_: Exception) {}
        }
    }

    private fun loadModelFile(file: File): MappedByteBuffer {
        val stream = FileInputStream(file)
        val channel = stream.channel
        return channel.map(FileChannel.MapMode.READ_ONLY, 0, file.length())
    }
}
