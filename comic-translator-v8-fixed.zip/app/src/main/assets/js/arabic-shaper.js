// ====== ARABIC TEXT SHAPING ======
// تحويل الحروف العربية المنفصلة إلى متصلة للـ Canvas

const ARABIC_CHARS = {
  // Basic Arabic letters with their forms: [isolated, final, initial, medial]
  'ا': ['ﺍ', 'ﺎ', 'ﺍ', 'ﺎ'],
  'ب': ['ﺏ', 'ﺐ', 'ﺑ', 'ﺒ'],
  'ت': ['ﺕ', 'ﺖ', 'ﺗ', 'ﺘ'],
  'ث': ['ﺙ', 'ﺚ', 'ﺛ', 'ﺜ'],
  'ج': ['ﺝ', 'ﺞ', 'ﺟ', 'ﺠ'],
  'ح': ['ﺡ', 'ﺢ', 'ﺣ', 'ﺤ'],
  'خ': ['ﺥ', 'ﺦ', 'ﺧ', 'ﺨ'],
  'د': ['ﺩ', 'ﺪ', 'ﺩ', 'ﺪ'],
  'ذ': ['ﺫ', 'ﺬ', 'ﺫ', 'ﺬ'],
  'ر': ['ﺭ', 'ﺮ', 'ﺭ', 'ﺮ'],
  'ز': ['ﺯ', 'ﺰ', 'ﺯ', 'ﺰ'],
  'س': ['ﺱ', 'ﺲ', 'ﺳ', 'ﺴ'],
  'ش': ['ﺵ', 'ﺶ', 'ﺷ', 'ﺸ'],
  'ص': ['ﺹ', 'ﺺ', 'ﺻ', 'ﺼ'],
  'ض': ['ﺽ', 'ﺾ', 'ﺿ', 'ﻀ'],
  'ط': ['ﻁ', 'ﻂ', 'ﻃ', 'ﻄ'],
  'ظ': ['ﻅ', 'ﻆ', 'ﻇ', 'ﻈ'],
  'ع': ['ﻉ', 'ﻊ', 'ﻋ', 'ﻌ'],
  'غ': ['ﻍ', 'ﻎ', 'ﻏ', 'ﻐ'],
  'ف': ['ﻑ', 'ﻒ', 'ﻓ', 'ﻔ'],
  'ق': ['ﻕ', 'ﻖ', 'ﻗ', 'ﻘ'],
  'ك': ['ﻙ', 'ﻚ', 'ﻛ', 'ﻜ'],
  'ل': ['ﻝ', 'ﻞ', 'ﻟ', 'ﻠ'],
  'م': ['ﻡ', 'ﻢ', 'ﻣ', 'ﻤ'],
  'ن': ['ﻥ', 'ﻦ', 'ﻧ', 'ﻨ'],
  'ه': ['ﻩ', 'ﻪ', 'ﻫ', 'ﻬ'],
  'و': ['ﻭ', 'ﻮ', 'ﻭ', 'ﻮ'],
  'ي': ['ﻯ', 'ﻰ', 'ﻱ', 'ﻲ'],
  'ى': ['ﻯ', 'ﻰ', 'ﻯ', 'ﻰ'],
  'ء': ['ﺀ', 'ﺀ', 'ﺀ', 'ﺀ'],
  'ئ': ['ﺋ', 'ﺌ', 'ﺋ', 'ﺌ'],
  'ؤ': ['ﺅ', 'ﺆ', 'ﺅ', 'ﺆ'],
  'إ': ['ﺇ', 'ﺈ', 'ﺇ', 'ﺈ'],
  'أ': ['ﺃ', 'ﺄ', 'ﺃ', 'ﺄ'],
  'آ': ['ﺁ', 'ﺂ', 'ﺁ', 'ﺂ'],
  'ة': ['ﺓ', 'ﺔ', 'ﺓ', 'ﺔ'],
  'لآ': ['ﻵ', 'ﻶ', 'ﻵ', 'ﻶ'],
  'لأ': ['ﻷ', 'ﻸ', 'ﻷ', 'ﻸ'],
  'لإ': ['ﻹ', 'ﻺ', 'ﻹ', 'ﻺ'],
  'لا': ['ﻻ', 'ﻼ', 'ﻻ', 'ﻼ'],
};

const CONNECTORS = new Set([
  'ب','ت','ث','ج','ح','خ','س','ش','ص','ض','ط','ظ','ع','غ','ف','ق','ك','ل','م','ن','ه','ي','ى','ئ'
]);

function isArabicChar(ch) {
  return /[؀-ۿ]/.test(ch);
}

function shapeArabic(text) {
  if (!text) return text;
  const chars = text.split('');
  const result = [];

  for (let i = 0; i < chars.length; i++) {
    const ch = chars[i];
    if (!ARABIC_CHARS[ch]) {
      result.push(ch);
      continue;
    }

    const prevConnects = i > 0 && CONNECTORS.has(chars[i - 1]);
    const nextIsArabic = i < chars.length - 1 && isArabicChar(chars[i + 1]);

    let form = 0; // isolated
    if (prevConnects && nextIsArabic) form = 3; // medial
    else if (prevConnects) form = 1; // final
    else if (nextIsArabic) form = 2; // initial

    result.push(ARABIC_CHARS[ch][form]);
  }

  return result.join('');
}

// Reverse Arabic text for proper RTL rendering in Canvas
function prepareArabicForCanvas(text) {
  if (!text) return text;
  // 1. Shape the text
  const shaped = shapeArabic(text);
  // 2. Reverse word order (but keep words intact)
  const words = shaped.split(/(\s+)/);
  const reversed = words.reverse().join('');
  return reversed;
}

// Export for use
window.ArabicShaper = {
  shape: shapeArabic,
  prepareForCanvas: prepareArabicForCanvas,
  isArabic: (text) => /[؀-ۿ]/.test(text)
};
