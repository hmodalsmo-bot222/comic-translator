#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PADDLE_DIR="$ROOT/app/.paddle"
PADDLE_ROOT="$PADDLE_DIR/inference_lite_lib.android.armv8"
ASSETS="$ROOT/app/src/main/assets/paddle"

mkdir -p "$PADDLE_DIR" "$ASSETS"

have_runtime() {
  test -s "$PADDLE_ROOT/cxx/include/paddle_api.h" &&
  test -s "$PADDLE_ROOT/cxx/lib/libpaddle_light_api_shared.so"
}

if ! have_runtime; then
  echo "Paddle-Lite runtime missing; resolving the official v2.10 ARMv8 release asset..."

  asset_name="inference_lite_lib.android.armv8.gcc.c++_shared.with_extra.with_cv.tar.gz"
  api_url="https://api.github.com/repos/PaddlePaddle/Paddle-Lite/releases/tags/v2.10"

  if command -v gh >/dev/null 2>&1; then
    asset_url="$(gh api "$api_url" --jq ".assets[] | select(.name == \"$asset_name\") | .browser_download_url" | head -n 1)"
  else
    asset_url="$(curl -fsSL --retry 8 --retry-all-errors \
      -H 'Accept: application/vnd.github+json' \
      -H 'X-GitHub-Api-Version: 2022-11-28' "$api_url" |
      python3 -c 'import json,sys; d=json.load(sys.stdin); n="inference_lite_lib.android.armv8.gcc.c++_shared.with_extra.with_cv.tar.gz"; print(next(a["browser_download_url"] for a in d["assets"] if a["name"]==n))')"
  fi

  test -n "$asset_url"
  archive="$PADDLE_DIR/$asset_name"

  curl -fL --retry 10 --retry-all-errors --retry-delay 3 \
    --connect-timeout 30 --max-time 1200 \
    -o "$archive" "$asset_url"

  test -s "$archive"
  tar -tzf "$archive" >/dev/null

  rm -rf "$PADDLE_ROOT"
  tar -xzf "$archive" -C "$PADDLE_DIR"
  rm -f "$archive"
fi

# The official PaddleOCR docs require the PP-OCRv2 slim .nb models with Paddle-Lite 2.10.
download_model() {
  local url="$1"
  local dest="$2"
  if test ! -s "$dest"; then
    curl -fL --retry 10 --retry-all-errors --retry-delay 2 \
      --connect-timeout 30 --max-time 1200 -o "$dest" "$url"
  fi
  test -s "$dest"
}

download_model \
  "https://paddleocr.bj.bcebos.com/PP-OCRv2/lite/ch_PP-OCRv2_det_slim_opt.nb" \
  "$ASSETS/det.nb"

download_model \
  "https://paddleocr.bj.bcebos.com/PP-OCRv2/lite/ch_PP-OCRv2_rec_slim_opt.nb" \
  "$ASSETS/rec.nb"

download_model \
  "https://paddleocr.bj.bcebos.com/PP-OCRv2/lite/ch_ppocr_mobile_v2.0_cls_slim_opt.nb" \
  "$ASSETS/cls.nb"

download_model \
  "https://raw.githubusercontent.com/PaddlePaddle/PaddleOCR/main/ppocr/utils/ppocr_keys_v1.txt" \
  "$ASSETS/ppocr_keys_v1.txt"

test -s "$PADDLE_ROOT/cxx/include/paddle_api.h"
test -s "$PADDLE_ROOT/cxx/lib/libpaddle_light_api_shared.so"
test -s "$ASSETS/det.nb"
test -s "$ASSETS/rec.nb"
test -s "$ASSETS/cls.nb"
test -s "$ASSETS/ppocr_keys_v1.txt"

echo "Paddle assets ready:"
ls -lh "$PADDLE_ROOT/cxx/include/paddle_api.h" \
       "$PADDLE_ROOT/cxx/lib/libpaddle_light_api_shared.so" \
       "$ASSETS/det.nb" "$ASSETS/rec.nb" "$ASSETS/cls.nb" "$ASSETS/ppocr_keys_v1.txt"
