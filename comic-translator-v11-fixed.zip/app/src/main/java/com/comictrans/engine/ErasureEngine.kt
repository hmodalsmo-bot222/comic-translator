package com.comictrans.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.util.Log
import com.comictrans.model.BlockData
import org.json.JSONObject
import org.opencv.android.Utils
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo
import org.tensorflow.lite.Interpreter
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

// حجم مُدخل نموذج LaMa (ONNX من Carve/LaMa-ONNX، ونفترض نفس المقاس لـ TFLite ما لم
// يوفّر المستخدم نموذجاً بمقاس مختلف — راجع ModelManager.kt لتفاصيل مصدر النموذج).
private const val MODEL_INPUT_SIZE = 512

class ErasureEngine(
    private val context: Context,
    private val modelManager: ModelManager
) {

    private val TAG = "ErasureEngine"

    // OpenCV Inpaint — works now if OpenCV is loaded
    fun inpaintOpenCV(bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        return try {
            // Convert Bitmap to Mat
            val srcMat = Mat()
            Utils.bitmapToMat(bitmap, srcMat)

            // Create mask (black image, white where text is)
            val maskMat = Mat.zeros(srcMat.size(), CvType.CV_8UC1)
            for (block in blocks) {
                val x1 = block.x.coerceIn(0, bitmap.width - 1)
                val y1 = block.y.coerceIn(0, bitmap.height - 1)
                val x2 = (block.x + block.width).coerceIn(0, bitmap.width)
                val y2 = (block.y + block.height).coerceIn(0, bitmap.height)
                Imgproc.rectangle(
                    maskMat,
                    Point(x1.toDouble(), y1.toDouble()),
                    Point(x2.toDouble(), y2.toDouble()),
                    Scalar(255.0), // White = inpaint this area
                    -1 // Filled
                )
            }

            // Inpaint using Telea algorithm
            val resultMat = Mat()
            Photo.inpaint(srcMat, maskMat, resultMat, 3.0, Photo.INPAINT_TELEA)

            // Convert back to Bitmap
            val resultBitmap = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(resultMat, resultBitmap)

            // Release mats
            srcMat.release()
            maskMat.release()
            resultMat.release()

            resultBitmap
        } catch (e: Exception) {
            Log.e(TAG, "OpenCV inpaint failed", e)
            // Fallback: return original with white boxes
            fallbackErase(bitmap, blocks)
        }
    }

    // AI Lite (TFLite) — يتطلب نموذج .tflite محمّل مسبقاً عبر قائمة النماذج (ModelManager).
    // نفترض نفس بنية مُدخلات/مُخرجات LaMa الموثّقة (صورة + قناع → صورة)، وهي البنية الشائعة
    // لنماذج inpainting المُصدَّرة لـ TFLite. لو المستخدم زوّد نموذجاً ببنية مختلفة، سيفشل
    // التنفيذ بخطأ واضح ونرجع تلقائياً لـ OpenCV بدل تعطّل التطبيق.
    fun inpaintTFLite(bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val model = modelManager.availableModels.find { it.id == "ai_lite" }
        if (model == null || !modelManager.isDownloaded(model)) {
            Log.w(TAG, "AI Lite model not downloaded — falling back to OpenCV")
            return inpaintOpenCV(bitmap, blocks)
        }
        return try {
            val tfliteModel = loadModelFile(modelManager.modelFile(model).absolutePath)
            val interpreter = Interpreter(tfliteModel)
            val result = inpaintPerBlockTFLite(interpreter, bitmap, blocks)
            interpreter.close()
            result
        } catch (e: Exception) {
            Log.e(TAG, "TFLite inpaint failed — falling back to OpenCV", e)
            inpaintOpenCV(bitmap, blocks)
        }
    }

    // AI Pro (ONNX) — يتطلب نموذج .onnx محمّل مسبقاً (افتراضياً LaMa من Carve/LaMa-ONNX،
    // انظر ModelManager.kt). المُدخلات: image float32[1,3,512,512] RGB مقسومة على 255،
    // mask float32[1,1,512,512] (1=امسح النص، 0=أبقِ). المُخرج: صورة RGB جاهزة [0..255].
    fun inpaintONNX(bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val model = modelManager.availableModels.find { it.id == "ai_pro" }
        if (model == null || !modelManager.isDownloaded(model)) {
            Log.w(TAG, "AI Pro model not downloaded — falling back to OpenCV")
            return inpaintOpenCV(bitmap, blocks)
        }
        var env: OrtEnvironment? = null
        var session: OrtSession? = null
        return try {
            env = OrtEnvironment.getEnvironment()
            session = env.createSession(modelManager.modelFile(model).absolutePath, OrtSession.SessionOptions())
            val result = inpaintPerBlockONNX(env, session, bitmap, blocks)
            result
        } catch (e: Exception) {
            Log.e(TAG, "ONNX inpaint failed — falling back to OpenCV", e)
            inpaintOpenCV(bitmap, blocks)
        } finally {
            try { session?.close() } catch (_: Exception) {}
        }
    }

    // ============ منطق مشترك: نقصّ حول كل فقاعة نص (مع هامش سياق)، نصغّر القصاصة
    // لمقاس مُدخل النموذج، نشغّل الاستدلال، ثم نعيد النتيجة لمقاسها الأصلي ونلصقها
    // في مكانها بالصورة الكاملة — بدل تصغير الصفحة كاملة لـ 512×512 (جودة أفضل بكثير
    // لصفحة كومك كاملة الدقة، وأقرب لكيفية عمل تطبيقات الترجمة الاحترافية) ============

    private fun paddedCropRect(block: BlockData, bmpW: Int, bmpH: Int): Rect {
        val padX = (block.width * 0.4f).toInt().coerceAtLeast(16)
        val padY = (block.height * 0.4f).toInt().coerceAtLeast(16)
        val x1 = (block.x - padX).coerceIn(0, bmpW - 1)
        val y1 = (block.y - padY).coerceIn(0, bmpH - 1)
        val x2 = (block.x + block.width + padX).coerceIn(x1 + 1, bmpW)
        val y2 = (block.y + block.height + padY).coerceIn(y1 + 1, bmpH)
        return Rect(x1, y1, x2, y2)
    }

    // مصفوفة float NCHW [1,3,S,S] RGB/255 من قصاصة مُصغّرة لمقاس النموذج
    private fun cropToNCHWFloatArray(bitmap: Bitmap, crop: Rect, size: Int): FloatArray {
        val cropped = Bitmap.createBitmap(bitmap, crop.left, crop.top, crop.width(), crop.height())
        val resized = Bitmap.createScaledBitmap(cropped, size, size, true)
        val pixels = IntArray(size * size)
        resized.getPixels(pixels, 0, size, 0, 0, size, size)
        val out = FloatArray(3 * size * size)
        val plane = size * size
        for (i in 0 until plane) {
            val p = pixels[i]
            out[i] = ((p shr 16) and 0xFF) / 255f            // R
            out[plane + i] = ((p shr 8) and 0xFF) / 255f      // G
            out[2 * plane + i] = (p and 0xFF) / 255f          // B
        }
        if (cropped !== bitmap) cropped.recycle()
        resized.recycle()
        return out
    }

    // قناع [1,1,S,S]: 1.0 داخل مستطيل الفقاعة الأصلي (بعد تحويله لمقاس القصاصة المُصغّرة)، 0 خارجه
    private fun blockMaskFloatArray(block: BlockData, crop: Rect, size: Int): FloatArray {
        val mask = FloatArray(size * size)
        val sx = size.toFloat() / crop.width()
        val sy = size.toFloat() / crop.height()
        val mx1 = (((block.x - crop.left) * sx).toInt()).coerceIn(0, size)
        val my1 = (((block.y - crop.top) * sy).toInt()).coerceIn(0, size)
        val mx2 = (((block.x + block.width - crop.left) * sx).toInt()).coerceIn(0, size)
        val my2 = (((block.y + block.height - crop.top) * sy).toInt()).coerceIn(0, size)
        for (y in my1 until my2) {
            for (x in mx1 until mx2) mask[y * size + x] = 1f
        }
        return mask
    }

    private fun outputArrayToBitmap(output: FloatArray, size: Int): Bitmap {
        val plane = size * size
        val pixels = IntArray(plane)
        for (i in 0 until plane) {
            val r = output[i].toInt().coerceIn(0, 255)
            val g = output[plane + i].toInt().coerceIn(0, 255)
            val b = output[2 * plane + i].toInt().coerceIn(0, 255)
            pixels[i] = Color.rgb(r, g, b)
        }
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        bmp.setPixels(pixels, 0, size, 0, 0, size, size)
        return bmp
    }

    private fun inpaintPerBlockONNX(env: OrtEnvironment, session: OrtSession, bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val result = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)
        val size = MODEL_INPUT_SIZE
        for (block in blocks) {
            try {
                val crop = paddedCropRect(block, bitmap.width, bitmap.height)
                val imgArr = cropToNCHWFloatArray(bitmap, crop, size)
                val maskArr = blockMaskFloatArray(block, crop, size)

                val imgBuf = FloatBufferOf(imgArr)
                val maskBuf = FloatBufferOf(maskArr)
                val imgTensor = OnnxTensor.createTensor(env, imgBuf, longArrayOf(1, 3, size.toLong(), size.toLong()))
                val maskTensor = OnnxTensor.createTensor(env, maskBuf, longArrayOf(1, 1, size.toLong(), size.toLong()))

                val inputs = mapOf("image" to imgTensor, "mask" to maskTensor)
                session.run(inputs).use { results ->
                    // اسم المُخرج موثّق في بطاقة النموذج (Carve/LaMa-ONNX) بأنه "output"
                    val outValue = results.get("output").orElseGet { results.iterator().next().value }
                    val outTensor = outValue.value as Array<*> // نتوقع [1,3,S,S] متداخلة
                    val flatOut = flattenOnnxOutput(outTensor, size)
                    val outBmp = outputArrayToBitmap(flatOut, size)
                    val scaledBack = Bitmap.createScaledBitmap(outBmp, crop.width(), crop.height(), true)
                    canvas.drawBitmap(scaledBack, crop.left.toFloat(), crop.top.toFloat(), null)
                    outBmp.recycle(); scaledBack.recycle()
                }
                imgTensor.close(); maskTensor.close()
            } catch (e: Exception) {
                Log.e(TAG, "ONNX block inference failed for block, using white fallback", e)
                val paint = Paint().apply { color = Color.WHITE }
                canvas.drawRect(Rect(block.x, block.y, block.x + block.width, block.y + block.height), paint)
            }
        }
        return result
    }

    private fun inpaintPerBlockTFLite(interpreter: Interpreter, bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val result = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)
        val size = MODEL_INPUT_SIZE
        for (block in blocks) {
            try {
                val crop = paddedCropRect(block, bitmap.width, bitmap.height)
                val imgArr = cropToNCHWFloatArray(bitmap, crop, size)
                val maskArr = blockMaskFloatArray(block, crop, size)

                val imgBuf = ByteBuffer.allocateDirect(imgArr.size * 4).order(ByteOrder.nativeOrder())
                imgArr.forEach { imgBuf.putFloat(it) }
                imgBuf.rewind()
                val maskBuf = ByteBuffer.allocateDirect(maskArr.size * 4).order(ByteOrder.nativeOrder())
                maskArr.forEach { maskBuf.putFloat(it) }
                maskBuf.rewind()

                val outputBuf = ByteBuffer.allocateDirect(3 * size * size * 4).order(ByteOrder.nativeOrder())
                interpreter.runForMultipleInputsOutputs(arrayOf(imgBuf, maskBuf), mapOf(0 to outputBuf))

                outputBuf.rewind()
                val plane = size * size
                val flatOut = FloatArray(3 * plane)
                for (i in flatOut.indices) flatOut[i] = outputBuf.float * 255f // نتوقع مخرج [0,1]؛ لو النموذج يخرج [0,255] عدّل هنا
                val outBmp = outputArrayToBitmap(flatOut, size)
                val scaledBack = Bitmap.createScaledBitmap(outBmp, crop.width(), crop.height(), true)
                canvas.drawBitmap(scaledBack, crop.left.toFloat(), crop.top.toFloat(), null)
                outBmp.recycle(); scaledBack.recycle()
            } catch (e: Exception) {
                Log.e(TAG, "TFLite block inference failed for block, using white fallback", e)
                val paint = Paint().apply { color = Color.WHITE }
                canvas.drawRect(Rect(block.x, block.y, block.x + block.width, block.y + block.height), paint)
            }
        }
        return result
    }

    private fun FloatBufferOf(arr: FloatArray): java.nio.FloatBuffer {
        val buf = ByteBuffer.allocateDirect(arr.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        buf.put(arr); buf.rewind()
        return buf
    }

    // مخرجات ONNX Runtime لـ Java تجي كمصفوفات متداخلة (Array<Array<Array<FloatArray>>>)
    // لشكل [1,3,S,S] — نسطّحها لنفس ترتيب NCHW المستخدم في outputArrayToBitmap
    @Suppress("UNCHECKED_CAST")
    private fun flattenOnnxOutput(out: Array<*>, size: Int): FloatArray {
        val batch = out[0] as Array<*>            // [3,S,S]
        val plane = size * size
        val result = FloatArray(3 * plane)
        for (c in 0 until 3) {
            val channel = batch[c] as Array<*>     // [S,S] (FloatArray rows)
            for (y in 0 until size) {
                val row = channel[y] as FloatArray
                System.arraycopy(row, 0, result, c * plane + y * size, size)
            }
        }
        return result
    }

    // Main entry point called from AppInterface
    fun processBlocks(bitmap: Bitmap, blocks: List<BlockData>, mode: String): List<JSONObject> {
        return when (mode) {
            "opencv" -> {
                val resultBitmap = inpaintOpenCV(bitmap, blocks)
                // Return single result for the whole page
                listOf(JSONObject().apply {
                    put("mode", "opencv")
                    put("type", "full_page")
                    put("imageBase64", bitmapToBase64(resultBitmap))
                })
            }
            "ai_lite" -> {
                val resultBitmap = inpaintTFLite(bitmap, blocks)
                listOf(JSONObject().apply {
                    put("mode", "ai_lite")
                    put("type", "full_page")
                    put("imageBase64", bitmapToBase64(resultBitmap))
                })
            }
            "ai_pro" -> {
                val resultBitmap = inpaintONNX(bitmap, blocks)
                listOf(JSONObject().apply {
                    put("mode", "ai_pro")
                    put("type", "full_page")
                    put("imageBase64", bitmapToBase64(resultBitmap))
                })
            }
            else -> {
                // For fill/blur - return block coordinates for HTML to handle
                blocks.map { block ->
                    JSONObject().apply {
                        put("x", block.x)
                        put("y", block.y)
                        put("width", block.width)
                        put("height", block.height)
                        put("mode", mode)
                        put("type", "block_coords")
                    }
                }
            }
        }
    }

    private fun fallbackErase(bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val result = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)
        val paint = Paint().apply { color = Color.WHITE }
        for (block in blocks) {
            canvas.drawRect(
                Rect(block.x, block.y, block.x + block.width, block.y + block.height),
                paint
            )
        }
        return result
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val stream = java.io.ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream)
        val bytes = stream.toByteArray()
        return "data:image/jpeg;base64," + android.util.Base64.encodeToString(bytes, android.util.Base64.DEFAULT)
    }

    private fun loadModelFile(path: String): MappedByteBuffer {
        val file = java.io.File(path)
        val stream = FileInputStream(file)
        val channel = stream.channel
        return channel.map(FileChannel.MapMode.READ_ONLY, 0, file.length())
    }
}
