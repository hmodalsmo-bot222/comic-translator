
// CBZ/ZIP Unzipper for Comic Translator
// Supports STORE and DEFLATE (raw inflate, RFC 1951) — pure JS, no external deps
(function(global) {
  'use strict';

  function readLE(bytes, off, len) {
    var r = 0;
    for (var i = 0; i < len; i++) r |= bytes[off + i] << (8 * i);
    return r >>> 0;
  }

  // ---------- Raw DEFLATE inflate (RFC 1951) ----------
  var LBASE = [3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258];
  var LEXT  = [0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0];
  var DBASE = [1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577];
  var DEXT  = [0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13];
  var CLORDER = [16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];

  function buildHuffman(lengths) {
    var maxBits = 0;
    for (var i = 0; i < lengths.length; i++) if (lengths[i] > maxBits) maxBits = lengths[i];
    var blCount = new Array(maxBits + 1).fill(0);
    for (i = 0; i < lengths.length; i++) if (lengths[i] > 0) blCount[lengths[i]]++;
    var code = 0;
    var nextCode = new Array(maxBits + 1).fill(0);
    for (var bits = 1; bits <= maxBits; bits++) {
      code = (code + blCount[bits - 1]) << 1;
      nextCode[bits] = code;
    }
    // map: bits -> { code: symbol }
    var codes = {};
    for (var n = 0; n < lengths.length; n++) {
      var len = lengths[n];
      if (len === 0) continue;
      var c = nextCode[len]++;
      codes[len + '_' + c] = n;
    }
    return { codes: codes, maxBits: maxBits };
  }

  function BitReader(data) {
    this.data = data;
    this.pos = 0;    // byte position
    this.bitBuf = 0;
    this.bitCnt = 0;
  }
  BitReader.prototype.getBit = function() {
    if (this.bitCnt === 0) {
      this.bitBuf = this.data[this.pos++];
      this.bitCnt = 8;
    }
    var bit = this.bitBuf & 1;
    this.bitBuf >>= 1;
    this.bitCnt--;
    return bit;
  };
  BitReader.prototype.getBits = function(n) {
    var v = 0;
    for (var i = 0; i < n; i++) v |= this.getBit() << i;
    return v;
  };
  BitReader.prototype.alignByte = function() {
    this.bitBuf = 0;
    this.bitCnt = 0;
  };
  BitReader.prototype.decodeSymbol = function(huff) {
    var code = 0;
    for (var len = 1; len <= huff.maxBits; len++) {
      code = (code << 1) | this.getBit();
      var key = len + '_' + code;
      if (huff.codes.hasOwnProperty(key)) return huff.codes[key];
    }
    throw new Error('bad huffman code');
  };

  function fixedLitLenLengths() {
    var l = new Array(288);
    var i = 0;
    for (; i <= 143; i++) l[i] = 8;
    for (; i <= 255; i++) l[i] = 9;
    for (; i <= 279; i++) l[i] = 7;
    for (; i <= 287; i++) l[i] = 8;
    return l;
  }
  function fixedDistLengths() {
    var l = new Array(30);
    for (var i = 0; i < 30; i++) l[i] = 5;
    return l;
  }

  function inflateRaw(input, outHint) {
    var br = new BitReader(input);
    var out = new Uint8Array(outHint && outHint > 0 ? outHint : (input.length * 4 + 64));
    var outPos = 0;

    function ensure(extra) {
      if (outPos + extra > out.length) {
        var bigger = new Uint8Array(Math.max(out.length * 2, outPos + extra + 64));
        bigger.set(out.subarray(0, outPos));
        out = bigger;
      }
    }

    var final = 0;
    do {
      final = br.getBit();
      var type = br.getBits(2);

      if (type === 0) {
        // Stored block
        br.alignByte();
        var len = input[br.pos] | (input[br.pos + 1] << 8);
        br.pos += 4; // skip LEN + NLEN
        ensure(len);
        for (var s = 0; s < len; s++) out[outPos++] = input[br.pos++];
      } else if (type === 1 || type === 2) {
        var litHuff, distHuff;
        if (type === 1) {
          litHuff = buildHuffman(fixedLitLenLengths());
          distHuff = buildHuffman(fixedDistLengths());
        } else {
          var hlit = br.getBits(5) + 257;
          var hdist = br.getBits(5) + 1;
          var hclen = br.getBits(4) + 4;
          var clLengths = new Array(19).fill(0);
          for (var c = 0; c < hclen; c++) clLengths[CLORDER[c]] = br.getBits(3);
          var clHuff = buildHuffman(clLengths);

          var allLengths = [];
          while (allLengths.length < hlit + hdist) {
            var sym = br.decodeSymbol(clHuff);
            if (sym < 16) {
              allLengths.push(sym);
            } else if (sym === 16) {
              var rep = br.getBits(2) + 3;
              var prev = allLengths[allLengths.length - 1];
              for (var r = 0; r < rep; r++) allLengths.push(prev);
            } else if (sym === 17) {
              var rep2 = br.getBits(3) + 3;
              for (var r2 = 0; r2 < rep2; r2++) allLengths.push(0);
            } else { // 18
              var rep3 = br.getBits(7) + 11;
              for (var r3 = 0; r3 < rep3; r3++) allLengths.push(0);
            }
          }
          litHuff = buildHuffman(allLengths.slice(0, hlit));
          distHuff = buildHuffman(allLengths.slice(hlit, hlit + hdist));
        }

        while (true) {
          var symbol = br.decodeSymbol(litHuff);
          if (symbol < 256) {
            ensure(1);
            out[outPos++] = symbol;
          } else if (symbol === 256) {
            break; // end of block
          } else {
            var li = symbol - 257;
            var length = LBASE[li] + br.getBits(LEXT[li]);
            var dSym = br.decodeSymbol(distHuff);
            var distance = DBASE[dSym] + br.getBits(DEXT[dSym]);
            ensure(length);
            var from = outPos - distance;
            for (var k = 0; k < length; k++) {
              out[outPos] = out[from + k];
              outPos++;
            }
          }
        }
      } else {
        throw new Error('invalid deflate block type');
      }
    } while (final === 0);

    return out.subarray(0, outPos);
  }

  function unzipCBZ(uint8) {
    var files = {};
    var len = uint8.length;
    var i = 0;

    // Find Central Directory (End of Central Directory record)
    var cdOffset = 0;
    var numEntries = 0;

    for (i = len - 22; i >= 0; i--) {
      if (readLE(uint8, i, 4) === 0x06054b50) {
        numEntries = readLE(uint8, i + 8, 2);
        cdOffset = readLE(uint8, i + 16, 4);
        break;
      }
    }

    if (!cdOffset) return null;

    i = cdOffset;
    var entries = [];

    for (var e = 0; e < numEntries; e++) {
      if (readLE(uint8, i, 4) !== 0x02014b50) break;
      var compMethod = readLE(uint8, i + 10, 2);
      var compSize = readLE(uint8, i + 20, 4);
      var uncompSize = readLE(uint8, i + 24, 4);
      var nameLen = readLE(uint8, i + 28, 2);
      var extraLen = readLE(uint8, i + 30, 2);
      var commentLen = readLE(uint8, i + 32, 2);
      var localOffset = readLE(uint8, i + 42, 4);

      var nameBytes = uint8.subarray(i + 46, i + 46 + nameLen);
      var name = '';
      for (var b = 0; b < nameBytes.length; b++) name += String.fromCharCode(nameBytes[b]);

      entries.push({
        name: name,
        offset: localOffset,
        compSize: compSize,
        uncompSize: uncompSize,
        method: compMethod
      });

      i += 46 + nameLen + extraLen + commentLen;
    }

    // Extract files
    for (var j = 0; j < entries.length; j++) {
      var ent = entries[j];
      if (ent.name.endsWith('/')) continue;

      var off = ent.offset + 26;
      var nameLen2 = readLE(uint8, off, 2);
      var extraLen2 = readLE(uint8, off + 2, 2);
      off += 4 + nameLen2 + extraLen2;

      var data = uint8.subarray(off, off + ent.compSize);

      if (ent.method === 0) {
        // STORE - no compression
        files[ent.name] = data;
      } else if (ent.method === 8) {
        // DEFLATE
        try {
          files[ent.name] = inflateRaw(data, ent.uncompSize);
        } catch (err) {
          console.warn('فشل فك ضغط الملف (DEFLATE):', ent.name, err.message);
        }
      } else {
        console.warn('طريقة ضغط غير مدعومة:', ent.name, 'method=', ent.method);
      }
    }

    return files;
  }

  global.CBZUnzip = { unzip: unzipCBZ };
})(typeof window !== 'undefined' ? window : globalThis);
