package com.comictrans.engine

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.comictrans.model.BlockData
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class OCREngine(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    // Tesseract instance — lazy initialization
    private var tesseract: com.googlecode.tesseract.android.TessBaseAPI? = null
    private var tesseractInitialized = false

    // Initialize Tesseract with English traineddata
    private fun initTesseract(): Boolean {
        if (tesseractInitialized) return tesseract != null

        return try {
            val tessDir = File(context.getExternalFilesDir(null), "tessdata")
            if (!tessDir.exists()) {
                Log.w("OCR", "tessdata folder not found at ${tessDir.absolutePath}")
                Log.w("OCR", "Please download eng.traineddata and place it in: ${tessDir.absolutePath}/eng.traineddata")
                tesseractInitialized = true
                return false
            }

            val api = com.googlecode.tesseract.android.TessBaseAPI()
            val success = api.init(tessDir.parentFile?.absolutePath, "eng")
            if (success) {
                api.setVariable("tessedit_char_whitelist", 
                    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 .,!?;:\'\"()-—\n")
                api.setPageSegMode(com.googlecode.tesseract.android.TessBaseAPI.PageSegMode.PSM_AUTO)
                tesseract = api
                tesseractInitialized = true
                Log.d("OCR", "Tesseract initialized successfully")
                true
            } else {
                Log.e("OCR", "Tesseract init failed")
                tesseractInitialized = true
                false
            }
        } catch (e: Exception) {
            Log.e("OCR", "Tesseract initialization error", e)
            tesseractInitialized = true
            false
        }
    }

    // 1. ML Kit — English/Latin (works immediately, no extra files)
    suspend fun recognizeMLKit(bitmap: Bitmap): List<BlockData> = withContext(Dispatchers.IO) {
        suspendCancellableCoroutine { continuation ->
            val image = InputImage.fromBitmap(bitmap, 0)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    val blocks = visionText.textBlocks.flatMap { block ->
                        block.lines.map { line ->
                            val rect = line.boundingBox
                            BlockData(
                                text = line.text,
                                x = rect?.left ?: 0,
                                y = rect?.top ?: 0,
                                width = rect?.width() ?: 100,
                                height = rect?.height() ?: 30,
                                confidence = line.confidence
                            )
                        }
                    }
                    continuation.resume(blocks)
                }
                .addOnFailureListener { e ->
                    continuation.resumeWithException(e)
                }
        }
    }

    // 2. Tesseract — REAL implementation (requires eng.traineddata)
    suspend fun recognizeTesseract(bitmap: Bitmap): List<BlockData> = withContext(Dispatchers.IO) {
        if (!initTesseract()) {
            Log.w("OCR", "Tesseract not available — falling back to ML Kit")
            return@withContext recognizeMLKit(bitmap)
        }

        try {
            val api = tesseract ?: return@withContext recognizeMLKit(bitmap)
            api.setImage(bitmap)

            val iterator = api.resultIterator
            val blocks = mutableListOf<BlockData>()

            if (iterator != null) {
                iterator.begin()
                do {
                    val text = iterator.getUTF8Text(com.googlecode.tesseract.android.TessBaseAPI.PageIteratorLevel.RIL_TEXTLINE) ?: ""
                    if (text.isNotBlank()) {
                        val rect = iterator.getBoundingRect(com.googlecode.tesseract.android.TessBaseAPI.PageIteratorLevel.RIL_TEXTLINE)
                        val confidence = iterator.confidence(com.googlecode.tesseract.android.TessBaseAPI.PageIteratorLevel.RIL_TEXTLINE)

                        blocks.add(BlockData(
                            text = text.trim(),
                            x = rect.left,
                            y = rect.top,
                            width = rect.width(),
                            height = rect.height(),
                            confidence = confidence / 100f
                        ))
                    }
                } while (iterator.next(com.googlecode.tesseract.android.TessBaseAPI.PageIteratorLevel.RIL_TEXTLINE))
            }

            Log.d("OCR", "Tesseract recognized ${blocks.size} lines")
            blocks
        } catch (e: Exception) {
            Log.e("OCR", "Tesseract recognition error", e)
            recognizeMLKit(bitmap)
        }
    }

    // Release Tesseract resources
    fun releaseTesseract() {
        try {
            tesseract?.end()
            tesseract = null
            tesseractInitialized = false
        } catch (e: Exception) {
            Log.e("OCR", "Error releasing Tesseract", e)
        }
    }

    // 3. OCR.space (cloud)
    suspend fun recognizeOCRSpace(bitmap: Bitmap, apiKey: String): List<BlockData> = withContext(Dispatchers.IO) {
        try {
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream)
            val byteArray = stream.toByteArray()

            val requestBody = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("apikey", apiKey)
                .addFormDataPart("isOverlayRequired", "true")
                .addFormDataPart("OCREngine", "2")
                .addFormDataPart("filetype", "jpg")
                .addFormDataPart(
                    "file", "image.jpg",
                    byteArray.toRequestBody("image/jpeg".toMediaType())
                )
                .build()

            val request = Request.Builder()
                .url("https://api.ocr.space/parse/image")
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return@withContext emptyList()
            val json = JSONObject(body)

            if (json.optBoolean("IsErroredOnProcessing", false)) {
                Log.e("OCRSpace", json.optString("ErrorMessage"))
                return@withContext emptyList()
            }

            val results = json.optJSONArray("ParsedResults") ?: return@withContext emptyList()
            val lines = results.getJSONObject(0).optJSONObject("TextOverlay")?.optJSONArray("Lines") ?: return@withContext emptyList()

            val blocks = mutableListOf<BlockData>()
            for (i in 0 until lines.length()) {
                val line = lines.getJSONObject(i)
                val words = line.optJSONArray("Words")
                if (words != null && words.length() > 0) {
                    val first = words.getJSONObject(0)
                    val totalWidth = (0 until words.length()).sumOf { words.getJSONObject(it).optInt("Width", 0) }
                    blocks.add(BlockData(
                        text = line.optString("LineText", ""),
                        x = first.optInt("Left", 0),
                        y = first.optInt("Top", 0),
                        width = totalWidth,
                        height = line.optInt("MaxHeight", 30)
                    ))
                }
            }
            blocks
        } catch (e: Exception) {
            Log.e("OCRSpace", "Error", e)
            emptyList()
        }
    }

    // 4. Cloud API (generic)
    suspend fun recognizeCloud(bitmap: Bitmap, apiUrl: String): List<BlockData> = withContext(Dispatchers.IO) {
        try {
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream)
            val base64 = android.util.Base64.encodeToString(stream.toByteArray(), android.util.Base64.DEFAULT)

            val jsonBody = JSONObject().put("image", "data:image/jpeg;base64,$base64").toString()
            val request = Request.Builder()
                .url(apiUrl)
                .post(jsonBody.toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return@withContext emptyList()
            val json = JSONObject(body)

            val results = json.optJSONArray("results") ?: json.optJSONArray("words") ?: json.optJSONArray("texts") ?: return@withContext emptyList()
            val blocks = mutableListOf<BlockData>()
            for (i in 0 until results.length()) {
                val item = results.getJSONObject(i)
                blocks.add(BlockData(
                    text = item.optString("text", ""),
                    x = item.optInt("x", 0),
                    y = item.optInt("y", 0),
                    width = item.optInt("width", 100),
                    height = item.optInt("height", 30),
                    confidence = item.optDouble("confidence", 80.0).toFloat()
                ))
            }
            blocks
        } catch (e: Exception) {
            Log.e("CloudOCR", "Error", e)
            emptyList()
        }
    }
}
