package com.comictrans

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.lifecycle.LifecycleCoroutineScope
import com.comictrans.db.AppDatabase
import com.comictrans.engine.*
import com.comictrans.error.AppError
import com.comictrans.error.AppResult
import com.comictrans.error.ErrorManager
import com.comictrans.model.SettingsData
import com.google.gson.Gson
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.Base64

/**
 * Refactored AppInterface - now delegates page processing to PageProcessor.
 * Reduced from God Class to coordinator.
 */
@SuppressLint("SetJavaScriptEnabled")
class AppInterface(
    private val context: Context,
    private val webView: WebView,
    private val lifecycleScope: LifecycleCoroutineScope
) {
    private val gson = Gson()
    private val db = AppDatabase.getDatabase(context)

    // Engines (lazy init to reduce startup time)
    private val ocrEngine by lazy { OCREngine(context) }
    private val translationEngine by lazy { TranslationEngine(context) }
    private val erasureEngine by lazy { ErasureEngine(context).apply { initialize(autoSelectLevel()) } }
    private val syncEngine by lazy { SyncEngine(context) }
    private val modelManager by lazy { ModelManager(context).apply { registerModels(getDefaultModels()) } }

    // Page Processor (extracted logic)
    private val pageProcessor by lazy {
        PageProcessor(
            context = context,
            ocrEngine = ocrEngine,
            translationEngine = translationEngine,
            erasureEngine = erasureEngine,
            syncEngine = syncEngine,
            cacheDao = db.pageCacheDao(),
            gson = gson
        )
    }

    // State
    private var processingJob: Job? = null
    @Volatile private var isProcessing = false
    @Volatile private var shouldStop = false
    private var currentComicHash: String = ""
    private var currentPageCount: Int = 0

    init {
        observeErrors()
        observeDownloads()
    }

    // ==================== ERROR & DOWNLOAD OBSERVERS ====================

    private fun observeErrors() {
        lifecycleScope.launch {
            ErrorManager.lastError.collect { error ->
                error?.let { reportErrorToJS(it) }
            }
        }
    }

    private fun observeDownloads() {
        lifecycleScope.launch {
            modelManager.downloadProgress.collect { progressMap ->
                progressMap.forEach { (modelId, progress) ->
                    reportDownloadProgressToJS(modelId, progress)
                }
            }
        }
    }

    // ==================== JAVASCRIPT INTERFACE ====================

    @JavascriptInterface
    fun listModels(): String = safeJS {
        gson.toJson(modelManager.availableModels.value)
    } ?: "[]"

    @JavascriptInterface
    fun downloadModel(modelId: String) {
        lifecycleScope.launch {
            modelManager.downloadModel(modelId)
                .onError { reportErrorToJS(it) }
        }
    }

    @JavascriptInterface
    fun pauseDownload(modelId: String) {
        lifecycleScope.launch { modelManager.pauseDownload(modelId) }
    }

    @JavascriptInterface
    fun resumeDownload(modelId: String) {
        lifecycleScope.launch { modelManager.resumeDownload(modelId) }
    }

    @JavascriptInterface
    fun cancelDownload(modelId: String) {
        lifecycleScope.launch { modelManager.cancelDownload(modelId) }
    }

    @JavascriptInterface
    fun deleteModel(modelId: String) {
        safeJS { modelManager.deleteModel(modelId) }
    }

    @JavascriptInterface
    fun getDownloadState(modelId: String): String = modelManager.getSavedState(modelId).name

    @JavascriptInterface
    fun isNativeFileImportEnabled(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT

    @JavascriptInterface
    fun logFromJS(message: String) = Log.d("JS_LOG", message)

    // ==================== CBZ OPERATIONS ====================

    @JavascriptInterface
    fun loadCBZ(filePath: String): String = safeJS {
        val result = syncEngine.loadCBZ(filePath)
        result.map { info ->
            currentComicHash = syncEngine.generateComicHash(filePath)
            currentPageCount = info.totalPages
            gson.toJson(mapOf(
                "success" to true,
                "totalPages" to info.totalPages,
                "fileName" to info.fileName,
                "comicHash" to currentComicHash
            ))
        }.getOrElse { error ->
            gson.toJson(mapOf(
                "success" to false,
                "error" to error.userMessage,
                "code" to error.code
            ))
        }
    } ?: gson.toJson(mapOf("success" to false, "error" to "Unknown error"))

    @JavascriptInterface
    fun getPagePreview(pageIndex: Int): String = safeJS {
        syncEngine.getPageBitmap(pageIndex, false).map { bitmap ->
            val base64 = bitmapToBase64(bitmap)
            bitmap.recycle()
            gson.toJson(mapOf("success" to true, "image" to base64))
        }.getOrElse { error ->
            gson.toJson(mapOf("success" to false, "error" to error.userMessage))
        }
    } ?: gson.toJson(mapOf("success" to false, "error" to "Failed to load page"))

    // ==================== PROCESSING ====================

    @JavascriptInterface
    fun startProcessing(settingsJson: String) {
        if (isProcessing) {
            reportErrorToJS(AppError.UnknownError(IllegalStateException("Already processing")))
            return
        }

        val settings = parseSettings(settingsJson) ?: return

        processingJob = lifecycleScope.launch {
            isProcessing = true
            shouldStop = false

            try {
                processAllPages(settings)
            } catch (e: Exception) {
                ErrorManager.reportException(e, "Processing")
            } finally {
                isProcessing = false
                processingJob = null
            }
        }
    }

    @JavascriptInterface
    fun stopProcessing() {
        shouldStop = true
        lifecycleScope.launch {
            processingJob?.cancelAndJoin()
            isProcessing = false
        }
    }

    @JavascriptInterface
    fun isProcessing(): Boolean = isProcessing

    // ==================== PRIVATE PROCESSING ====================

    private suspend fun processAllPages(settings: SettingsData) {
        for (pageIndex in 0 until currentPageCount) {
            if (!lifecycleScope.launch { }.isActive || shouldStop) break

            reportProgressToJS(pageIndex, currentPageCount, "loading")

            // Load page
            val bitmapResult = syncEngine.getPageBitmap(pageIndex, true)
            val bitmap = when (bitmapResult) {
                is AppResult.Success -> bitmapResult.data
                is AppResult.Error -> {
                    ErrorManager.report(bitmapResult.error)
                    continue
                }
            }

            // Process via PageProcessor
            val result = pageProcessor.processPage(pageIndex, bitmap, currentComicHash, settings)

            when (result) {
                is AppResult.Success -> {
                    val processed = result.data
                    if (!processed.isFromCache) {
                        // Save and report
                        val pathResult = syncEngine.saveProcessedPage(pageIndex, processed.processedBitmap, currentComicHash)
                        pathResult.onSuccess { filePath ->
                            reportPageCompleteToJS(pageIndex, filePath)
                        }

                        // Cleanup
                        processed.originalBitmap.recycle()
                        if (processed.processedBitmap != processed.originalBitmap) {
                            processed.processedBitmap.recycle()
                        }
                        BubbleDetector.releaseBubbles(processed.bubbles)
                    } else {
                        reportPageCompleteToJS(pageIndex, processed.processedBitmap.toString())
                    }
                }
                is AppResult.Error -> {
                    ErrorManager.report(result.error)
                    // Keep original on failure
                    reportPageCompleteToJS(pageIndex, "")
                }
            }

            // Memory management
            if (pageIndex % 5 == 0) System.gc()
        }

        reportProgressToJS(currentPageCount, currentPageCount, "completed")
    }

    // ==================== LEGACY SYNC ====================

    @JavascriptInterface
    fun pushMemorySync(): String = safeJS {
        val data = db.translationDao().getAll()
        gson.toJson(data)
    } ?: "[]"

    @JavascriptInterface
    fun pullMemorySync(dataJson: String) {
        lifecycleScope.launch {
            safeJS { /* Process sync data */ }
        }
    }

    // ==================== JS REPORTING ====================

    private fun reportErrorToJS(error: AppError) {
        val json = JSONObject().apply {
            put("type", "error")
            put("code", error.code)
            put("message", error.userMessage)
            put("technical", error.technicalDetails ?: "")
        }
        evaluateJS("window.onAppError?.(${json})")
    }

    private fun reportProgressToJS(current: Int, total: Int, stage: String) {
        val percent = if (total > 0) (current * 100 / total) else 0
        val json = JSONObject().apply {
            put("type", "progress")
            put("current", current)
            put("total", total)
            put("percent", percent)
            put("stage", stage)
        }
        evaluateJS("window.onProgress?.(${json})")
    }

    private fun reportPageCompleteToJS(pageIndex: Int, imagePath: String) {
        val json = JSONObject().apply {
            put("type", "pageComplete")
            put("pageIndex", pageIndex)
            put("imagePath", imagePath)
        }
        evaluateJS("window.onPageComplete?.(${json})")
    }

    private fun reportDownloadProgressToJS(modelId: String, progress: ModelManager.DownloadProgress) {
        val json = JSONObject().apply {
            put("type", "downloadProgress")
            put("modelId", modelId)
            put("state", progress.state.name)
            put("progress", progress.progressPercent)
            put("speed", progress.speedBps)
        }
        evaluateJS("window.onDownloadProgress?.(${json})")
    }

    private fun evaluateJS(script: String) {
        webView.post {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                webView.evaluateJavascript(script, null)
            } else {
                webView.loadUrl("javascript:$script")
            }
        }
    }

    // ==================== UTILITIES ====================

    private fun parseSettings(json: String): SettingsData? {
        return try {
            gson.fromJson(json, SettingsData::class.java)
        } catch (e: Exception) {
            ErrorManager.reportException(e, "Parse Settings")
            null
        }
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val output = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, output)
        val bytes = output.toByteArray()
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Base64.getEncoder().encodeToString(bytes)
        } else {
            android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
        }
    }

    private fun <T> safeJS(block: suspend () -> T): T? {
        return try {
            runBlocking { block() }
        } catch (e: Exception) {
            ErrorManager.reportException(e, "JS Bridge")
            null
        }
    }

    private fun getDefaultModels(): List<ModelManager.ModelInfo> = listOf(
        ModelManager.ModelInfo(
            id = "inpaint_lite", name = "Inpaint Lite",
            description = "Lightweight inpainting (20MB)",
            url = "https://models.comictrans.app/inpaint_lite.tflite",
            sizeBytes = 20_971_520, sha256 = "", fileName = "inpaint_lite.tflite", isOptional = true
        ),
        ModelManager.ModelInfo(
            id = "ocr_paddle", name = "PaddleOCR",
            description = "High accuracy OCR",
            url = "https://models.comictrans.app/ocr_paddle.onnx",
            sizeBytes = 52_428_800, sha256 = "", fileName = "ocr_paddle.onnx", isOptional = true
        ),
        ModelManager.ModelInfo(
            id = "enhance_ai", name = "AI Image Enhance",
            description = "Real-ESRGAN x2 AI upscaling/enhancement",
            url = "https://models.comictrans.app/realesrgan-x2.tflite",
            sizeBytes = 4_194_304, sha256 = "", fileName = "realesrgan-x2.tflite", isOptional = true
        )
    )

    // ==================== LIFECYCLE ====================

    fun release() {
        processingJob?.cancel()
        ocrEngine.release()
        translationEngine.release()
        erasureEngine.release()
        syncEngine.release()
        modelManager.release()
        pageProcessor.release()
    }
}
