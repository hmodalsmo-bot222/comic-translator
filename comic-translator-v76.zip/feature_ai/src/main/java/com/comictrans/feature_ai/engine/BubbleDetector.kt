package com.comictrans.feature_ai.engine

import android.graphics.Bitmap
import android.util.Log
import com.comictrans.engine.OpenCVStatus
import com.comictrans.model.BlockData
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import org.opencv.android.Utils
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfFloat
import org.opencv.core.MatOfInt
import org.opencv.core.MatOfPoint
import org.opencv.core.MatOfRect2d
import org.opencv.core.Point
import org.opencv.core.Rect2d
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.dnn.Dnn
import org.opencv.imgproc.Imgproc
import java.nio.FloatBuffer

/**
 * بند 3: كشف فقاعات الكلام (Speech Bubble Detection).
 *
 * فقاعات الكلام في الكوميكس/المانجا عادة مناطق فاتحة جداً (أبيض تقريباً) محاطة بخط حدّي
 * غامق (outline)، بيضاوية أو مستطيلة الزوايا أو غيمية الشكل (فقاعات الأفكار). الهدف هنا:
 * بدل الاعتماد فقط على المستطيل الخام اللي يرجعه محرك OCR لكل بلوك نص (يتضمن أحياناً هوامش
 * بيضاء زائدة، أو لا يغطي الفقاعة كاملة لو النص لا يملأها) — نحاول إيجاد **حدود الفقاعة
 * الفعلية** حول كل بلوك عبر Imgproc.findContours، لاستخدامها كقناع طمس (Photo.inpaint mask)
 * أدق من مستطيل خام قد يقصّ جزءاً من الفقاعة أو يطمس رسماً حولها بلا داعٍ.
 *
 * ⚠️ ملاحظة صريحة لمن يبني ويختبر: هذا أصعب بنود الخطة الأصلية تقنياً — القيم الثابتة تحت
 * ([LIGHT_THRESHOLD]، [MIN_AREA_RATIO]/[MAX_AREA_RATIO]، هامش منطقة البحث، كيرنل الإغلاق)
 * ضُبطت واختُبرت (2026-08-22) عبر محاكاة اصطناعية بـPython/OpenCV تحاكي عدة أنماط فن
 * (مانجا أبيض/أسود، مانهوا ملوّنة بخلفية فاتحة، فقاعة أفكار بضغط JPEG قوي، مشهد ليلي غامق،
 * فقاعة صغيرة، فقاعتان متلاصقتان، فقاعة تملأ اللوحة) — 7/7 حالات نجحت بعد إضافة محاولة
 * كيرنل إغلاق ثانية أصغر كخط رجوع (راجع تعليق detectBubbleContour). **تنبيه**: هذا اختبار
 * اصطناعي فقط — بيئة الكتابة ما زالت بلا Android SDK ولا صور مانجا حقيقية ولا جهاز فعلي،
 * فالقيم لم تُختبَر بصرياً على صور حقيقية بعد. توقّع حاجة محتملة لضبط إضافي بعد أول استخدام
 * فعلي على جهاز.
 *
 * الميزة مفعّلة افتراضياً (`SettingsData.bubbleAwareErasure = true`) منذ 2026-08-22 — راجع
 * `ErasureEngine.processBitmap(..., bubbleAware)` وAppInterface.kt لمسار الاستدعاء. كل بلوك
 * لم يُعثر لفقاعته على كونتور معقول يرجع لمستطيل خام تلقائياً (لا فشل صريح للصفحة كاملة).
 *
 * 🆕 (2026-08-22) القيم الثابتة أصبحت متحركة (val بـgetter لا const) وتُقرَأ من
 * [com.comictrans.engine.MergeStrictness] — خيار المستخدم من الإعدادات (شاشة الإعدادات →
 * "صرامة شروط كشف/دمج الفقاعات") يتحكم بهذا الملف وبـOCREngine.mergeIntoComicBlocks معاً
 * بنفس القيمة.
 */
object BubbleDetector {

    private const val TAG = "BubbleDetector"

    // ============================================================================
    // 🆕 (2026-08-22) موديل YOLOv8m-seg (kitsumed/yolov8m_seg-speech-bubble) — بديل ML
    // حقيقي لهيوريستيك OpenCV أدناه.
    //
    // ⚠️⚠️ تنبيه صريح وحرج: كل الافتراضات تحت (اسم/شكل المُدخل، ترتيب المخرجات، حجم
    // الالتقاط الصحيح imgsz، عتبات الثقة/NMS) تتبع تنسيق تصدير Ultralytics YOLOv8-seg
    // القياسي الموثَّق (4 إحداثيات صندوق + عدد فئات + 32 معامل قناع + proto منفصل)،
    // **لم تُتحقَّق بفتح الملف الفعلي بهذه البيئة** (بلا إنترنت لتنزيل 171MB، وبلا مكتبة
    // onnx/torch محليّاً لبناء ملف وهمي بنفس البنية للتحقق). بعكس الـheuristics الهندسية
    // بأسفل (اتضبطت واتختبرت فعلياً بمحاكاة اصطناعية)، هذا المسار **غير مختبَر إطلاقاً** —
    // متوقَّع يحتاج تصحيح/ضبط بعد أول تشغيل حقيقي على جهاز (خصوصاً: اسم/ترتيب التنسورات،
    // وimgsz الفعلي اللي دُرِّب/صُدِّر بيه الموديل — افتراضنا هنا 640×640 كقيمة شائعة
    // افتراضية لو الجلسة رجعت بُعداً ديناميكياً). لهذا نستخدم أسماء التنسورات الفعلية من
    // الجلسة نفسها وقت التشغيل بدل افتراض أسماء ثابتة ("images"/"output0"...) — بنفس فلسفة
    // ErasureEngine.inpaintPerBlockMiGan (مطابقة بالاسم أولاً، رجوع بالترتيب لو فشلت).
    // أي فشل بأي خطوة يُلتقَط بالكامل في buildBubbleMask ويرجع بهدوء تام لمسار OpenCV.
    // ============================================================================

    private var cachedYoloEnv: OrtEnvironment? = null
    private var cachedYoloSession: OrtSession? = null
    private var cachedYoloModelPath: String? = null

    private fun getOrCreateYoloSession(modelPath: String): Pair<OrtEnvironment, OrtSession> {
        if (cachedYoloSession != null && cachedYoloModelPath == modelPath) {
            return cachedYoloEnv!! to cachedYoloSession!!
        }
        try { cachedYoloSession?.close() } catch (_: Exception) {}
        val env = cachedYoloEnv ?: OrtEnvironment.getEnvironment().also { cachedYoloEnv = it }
        val options = OrtSession.SessionOptions().apply {
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceAtLeast(1))
            try { addNnapi() } catch (e: Throwable) {
                Log.w(TAG, "YOLO فقاعات: NNAPI غير متاح — استمرار على CPU فقط", e)
            }
        }
        val session = env.createSession(modelPath, options)
        // 🔧 (2026-08-22) SessionOptions تُنفَّذ AutoCloseable — createSession() ينسخ كل ما
        // يحتاجه داخلياً فور الإنشاء، فلا حاجة لإبقاء الكائن حياً بعدها. تسريب صغير لمرة
        // واحدة بس (عند أول تحميل للموديل؛ الجلسة نفسها مخزَّنة مؤقتاً بعدها، فمش متراكم كل
        // صفحة) — لاحظته بمراجعة ذاتية قبل التغليف. (تنويه: نفس الغياب موجود بالنمط الأصلي
        // المطابق بـErasureEngine.getOrCreateOnnxSession لـMI-GAN — خارج نطاق هذا التعديل.)
        try { options.close() } catch (_: Exception) {}
        cachedYoloSession = session
        cachedYoloModelPath = modelPath
        return env to session
    }

    /** يُستدعى عند إغلاق التطبيق لتحرير جلسة ONNX المُخزَّنة (native resources). */
    fun closeYoloSession() {
        try { cachedYoloSession?.close() } catch (_: Exception) {}
        cachedYoloSession = null
        cachedYoloModelPath = null
    }

    private data class LetterboxInfo(val scale: Double, val padX: Int, val padY: Int, val inputW: Int, val inputH: Int)

    // تحجيم بالحفاظ على النسبة + حشو رمادي (114 — قيمة Ultralytics القياسية) حتى يملأ
    // المدخل بالضبط inputW×inputH بدون تشويه الأبعاد — نفس منطق "letterbox" المستخدم أثناء
    // تدريب/تصدير موديلات YOLO، ولازم نفس المنطق بالضبط أثناء الاستدلال أو تنحرف الإحداثيات.
    private fun letterbox(bitmap: Bitmap, inputW: Int, inputH: Int): Pair<Mat, LetterboxInfo> {
        val src = Mat()
        Utils.bitmapToMat(bitmap, src)
        val srcRgb = Mat()
        Imgproc.cvtColor(src, srcRgb, Imgproc.COLOR_RGBA2RGB)
        src.release()

        val scale = minOf(inputW.toDouble() / bitmap.width, inputH.toDouble() / bitmap.height)
        val newW = (bitmap.width * scale).toInt().coerceAtLeast(1)
        val newH = (bitmap.height * scale).toInt().coerceAtLeast(1)
        val resized = Mat()
        Imgproc.resize(srcRgb, resized, Size(newW.toDouble(), newH.toDouble()))
        srcRgb.release()

        val padX = (inputW - newW) / 2
        val padY = (inputH - newH) / 2
        val padded = Mat(inputH, inputW, resized.type(), Scalar(114.0, 114.0, 114.0))
        resized.copyTo(padded.submat(padY, padY + newH, padX, padX + newW))
        resized.release()

        return padded to LetterboxInfo(scale, padX, padY, inputW, inputH)
    }

    /**
     * يُشغَّل مرة واحدة للصفحة كاملة (بعكس detectBubbleContour اللي يعمل بلوك ببلوك) —
     * يرجّع قائمة أقنعة Mat (CV_8UC1، 0/255) **بحجم الصفحة الأصلي كاملاً** لكل فقاعة كلام
     * اكتُشفت بثقة كافية. المتصل (buildBubbleMask) مسؤول عن مطابقة كل قناع لبلوك النص
     * المناسب (باحتواء المركز)، وعن تحرير كل Mat راجع بعد الاستخدام.
     */
    private fun runYoloBubbleSegmentation(bitmap: Bitmap, modelPath: String): List<Mat> {
        val (env, session) = getOrCreateYoloSession(modelPath)

        // اسم/شكل المُدخل الفعليين من الجلسة نفسها — لا افتراض أسماء ثابتة.
        val inputName = session.inputInfo.keys.firstOrNull()
            ?: throw IllegalStateException("موديل YOLO الفقاعات: لا يوجد اسم مُدخل بالجلسة")
        val inputShape = (session.inputInfo[inputName]?.info as? ai.onnxruntime.TensorInfo)?.shape
        // شكل المُدخل القياسي NCHW: [1,3,H,W]. لو H/W ديناميكي (قيمة سالبة بـONNX)، نفترض
        // 640×640 (القيمة الأشيع لتصدير Ultralytics الافتراضي — غير مؤكَّدة لهذا الملف تحديداً).
        val inputH = inputShape?.getOrNull(2)?.let { if (it > 0) it.toInt() else null } ?: 640
        val inputW = inputShape?.getOrNull(3)?.let { if (it > 0) it.toInt() else null } ?: 640

        val (padded, lb) = letterbox(bitmap, inputW, inputH)
        try {
            // NHWC → NCHW + تطبيع [0,1] — قناة RGB بالترتيب (letterbox أعلاه حوّل من RGBA
            // لـRGB بالفعل عبر COLOR_RGBA2RGB).
            val chwData = FloatArray(3 * inputH * inputW)
            val pixelBuf = FloatArray(inputW * inputH * 3)
            val floatMat = Mat()
            padded.convertTo(floatMat, CvType.CV_32FC3, 1.0 / 255.0)
            floatMat.get(0, 0, pixelBuf)
            floatMat.release()
            val plane = inputH * inputW
            for (i in 0 until plane) {
                chwData[i] = pixelBuf[i * 3]                 // R
                chwData[plane + i] = pixelBuf[i * 3 + 1]      // G
                chwData[2 * plane + i] = pixelBuf[i * 3 + 2]  // B
            }

            val inputTensor = OnnxTensor.createTensor(
                env, FloatBuffer.wrap(chwData), longArrayOf(1, 3, inputH.toLong(), inputW.toLong())
            )
            val results = try {
                session.run(mapOf(inputName to inputTensor))
            } finally {
                inputTensor.close()
            }

            try {
                // نميّز مخرج الـproto (رتبة 4: [1,32,protoH,protoW]) عن مخرج الاكتشافات
                // (رتبة 3: [1,C,N] أو [1,N,C]) بالاعتماد على رتبة الشكل نفسها، لا على اسم
                // التنسور (قد يختلف بين تصديرات مختلفة).
                var protoTensor: OnnxTensor? = null
                var detTensor: OnnxTensor? = null
                for (v in results) {
                    val t = v.value as? OnnxTensor ?: continue
                    when (t.info.shape.size) {
                        4 -> protoTensor = t
                        3 -> detTensor = t
                    }
                }
                if (protoTensor == null || detTensor == null) {
                    Log.w(TAG, "YOLO فقاعات: شكل مخرجات غير متوقَّع (proto=${protoTensor != null}, det=${detTensor != null})")
                    return emptyList()
                }

                return decodeYoloSegOutputs(detTensor, protoTensor, lb, bitmap.width, bitmap.height)
            } finally {
                results.close()
            }
        } finally {
            padded.release()
        }
    }

    private fun decodeYoloSegOutputs(
        detTensor: OnnxTensor,
        protoTensor: OnnxTensor,
        lb: LetterboxInfo,
        origW: Int,
        origH: Int
    ): List<Mat> {
        val detShape = detTensor.info.shape // [1, C, N] أو [1, N, C]
        val protoShape = protoTensor.info.shape // [1, 32, protoH, protoW]
        val numMaskCoeffs = protoShape[1].toInt()
        val protoH = protoShape[2].toInt()
        val protoW = protoShape[3].toInt()

        val protoFlat = FloatArray((numMaskCoeffs * protoH * protoW))
        val protoBuf = protoTensor.floatBuffer ?: return emptyList()
        protoBuf.rewind()
        protoBuf.get(protoFlat)

        // تحديد الاتجاه: القناة (4+nc+32) عادة أصغر بكثير من عدد المرشحين (8400+) —
        // لو detShape[1] < detShape[2] فالتنسور [1,C,N] (قنوات أولاً، شائع بتصدير Ultralytics
        // الخام)، وإلا فهو [1,N,C] بالفعل.
        val channelsFirst = detShape[1] < detShape[2]
        val numChannels = (if (channelsFirst) detShape[1] else detShape[2]).toInt()
        val numAnchors = (if (channelsFirst) detShape[2] else detShape[1]).toInt()
        val numClasses = numChannels - 4 - numMaskCoeffs
        if (numClasses < 1) return emptyList()

        val detBuf = detTensor.floatBuffer ?: return emptyList()
        detBuf.rewind()
        val detFlat = FloatArray(numChannels * numAnchors)
        detBuf.get(detFlat)

        fun valueAt(channel: Int, anchor: Int): Float =
            if (channelsFirst) detFlat[channel * numAnchors + anchor] else detFlat[anchor * numChannels + channel]

        val CONF_THRESHOLD = 0.35f
        val boxes = ArrayList<Rect2d>()
        val confidences = ArrayList<Float>()
        val coeffsList = ArrayList<FloatArray>()

        for (a in 0 until numAnchors) {
            // فئة واحدة فقط متوقَّعة لهذا الموديل ("speech bubble") — نأخذ أعلى ثقة بين
            // numClasses احتياطاً لو كان الملف الفعلي مُدرَّباً بأكثر من فئة.
            var bestClsScore = -1f
            for (c in 0 until numClasses) {
                val s = valueAt(4 + c, a)
                if (s > bestClsScore) bestClsScore = s
            }
            if (bestClsScore < CONF_THRESHOLD) continue

            val cx = valueAt(0, a); val cy = valueAt(1, a)
            val w = valueAt(2, a); val h = valueAt(3, a)
            val x1 = (cx - w / 2).toDouble(); val y1 = (cy - h / 2).toDouble()
            boxes.add(Rect2d(x1, y1, w.toDouble(), h.toDouble()))
            confidences.add(bestClsScore)

            val coeffs = FloatArray(numMaskCoeffs) { i -> valueAt(4 + numClasses + i, a) }
            coeffsList.add(coeffs)
        }
        if (boxes.isEmpty()) return emptyList()

        val boxesMat = MatOfRect2d(*boxes.toTypedArray())
        val scoresMat = MatOfFloat(*confidences.toFloatArray())
        val indicesMat = MatOfInt()
        Dnn.NMSBoxes(boxesMat, scoresMat, CONF_THRESHOLD, 0.45f, indicesMat)
        val keepIndices = indicesMat.toArray()
        boxesMat.release(); scoresMat.release(); indicesMat.release()

        val results = ArrayList<Mat>()
        for (idx in keepIndices) {
            val coeffs = coeffsList[idx]
            // sigmoid(proto·coeffs) لكل بكسل بشبكة الـproto (عادة 1/4 دقة المُدخل)
            val protoPlane = protoH * protoW
            val maskSmall = FloatArray(protoPlane)
            for (p in 0 until protoPlane) {
                var sum = 0f
                for (k in 0 until numMaskCoeffs) sum += coeffs[k] * protoFlat[k * protoPlane + p]
                maskSmall[p] = (1.0 / (1.0 + kotlin.math.exp(-sum.toDouble()))).toFloat()
            }
            val maskMatSmall = Mat(protoH, protoW, CvType.CV_32FC1)
            maskMatSmall.put(0, 0, maskSmall)

            // تكبير لحجم المُدخل الملفوف (letterbox) الكامل، ثم استخراج المنطقة غير المحشوّة
            // فقط، ثم إعادة التحجيم لحجم الصفحة الأصلي — بترتيب عكسي مضبوط لعملية letterbox.
            val maskFull = Mat()
            Imgproc.resize(maskMatSmall, maskFull, Size(lb.inputW.toDouble(), lb.inputH.toDouble()))
            maskMatSmall.release()

            val unpaddedW = (lb.inputW - 2 * lb.padX).coerceAtLeast(1)
            val unpaddedH = (lb.inputH - 2 * lb.padY).coerceAtLeast(1)
            val cropRect = org.opencv.core.Rect(
                lb.padX.coerceIn(0, lb.inputW - 1), lb.padY.coerceIn(0, lb.inputH - 1),
                unpaddedW.coerceAtMost(lb.inputW - lb.padX), unpaddedH.coerceAtMost(lb.inputH - lb.padY)
            )
            val maskCropped = Mat(maskFull, cropRect)
            val maskOrig = Mat()
            Imgproc.resize(maskCropped, maskOrig, Size(origW.toDouble(), origH.toDouble()))
            maskCropped.release() // Mat "view" بس (يشارك بيانات maskFull) — يُحرَّر فور
                                   // الاستخدام، قبل تحرير maskFull نفسها بالسطر التالي
            maskFull.release()

            val maskBinary = Mat()
            Imgproc.threshold(maskOrig, maskBinary, 0.5, 255.0, Imgproc.THRESH_BINARY)
            maskOrig.release()
            val maskU8 = Mat()
            maskBinary.convertTo(maskU8, CvType.CV_8UC1)
            maskBinary.release()
            results.add(maskU8)
        }
        return results
    }


    // فقاعة الكلام النموذجية فاتحة جداً (أبيض تقريباً) — نفصل الفاتح عن الغامق بعتبة ثابتة
    // بدل Otsu التكيفية، لأن Otsu قد "يقرر" عتبة سيئة على صفحة يغلب عليها رسم غامق (مشهد
    // ليلي مثلاً) فتفشل في عزل فقاعة فاتحة صغيرة وسط صفحة غامقة أغلبها. عتبة ثابتة عالية
    // (200/255 بالوضع الطبيعي) تفترض أن الفقاعة فعلاً فاتحة جداً مقارنة بمعظم فن الكوميكس
    // المحيط — افتراض معقول شائع لكنه سيفشل عمداً (يرجع null) مع أنماط فن غير تقليدية
    // (فقاعات ملوّنة غامقة) بدل تخمين خاطئ صامت.
    //
    // 🆕 (2026-08-22) بطلب المستخدم: صارت هذه القيم قابلة للتحكم عبر MergeStrictness (نفس
    // الإعداد اللي بيتحكم بدمج سطور OCREngine — راجع تعليقها الكامل بموديول app/engine/).
    // القيم أدناه عند factor=0 مطابقة تماماً للثوابت السابقة (200 / 0.05 / 0.92) — لا تغيير
    // بالسلوك الافتراضي. factor=-1 (متساهل) يوسّع النطاق المقبول (يكشف كونتورات فقاعة
    // بثقة أقل)، factor=+1 (صارم) يضيّقه (يرفض أسهل، رجوع أكثر لمستطيل خام).
    private val LIGHT_THRESHOLD: Double
        get() = when (com.comictrans.engine.MergeStrictness.factor) {
            -1 -> 185.0
            1 -> 210.0
            else -> 200.0
        }

    // نطاق نسبة (مساحة الكونتور ÷ مساحة منطقة البحث المُوسَّعة) المقبول لاعتباره "فقاعة"
    // منطقية — كونتور أصغر من هذا غالباً ضوضاء/جزء حرف منفصل، وأكبر منه غالباً التقط خلفية
    // الصفحة كلها بالخطأ (فشل الفصل بين الفقاعة والمحيط).
    //
    // ⚠️ (2026-08-22) تنبيه ضبط: أول محاولة لـMAX_AREA_RATIO الصارم كانت 0.85 — فشلت
    // بالمحاكاة الاصطناعية على حالتين طبيعيتين تماماً (فقاعة تملأ اللوحة نسبة 0.91، وفقاعة
    // مانجا كلاسيكية عادية نسبة 0.877) لأن فقاعات كبيرة حقيقية شائعة الحدوث بهذا النطاق
    // أصلاً حتى بالوضع الطبيعي. الضبط النهائي (0.93) أخف بكثير عن القديم فيبقي هالفقاعات
    // سليمة بينما لسه أضيق شوي من الطبيعي (0.92).
    private val MIN_AREA_RATIO: Double
        get() = when (com.comictrans.engine.MergeStrictness.factor) {
            -1 -> 0.035
            1 -> 0.07
            else -> 0.05
        }
    private val MAX_AREA_RATIO: Double
        get() = when (com.comictrans.engine.MergeStrictness.factor) {
            -1 -> 0.95
            1 -> 0.93
            else -> 0.92
        }

    /**
     * يحاول إيجاد كونتور فقاعة الكلام المحيطة بمستطيل نص [block] داخل [bitmap]. يبحث في
     * منطقة مُوسَّعة حول المستطيل (padding نسبي لحجم النص) لأن حدود الفقاعة الفعلية عادة
     * أكبر من مستطيل النص الخام. يرجع null لو لم يُعثر على كونتور معقول يحتوي مركز النص —
     * عندها يجب على المتصل الرجوع للمستطيل الخام (لا يوجد افتراض بديل هنا، تعمّداً).
     * الإحداثيات المُرجَعة بمقياس [bitmap] الأصلي كاملاً (وليس منطقة البحث المقصوصة).
     */
    fun detectBubbleContour(bitmap: Bitmap, block: BlockData): MatOfPoint? {
        if (!OpenCVStatus.isAvailable) return null
        if (block.width <= 0 || block.height <= 0) return null

        // هامش بحث حول مستطيل النص — فقاعة الكلام النموذجية أكبر من نصّها بوضوح على كل
        // جهة (~60% من أبعاد النص كحد أدنى للهامش، بحد أدنى 20 بكسل حتى لا يضيق البحث جداً
        // لنص صغير الخط).
        val padX = maxOf((block.width * 0.6).toInt(), 20)
        val padY = maxOf((block.height * 0.6).toInt(), 20)
        val rx1 = (block.x - padX).coerceIn(0, bitmap.width - 1)
        val ry1 = (block.y - padY).coerceIn(0, bitmap.height - 1)
        val rx2 = (block.x + block.width + padX).coerceIn(rx1 + 1, bitmap.width)
        val ry2 = (block.y + block.height + padY).coerceIn(ry1 + 1, bitmap.height)
        val regionW = rx2 - rx1
        val regionH = ry2 - ry1
        if (regionW <= 4 || regionH <= 4) return null

        var mat: Mat? = null
        var gray: Mat? = null
        var cropped: Bitmap? = null
        return try {
            cropped = Bitmap.createBitmap(bitmap, rx1, ry1, regionW, regionH)
            mat = Mat()
            Utils.bitmapToMat(cropped, mat)
            gray = Mat()
            Imgproc.cvtColor(mat, gray, Imgproc.COLOR_RGBA2GRAY)

            // 🔍 (2026-08-22) بمحاكاة اصطناعية (فقاعات مانهوا بخلفية فاتحة + خط حد رفيع
            // ~2px) تبيّن أن كيرنل الإغلاق 5×5 القديم كان يمسح خط الحد الرفيع تماماً لو
            // الخلفية حوله فاتحة هي كمان (أعلى من LIGHT_THRESHOLD) — الإغلاق (dilate ثم
            // erode) بيلحم أي منطقة غامقة أرفع من نصف قطر الكيرنل بالخلفية البيضاء
            // المحيطة، فتصير الفقاعة+الخلفية كتلة بيضاء واحدة تتجاوز MAX_AREA_RATIO
            // فتُرفَض بالكامل (لا كونتور إطلاقاً). بالمقابل كيرنل أصغر (3×3) بيحافظ على
            // خطوط الحد الرفيعة لكنه أضعف بلحم فجوات كبيرة (فقاعة أفكار بخط متقطع بضغط
            // JPEG قوي). الحل: محاولتين بالتتابع — 5×5 أولاً (يعالج الحالة الأشيع: خطوط
            // حد متقطعة/غير منتظمة)، ولو فشلت (فقاعة برجع null) نعيد المحاولة بـ3×3 (يعالج
            // خطوط الحد الرفيعة على خلفية فاتحة). كل محاولة تُصفّى موارد OpenCV الخاصة بها
            // بشكل مستقل قبل المحاولة التالية.
            findContourWithKernel(gray, regionW, regionH, block, rx1, ry1, kernelSize = 5.0)
                ?: findContourWithKernel(gray, regionW, regionH, block, rx1, ry1, kernelSize = 3.0)
        } catch (e: Throwable) {
            Log.w(TAG, "فشل كشف فقاعة الكلام لبلوك نص — رجوع متوقَّع لمستطيل خام من المتصل", e)
            null
        } finally {
            mat?.release(); gray?.release()
            cropped?.recycle()
        }
    }

    private fun findContourWithKernel(
        gray: Mat,
        regionW: Int,
        regionH: Int,
        block: BlockData,
        rx1: Int,
        ry1: Int,
        kernelSize: Double
    ): MatOfPoint? {
        var binary: Mat? = null
        var kernel: Mat? = null
        var hierarchy: Mat? = null
        return try {
            binary = Mat()
            Imgproc.threshold(gray, binary, LIGHT_THRESHOLD, 255.0, Imgproc.THRESH_BINARY)

            // إغلاق فتحات صغيرة بخط الحدّ (outline) قد تنقطع بسبب ضغط JPEG/تعرّج المسح
            // الضوئي — closing يعيد وصلها حتى لا تنقسم الفقاعة الواحدة لعدة كونتورات صغيرة
            // منفصلة بدل كونتور واحد متكامل. (حجم الكيرنل يُحدَّد بالمتصل — راجع تعليق
            // detectBubbleContour لسبب وجود محاولتين بحجمين مختلفين.)
            kernel = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(kernelSize, kernelSize))
            Imgproc.morphologyEx(binary, binary, Imgproc.MORPH_CLOSE, kernel)

            val contours = ArrayList<MatOfPoint>()
            hierarchy = Mat()
            Imgproc.findContours(binary, contours, hierarchy, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)

            val regionArea = (regionW * regionH).toDouble()
            val blockCenterX = (block.x - rx1 + block.width / 2).toDouble()
            val blockCenterY = (block.y - ry1 + block.height / 2).toDouble()

            // من بين كل الكونتورات المُكتشَفة، نختار الأقرب منطقياً لفقاعة كلام حقيقية:
            // مساحة ضمن النطاق المقبول، **ويحتوي مركز مستطيل النص فعلياً** (يمنع التقاط
            // فقاعة مجاورة تقع جزئياً داخل منطقة البحث المُوسَّعة بالخطأ).
            var best: MatOfPoint? = null
            var bestArea = -1.0
            for (c in contours) {
                val area = Imgproc.contourArea(c)
                val ratio = area / regionArea
                if (ratio < MIN_AREA_RATIO || ratio > MAX_AREA_RATIO) { c.release(); continue }
                val rect = Imgproc.boundingRect(c)
                val containsCenter = blockCenterX >= rect.x && blockCenterX <= rect.x + rect.width &&
                    blockCenterY >= rect.y && blockCenterY <= rect.y + rect.height
                if (!containsCenter) { c.release(); continue }
                if (area > bestArea) {
                    best?.release()
                    bestArea = area
                    best = c
                } else {
                    c.release()
                }
            }

            // نترجم إحداثيات الكونتور الفائز من مقياس منطقة البحث المقصوصة لمقياس الصورة
            // الأصلية كاملة (نضيف إزاحة rx1/ry1) قبل إرجاعه للمتصل.
            best?.let { winner ->
                val points = winner.toArray().map { p -> Point(p.x + rx1, p.y + ry1) }
                winner.release()
                MatOfPoint(*points.toTypedArray())
            }
        } finally {
            binary?.release(); kernel?.release(); hierarchy?.release()
        }
    }

    /**
     * يبني قناع (Mat بمقاس [bitmap]، CV_8UC1، 255=أبيض داخل منطقة الطمس) لكل [blocks] —
     * يُستخدَم مباشرة كقناع لـPhoto.inpaint() بدل قناع المستطيلات الخام. أي بلوك لم يُعثر
     * لفقاعته على كونتور معقول يُرسَم كمستطيل خام (نفس السلوك القديم قبل هذا البند) بدل
     * تركه بدون طمس إطلاقاً — سلوك احتياطي متعمَّد لكل بلوك على حدة، لا للصفحة كاملة.
     * المتصل مسؤول عن استدعاء `mask.release()` بعد الاستخدام.
     */
    fun buildBubbleMask(bitmap: Bitmap, blocks: List<BlockData>, yoloModelPath: String? = null): Mat {
        val mask = Mat.zeros(Size(bitmap.width.toDouble(), bitmap.height.toDouble()), CvType.CV_8UC1)

        // 🆕 (2026-08-22) لو محرك المستخدم "yolo" ومسار الموديل معروف (محمَّل فعلياً على
        // الجهاز)، نحاول تشغيله **مرة واحدة للصفحة كاملة** (بعكس OpenCV اللي يعمل بلوك
        // ببلوك) — نتيجته: قائمة أقنعة (Mat) بحجم الصفحة كاملة، واحد لكل فقاعة اكتُشفت.
        // أي فشل (موديل غير محمَّل، خطأ تحميل جلسة ONNX، شكل مخرجات غير متوقَّع...) يُلتقَط
        // كاملاً هنا ونرجع بهدوء لقائمة فارغة — الحلقة تحت بترجع تلقائياً لمسار OpenCV
        // الهندسي (detectBubbleContour) بلوك ببلوك، فلا فشل صريح للصفحة كاملة أبداً.
        val yoloInstances: List<Mat> = if (
            com.comictrans.engine.BubbleDetectionEngine.engine == "yolo" && yoloModelPath != null
        ) {
            try {
                runYoloBubbleSegmentation(bitmap, yoloModelPath)
            } catch (e: Throwable) {
                Log.w(TAG, "فشل تشغيل موديل YOLO لكشف الفقاعات — رجوع كامل لمسار OpenCV الهندسي", e)
                emptyList()
            }
        } else emptyList()

        for (block in blocks) {
            // نبحث أولاً عن قناع YOLO يحتوي مركز مستطيل النص فعلياً — نفس فلسفة الاحتواء
            // المستخدمة بمسار OpenCV (detectBubbleContour) بالضبط، لمنع التقاط فقاعة مجاورة.
            val centerX = (block.x + block.width / 2).coerceIn(0, bitmap.width - 1)
            val centerY = (block.y + block.height / 2).coerceIn(0, bitmap.height - 1)
            val yoloMatch = yoloInstances.firstOrNull { inst ->
                inst.get(centerY, centerX)?.getOrNull(0) == 255.0
            }
            when {
                yoloMatch != null -> {
                    // 🔧 (2026-08-22) يجب تحرير الكونتور الناتج صراحة بعد fillPoly — نفس
                    // نمط التحرير المستخدم لمسار OpenCV تحت (contour.release() بعده مباشرة)،
                    // وإلا تسريب ذاكرة native صغير متراكم لكل بلوك مطابَق بموديل YOLO.
                    val yoloContour = matToContour(yoloMatch)
                    Imgproc.fillPoly(mask, listOf(yoloContour), Scalar(255.0))
                    yoloContour.release()
                }
                else -> {
                    val contour = detectBubbleContour(bitmap, block)
                    if (contour != null) {
                        Imgproc.fillPoly(mask, listOf(contour), Scalar(255.0))
                        contour.release()
                    } else {
                        val x1 = block.x.coerceIn(0, bitmap.width - 1)
                        val y1 = block.y.coerceIn(0, bitmap.height - 1)
                        val x2 = (block.x + block.width).coerceIn(0, bitmap.width)
                        val y2 = (block.y + block.height).coerceIn(0, bitmap.height)
                        Imgproc.rectangle(
                            mask,
                            Point(x1.toDouble(), y1.toDouble()),
                            Point(x2.toDouble(), y2.toDouble()),
                            Scalar(255.0),
                            -1
                        )
                    }
                }
            }
        }
        yoloInstances.forEach { it.release() }
        return mask
    }

    // قناع YOLO Mat (CV_8UC1، أبيض=فقاعة) أسهل يُدمَج مباشرة بـImgproc.fillPoly لو حوّلناه
    // لكونتور واحد بسيط عبر findContours (أكبر كونتور خارجي مساحةً) بدل نسخه بكسل ببكسل
    // على mask الصفحة الرئيسي — أرخص حسابياً ومتّسق مع مسار OpenCV اللي أصلاً بيرجّع
    // MatOfPoint. **تنبيه**: الكونتور المُرجَع (الفائز) ملكية المتصل — هو من يُحرِّره بعد
    // استخدامه (fillPoly)، بنفس نمط detectBubbleContour بالضبط.
    private fun matToContour(instanceMask: Mat): MatOfPoint {
        val contours = ArrayList<MatOfPoint>()
        val hierarchy = Mat()
        try {
            Imgproc.findContours(instanceMask, contours, hierarchy, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
            if (contours.isEmpty()) return MatOfPoint()
            var winner = contours[0]
            var winnerArea = Imgproc.contourArea(winner)
            for (i in 1 until contours.size) {
                val c = contours[i]
                val area = Imgproc.contourArea(c)
                if (area > winnerArea) {
                    winner.release() // نحرّر الفائز السابق (أياً كان) قبل استبداله
                    winner = c
                    winnerArea = area
                } else {
                    c.release()
                }
            }
            return winner
        } finally {
            hierarchy.release()
        }
    }
}
