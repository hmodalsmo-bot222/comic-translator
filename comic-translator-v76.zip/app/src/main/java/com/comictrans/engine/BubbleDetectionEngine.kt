package com.comictrans.engine

/**
 * 🆕 (2026-08-22) أي محرك يُستخدَم لكشف حدود الفقاعة الفعلية (لما SettingsData
 * .bubbleAwareErasure = true) — بطلب المستخدم صراحة: قائمة اختيار واحدة بالإعدادات
 * ("كشف حدود الفقاعة تلقائياً") بدل مربع اختيار ثنائي، تسمح بالتبديل بين محركين.
 *
 * "opencv" = الـheuristics الهندسية الموجودة أصلاً (BubbleDetector.detectBubbleContour —
 * عتبة إضاءة + findContours، مُختبَرة بمحاكاة اصطناعية، بلا نموذج ML).
 * "yolo" = موديل YOLOv8m-seg حقيقي مُدرَّب لفقاعات الكلام (BubbleDetector
 * .runYoloBubbleSegmentation) — **غير مختبَر فعلياً على صورة حقيقية بهذه البيئة**، راجع
 * تعليقها الطويل لتفاصيل الافتراضات وخطة الرجوع الآمن الكامل لكل مسار فشل.
 *
 * نفس نمط MergeStrictness.kt وOpenCVStatus.kt بالضبط (object مشترك بموديول app يُقرَأ
 * مباشرة من feature_ai بلا أي تعديل بواجهات IOcrEngine/IErasureEngine المحمَّلة بـReflection
 * — راجع تعليق MergeStrictness.kt لتفصيل السبب الكامل). AppInterface.startProcessing
 * يحدّث [engine] من settings.bubbleDetectionEngine قبل أي استدعاء طمس.
 */
object BubbleDetectionEngine {
    // "opencv" | "yolo" — أي قيمة غير معروفة تُعامَل كـ"opencv" بأمان (السلوك الأقدم
    // والأكثر اختباراً).
    @Volatile
    var engine: String = "opencv"
}
