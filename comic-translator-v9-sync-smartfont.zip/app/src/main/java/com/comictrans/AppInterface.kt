package com.comictrans

import android.content.Context
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.lifecycle.lifecycleScope
import com.comictrans.engine.OCREngine
import com.comictrans.engine.TranslationEngine
import com.comictrans.engine.ErasureEngine
import com.comictrans.engine.ImageEnhanceEngine
import com.comictrans.engine.SyncEngine
import com.comictrans.db.AppDatabase
import com.comictrans.db.TranslationEntity
import com.comictrans.model.BlockData
import com.comictrans.model.SettingsData
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class AppInterface(
    private val context: Context,
    private val webView: WebView
) {

    private val gson = Gson()
    private var isProcessing = false
    private var shouldStop = false

    private val ocrEngine = OCREngine(context)
    private val translateEngine = TranslationEngine(context)
    private val erasureEngine = ErasureEngine(context)
    private val imageEnhanceEngine = ImageEnhanceEngine(context)
    private val syncEngine = SyncEngine()
    private val db = AppDatabase.getInstance(context)

    @JavascriptInterface
    fun startProcessing(pageIndex: Int, settingsJson: String) {
        if (isProcessing) return
        isProcessing = true
        shouldStop = false

        val settings = gson.fromJson(settingsJson, SettingsData::class.java)
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            processPage(pageIndex, settings)
        }
    }

    @JavascriptInterface
    fun stopProcessing() {
        shouldStop = true
        isProcessing = false
    }

    @JavascriptInterface
    fun logFromJS(message: String) {
        Log.d("ComicJS", message)
    }

    // ================= خلفية المجتمع (مزامنة ذاكرة الترجمة) =================

    @JavascriptInterface
    fun pushMemorySync(backend: String, config: String) {
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            try {
                if (backend == "local") {
                    val entries = db.translationDao().getAll()
                    val json = gson.toJson(entries)
                    withContext(Dispatchers.Main) {
                        (context as MainActivity).exportJsonToFile(json, "comictrans_memory.json")
                    }
                    return@launch
                }
                val entries = db.translationDao().getAll()
                val json = gson.toJson(entries)
                val result = syncEngine.push(backend, config, json)
                result.fold(
                    onSuccess = { msg -> sendSyncResult(true, msg) },
                    onFailure = { err -> sendSyncResult(false, err.message ?: "فشل غير معروف") }
                )
            } catch (e: Exception) {
                sendSyncResult(false, e.message ?: "فشل غير معروف")
            }
        }
    }

    @JavascriptInterface
    fun pullMemorySync(backend: String, config: String) {
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            try {
                if (backend == "local") {
                    withContext(Dispatchers.Main) { (context as MainActivity).importJsonFromFile() }
                    return@launch
                }
                val result = syncEngine.pull(backend, config)
                result.fold(
                    onSuccess = { json -> importEntriesAndReport(json) },
                    onFailure = { err -> sendSyncResult(false, err.message ?: "فشل غير معروف") }
                )
            } catch (e: Exception) {
                sendSyncResult(false, e.message ?: "فشل غير معروف")
            }
        }
    }

    // يُستدعى من MainActivity بعد نجاح/فشل تصدير أو استيراد ملف محلي (Local Sync، بدون إنترنت)
    fun onLocalSyncResult(success: Boolean, message: String, importedJson: String?) {
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            if (success && importedJson != null) {
                importEntriesAndReport(importedJson)
            } else {
                sendSyncResult(success, message)
            }
        }
    }

    private suspend fun importEntriesAndReport(json: String) {
        try {
            val type = object : TypeToken<List<TranslationEntity>>() {}.type
            val entries: List<TranslationEntity> = gson.fromJson(json, type) ?: emptyList()
            // نصفّر id عشان autoGenerate يعطي معرفات جديدة محلياً، ونعتمد على unique index
            // (sourceText+sourceLang+targetLang) لمنع التكرار بدل تصادم PK
            val cleaned = entries.map { it.copy(id = 0) }
            db.translationDao().insertAll(cleaned)
            sendSyncResult(true, "تم استيراد ${cleaned.size} عبارة إلى الذاكرة الذكية بنجاح")
        } catch (e: Exception) {
            sendSyncResult(false, "فشل تفسير البيانات المستوردة: ${e.message}")
        }
    }

    private fun sendSyncResult(success: Boolean, message: String) {
        val json = JSONObject().apply {
            put("success", success)
            put("message", message)
        }
        sendToWebView("onSyncResult", json.toString())
    }

    private suspend fun processPage(pageIndex: Int, settings: SettingsData) {
        try {
            // 1. OCR
            sendStatus(pageIndex, "ocr", 0)
            val imageBase64 = requestImageFromJS(pageIndex) ?: run {
                sendError(pageIndex, "No image data")
                return
            }

            val bitmap = MainActivity.base64ToBitmap(imageBase64) ?: run {
                sendError(pageIndex, "Invalid image")
                return
            }

            // تعزيز الصورة قبل OCR (اختياري) — يُستخدم فقط لتحسين دقة القراءة، والصورة
            // الأصلية تبقى كما هي لخطوات الطمس والعرض لاحقاً.
            val enhanceResult = if (settings.enhanceImage) {
                sendStatus(pageIndex, "enhance", 0)
                val r = imageEnhanceEngine.enhance(bitmap, settings.enhanceMethod)
                sendStatus(pageIndex, "enhance", 100)
                r
            } else null
            val ocrBitmap = enhanceResult?.bitmap ?: bitmap
            val enhanceScale = enhanceResult?.scale ?: 1f

            val rawBlocks = when (settings.ocrEngine) {
                "mlkit" -> ocrEngine.recognizeMLKit(ocrBitmap)
                "tesseract" -> ocrEngine.recognizeTesseract(ocrBitmap)
                "ocrspace" -> ocrEngine.recognizeOCRSpace(ocrBitmap, settings.ocrSpaceKey)
                "cloud" -> ocrEngine.recognizeCloud(ocrBitmap, settings.cloudApiUrl)
                else -> ocrEngine.recognizeMLKit(ocrBitmap)
            }
            // لو التعزيز كبّر أبعاد الصورة (وضع AI)، نرجّع إحداثيات الكتل لمقياس الصورة الأصلية
            val blocks = if (enhanceScale != 1f) {
                rawBlocks.map {
                    it.copy(
                        x = (it.x / enhanceScale).toInt(),
                        y = (it.y / enhanceScale).toInt(),
                        width = (it.width / enhanceScale).toInt(),
                        height = (it.height / enhanceScale).toInt()
                    )
                }
            } else rawBlocks

            if (shouldStop) { sendStopped(pageIndex); return }
            sendStatus(pageIndex, "ocr", 100)

            // 2. Translation
            sendStatus(pageIndex, "translate", 0)
            val translatedBlocks = blocks.mapIndexed { idx, block ->
                if (shouldStop) return@mapIndexed block

                val memoryResult = if (settings.useMemory) {
                    db.translationDao().findExact(block.text.trim())
                } else null

                val translated = if (memoryResult != null) {
                    memoryResult.translatedText
                } else {
                    when (settings.translateEngine) {
                        "mlkit" -> translateEngine.translateMLKit(block.text, settings.sourceLang, settings.targetLang)
                        "google" -> translateEngine.translateGoogle(block.text, settings.sourceLang, settings.targetLang)
                        "gemini" -> translateEngine.translateGemini(block.text, settings.sourceLang, settings.targetLang, settings.geminiKey, settings.geminiModel)
                        "openai" -> translateEngine.translateOpenAI(block.text, settings.sourceLang, settings.targetLang, settings.openaiKey, settings.openaiModel)
                        "deepl" -> translateEngine.translateDeepL(block.text, settings.sourceLang, settings.targetLang, settings.deeplKey)
                        else -> translateEngine.translateGoogle(block.text, settings.sourceLang, settings.targetLang)
                    }
                }

                if (settings.useMemory && memoryResult == null && translated.isNotBlank()) {
                    db.translationDao().insert(
                        com.comictrans.db.TranslationEntity(
                            sourceText = block.text.trim(),
                            translatedText = translated.trim(),
                            sourceLang = settings.sourceLang,
                            targetLang = settings.targetLang
                        )
                    )
                }

                sendStatus(pageIndex, "translate", ((idx + 1) * 100 / blocks.size.coerceAtLeast(1)))
                block.copy(translatedText = translated)
            }

            if (shouldStop) { sendStopped(pageIndex); return }

            // 3. Erasure
            sendStatus(pageIndex, "erasure", 0)
            val erasureData = when (settings.erasureMode) {
                "fill", "blur" -> {
                    // HTML handles these simple modes
                    translatedBlocks.map { block ->
                        JSONObject().apply {
                            put("x", block.x)
                            put("y", block.y)
                            put("width", block.width)
                            put("height", block.height)
                            put("translatedText", block.translatedText)
                            put("mode", settings.erasureMode)
                            put("type", "block_coords")
                        }
                    }
                }
                "opencv", "ai_lite", "ai_pro" -> {
                    // Native processing - returns full page image
                    val result = erasureEngine.processBlocks(bitmap, translatedBlocks, settings.erasureMode)
                    // Also need to include translated text data
                    val textData = translatedBlocks.map { block ->
                        JSONObject().apply {
                            put("x", block.x)
                            put("y", block.y)
                            put("width", block.width)
                            put("height", block.height)
                            put("translatedText", block.translatedText)
                        }
                    }
                    listOf(JSONObject().apply {
                        put("type", "full_page")
                        put("imageBase64", result.firstOrNull()?.optString("imageBase64", "") ?: "")
                        put("textBlocks", JSONArray(textData))
                        put("mode", settings.erasureMode)
                    })
                }
                else -> emptyList()
            }
            sendStatus(pageIndex, "erasure", 100)

            // 4. Send result back to HTML
            val result = JSONObject().apply {
                put("pageIndex", pageIndex)
                put("blocks", JSONArray(translatedBlocks.map { gson.toJson(it) }))
                put("erasureData", JSONArray(erasureData))
                put("settings", gson.toJson(settings))
            }

            sendToWebView("onPageReady", result.toString())
            isProcessing = false

        } catch (e: Exception) {
            Log.e("ComicApp", "Process error", e)
            sendError(pageIndex, e.message ?: "Unknown error")
            isProcessing = false
        }
    }

    private fun requestImageFromJS(pageIndex: Int): String? {
        // HTML should provide image via callback mechanism
        // For now, we expect HTML to send image before calling startProcessing
        // Or we can request it via evaluateJavascript
        var result: String? = null
        val latch = java.util.concurrent.CountDownLatch(1)
        (context as MainActivity).runOnUiThread {
            webView.evaluateJavascript(
                "window.getPageImageBase64($pageIndex)",
                android.webkit.ValueCallback { value ->
                    result = value?.removeSurrounding("\"")?.replace("\\\"", "\"")
                    latch.countDown()
                }
            )
        }
        latch.await(5, java.util.concurrent.TimeUnit.SECONDS)
        return result
    }

    private fun sendStatus(pageIndex: Int, stage: String, progress: Int) {
        val json = JSONObject().apply {
            put("pageIndex", pageIndex)
            put("stage", stage)
            put("progress", progress)
        }
        sendToWebView("onStatusUpdate", json.toString())
    }

    private fun sendError(pageIndex: Int, message: String) {
        val json = JSONObject().apply {
            put("pageIndex", pageIndex)
            put("error", message)
        }
        sendToWebView("onError", json.toString())
    }

    private fun sendWarning(pageIndex: Int, message: String) {
        val json = JSONObject().apply {
            put("pageIndex", pageIndex)
            put("warning", message)
        }
        sendToWebView("onWarning", json.toString())
    }

    private fun sendStopped(pageIndex: Int) {
        val json = JSONObject().apply {
            put("pageIndex", pageIndex)
            put("stopped", true)
        }
        sendToWebView("onStopped", json.toString())
    }

    private fun sendToWebView(functionName: String, data: String) {
        (context as MainActivity).runOnUiThread {
            // JSONObject.quote() ينتج نص JS/JSON آمن (يهرب الاقتباسات والأسطر الجديدة وغيرها)
            // بدل تضمين data مباشرة داخل اقتباس أحادي، لتفادي انكسار الاستدعاء لو النص يحتوي على '
            val safeData = JSONObject.quote(data)
            webView.evaluateJavascript("window.$functionName($safeData)", null)
        }
    }
}
