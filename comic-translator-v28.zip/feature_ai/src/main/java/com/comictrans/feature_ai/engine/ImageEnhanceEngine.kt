package com.comictrans.feature_ai.engine

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.comictrans.engine.ModelManager
import com.comictrans.engine.OpenCVStatus
import com.comictrans.engine.contracts.EnhanceResult
import com.comictrans.engine.contracts.IImageEnhanceEngine
import org.opencv.android.Utils
import org.opencv.core.Mat
import org.opencv.imgproc.Imgproc
import org.tensorflow.lite.Interpreter
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

/**
 * محرك تعزيز الصورة قبل OCR.
 *
 * وضعان:
 *  - "opencv": تحسين كلاسيكي (CLAHE على قناة الإضاءة + شحذ خفيف) — يعمل فوراً بدون أي
 *    ملف خارجي، يرفع تباين النص الضعيف/منخفض الجودة قبل تمريره لمحرك OCR.
 *  - "ai": Real-ESRGAN x2 عبر TFLite — تكبير فعلي بالذكاء الاصطناعي (يحسّن الحروف الدقيقة
 *    والخطوط الرفيعة بشكل أقوى من الطرق الكلاسيكية). البنية الكاملة جاهزة ومُطبَّقة هنا
 *    (تحميل النموذج، المعالجة المسبقة، الاستدلال، المعالجة اللاحقة)، لكنها تحتاج ملف
 *    النموذج الفعلي الذي المستخدم يحمّله بنفسه (غير مرفق بالمشروع، ~5-20MB). لو الملف غير
 *    موجود، نرجع تلقائياً وبشكل واضح بالسجل لتحسين OpenCV بدل الفشل الصامت.
 *
 * ملاحظة مهمة: وضع AI يكبّر أبعاد الصورة (scale=2) فعلياً، فإحداثيات النتائج القادمة من OCR
 * على الصورة المكبّرة يجب قسمتها على [EnhanceResult.scale] قبل استخدامها مع الصورة الأصلية
 * (الطمس/العرض) — هذا يتم في AppInterface.kt بعد استدعاء enhance().
 */
class ImageEnhanceEngine(private val context: Context, private val modelManager: ModelManager) : IImageEnhanceEngine {

    private val TAG = "ImageEnhance"

    override fun enhance(bitmap: Bitmap, method: String): EnhanceResult {
        return when (method) {
            "ai" -> tryAIEnhance(bitmap) ?: run {
                Log.w(TAG, "نموذج Real-ESRGAN (.tflite) غير موجود في مجلد models — رجوع تلقائي لتحسين OpenCV")
                EnhanceResult(enhanceOpenCV(bitmap), 1f)
            }
            else -> EnhanceResult(enhanceOpenCV(bitmap), 1f)
        }
    }

    // ====== تحسين OpenCV كلاسيكي (يعمل فوراً، بدون أي ملف إضافي) ======
    private fun enhanceOpenCV(bitmap: Bitmap): Bitmap {
        if (!OpenCVStatus.isAvailable) {
            Log.w(TAG, "OpenCV غير محمّلة على هذا الجهاز — تعزيز الصورة مُلغى، استخدام الصورة الأصلية")
            return bitmap
        }
        return try {
            val src = Mat()
            Utils.bitmapToMat(bitmap, src)

            val rgb = Mat()
            Imgproc.cvtColor(src, rgb, Imgproc.COLOR_RGBA2RGB)

            // بند 2 (تحسين OCR): تقليل الضوضاء قبل أي تحسين تباين. bilateralFilter يحافظ على
            // حواف الحروف حادة أثناء إزالة تحبب المسح الضوئي/ضوضاء ضغط JPEG — بعكس Gaussian
            // blur العادي اللي يطمس الحواف مع الضوضاء معاً وقد يزيد صعوبة قراءة OCR للنص
            // الدقيق. لازم تُنفَّذ **قبل** CLAHE: لو نفّذناها بعده، CLAHE يكون رفع تباين
            // الضوضاء نفسها (يكبّرها بدل إزالتها) فيصعب حذفها بعدها بفلتر تنعيم عادي.
            // القيم (d=9, sigmaColor=75, sigmaSpace=75) متوازنة تجريبياً: تزيل تحبباً واضحاً
            // بدون تنعيم مفرط يفقد تفاصيل الحروف الرفيعة.
            val denoised = Mat()
            Imgproc.bilateralFilter(rgb, denoised, 9, 75.0, 75.0)

            // نحوّل لـ Lab ونطبّق CLAHE على قناة الإضاءة L بس، عشان نحسّن التباين
            // بدون ما نأثر على الألوان (يفرق عن تحويل رمادي كامل، يحافظ على شكل الكوميك).
            val lab = Mat()
            Imgproc.cvtColor(denoised, lab, Imgproc.COLOR_RGB2Lab)

            val channels = ArrayList<Mat>()
            org.opencv.core.Core.split(lab, channels)

            val clahe = Imgproc.createCLAHE(2.5, org.opencv.core.Size(8.0, 8.0))
            val enhancedL = Mat()
            clahe.apply(channels[0], enhancedL)
            enhancedL.copyTo(channels[0])

            org.opencv.core.Core.merge(channels, lab)
            val enhancedRgb = Mat()
            Imgproc.cvtColor(lab, enhancedRgb, Imgproc.COLOR_Lab2RGB)

            // شحذ خفيف (unsharp mask) يبرز حواف الحروف بعد تحسين التباين
            val blurred = Mat()
            Imgproc.GaussianBlur(enhancedRgb, blurred, org.opencv.core.Size(0.0, 0.0), 3.0)
            val sharpened = Mat()
            org.opencv.core.Core.addWeighted(enhancedRgb, 1.5, blurred, -0.5, 0.0, sharpened)

            val result = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(sharpened, result)

            src.release(); rgb.release(); denoised.release(); lab.release(); enhancedL.release(); enhancedRgb.release()
            blurred.release(); sharpened.release()
            channels.forEach { it.release() }

            result
        } catch (e: Throwable) {
            Log.e(TAG, "فشل تحسين OpenCV — رجعنا الصورة الأصلية بدون تعديل", e)
            bitmap
        }
    }

    // ====== Real-ESRGAN x2 عبر TFLite (بنية كاملة، تحتاج ملف النموذج) ======
    private val MODEL_SCALE = 2 // Real-ESRGAN x2 — يجب يطابق النموذج الفعلي اللي تحطه

    // *** إصلاح: "لا يوجد زر تنزيل" لوضع تعزيز AI ***
    // هذا النموذج (realesrgan-x2.tflite) لم يكن مسجَّلاً إطلاقاً في ModelManager.availableModels
    // — كان مسار الملف هنا مستقلاً تماماً عن نظام إدارة النماذج (⚙️) في الواجهة، فلا توجد أي
    // طريقة للمستخدم لتنزيله من داخل التطبيق (لا AndroidBridge.downloadModel يعرفه، ولا يظهر
    // في شاشة ⚙️ إدارة النماذج). الحل: تسجيله كنموذج "enhance_ai" في ModelManager (نفس آلية
    // ai_lite/ai_pro/paddle_*)، ونقرأ مساره من modelManager.modelFile() بدل بناء المسار يدوياً
    // هنا — هذا يضمن تطابق المسار بين ما تحمّله ModelManager وما يقرأه هذا المحرك دائماً.
    private fun modelFile(): File =
        modelManager.availableModels.find { it.id == "enhance_ai" }
            ?.let { modelManager.modelFile(it) }
            ?: File(context.getExternalFilesDir(null), "models/realesrgan-x2.tflite") // احتياطي فقط

    private fun tryAIEnhance(bitmap: Bitmap): EnhanceResult? {
        val file = modelFile()
        if (!file.exists()) return null

        return try {
            val interpreter = Interpreter(loadModelFile(file))

            // المدخل: NHWC float32 [1, H, W, 3] بمدى 0-255 (تطابقاً مع تحويل ESRGAN الرسمي من TF Hub)
            val w = bitmap.width; val h = bitmap.height
            interpreter.resizeInput(0, intArrayOf(1, h, w, 3))
            interpreter.allocateTensors()

            val inputBuffer = ByteBuffer.allocateDirect(4 * h * w * 3).order(ByteOrder.nativeOrder())
            val pixels = IntArray(w * h)
            bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
            for (p in pixels) {
                inputBuffer.putFloat(((p shr 16) and 0xFF).toFloat()) // R
                inputBuffer.putFloat(((p shr 8) and 0xFF).toFloat())  // G
                inputBuffer.putFloat((p and 0xFF).toFloat())          // B
            }
            inputBuffer.rewind()

            val outW = w * MODEL_SCALE; val outH = h * MODEL_SCALE
            val outputBuffer = ByteBuffer.allocateDirect(4 * outH * outW * 3).order(ByteOrder.nativeOrder())

            interpreter.run(inputBuffer, outputBuffer)
            interpreter.close()

            outputBuffer.rewind()
            val outPixels = IntArray(outW * outH)
            for (i in outPixels.indices) {
                val r = outputBuffer.float.coerceIn(0f, 255f).toInt()
                val g = outputBuffer.float.coerceIn(0f, 255f).toInt()
                val b = outputBuffer.float.coerceIn(0f, 255f).toInt()
                outPixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
            val outBitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
            outBitmap.setPixels(outPixels, 0, outW, 0, 0, outW, outH)

            Log.d(TAG, "Real-ESRGAN: تكبير ${w}x$h → ${outW}x$outH")
            EnhanceResult(outBitmap, MODEL_SCALE.toFloat())
        } catch (e: Throwable) {
            Log.e(TAG, "فشل تشغيل نموذج Real-ESRGAN — رجوع لتحسين OpenCV", e)
            null
        }
    }

    private fun loadModelFile(file: File): MappedByteBuffer {
        val stream = FileInputStream(file)
        val channel = stream.channel
        return channel.map(FileChannel.MapMode.READ_ONLY, 0, file.length())
    }
}
