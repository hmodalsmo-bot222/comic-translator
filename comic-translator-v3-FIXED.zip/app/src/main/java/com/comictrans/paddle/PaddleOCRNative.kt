package com.comictrans.paddle

import android.graphics.Bitmap
import android.util.Log

/** Real Paddle-Lite bridge. The runtime/model pair is prepared automatically by Gradle. */
object PaddleOCRNative {
    init {
        try {
            System.loadLibrary("paddle_light_api_shared")
            System.loadLibrary("comictranspaddle")
        } catch (e: UnsatisfiedLinkError) {
            Log.e("PaddleOCR", "Native libraries unavailable", e)
        }
    }

    external fun init(detModelPath: String, recModelPath: String, dictPath: String): Long
    external fun runOCR(handle: Long, bitmap: Bitmap): String
    external fun release(handle: Long)

    @JvmStatic
    fun isAvailable(): Boolean = try {
        System.loadLibrary("paddle_light_api_shared")
        System.loadLibrary("comictranspaddle")
        true
    } catch (_: Throwable) { false }
}
