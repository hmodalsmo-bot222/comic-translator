#include <jni.h>
#include <android/bitmap.h>
#include <android/log.h>
#include <paddle_api.h>
#include <algorithm>
#include <cmath>
#include <fstream>
#include <memory>
#include <sstream>
#include <string>
#include <vector>
#include <queue>
#include <unordered_map>

#define LOG_TAG "ComicPaddleOCR"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

using paddle::lite_api::MobileConfig;
using paddle::lite_api::PaddlePredictor;
using paddle::lite_api::CreatePaddlePredictor;
using paddle::lite_api::LITE_POWER_HIGH;

struct Box { int x, y, w, h; float score; };

static std::string jstr(JNIEnv* env, jstring s) {
    if (!s) return {};
    const char* p = env->GetStringUTFChars(s, nullptr);
    std::string r = p ? p : "";
    if (p) env->ReleaseStringUTFChars(s, p);
    return r;
}

static std::vector<std::string> loadDict(const std::string& path) {
    std::ifstream f(path);
    std::vector<std::string> d;
    std::string line;
    while (std::getline(f, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        d.push_back(line);
    }
    return d;
}

static bool readBitmap(JNIEnv* env, jobject bitmap, AndroidBitmapInfo& info, void*& pixels) {
    if (AndroidBitmap_getInfo(env, bitmap, &info) != ANDROID_BITMAP_RESULT_SUCCESS) return false;
    if (info.format != ANDROID_BITMAP_FORMAT_RGBA_8888 && info.format != ANDROID_BITMAP_FORMAT_RGB_565) return false;
    return AndroidBitmap_lockPixels(env, bitmap, &pixels) == ANDROID_BITMAP_RESULT_SUCCESS;
}

static void unlockBitmap(JNIEnv* env, jobject bitmap) { AndroidBitmap_unlockPixels(env, bitmap); }

static inline void rgbAt(const AndroidBitmapInfo& info, const void* pixels, int x, int y, float& r, float& g, float& b) {
    if (info.format == ANDROID_BITMAP_FORMAT_RGBA_8888) {
        const uint8_t* row = static_cast<const uint8_t*>(pixels) + y * info.stride;
        const uint8_t* p = row + x * 4;
        r = p[0]; g = p[1]; b = p[2];
    } else {
        const uint16_t* row = reinterpret_cast<const uint16_t*>(static_cast<const uint8_t*>(pixels) + y * info.stride);
        uint16_t v = row[x];
        r = ((v >> 11) & 31) * 255.0f / 31.0f;
        g = ((v >> 5) & 63) * 255.0f / 63.0f;
        b = (v & 31) * 255.0f / 31.0f;
    }
}

static std::vector<float> makeNchw(const AndroidBitmapInfo& info, const void* pixels, int outW, int outH) {
    std::vector<float> data(3ull * outW * outH);
    const float mean[3] = {0.485f, 0.456f, 0.406f};
    const float invStd[3] = {1.0f/0.229f, 1.0f/0.224f, 1.0f/0.225f};
    for (int y = 0; y < outH; ++y) {
        int sy = std::min(info.height - 1, std::max(0, (int)std::floor((y + 0.5) * info.height / (double)outH)));
        for (int x = 0; x < outW; ++x) {
            int sx = std::min(info.width - 1, std::max(0, (int)std::floor((x + 0.5) * info.width / (double)outW)));
            float r,g,b; rgbAt(info,pixels,sx,sy,r,g,b);
            size_t i = (size_t)y*outW+x;
            data[i] = (r/255.0f-mean[0])*invStd[0];
            data[(size_t)outW*outH+i] = (g/255.0f-mean[1])*invStd[1];
            data[2ull*outW*outH+i] = (b/255.0f-mean[2])*invStd[2];
        }
    }
    return data;
}

static std::vector<float> cropNchw(const AndroidBitmapInfo& info, const void* pixels, const Box& box, int outH, int outW) {
    std::vector<float> data(3ull*outW*outH);
    const float mean[3] = {0.485f,0.456f,0.406f};
    const float invStd[3] = {1.f/0.229f,1.f/0.224f,1.f/0.225f};
    int x0=std::max(0,box.x), y0=std::max(0,box.y), x1=std::min((int)info.width,box.x+box.w), y1=std::min((int)info.height,box.y+box.h);
    int cw=std::max(1,x1-x0), ch=std::max(1,y1-y0);
    for(int y=0;y<outH;y++){
        int sy=y0+std::min(ch-1,(int)((y+0.5)*ch/outH));
        for(int x=0;x<outW;x++){
            int sx=x0+std::min(cw-1,(int)((x+0.5)*cw/outW));
            float r,g,b; rgbAt(info,pixels,sx,sy,r,g,b); size_t i=(size_t)y*outW+x;
            data[i]=(r/255.f-mean[0])*invStd[0];
            data[(size_t)outW*outH+i]=(g/255.f-mean[1])*invStd[1];
            data[2ull*outW*outH+i]=(b/255.f-mean[2])*invStd[2];
        }
    }
    return data;
}

static std::vector<Box> detect(PaddlePredictor* predictor, const AndroidBitmapInfo& info, const void* pixels) {
    int maxSide = 960;
    float scale = std::min(1.0f, maxSide / (float)std::max(info.width, info.height));
    int w = std::max(32, (int)std::round(info.width * scale));
    int h = std::max(32, (int)std::round(info.height * scale));
    w = (w + 31) / 32 * 32; h = (h + 31) / 32 * 32;
    auto inputData = makeNchw(info,pixels,w,h);
    auto input = predictor->GetInput(0); input->Resize({1,3,h,w}); input->SetData<float>(inputData.data(), inputData.size()); predictor->Run();
    auto out = predictor->GetOutput(0); auto shape = out->shape();
    if (shape.size() < 4) return {};
    int oh=(int)shape[shape.size()-2], ow=(int)shape[shape.size()-1];
    const float* prob=out->data<float>();
    std::vector<uint8_t> seen((size_t)oh*ow,0);
    std::vector<Box> boxes;
    const float threshold=0.30f;
    for(int y=0;y<oh;y++) for(int x=0;x<ow;x++){
        int idx=y*ow+x; if(seen[idx] || prob[idx] < threshold) continue;
        std::queue<std::pair<int,int>> q; q.push({x,y}); seen[idx]=1;
        int minx=x,maxx=x,miny=y,maxy=y,count=0; float sum=0;
        while(!q.empty()){
            auto [cx,cy]=q.front();q.pop(); int ci=cy*ow+cx; count++; sum+=prob[ci];
            minx=std::min(minx,cx);maxx=std::max(maxx,cx);miny=std::min(miny,cy);maxy=std::max(maxy,cy);
            const int dx[4]={1,-1,0,0},dy[4]={0,0,1,-1};
            for(int k=0;k<4;k++){int nx=cx+dx[k],ny=cy+dy[k];if(nx<0||ny<0||nx>=ow||ny>=oh)continue;int ni=ny*ow+nx;if(!seen[ni]&&prob[ni]>=threshold){seen[ni]=1;q.push({nx,ny});}}
        }
        int bw=maxx-minx+1,bh=maxy-miny+1;
        if(count < 3 || bw<2 || bh<2) continue;
        float sx=info.width/(float)ow, sy=info.height/(float)oh;
        int bx=std::max(0,(int)(minx*sx-2)), by=std::max(0,(int)(miny*sy-2));
        int bx2=std::min((int)info.width,(int)((maxx+1)*sx+2)), by2=std::min((int)info.height,(int)((maxy+1)*sy+2));
        boxes.push_back({bx,by,bx2-bx,by2-by,sum/count});
    }
    // Merge very close horizontal components so one speech bubble does not explode into many tiny boxes.
    std::sort(boxes.begin(),boxes.end(),[](const Box&a,const Box&b){return a.y<b.y;});
    std::vector<Box> merged;
    for(const auto& b:boxes){ bool done=false; for(auto& m:merged){int gap=std::max(0,std::max(m.x,b.x)-std::min(m.x+m.w,b.x+b.w));int ygap=std::max(0,std::max(m.y,b.y)-std::min(m.y+m.h,b.y+b.h));int minH=std::min(m.h,b.h);if(gap<=std::max(12,minH/2)&&ygap<=std::max(24,minH*2)){int x1=std::min(m.x,b.x),y1=std::min(m.y,b.y),x2=std::max(m.x+m.w,b.x+b.w),y2=std::max(m.y+m.h,b.y+b.h);m={x1,y1,x2-x1,y2-y1,std::max(m.score,b.score)};done=true;break;}} if(!done)merged.push_back(b); }
    return merged;
}

static std::string decodeRec(PaddlePredictor* predictor, const std::vector<float>& inputData, int w, const std::vector<std::string>& dict) {
    auto input=predictor->GetInput(0); input->Resize({1,3,32,w}); input->SetData<float>(inputData.data(),inputData.size()); predictor->Run(); auto out=predictor->GetOutput(0); auto shape=out->shape(); if(shape.size()<3)return "";
    int T=(int)shape[shape.size()-2], C=(int)shape[shape.size()-1]; const float* p=out->data<float>(); std::string text; int last=-1;
    for(int t=0;t<T;t++){int best=0;float bv=p[t*C];for(int c=1;c<C;c++)if(p[t*C+c]>bv){bv=p[t*C+c];best=c;} if(best!=0&&best!=last&&best-1<(int)dict.size())text+=dict[best-1]; last=best;}
    return text;
}

struct Engine { std::shared_ptr<PaddlePredictor> det, rec; std::vector<std::string> dict; };


extern "C" JNIEXPORT jlong JNICALL
Java_com_comictrans_paddle_PaddleOCRNative_init(JNIEnv* env, jobject, jstring detPath, jstring recPath, jstring dictPath) {
    try {
        MobileConfig dc;
        dc.set_model_from_file(jstr(env, detPath));
        dc.set_threads(4);
        dc.set_power_mode(LITE_POWER_HIGH);
        MobileConfig rc;
        rc.set_model_from_file(jstr(env, recPath));
        rc.set_threads(4);
        rc.set_power_mode(LITE_POWER_HIGH);
        auto* e = new Engine();
        e->det = CreatePaddlePredictor<MobileConfig>(dc);
        e->rec = CreatePaddlePredictor<MobileConfig>(rc);
        e->dict = loadDict(jstr(env, dictPath));
        if (!e->det || !e->rec || e->dict.empty()) { delete e; return 0; }
        return reinterpret_cast<jlong>(e);
    } catch (const std::exception& ex) {
        LOGE("init failed: %s", ex.what());
        return 0;
    }
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_comictrans_paddle_PaddleOCRNative_runOCR(JNIEnv* env, jobject, jlong handle, jobject bitmap) {
    if (!handle || !bitmap) return env->NewStringUTF("[]");
    Engine* e = reinterpret_cast<Engine*>(handle);
    AndroidBitmapInfo info{}; void* pixels = nullptr;
    if (!readBitmap(env, bitmap, info, pixels)) return env->NewStringUTF("[]");
    try {
        auto boxes = detect(e->det.get(), info, pixels);
        std::ostringstream json;
        json << "[";
        bool first = true;
        for (const auto& b : boxes) {
            int rw = std::max(32, std::min(320, (int)std::round(b.w * 32.0 / std::max(1, b.h))));
            auto recData = cropNchw(info, pixels, b, 32, rw);
            std::string text = decodeRec(e->rec.get(), recData, rw, e->dict);
            if (text.empty()) continue;
            if (!first) json << ",";
            first = false;
            // Escape the small set of JSON characters that can occur in decoded text.
            std::string esc;
            for (char c : text) { if (c=='\\') esc += "\\\\"; else if(c=='\"') esc += "\\\""; else if(c=='\n') esc += "\\n"; else esc += c; }
            json << "{\"text\":\"" << esc << "\",\"box\":[[" << b.x << "," << b.y << "],[" << b.x+b.w << "," << b.y << "],[" << b.x+b.w << "," << b.y+b.h << "],[" << b.x << "," << b.y+b.h << "]],\"score\":" << b.score << "}";
        }
        json << "]";
        unlockBitmap(env, bitmap);
        return env->NewStringUTF(json.str().c_str());
    } catch (const std::exception& ex) {
        LOGE("OCR failed: %s", ex.what());
        unlockBitmap(env, bitmap);
        return env->NewStringUTF("[]");
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_comictrans_paddle_PaddleOCRNative_release(JNIEnv*, jobject, jlong handle) {
    delete reinterpret_cast<Engine*>(handle);
}
