هذه النسخة تحافظ على المشروع داخل ZIP ولا تتطلب رفع ملفات المشروع منفصلة.
الإصلاح الأساسي داخل app/build.gradle: إذا لم تكن ملفات Paddle موجودة، Gradle يشغّل
scripts/ensure_paddle.sh تلقائياً قبل البناء. لذلك حتى لو كان الـworkflow الخارجي
يفك ZIP ثم يشغّل Gradle مباشرة، لن يصل إلى preparePaddleLite بملفات ناقصة.
