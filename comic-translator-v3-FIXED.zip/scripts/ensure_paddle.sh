#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PADDLE_DIR="$ROOT/app/.paddle"
PADDLE_ROOT="$PADDLE_DIR/inference_lite_lib.android.armv8"
ASSETS="$ROOT/app/src/main/assets/paddle"

mkdir -p "$PADDLE_DIR" "$ASSETS"

have_runtime() {
  test -s "$PADDLE_ROOT/cxx/include/paddle_api.h" &&
  test -s "$PADDLE_ROOT/cxx/lib/libpaddle_light_api_shared.so"
}

if ! have_runtime; then
  echo "==> Downloading official Paddle-Lite 2.10 Android ARMv8 runtime"

  asset_name='inference_lite_lib.android.armv8.gcc.c++_shared.with_extra.with_cv.tar.gz'
  api_url='https://api.github.com/repos/PaddlePaddle/Paddle-Lite/releases/tags/v2.10'
  api_json="$PADDLE_DIR/release.json"

  curl -fL --retry 8 --retry-all-errors --retry-delay 3 \
    --connect-timeout 30 --max-time 300 \
    -H 'Accept: application/vnd.github+json' \
    -H 'X-GitHub-Api-Version: 2022-11-28' \
    -o "$api_json" "$api_url"

  test -s "$api_json"

  asset_url="$(python3 - "$api_json" "$asset_name" <<'PY'
import json, sys
data=json.load(open(sys.argv[1], encoding="utf-8"))
name=sys.argv[2]
for a in data.get("assets", []):
    if a.get("name")==name:
        print(a["browser_download_url"])
        break
else:
    raise SystemExit("Official Paddle-Lite v2.10 ARMv8 asset was not found")
PY
)"

  test -n "$asset_url"

  archive="$PADDLE_DIR/$asset_name"
  curl -fL --retry 10 --retry-all-errors --retry-delay 3 \
    --connect-timeout 30 --max-time 1200 \
    -o "$archive" "$asset_url"

  test -s "$archive"
  tar -tzf "$archive" >/dev/null

  rm -rf "$PADDLE_ROOT"
  tar -xzf "$archive" -C "$PADDLE_DIR"
  rm -f "$archive" "$api_json"
fi

download() {
  local url="$1"
  local dest="$2"
  if ! test -s "$dest"; then
    echo "==> Downloading $(basename "$dest")"
    curl -fL --retry 10 --retry-all-errors --retry-delay 2 \
      --connect-timeout 30 --max-time 1200 \
      -o "$dest" "$url"
  fi
  test -s "$dest"
}

download 'https://paddleocr.bj.bcebos.com/PP-OCRv2/lite/ch_PP-OCRv2_det_slim_opt.nb' \
  "$ASSETS/det.nb"
download 'https://paddleocr.bj.bcebos.com/PP-OCRv2/lite/ch_PP-OCRv2_rec_slim_opt.nb' \
  "$ASSETS/rec.nb"
download 'https://paddleocr.bj.bcebos.com/PP-OCRv2/lite/ch_ppocr_mobile_v2.0_cls_slim_opt.nb' \
  "$ASSETS/cls.nb"
download 'https://raw.githubusercontent.com/PaddlePaddle/PaddleOCR/main/ppocr/utils/ppocr_keys_v1.txt' \
  "$ASSETS/ppocr_keys_v1.txt"

test -s "$PADDLE_ROOT/cxx/include/paddle_api.h"
test -s "$PADDLE_ROOT/cxx/lib/libpaddle_light_api_shared.so"
test -s "$ASSETS/det.nb"
test -s "$ASSETS/rec.nb"
test -s "$ASSETS/cls.nb"
test -s "$ASSETS/ppocr_keys_v1.txt"

echo "==> PaddleOCR Lite inputs are ready."
