# PaddleOCR Lite integration

The project uses the official Paddle-Lite 2.10 Android arm64 runtime and the official PP-OCRv2 slim `.nb` models.

## GitHub Actions build

The workflow prepares everything before Gradle starts:

1. Downloads the official Paddle-Lite 2.10 arm64 release asset through the authenticated GitHub CLI.
2. Extracts `inference_lite_lib.android.armv8/`.
3. Downloads the official PP-OCRv2 slim detector/recognizer/classifier models.
4. Retrieves the PaddleOCR `ppocr_keys_v1.txt` dictionary through the GitHub API.
5. Builds the Android debug APK with Gradle 8.4.

This avoids the previous raw GitHub release-asset download failure/rate-limit problem.

OCR inference in the resulting APK is local/offline; the OCR models are packaged into the APK and are not downloaded at runtime.

The project is intentionally `arm64-v8a` only.
