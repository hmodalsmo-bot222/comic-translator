package com.comictrans.engine

import android.content.Context
import android.util.Log
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.nl.languageid.LanguageIdentification
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class TranslationEngine(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val languageIdentifier = LanguageIdentification.getClient()

    // Auto-detect language
    suspend fun detectLanguage(text: String): String = withContext(Dispatchers.IO) {
        try {
            // FIX: مهلة احترازية حتى لا يعلق الطلب للأبد إذا لم يستدعِ ML Kit أي رد.
            kotlinx.coroutines.withTimeoutOrNull(15_000) {
                suspendCancellableCoroutine<String> { continuation ->
                    languageIdentifier.identifyLanguage(text)
                        .addOnSuccessListener { languageCode ->
                            val code = when (languageCode) {
                                "und" -> "en" // undefined -> default to English
                                "ar" -> "ar"
                                "ja" -> "ja"
                                "ko" -> "ko"
                                "zh" -> "zh"
                                "fr" -> "fr"
                                "de" -> "de"
                                "es" -> "es"
                                "it" -> "it"
                                "ru" -> "ru"
                                "pt" -> "pt"
                                else -> "en"
                            }
                            if (continuation.isActive) continuation.resume(code)
                        }
                        .addOnFailureListener { e ->
                            Log.e("LangDetect", "Error detecting language", e)
                            if (continuation.isActive) continuation.resume("en")
                        }
                }
            } ?: "en"
        } catch (e: Exception) {
            Log.e("LangDetect", "Error", e)
            "en"
        }
    }

    // 1. ML Kit Translation
    suspend fun translateMLKit(
        text: String, source: String, target: String,
        onError: (String) -> Unit = {}
    ): String = withContext(Dispatchers.IO) {
        try {
            val actualSource = if (source == "auto") detectLanguage(text) else source

            val options = TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.fromLanguageTag(actualSource) ?: TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.fromLanguageTag(target) ?: TranslateLanguage.ARABIC)
                .build()
            val translator = Translation.getClient(options)

            // FIX: كان الشرط requireWifi() يعلّق التحميل للأبد إذا الجهاز غير متصل
            // بشبكة WiFi (مثل بيانات الجوال) — يسمح الآن بالتحميل عبر أي شبكة،
            // ومع timeout احترازي حتى لا يعلق الطلب مهما كان السبب.
            val downloaded = kotlinx.coroutines.withTimeoutOrNull(45_000) {
                suspendCancellableCoroutine<Unit> { continuation ->
                    val conditions = DownloadConditions.Builder().build()
                    translator.downloadModelIfNeeded(conditions)
                        .addOnSuccessListener { if (continuation.isActive) continuation.resume(Unit) }
                        .addOnFailureListener { if (continuation.isActive) continuation.resumeWithException(it) }
                }
            }
            if (downloaded == null) {
                Log.e("MLKitTrans", "Timeout downloading translation model")
                onError("ML Kit: انتهت المهلة أثناء تحميل نموذج الترجمة (تحقق من الاتصال بالإنترنت)")
                return@withContext text
            }

            kotlinx.coroutines.withTimeoutOrNull(30_000) {
                suspendCancellableCoroutine<String> { continuation ->
                    translator.translate(text)
                        .addOnSuccessListener { if (continuation.isActive) continuation.resume(it) }
                        .addOnFailureListener { if (continuation.isActive) continuation.resumeWithException(it) }
                }
            } ?: run { onError("ML Kit: انتهت مهلة الترجمة"); text }
        } catch (e: Exception) {
            Log.e("MLKitTrans", "Error", e)
            onError("ML Kit: ${e.message ?: "خطأ غير معروف"}")
            text
        }
    }

    // 2. Google Translate (with auto-detect)
    suspend fun translateGoogle(
        text: String, source: String, target: String,
        onError: (String) -> Unit = {}
    ): String = withContext(Dispatchers.IO) {
        try {
            val src = if (source == "auto") "auto" else source
            val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=${src}&tl=${target}&dt=t&q=${URLEncoder.encode(text, "UTF-8")}"
            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()
            val body = response.body?.string()
            if (body == null) {
                onError("Google Translate: لا يوجد رد من الخادم")
                return@withContext text
            }
            if (!response.isSuccessful) {
                onError("Google Translate فشل (HTTP ${response.code}) — قد يكون محظوراً مؤقتاً من قبل Google، جرّب محرك ترجمة آخر")
                return@withContext text
            }

            val jsonArray = org.json.JSONArray(body)
            val sentences = jsonArray.getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until sentences.length()) {
                val sentence = sentences.getJSONArray(i)
                sb.append(sentence.getString(0))
            }
            val result = sb.toString()
            if (result.isBlank()) onError("Google Translate: رجع نص فارغ")
            result
        } catch (e: Exception) {
            Log.e("GoogleTrans", "Error", e)
            onError("Google Translate: ${e.message ?: "خطأ غير معروف"}")
            text
        }
    }

    // Helper: يستخرج رسالة خطأ مقروءة من رد API فاشل (Gemini/OpenAI/DeepL بأشكال مختلفة)
    private fun extractApiError(body: String?, httpCode: Int): String {
        if (body.isNullOrBlank()) return "HTTP $httpCode — لا يوجد تفاصيل"
        return try {
            val json = JSONObject(body)
            val errObj = json.optJSONObject("error")
            val msg = errObj?.optString("message")?.takeIf { it.isNotBlank() }
                ?: json.optString("message").takeIf { it.isNotBlank() }
                ?: body.take(200)
            "HTTP $httpCode — $msg"
        } catch (e: Exception) {
            "HTTP $httpCode — ${body.take(200)}"
        }
    }

    // 3. Gemini (with auto-detect)
    suspend fun translateGemini(
        text: String, source: String, target: String, apiKey: String, model: String,
        onError: (String) -> Unit = {}
    ): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) { onError("Gemini: لم يتم إدخال مفتاح API"); return@withContext text }
        try {
            val detectedLang = if (source == "auto") detectLanguage(text) else source
            val targetName = if (target == "ar") "Arabic" else target
            val sourceName = if (detectedLang == "en") "English" else detectedLang

            val prompt = "Translate this $sourceName comic text into $targetName naturally. Return only the translation:\n\n$text"
            val jsonBody = JSONObject().apply {
                put("contents", org.json.JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", org.json.JSONArray().apply {
                            put(JSONObject().put("text", prompt))
                        })
                    })
                })
            }
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()
            val response = client.newCall(request).execute()
            val body = response.body?.string()
            if (!response.isSuccessful || body == null) {
                onError("Gemini فشل: ${extractApiError(body, response.code)}")
                return@withContext text
            }
            val json = JSONObject(body)
            val candidates = json.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                onError("Gemini: لم يرجع أي نتيجة — ${json.optString("promptFeedback", body.take(150))}")
                return@withContext text
            }
            candidates.getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                .getString("text").trim()
        } catch (e: Exception) {
            Log.e("Gemini", "Error", e)
            onError("Gemini: ${e.message ?: "خطأ غير معروف"}")
            text
        }
    }

    // 4. OpenAI (with auto-detect)
    suspend fun translateOpenAI(
        text: String, source: String, target: String, apiKey: String, model: String,
        onError: (String) -> Unit = {}
    ): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) { onError("OpenAI: لم يتم إدخال مفتاح API"); return@withContext text }
        try {
            val detectedLang = if (source == "auto") detectLanguage(text) else source
            val targetName = if (target == "ar") "Arabic" else target
            val sourceName = if (detectedLang == "en") "English" else detectedLang

            val prompt = "Translate this $sourceName comic text into $targetName naturally. Return only the translation:\n\n$text"
            val jsonBody = JSONObject().apply {
                put("model", model)
                put("messages", org.json.JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "user")
                        put("content", prompt)
                    })
                })
                put("temperature", 0.3)
            }
            val request = Request.Builder()
                .url("https://api.openai.com/v1/chat/completions")
                .header("Authorization", "Bearer $apiKey")
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()
            val response = client.newCall(request).execute()
            val body = response.body?.string()
            if (!response.isSuccessful || body == null) {
                onError("OpenAI فشل: ${extractApiError(body, response.code)}")
                return@withContext text
            }
            val json = JSONObject(body)
            val choices = json.optJSONArray("choices")
            if (choices == null || choices.length() == 0) {
                onError("OpenAI: لم يرجع أي نتيجة — ${body.take(150)}")
                return@withContext text
            }
            choices.getJSONObject(0)
                .getJSONObject("message").getString("content").trim()
        } catch (e: Exception) {
            Log.e("OpenAI", "Error", e)
            onError("OpenAI: ${e.message ?: "خطأ غير معروف"}")
            text
        }
    }

    // 5. DeepL (with auto-detect)
    suspend fun translateDeepL(
        text: String, source: String, target: String, apiKey: String,
        onError: (String) -> Unit = {}
    ): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) { onError("DeepL: لم يتم إدخال مفتاح API"); return@withContext text }
        try {
            val src = if (source == "auto") "" else "&source_lang=${source.uppercase()}"
            val body = "text=${URLEncoder.encode(text, "UTF-8")}&target_lang=${target.uppercase()}$src"
            val request = Request.Builder()
                .url("https://api-free.deepl.com/v2/translate")
                .header("Authorization", "DeepL-Auth-Key $apiKey")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .post(body.toRequestBody("application/x-www-form-urlencoded".toMediaType()))
                .build()
            val response = client.newCall(request).execute()
            val resBody = response.body?.string()
            if (!response.isSuccessful || resBody == null) {
                onError("DeepL فشل: ${extractApiError(resBody, response.code)} — تأكد إن المفتاح من نوع Free API (ينتهي بـ :fx) إذا تستخدم رابط api-free")
                return@withContext text
            }
            val json = JSONObject(resBody)
            val translations = json.optJSONArray("translations")
            if (translations == null || translations.length() == 0) {
                onError("DeepL: لم يرجع أي نتيجة — ${resBody.take(150)}")
                return@withContext text
            }
            translations.getJSONObject(0).getString("text")
        } catch (e: Exception) {
            Log.e("DeepL", "Error", e)
            onError("DeepL: ${e.message ?: "خطأ غير معروف"}")
            text
        }
    }
}
