package com.comictrans.engine

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.ZipInputStream

data class ModelInfo(
    val id: String,          // يطابق قيمة erasureMode: "ai_lite" أو "ai_pro"، أو أحد ملفات
                              // PaddleOCR Lite: "paddle_det" / "paddle_rec" / "paddle_cls" / "paddle_dict"
    val displayName: String,
    val fileName: String,
    val url: String,         // فارغ = لا يوجد رابط تنزيل رسمي معروف؛ يحتاج المستخدم يوفّر رابط بديل
    val approxSizeMB: Int,
    val sha256: String? = null,
    // حد أدنى لحجم الملف (بايت) لاعتباره "محمّلاً بنجاح" — منخفض لملفات PaddleOCR الصغيرة
    // نسبياً (القاموس نص عادي بضع كيلوبايت فقط، cls.nb صغير أيضاً) بدل الحد الافتراضي
    // 1MB المناسب فقط لنماذج AI Lite/Pro الكبيرة.
    val minValidBytes: Long = 1_000_000L,
    // 🔍 (أُضيف 2026-08-15، بحث فعلي مباشر لحظة الكتابة): لو الرابط أعلاه يشير لملف .zip
    // (مثل حالة EasyOCR الحالية — راجع تعليق EasyOCR أدناه لسبب هذا)، هذا الحقل يحدد جزءاً
    // نصياً (بدون حساسية لحالة الأحرف) يُطابَق بمقارنة "يحتوي على" ضد أسماء الملفات **داخل**
    // الـzip بعد التنزيل — أول تطابق يُستخرَج ليصبح هو fileName النهائي، والباقي يُهمَل.
    // استخدام "يحتوي على" بدل اسم دقيق كامل مقصود: يتحمّل تغييرات تسمية بسيطة محتملة داخل
    // الأرشيف (حرف كبير/صغير، بادئة/لاحقة) بدل الاعتماد على اسم حرفي دقيق لم يُتحقَّق منه
    // بالضبط (لا توجد وسيلة فعلية بهذه الجلسة لفتح الـzip وقراءة أسماء الملفات بداخله فعلياً —
    // فقط تأكيد رسمي أن الرابط نفسه صحيح وأن الملف المطلوب موجود بداخله وفق توثيق Qualcomm).
    val zipEntryContains: String? = null
)

/** حالة تنزيل نموذج واحد — تطابق مواصفة "Download State Management". */
enum class DownloadState { NONE, DOWNLOADING, PAUSED, VERIFYING, COMPLETED, FAILED }

/** تحديث لحظي عن تقدّم/حالة تنزيل نموذج، يُرسَل عبر onUpdate في startDownload(). */
data class DownloadStatus(
    val modelId: String,
    val state: DownloadState,
    val progressPct: Int = 0,
    val message: String? = null
)

/**
 * يدير تنزيل/تخزين/التحقق من نماذج الطمس بالذكاء الاصطناعي (AI Lite / AI Pro) وملفات
 * PaddleOCR وتعزيز الصورة. الملفات تُخزَّن في: <external-files>/models/
 *
 * يدعم:
 * - **Resume Download**: لو توقف التنزيل (إغلاق التطبيق، انقطاع شبكة، Pause يدوي)، يُكمَل
 *   من آخر بايت مكتوب فعلياً في ملف .part عبر HTTP Range، بدل إعادة التنزيل من الصفر.
 *   لو رفض الخادم Range (رجع 200 كامل بدل 206 Partial Content)، يُكتشَف ذلك تلقائياً
 *   ويُعاد الكتابة من الصفر بأمان بدل ملف تالف بترقيع خاطئ.
 * - **Download State Management**: كل نموذج له حالة صريحة NONE/DOWNLOADING/PAUSED/
 *   VERIFYING/COMPLETED/FAILED عبر stateOf(modelId)، بدل الاعتماد فقط على وجود/عدم وجود
 *   الملف على القرص.
 * - **منع التنزيل المكرر**: startDownload() لنموذج قيد التنزيل فعلاً لا يبدأ نسخة ثانية
 *   (activeJobs)، وحتى مع سباق نادر، قفل Mutex مستقل لكل معرّف نموذج يمنع كتابتين متزامنتين
 *   لنفس الملف.
 * - **التحقق من سلامة الملف**: بعد اكتمال الكتابة الكاملة (وليس أثناءها — حتى يعمل بشكل
 *   صحيح مع الاستئناف الجزئي)، يُتحقَّق من الحجم الأدنى، ثم SHA256 إن كان معروفاً.
 *
 * مصدر AI Pro (ONNX): Carve/LaMa-ONNX على Hugging Face (lama_fp32.onnx) — نموذج LaMa
 * الأصلي محوّل لـ ONNX، مرخّص Apache-2.0، حجمه ~208MB، مُدخلاته: image float32[1,3,512,512]
 * (RGB مقسومة على 255) + mask float32[1,1,512,512] (1=امسح، 0=أبقِ)، ومُخرجه صورة RGB
 * [0..255] جاهزة مباشرة بنفس المقاس. هذا معروف وموثّق من صفحة النموذج، وتم التحقق منه.
 *
 * مصدر AI Lite (TFLite) — تحديث بعد بحث فعلي (2026-08-15): وُجد تصدير TFLite حقيقي لعائلة
 * LaMa منشور علناً بدون تسجيل دخول: qualcomm/LaMa-Dilated على Hugging Face (رابط resolve
 * مباشر أدناه، 183MB، رخصة "other" من Qualcomm AI Hub — راجع صفحة النموذج للتفاصيل الكاملة).
 * ⚠️ تنبيه صريح: هذا تصدير من خط أنابيب qai_hub_models الخاص بـQualcomm، **ليس** نفس
 * تصدير Carve/LaMa-ONNX المستخدم لـ"ai_pro" أعلاه — قد يختلف ترتيب/شكل المُدخلات (NHWC مقابل
 * NCHW، حجم مُدخل ثابت مختلف عن 512×512، أو مُدخل واحد مدمج صورة+قناع بدل مُدخلين منفصلين)
 * عن ما يفترضه inpaintTFLite() الحالي في ErasureEngine.kt (مبني على مواصفة ai_pro). **لم
 * يُختبَر التوافق فعلياً بهذه البيئة** (بدون Android SDK ولا إنترنت) — بعد التنزيل الفعلي على
 * جهاز حقيقي، تحقق من شكل مُدخلات/مُخرجات النموذج (مثلاً عبر Interpreter.getInputTensor)
 * وعدّل ErasureEngine.inpaintTFLite لو اختلفت عن الافتراض الحالي. لو الملف لا يعمل، احذفه
 * وأضف رابطاً بديلاً عبر setCustomUrl كما كان متاحاً دائماً.
 */
class ModelManager(private val context: Context) {

    private val TAG = "ModelManager"
    private val client = OkHttpClient.Builder().build()

    private val modelsDir: File by lazy {
        File(context.getExternalFilesDir(null), "models").apply { mkdirs() }
    }

    // ملفات PaddleOCR Lite (det/rec/cls/dict) تُخزَّن في مجلد فرعي مستقل حتى نستطيع تمرير
    // مساره كاملاً لمكتبة paddleocr4android عبر OcrConfig.modelPath (المكتبة تفهم أي مسار
    // يبدأ بـ "/" كمسار مباشر على تخزين الجهاز بدل مجلد assets داخل الحزمة — موثّق في
    // doc/paddlelite.md الخاص بالمكتبة). راجع OCREngine.recognizePaddleLite لتفاصيل الاستخدام.
    val paddleModelsDir: File by lazy {
        File(modelsDir, "paddle").apply { mkdirs() }
    }

    // روابط قابلة للتعديل من المستخدم (تُخزَّن في SharedPreferences) — تسمح بإضافة نموذج
    // TFLite بديل لـ AI Lite لو ما توفر رابط رسمي، أو استبدال رابط AI Pro لو تغيّر.
    private val prefs by lazy { context.getSharedPreferences("model_urls", Context.MODE_PRIVATE) }

    val availableModels: List<ModelInfo>
        get() = listOf(
            ModelInfo(
                id = "ai_pro",
                displayName = "AI Pro (ONNX — LaMa)",
                fileName = "lama-pro.onnx",
                url = prefs.getString("url_ai_pro", DEFAULT_ONNX_URL) ?: DEFAULT_ONNX_URL,
                approxSizeMB = 208,
                sha256 = "1faef5301d78db7dda502fe59966957ec4b79dd64e16f03ed96913c7a4eb68d6"
            ),
            ModelInfo(
                id = "ai_lite",
                displayName = "AI Lite (TFLite)",
                fileName = "lama-lite.tflite",
                url = prefs.getString("url_ai_lite", DEFAULT_AI_LITE_URL) ?: DEFAULT_AI_LITE_URL,
                approxSizeMB = 183
            ),
            ModelInfo(
                id = "paddle_det",
                displayName = "PaddleOCR — DET (كشف النص)",
                fileName = "det.nb",
                url = prefs.getString("url_paddle_det", DEFAULT_PADDLE_DET_URL) ?: DEFAULT_PADDLE_DET_URL,
                approxSizeMB = 3,
                minValidBytes = 50_000L
            ),
            ModelInfo(
                id = "paddle_rec",
                displayName = "PaddleOCR — REC (التعرف على النص)",
                fileName = "rec.nb",
                url = prefs.getString("url_paddle_rec", DEFAULT_PADDLE_REC_URL) ?: DEFAULT_PADDLE_REC_URL,
                approxSizeMB = 10,
                minValidBytes = 50_000L
            ),
            ModelInfo(
                id = "paddle_cls",
                displayName = "PaddleOCR — CLS (اتجاه النص)",
                fileName = "cls.nb",
                url = prefs.getString("url_paddle_cls", DEFAULT_PADDLE_CLS_URL) ?: DEFAULT_PADDLE_CLS_URL,
                approxSizeMB = 1,
                minValidBytes = 10_000L
            ),
            ModelInfo(
                id = "paddle_dict",
                displayName = "PaddleOCR — قاموس الرموز (dict)",
                fileName = "ppocr_keys_v1.txt",
                url = prefs.getString("url_paddle_dict", DEFAULT_PADDLE_DICT_URL) ?: DEFAULT_PADDLE_DICT_URL,
                approxSizeMB = 1,
                minValidBytes = 1_000L
            ),
            // ⭐ EasyOCR — تصحيح ثانٍ وأعمق (2026-08-15، جلسة رابعة، فحص حي فعلي لحظة الكتابة
            // عبر جلب صفحة qualcomm/EasyOCR الحقيقية الآن، لا نتيجة بحث مخزَّنة/قديمة):
            // ⚠️ الإصلاح السابق (تصحيح "جذري" بتاريخ اليوم نفسه أعلاه) كان صحيحاً **وقت كتابته
            // فقط** — Qualcomm غيّرت طريقة التوزيع بالكامل منذ ذلك الحين (المستودع الآن على
            // v0.60.0، آخر تحديث "قبل أيام" وقت هذا التصحيح). تحققت الآن مباشرة: جذر مستودع
            // qualcomm/EasyOCR **لم يعد يحتوي أي ملف .tflite مباشر إطلاقاً** — فقط
            // .gitattributes/LICENSE/README.md/release_assets.json. قرأت release_assets.json
            // نفسه (JSON رسمي من Qualcomm، لا تخمين): يشير لملف zip واحد مُستضاف على S3 يحوي
            // كلا الملفين معاً:
            // https://qaihub-public-assets.s3.us-west-2.amazonaws.com/qai-hub-models/models/easyocr/releases/v0.60.0/easyocr-tflite-float.zip
            // هذا النمط (ملفات .tflite الفردية على HF تُستبدَل دورياً بحزمة S3 واحدة) هو نفس
            // ما حصل تاريخياً مع أسماء متعددة سابقة لهذا المستودع بالذات (راجع سجل الـcommits:
            // "EasyOCR.tflite" ← "EasyOCR_EasyOCRDetector_float.tflite" ← حُذِف ← أُعيد ← الآن
            // zip فقط) — أي أن أي رابط "ملف مباشر" هنا **سيتعطّل مجدداً مستقبلاً** بطبيعته،
            // بعكس LaMa-Dilated/Real-ESRGAN اللذين ثُبِّتا بـcommit SHA لأنهما لا يزالان ملفات
            // مباشرة. الحل البنيوي هنا مختلف: كلا الإدخالين (det/rec) يشيران الآن **لنفس رابط
            // الـzip**، مع حقل zipEntryContains الجديد بـModelInfo يحدد أي ملف بداخله يُستخرَج
            // لكل منهما (راجع تعليق الحقل بأعلى data class ModelInfo لسبب استخدام "يحتوي على"
            // بدل اسم دقيق — لم يتسنَّ فتح الـzip فعلياً بهذه الجلسة للتأكد من الاسم الحرفي
            // الدقيق بداخله، فقط تأكيد رسمي من Qualcomm أن الرابط والمحتوى المطلوب موجودان).
            // approxSizeMB و minValidBytes هنا يخصان حجم الـzip الكامل (كلا الملفين معاً
            // مضغوطين، وليس أحدهما فقط) — راجع doDownload/extractFromZip بالأسفل لتفاصيل كيف
            // يُستخرَج كل ملف من نفس الزيب مرتين (مرة لكل ModelInfo) دون تعارض بينهما.
            ModelInfo(
                id = "ocr_easyocr_det",
                displayName = "⭐ EasyOCR — Detector (كشف، جزء 1 من 2)",
                fileName = "EasyOCRDetector.tflite",
                url = prefs.getString("url_ocr_easyocr_det", DEFAULT_EASYOCR_ZIP_URL) ?: DEFAULT_EASYOCR_ZIP_URL,
                approxSizeMB = 95,
                minValidBytes = 20_000_000L,
                zipEntryContains = "detector"
            ),
            ModelInfo(
                id = "ocr_easyocr_rec",
                displayName = "⭐ EasyOCR — Recognizer (قراءة، جزء 2 من 2)",
                fileName = "EasyOCRRecognizer.tflite",
                url = prefs.getString("url_ocr_easyocr_rec", DEFAULT_EASYOCR_ZIP_URL) ?: DEFAULT_EASYOCR_ZIP_URL,
                approxSizeMB = 95,
                minValidBytes = 20_000_000L,
                zipEntryContains = "recognizer"
            ),
            // مصدر تعزيز الصورة AI — تحديث بعد بحث فعلي (2026-08-15): لا يوجد إصدار x2 بصيغة
            // .tflite منشور علناً للتنزيل المباشر بدون تسجيل دخول (نسخة x2plus الوحيدة
            // الموجودة علناً بصيغ ONNX/NCNN/PyTorch فقط، وليست TFLite). أقرب بديل حقيقي
            // ومؤكَّد التنزيل المباشر: qualcomm/Real-ESRGAN-x4plus.tflite على Hugging Face
            // (x4 وليس x2، 67MB). لتفادي كسر الأبعاد عند استخدام نموذج بمقياس مختلف، عُدِّل
            // ImageEnhanceEngine.tryAIEnhance ليقرأ مقياس التكبير الفعلي من شكل مُخرَج
            // النموذج بعد allocateTensors() بدل افتراض x2 ثابت (راجع MODEL_SCALE سابقاً) —
            // فيعمل صحيحاً مع هذا الملف x4 أو أي ملف x2 يضيفه المستخدم لاحقاً عبر setCustomUrl.
            ModelInfo(
                id = "enhance_ai",
                displayName = "تعزيز الصورة AI (Real-ESRGAN — افتراضياً x4، لا يوجد x2 بصيغة TFLite للتنزيل المباشر)",
                fileName = "realesrgan-x2.tflite",
                url = prefs.getString("url_enhance_ai", DEFAULT_ENHANCE_AI_URL) ?: DEFAULT_ENHANCE_AI_URL,
                approxSizeMB = 67,
                minValidBytes = 500_000L
            ),

            // ============ نماذج كشف مناطق النص (Detection) — بند جديد ============
            // "PP-OCRv4_det_slim" لا يحتاج إدخالاً منفصلاً هنا — هو نفسه "paddle_det" أعلاه
            // (det.nb)، يُستخدَم تلقائياً فعلياً مع محرك paddle_lite.
            //
            // نماذج EAST Text Detector (مُدرَّبة على كشف نصوص الإنجليزية):
            //  مصدر: tulasiram58827/craft_tflite (نفس المستودع اللي يحتوي CRAFT TFLite).
            //  EAST نموذج كشف نصوص فقط (مثل CRAFT) — يكتشف صناديق النص ثم تُمرَّر لـML Kit
            //  للقراءة. ثلاثة أحجام: 320 (أسرع/أقل دقة)، 640 (متوازن)، 1280 (أدق/أبطأ).
            //  روابط التنزيل مباشرة من GitHub raw — لا يحتاج تسجيل دخول.
            ModelInfo(
                id = "det_east_320",
                displayName = "كشف النص — EAST-320 (سريع ✅)",
                fileName = "east_float_320.tflite",
                url = prefs.getString("url_det_east_320", DEFAULT_EAST_320_URL) ?: DEFAULT_EAST_320_URL,
                approxSizeMB = 20
            ),
            ModelInfo(
                id = "det_east_640",
                displayName = "كشف النص — EAST-640 (متوازن ✅)",
                fileName = "east_float_640.tflite",
                url = prefs.getString("url_det_east_640", DEFAULT_EAST_640_URL) ?: DEFAULT_EAST_640_URL,
                approxSizeMB = 20
            ),
            ModelInfo(
                id = "det_east_1280",
                displayName = "كشف النص — EAST-1280 (دقيق ✅)",
                fileName = "east_float_1280.tflite",
                url = prefs.getString("url_det_east_1280", DEFAULT_EAST_1280_URL) ?: DEFAULT_EAST_1280_URL,
                approxSizeMB = 20
            ),
            // CRAFT Mobile: أول موديول من الأربعة يُفعَّل فعلياً بأنبوب المعالجة (راجع
            // AppInterface.processPage + OCREngine.recognizeCraftMobile). الرابط الافتراضي
            // تصدير TFLite رسمي منشور علناً (tulasiram58827/craft_tflite، نُشر أيضاً على
            // TensorFlow Hub/Kaggle Models) — تنزيل مباشر بصيغة tflite بدون تسجيل دخول
            // (بعكس صفحة tfhub.dev نفسها اللي صارت تُحوِّل لصفحة Kaggle تحتاج حساباً؛ رابط
            // ?lite-format=tflite أدناه يتجاوز هذا التحويل ويرجع الملف مباشرة — **لم يُختبَر
            // تنزيله فعلياً بهذه البيئة بدون إنترنت**، لو تغيّر لاحقاً استخدم setCustomUrl()).
            ModelInfo(
                id = "det_craft_mobile",
                displayName = "كشف النص — CRAFT Mobile (نشط ✅)",
                fileName = "craft-mobile-text.tflite",
                url = prefs.getString("url_det_craft_mobile", DEFAULT_CRAFT_MOBILE_URL) ?: DEFAULT_CRAFT_MOBILE_URL,
                approxSizeMB = 3
            )
        )

    fun setCustomUrl(modelId: String, url: String) {
        prefs.edit().putString("url_$modelId", url).apply()
        // امسح أي ملف .part متبقٍّ من محاولة تنزيل سابقة بالرابط القديم — لو تُرِك، محاولة
        // التنزيل التالية (startDownload) تكتشفه وتحاول "استئناف" (Resume) منه بطلب Range
        // على الرابط الجديد. لو الخادم الجديد قبل الطلب بنفس المُزاح (بدل رفضه أو إرجاع
        // الملف كاملاً)، ينتج ملف تالف فعلياً (بايتات من مصدرين مختلفين تماماً) قد يمرّ من
        // فحص الحجم الأدنى بصمت. حذف .part هنا يضمن أن أي تنزيل بعد تغيير الرابط يبدأ من
        // الصفر دائماً. لا نحذف الملف *المكتمل* السابق (لو موجود) تلقائياً — لو المستخدم
        // يريد استبداله فعلياً يحذفه صراحة عبر زر 🗑️ أولاً، بنفس ما كان متاحاً له دائماً.
        availableModels.find { it.id == modelId }?.let { partFile(it).delete() }
    }

    fun modelFile(model: ModelInfo): File =
        if (model.id.startsWith("paddle_")) File(paddleModelsDir, model.fileName)
        else File(modelsDir, model.fileName)

    private fun partFile(model: ModelInfo): File =
        File(modelFile(model).parentFile, model.fileName + ".part")

    fun isDownloaded(model: ModelInfo): Boolean {
        val f = modelFile(model)
        return f.exists() && f.length() >= model.minValidBytes // أصغر من الحد = غالباً تنزيل ناقص/فاشل
    }

    fun delete(model: ModelInfo): Boolean {
        partFile(model).delete()
        return modelFile(model).delete()
    }

    // ============== إدارة حالة التنزيل: Resume / Pause / منع التكرار ==============

    // نطاق تعاوني خاص بالمنزّل، مستقل عن lifecycleScope الخاص بالـActivity — بهذا نقدر
    // نلغي/نوقف تنزيلاً معيّناً بمعرّفه دون التأثير على أي عملية أخرى، وبدون أن يُقتَل
    // التنزيل تلقائياً لمجرد إعادة إنشاء الواجهة. يُحرَّر عبر release() من AppInterface.
    private val downloadScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val activeJobs = ConcurrentHashMap<String, Job>()
    private val states = ConcurrentHashMap<String, DownloadState>()
    private val locks = ConcurrentHashMap<String, Mutex>()

    private fun lockFor(id: String): Mutex = locks.getOrPut(id) { Mutex() }

    fun stateOf(modelId: String): DownloadState = states[modelId] ?: DownloadState.NONE
    fun isDownloading(modelId: String): Boolean = activeJobs[modelId]?.isActive == true

    /**
     * يبدأ تنزيل نموذج، أو يستأنفه تلقائياً لو وجد ملف .part من محاولة سابقة متوقفة.
     * لو نفس النموذج قيد التنزيل فعلاً، لا يبدأ نسخة ثانية بصمت — يمنع تشغيل أكثر من
     * Download Task واحد لنفس النموذج بالتوازي.
     */
    fun startDownload(model: ModelInfo, onUpdate: (DownloadStatus) -> Unit) {
        if (isDownloading(model.id)) return
        val job = downloadScope.launch {
            lockFor(model.id).withLock { doDownload(model, onUpdate) }
        }
        activeJobs[model.id] = job
        job.invokeOnCompletion { activeJobs.remove(model.id) }
    }

    /** يوقف التنزيل مؤقتاً مع الحفاظ على الملف الجزئي (.part) — يُستأنف لاحقاً من نفس النقطة. */
    fun pauseDownload(modelId: String) {
        states[modelId] = DownloadState.PAUSED
        activeJobs[modelId]?.cancel()
    }

    /** يلغي التنزيل نهائياً ويحذف الملف الجزئي — بعكس pauseDownload لا يمكن استئنافه. */
    fun cancelDownload(modelId: String) {
        val job = activeJobs[modelId]
        val model = availableModels.find { it.id == modelId }
        downloadScope.launch {
            job?.cancelAndJoin() // ننتظر توقف الكتابة الفعلي قبل حذف الملف لتفادي تعارض I/O
            model?.let { partFile(it).delete() }
            states[modelId] = DownloadState.NONE
        }
    }

    /** يُستدعى عند إغلاق التطبيق/الشاشة — يلغي كل التنزيلات الجارية بدون حذف الملفات الجزئية. */
    fun release() {
        downloadScope.cancel()
    }

    private suspend fun doDownload(model: ModelInfo, onUpdate: (DownloadStatus) -> Unit) {
        if (model.url.isBlank()) {
            states[model.id] = DownloadState.FAILED
            onUpdate(DownloadStatus(model.id, DownloadState.FAILED, 0, "لا يوجد رابط تنزيل لهذا النموذج — أضف رابطاً مخصصاً أولاً"))
            return
        }
        if (isDownloaded(model)) {
            states[model.id] = DownloadState.COMPLETED
            onUpdate(DownloadStatus(model.id, DownloadState.COMPLETED, 100, "محمّل مسبقاً"))
            return
        }

        val tmp = partFile(model)
        val resumeOffset = if (tmp.exists()) tmp.length() else 0L
        states[model.id] = DownloadState.DOWNLOADING
        onUpdate(
            DownloadStatus(
                model.id, DownloadState.DOWNLOADING,
                if (resumeOffset > 0) 1 else 0,
                if (resumeOffset > 0) "استئناف التنزيل من ${resumeOffset / 1024}KB..." else null
            )
        )

        try {
            val reqBuilder = Request.Builder().url(model.url)
            if (resumeOffset > 0) reqBuilder.addHeader("Range", "bytes=$resumeOffset-")

            client.newCall(reqBuilder.build()).execute().use { resp ->
                if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
                val isPartial = resp.code == 206
                // لو طلبنا Range لكن الخادم رجّع 200 كامل (لا يدعم Range)، لازم نكتب من
                // الصفر بدل إلحاق المحتوى الكامل فوق بيانات قديمة (ينتج ملف تالف مضاعَف).
                val append = resumeOffset > 0 && isPartial
                val startAt = if (append) resumeOffset else 0L
                val body = resp.body ?: throw IOException("استجابة فارغة")
                val newBytes = body.contentLength()
                val total = if (newBytes > 0) startAt + newBytes else -1L

                body.byteStream().use { input ->
                    FileOutputStream(tmp, append).use { output ->
                        val buffer = ByteArray(64 * 1024)
                        var downloaded = startAt
                        var lastReportedPct = -1
                        while (true) {
                            if (!currentCoroutineContext().isActive) return // Pause: نخرج بأمان، .part محفوظ كما هو
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            downloaded += read
                            if (total > 0) {
                                val pct = ((downloaded * 100) / total).toInt().coerceIn(0, 99)
                                if (pct != lastReportedPct) {
                                    lastReportedPct = pct
                                    onUpdate(DownloadStatus(model.id, DownloadState.DOWNLOADING, pct))
                                }
                            }
                        }
                    }
                }
            }

            // التحقق من السلامة بعد اكتمال الكتابة كاملة (وليس تدريجياً أثناء التنزيل) —
            // هذا يدعم الاستئناف الجزئي بشكل صحيح: حساب SHA256 تدريجياً أثناء التنزيل كان
            // سيُنتِج هاشاً خاطئاً لو جزء من الملف أتى من محاولة سابقة قبل الاستئناف.
            states[model.id] = DownloadState.VERIFYING
            onUpdate(DownloadStatus(model.id, DownloadState.VERIFYING, 100, "جارٍ التحقق من سلامة الملف..."))

            if (tmp.length() < model.minValidBytes) {
                tmp.delete()
                states[model.id] = DownloadState.FAILED
                onUpdate(DownloadStatus(model.id, DownloadState.FAILED, 0, "الملف الناتج أصغر من المتوقع — قد يكون تالفاً، أُعيد التنزيل مطلوب"))
                return
            }
            if (model.sha256 != null) {
                val digest = MessageDigest.getInstance("SHA-256")
                tmp.inputStream().use { ins ->
                    val buf = ByteArray(128 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n == -1) break
                        digest.update(buf, 0, n)
                    }
                }
                val hex = digest.digest().joinToString("") { "%02x".format(it) }
                if (!hex.equals(model.sha256, ignoreCase = true)) {
                    tmp.delete()
                    states[model.id] = DownloadState.FAILED
                    onUpdate(DownloadStatus(model.id, DownloadState.FAILED, 0, "فشل التحقق من سلامة الملف (checksum) — أُعيد التنزيل مطلوب"))
                    return
                }
            }

            val finalFile = modelFile(model)
            finalFile.delete()

            if (model.zipEntryContains != null) {
                val zipMatch = model.zipEntryContains
                // 🔍 (2026-08-15) الملف المُنزَّل هنا zip كامل (حالة EasyOCR — راجع تعليق
                // الحقل بأعلى data class ModelInfo)، لا الملف النهائي نفسه. نفتحه، نبحث عن
                // أول entry اسمه يحتوي (بلا حساسية لحالة الأحرف) على zipEntryContains،
                // ونستخرجه فقط لـfinalFile — ثم نحذف الـzip المؤقت (تمّ استخراج المطلوب منه).
                // ملاحظة: كل ModelInfo (det/rec) يُنزِّل نفس رابط الـzip بشكل مستقل بملفه
                // المؤقت الخاص (partFile مبني على fileName الفريد لكل منهما)، فلا يوجد تعارض
                // كتابة متزامنة على نفس الملف المؤقت بين الاثنين.
                var extracted = false
                ZipInputStream(tmp.inputStream().buffered()).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        if (!entry.isDirectory && entry.name.contains(zipMatch, ignoreCase = true)) {
                            FileOutputStream(finalFile).use { out ->
                                val buf = ByteArray(64 * 1024)
                                while (true) {
                                    val n = zip.read(buf)
                                    if (n == -1) break
                                    out.write(buf, 0, n)
                                }
                            }
                            extracted = true
                            break
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
                tmp.delete() // ننظّف الـzip المؤقت — لسنا بحاجته بعد الاستخراج
                if (!extracted) {
                    states[model.id] = DownloadState.FAILED
                    onUpdate(DownloadStatus(model.id, DownloadState.FAILED, 0, "لم يُعثَر داخل الأرشيف على ملف يحتوي \"$zipMatch\" باسمه — راجع محتويات الـzip يدوياً"))
                    return
                }
                if (finalFile.length() < 1_000_000L) {
                    // ملف tflite حقيقي لن يكون أصغر من ~1MB — لو صار هذا فعلياً الاستخراج
                    // طابق entry خاطئ (اسم يحتوي الكلمة لكنه ليس ملف النموذج، مثل نص توثيقي
                    // بداخل الأرشيف بالصدفة بنفس الكلمة) — نرفض بدل حفظ ملف تالف صامت.
                    finalFile.delete()
                    states[model.id] = DownloadState.FAILED
                    onUpdate(DownloadStatus(model.id, DownloadState.FAILED, 0, "الملف المُستخرَج من الأرشيف أصغر من المتوقع — قد يكون Entry خاطئاً بالأرشيف"))
                    return
                }
                states[model.id] = DownloadState.COMPLETED
                onUpdate(DownloadStatus(model.id, DownloadState.COMPLETED, 100, "تم تنزيل ${model.displayName} بنجاح (من أرشيف zip)"))
                return
            }

            if (!tmp.renameTo(finalFile)) {
                states[model.id] = DownloadState.FAILED
                onUpdate(DownloadStatus(model.id, DownloadState.FAILED, 0, "فشل حفظ النموذج على التخزين"))
                return
            }
            states[model.id] = DownloadState.COMPLETED
            onUpdate(DownloadStatus(model.id, DownloadState.COMPLETED, 100, "تم تنزيل ${model.displayName} بنجاح"))
        } catch (e: CancellationException) {
            // إلغاء تعاوني (Pause أو Cancel) — الحالة مضبوطة مسبقاً من pauseDownload/
            // cancelDownload، فلا نُعيد كتابتها هنا بحالة خاطئة (مثل FAILED).
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Model download failed: ${model.id}", e)
            states[model.id] = DownloadState.FAILED
            onUpdate(DownloadStatus(model.id, DownloadState.FAILED, 0, e.message ?: "فشل التنزيل"))
        }
    }

    companion object {
        private const val DEFAULT_ONNX_URL =
            "https://huggingface.co/Carve/LaMa-ONNX/resolve/main/lama_fp32.onnx"

        // تصدير TFLite رسمي لعائلة LaMa، منشور من Qualcomm AI Hub على Hugging Face.
        // ⚠️ تصحيح حرج (2026-08-15، سبب حقيقي لبلاغ "لا يتنزّل" مؤكَّد بالبحث): الرابط
        // القديم استخدم "resolve/main/..." — لكن مستودعات qualcomm/* على Hugging Face
        // تُعاد هيكلتها بشكل متكرر جداً (مثال مؤكَّد أدناه بـReal-ESRGAN)، فملف "main" قد
        // يُعاد تسميته لاحقاً (مثلاً بإضافة لاحقة "_float" عند إضافة نسخ تكميم بديلة) —
        // "main" يتحرك مع كل تحديث للمستودع، فأي رابط resolve/main/<اسم-ملف-محدد> قابل
        // للانكسار في أي وقت لاحق. الإصلاح: تثبيت الرابط على commit SHA محدد تحقّقت من
        // احتوائه فعلياً على الملف بهذا الاسم بالضبط (بدل "main" المتحرك) — لا ينكسر حتى
        // لو أُعيدت تسمية الملف على main لاحقاً. لا يزال هذا لا يثبت التوافق مع شكل
        // مُدخلات inpaintTFLite الحالي (راجع التعليق الطويل أعلى ModelInfo الخاصة بـ"ai_lite").
        private const val DEFAULT_AI_LITE_URL =
            "https://huggingface.co/qualcomm/LaMa-Dilated/resolve/ab898502c9bd764a50eb2719a309694b43eae658/LaMa-Dilated.tflite"

        // تصدير TFLite رسمي لـReal-ESRGAN-x4plus، منشور من Qualcomm AI Hub على Hugging Face.
        // ⚠️ تصحيح حرج (2026-08-15): هذا هو السبب الفعلي المؤكَّد لبلاغ "Real-ESRGAN لا
        // يتنزّل" — تحقَّقت بالبحث أن ملف "Real-ESRGAN-x4plus.tflite" على "main" أُعيد
        // تسميته فعلياً إلى "Real-ESRGAN-x4plus_float.tflite" بتحديث v0.44.0 للمستودع
        // (المستودع وصل الآن v0.59.0 — 11 يوماً فقط منذ آخر تحديث وقت كتابة هذا)، فرابط
        // "resolve/main/Real-ESRGAN-x4plus.tflite" القديم يرجع 404 فعلياً منذ ذلك التحديث.
        // نفس إصلاح "ai_lite" أعلاه: تثبيت على commit SHA محدد تحقّقت من احتوائه على الملف
        // بهذا الاسم بالضبط (67.1MB) بدل "main" المتحرك. x4 وليس x2 (راجع التعليق أعلى
        // ModelInfo الخاصة بـ"enhance_ai" — لا يوجد إصدار x2 بصيغة TFLite منشور علناً).
        private const val DEFAULT_ENHANCE_AI_URL =
            "https://huggingface.co/qualcomm/Real-ESRGAN-x4plus/resolve/5f4491334213711be70a6253a600aa3dad2c6927/Real-ESRGAN-x4plus.tflite"

        // تصدير TFLite رسمي لـCRAFT (Dynamic Range quantized) — tulasiram58827/craft_tflite،
        // منشور على TensorFlow Hub. صفحة tfhub.dev الاعتيادية صارت تُحوِّل لـKaggle Models
        // (يحتاج حساب لفتح الصفحة)، لكن رابط lite-format=tflite أدناه (نفس الرابط المستخدم
        // بأمثلة onnx2tf/tf2onnx الرسمية لتنزيل الملف مباشرة عبر wget) يرجع الملف الثنائي
        // مباشرة بدون تسجيل دخول — **لم يُختبَر التنزيل الفعلي بهذه البيئة (بدون إنترنت)**.
        private const val DEFAULT_CRAFT_MOBILE_URL =
            "https://tfhub.dev/tulasiram58827/lite-model/craft-text-detector/dr/1?lite-format=tflite"

        // ملف القاموس نص عادي (UTF-8) بدون أي تبعية لإصدار Paddle-Lite، لذلك آمن وضع رابط
        // افتراضي رسمي مباشر له من مستودع PaddleOCR (بعكس ملفات .nb الثنائية التي يعتمد
        // نجاح تحميلها على توافق إصدار opset/runtime — انظر التعليق أعلى paddle_det).
        private const val DEFAULT_PADDLE_DICT_URL =
            "https://raw.githubusercontent.com/PaddlePaddle/PaddleOCR/main/ppocr/utils/ppocr_keys_v1.txt"

        // مصدر ملفات det.nb/rec.nb/cls.nb — راجع الملاحظة الطويلة أعلى ModelInfo الخاصة
        // بـpaddle_det لتفاصيل سبب اختيار هذا المصدر بالذات (توافق نسخة Paddle-Lite).
        private const val PADDLE4ANDROID_DEMO_MODELS_BASE =
            "https://raw.githubusercontent.com/equationl/paddleocr4android/master/app/src/main/assets/models/ch_PP-OCRv4"
        private const val DEFAULT_PADDLE_DET_URL = "$PADDLE4ANDROID_DEMO_MODELS_BASE/det.nb"
        private const val DEFAULT_PADDLE_REC_URL = "$PADDLE4ANDROID_DEMO_MODELS_BASE/rec.nb"
        private const val DEFAULT_PADDLE_CLS_URL = "$PADDLE4ANDROID_DEMO_MODELS_BASE/cls.nb"

        // روابط تنزيل مباشرة لنماذج EAST Text Detector
        private const val DEFAULT_EAST_320_URL =
            "https://raw.githubusercontent.com/tulasiram58827/craft_tflite/main/models/east/east_float_320.tflite"
        private const val DEFAULT_EAST_640_URL =
            "https://raw.githubusercontent.com/tulasiram58827/craft_tflite/main/models/east/east_float_640.tflite"
        private const val DEFAULT_EAST_1280_URL =
            "https://raw.githubusercontent.com/tulasiram58827/craft_tflite/main/models/east/east_float_1280.tflite"

        // رابط تنزيل EasyOCR — تصحيح ثانٍ (2026-08-15، جلسة رابعة): المستودع لم يعد يحتوي
        // ملفات .tflite فردية إطلاقاً (تحقَّق حياً وقت الكتابة، راجع التعليق الطويل أعلى
        // ModelInfo لـ"ocr_easyocr_det"/"ocr_easyocr_rec" للتفاصيل الكاملة). هذا رابط S3
        // رسمي من Qualcomm نفسها (مذكور بـrelease_assets.json وREADME.md الحاليين لنفس
        // المستودع)، مُثبَّت برقم إصدار صريح بالمسار (v0.60.0) لا "latest" متحرك — يحتوي
        // كلا الملفين (Detector+Recognizer) معاً بصيغة zip، يُستخرَجان بواسطة
        // zipEntryContains بـModelInfo (راجع doDownload/extractFromZip بالأسفل).
        private const val DEFAULT_EASYOCR_ZIP_URL =
            "https://qaihub-public-assets.s3.us-west-2.amazonaws.com/qai-hub-models/models/easyocr/releases/v0.60.0/easyocr-tflite-float.zip"
    }
}
