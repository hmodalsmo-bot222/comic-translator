package com.comictrans

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import java.io.ByteArrayInputStream
import java.io.File
import java.io.IOException

/**
 * Enhanced MainActivity with proper permissions, lifecycle management, and memory cleanup.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var appInterface: AppInterface? = null

    companion object {
        private const val TAG = "MainActivity"
        private const val PERMISSION_REQUEST_CODE = 1001
        private val REQUIRED_PERMISSIONS = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.INTERNET,
                Manifest.permission.ACCESS_NETWORK_STATE
            )
        } else {
            arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.INTERNET,
                Manifest.permission.ACCESS_NETWORK_STATE
            )
        }
    }

    // Activity Result Launcher for file picker
    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            appInterface?.let { iface ->
                // Handle file selection
                val path = copyUriToCache(it)
                path?.let { filePath ->
                    webView.evaluateJavascript(
                        "window.onFileSelected && window.onFileSelected('$filePath')",
                        null
                    )
                }
            }
        }
    }

    // Permission launcher
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.entries.all { it.value }
        if (!allGranted) {
            showPermissionRationale()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        setupWebView()
        checkPermissions()
    }

    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
        }

        webView.webChromeClient = WebChromeClient()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                val url = request.url.toString()

                // Serve local files from cache
                if (url.startsWith("https://comic.local/")) {
                    return serveLocalFile(url)
                }

                return super.shouldInterceptRequest(view, request)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // Notify JS that app is ready
                webView.evaluateJavascript("window.onAppReady && window.onAppReady()", null)
            }
        }

        // Initialize AppInterface with lifecycle scope
        appInterface = AppInterface(this, webView, lifecycleScope)
        webView.addJavascriptInterface(appInterface!!, "AppInterface")

        // Load UI
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun serveLocalFile(url: String): WebResourceResponse? {
        return try {
            when {
                url.contains("/page/") -> {
                    // Serve page image
                    val pageIndex = url.substringAfter("/page/").substringBefore("?").toIntOrNull()
                    pageIndex?.let { servePageImage(it) }
                }
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun servePageImage(pageIndex: Int): WebResourceResponse? {
        // Implementation would read from cache
        return null
    }

    // ==================== PERMISSIONS ====================

    private fun checkPermissions() {
        val missingPermissions = REQUIRED_PERMISSIONS.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missingPermissions.isNotEmpty()) {
            permissionLauncher.launch(missingPermissions.toTypedArray())
        }
    }

    private fun showPermissionRationale() {
        AlertDialog.Builder(this)
            .setTitle("صلاحيات التخزين مطلوبة")
            .setMessage("يحتاج التطبيق إلى صلاحية الوصول للملفات لقراءة ملفات الكوميكس (CBZ)")
            .setPositiveButton("الإعدادات") { _, _ ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    startActivity(intent)
                } else {
                    checkPermissions()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // ==================== FILE HANDLING ====================

    private fun copyUriToCache(uri: Uri): String? {
        return try {
            val fileName = uri.lastPathSegment ?: "comic.cbz"
            val cacheFile = File(cacheDir, "imports/$fileName")
            cacheFile.parentFile?.mkdirs()

            contentResolver.openInputStream(uri)?.use { input ->
                cacheFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }

            cacheFile.absolutePath
        } catch (e: Exception) {
            Toast.makeText(this, "فشل في نسخ الملف: ${e.message}", Toast.LENGTH_SHORT).show()
            null
        }
    }

    // ==================== LIFECYCLE ====================

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onPause() {
        super.onPause()
        webView.onPause()
    }

    override fun onDestroy() {
        // Critical: Clean up to prevent memory leaks
        appInterface?.release()
        appInterface = null

        webView.apply {
            stopLoading()
            loadUrl("about:blank")
            clearHistory()
            removeAllViews()
            destroy()
        }

        super.onDestroy()
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    // ==================== MEMORY MANAGEMENT ====================

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        when (level) {
            TRIM_MEMORY_RUNNING_MODERATE,
            TRIM_MEMORY_RUNNING_LOW,
            TRIM_MEMORY_RUNNING_CRITICAL -> {
                // Clear non-essential caches
                webView.clearCache(false)
            }
            TRIM_MEMORY_UI_HIDDEN,
            TRIM_MEMORY_BACKGROUND,
            TRIM_MEMORY_MODERATE,
            TRIM_MEMORY_COMPLETE -> {
                // Clear all caches when in background
                webView.clearCache(true)
                appInterface?.let { iface ->
                    // Notify to release memory
                }
            }
        }
    }
}
