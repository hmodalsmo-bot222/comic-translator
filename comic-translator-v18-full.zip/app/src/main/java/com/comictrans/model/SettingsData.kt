package com.comictrans.model

/**
 * Enhanced settings data class with all new features.
 */
data class SettingsData(
    // Translation
    val provider: String = "google_free",
    val apiKey: String = "",
    val sourceLanguage: String = "auto",
    val targetLanguage: String = "en",
    val model: String = "gpt-3.5-turbo",
    val temperature: Float = 0.7f,

    // Custom Provider (Local LLM)
    val customApiUrl: String = "",
    val customApiKey: String = "",
    val customModel: String = "",

    // OCR
    val ocrEngine: String = "mlkit",
    val usePreprocessing: Boolean = true,
    val detectBubbles: Boolean = true,
    val fastMode: Boolean = false,

    // Erasure
    val erasureLevel: String = "auto", // fast, medium, high, ultra, auto
    val useBubbleMask: Boolean = true,

    // Comic Context
    val comicType: String = "manga", // manga, manhwa, western
    val seriesName: String = "",
    val chapterNumber: Int = 0,
    val previousSummary: String = "",
    val charactersPresent: List<String> = emptyList(),
    val characterMap: Map<String, String> = emptyMap(),
    val termMap: Map<String, String> = emptyMap(),

    // Processing
    val batchMode: Boolean = true,
    val forceReprocess: Boolean = false,

    // Text Rendering
    val fontSize: Float = 16f,
    val fontFamily: String = "default",
    val textColor: String = "#000000",
    val backgroundColor: String = "#FFFFFF",

    // Cache
    val useCache: Boolean = true,
    val maxCacheSizeMB: Int = 500
)
