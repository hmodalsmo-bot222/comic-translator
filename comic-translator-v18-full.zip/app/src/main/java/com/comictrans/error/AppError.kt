package com.comictrans.error

import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Sealed class representing all possible app errors.
 * Provides structured error information for every module.
 */
sealed class AppError(val code: String, val userMessage: String, val technicalDetails: String? = null) {

    // OCR Errors
    data class OCRError(val details: String, val source: String = "OCR") : 
        AppError("OCR_001", "فشل في التعرف على النص", details)

    data class OCRModelNotFound(val modelName: String) : 
        AppError("OCR_002", "نموذج OCR غير متوفر", "Model: $modelName not found")

    data class OCRPreprocessingFailed(val step: String) : 
        AppError("OCR_003", "فشل في معالجة الصورة", "Preprocessing step failed: $step")

    // Translation Errors
    data class TranslationError(val provider: String, val details: String) : 
        AppError("TR_001", "فشل في الترجمة", "Provider: $provider, Details: $details")

    data class TranslationNetworkError(val url: String) : 
        AppError("TR_002", "مشكلة في الاتصال", "Failed to connect to: $url")

    data class TranslationRateLimited(val provider: String) : 
        AppError("TR_003", "تم تجاوز الحد المسموح", "Rate limited by: $provider")

    data class TranslationInvalidResponse(val provider: String) : 
        AppError("TR_004", "رد غير صالح من خادم الترجمة", "Provider: $provider")

    // AI Model Errors
    data class ModelDownloadError(val modelId: String, val reason: String) : 
        AppError("MDL_001", "فشل في تحميل النموذج", "Model: $modelId, Reason: $reason")

    data class ModelCorrupted(val modelId: String, val expectedHash: String, val actualHash: String) : 
        AppError("MDL_002", "النموذج تالف", "Model: $modelId, Hash mismatch")

    data class ModelLoadError(val modelId: String, val reason: String) : 
        AppError("MDL_003", "فشل في تحميل النموذج", "Model: $modelId, Reason: $reason")

    data class ModelOutOfMemory(val modelId: String, val requiredMB: Long, val availableMB: Long) : 
        AppError("MDL_004", "الذاكرة غير كافية", "Model: $modelId needs ${requiredMB}MB, available ${availableMB}MB")

    // CBZ Errors
    data class CBZParseError(val fileName: String, val reason: String) : 
        AppError("CBZ_001", "فشل في قراءة ملف الكوميكس", "File: $fileName, Reason: $reason")

    data class CBZCorrupted(val fileName: String) : 
        AppError("CBZ_002", "ملف الكوميكس تالف", "File: $fileName is corrupted or invalid ZIP")

    data class CBZExtractionError(val fileName: String, val entryName: String) : 
        AppError("CBZ_003", "فشل في استخراج الصفحة", "File: $fileName, Entry: $entryName")

    // File System Errors
    data class FileNotFound(val path: String) : 
        AppError("FILE_001", "الملف غير موجود", "Path: $path")

    data class FilePermissionDenied(val path: String) : 
        AppError("FILE_002", "لا توجد صلاحية للوصول", "Path: $path")

    data class FileWriteError(val path: String, val reason: String) : 
        AppError("FILE_003", "فشل في حفظ الملف", "Path: $path, Reason: $reason")

    data class StorageFull(val requiredMB: Long, val availableMB: Long) : 
        AppError("FILE_004", "الذاكرة ممتلئة", "Need ${requiredMB}MB, have ${availableMB}MB")

    // Network Errors
    data class NetworkTimeout(val url: String, val timeoutMs: Long) : 
        AppError("NET_001", "انتهت مهلة الاتصال", "URL: $url, Timeout: ${timeoutMs}ms")

    data class NetworkNoConnection() : 
        AppError("NET_002", "لا يوجد اتصال بالإنترنت", "Device is offline")

    data class NetworkSSLException(val url: String) : 
        AppError("NET_003", "مشكلة في شهادة الأمان", "URL: $url")

    // Image Processing Errors
    data class ImageDecodeError(val source: String) : 
        AppError("IMG_001", "فشل في فك تشفير الصورة", "Source: $source")

    data class ImageProcessingError(val operation: String, val details: String) : 
        AppError("IMG_002", "فشل في معالجة الصورة", "Operation: $operation, Details: $details")

    data class ImageOutOfMemory(val dimensions: String) : 
        AppError("IMG_003", "الصورة كبيرة جداً", "Dimensions: $dimensions")

    // Cache Errors
    data class CacheError(val operation: String, val details: String) : 
        AppError("CACHE_001", "مشكلة في الذاكرة المؤقتة", "Operation: $operation, Details: $details")

    // Unknown/Catch-all
    data class UnknownError(val exception: Throwable) : 
        AppError("UNK_001", "حدث خطأ غير متوقع", exception.stackTraceToString())

    companion object {
        fun fromException(e: Throwable, context: String = ""): AppError {
            return when (e) {
                is java.net.SocketTimeoutException -> NetworkTimeout(context, 30000)
                is java.net.UnknownHostException -> NetworkNoConnection()
                is java.net.SSLException -> NetworkSSLException(context)
                is java.io.FileNotFoundException -> FileNotFound(context)
                is java.security.cert.CertPathValidatorException -> NetworkSSLException(context)
                is OutOfMemoryError -> ImageOutOfMemory(context)
                else -> UnknownError(e)
            }
        }
    }
}

/**
 * Result wrapper that forces explicit error handling.
 * Replaces throwing exceptions in core business logic.
 */
sealed class AppResult<out T> {
    data class Success<T>(val data: T) : AppResult<T>()
    data class Error(val error: AppError) : AppResult<Nothing>()

    val isSuccess: Boolean get() = this is Success
    val isError: Boolean get() = this is Error

    fun getOrNull(): T? = (this as? Success)?.data
    fun errorOrNull(): AppError? = (this as? Error)?.error

    inline fun <R> map(transform: (T) -> R): AppResult<R> = when (this) {
        is Success -> Success(transform(data))
        is Error -> this
    }

    inline fun <R> flatMap(transform: (T) -> AppResult<R>): AppResult<R> = when (this) {
        is Success -> transform(data)
        is Error -> this
    }

    inline fun onSuccess(action: (T) -> Unit): AppResult<T> {
        if (this is Success) action(data)
        return this
    }

    inline fun onError(action: (AppError) -> Unit): AppResult<T> {
        if (this is Error) action(error)
        return this
    }

    fun getOrElse(default: (AppError) -> T): T = when (this) {
        is Success -> data
        is Error -> default(error)
    }
}

/**
 * Centralized error manager with logging and user-facing state.
 */
object ErrorManager {
    private const val TAG = "ErrorManager"

    private val _lastError = MutableStateFlow<AppError?>(null)
    val lastError: StateFlow<AppError?> = _lastError.asStateFlow()

    private val _errorHistory = MutableStateFlow<List<AppError>>(emptyList())
    val errorHistory: StateFlow<List<AppError>> = _errorHistory.asStateFlow()

    private val maxHistorySize = 50

    fun report(error: AppError, logLevel: Int = Log.ERROR) {
        // Log with appropriate level
        when (logLevel) {
            Log.VERBOSE -> Log.v(TAG, "[${error.code}] ${error.technicalDetails ?: error.userMessage}")
            Log.DEBUG -> Log.d(TAG, "[${error.code}] ${error.technicalDetails ?: error.userMessage}")
            Log.INFO -> Log.i(TAG, "[${error.code}] ${error.technicalDetails ?: error.userMessage}")
            Log.WARN -> Log.w(TAG, "[${error.code}] ${error.technicalDetails ?: error.userMessage}")
            Log.ERROR -> Log.e(TAG, "[${error.code}] ${error.technicalDetails ?: error.userMessage}")
            else -> Log.e(TAG, "[${error.code}] ${error.technicalDetails ?: error.userMessage}")
        }

        // Update state
        _lastError.value = error

        // Add to history
        val current = _errorHistory.value.toMutableList()
        current.add(error)
        if (current.size > maxHistorySize) {
            current.removeAt(0)
        }
        _errorHistory.value = current
    }

    fun reportException(e: Throwable, context: String = "", logLevel: Int = Log.ERROR) {
        val error = AppError.fromException(e, context)
        report(error, logLevel)
    }

    fun clearLastError() {
        _lastError.value = null
    }

    fun clearHistory() {
        _errorHistory.value = emptyList()
    }

    /**
     * Wraps a suspend function with error handling.
     */
    inline fun <T> runCatchingApp(block: () -> T): AppResult<T> {
        return try {
            AppResult.Success(block())
        } catch (e: Exception) {
            val error = AppError.fromException(e)
            report(error)
            AppResult.Error(error)
        }
    }

    /**
     * Wraps a suspend function with error handling.
     */
    suspend inline fun <T> runCatchingAppSuspend(crossinline block: suspend () -> T): AppResult<T> {
        return try {
            AppResult.Success(block())
        } catch (e: Exception) {
            val error = AppError.fromException(e)
            report(error)
            AppResult.Error(error)
        }
    }
}

/**
 * Extension to convert Kotlin Result to AppResult.
 */
fun <T> kotlin.Result<T>.toAppResult(): AppResult<T> {
    return fold(
        onSuccess = { AppResult.Success(it) },
        onFailure = { 
            val error = if (it is AppError) it else AppError.fromException(it)
            AppResult.Error(error)
        }
    )
}
