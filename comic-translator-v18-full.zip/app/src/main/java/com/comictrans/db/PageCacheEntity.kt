package com.comictrans.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Cache entity for processed comic pages.
 * Prevents re-processing the same page.
 */
@Entity(
    tableName = "page_cache",
    indices = [
        Index(value = ["comic_hash", "page_number"], unique = true),
        Index(value = ["processing_date"])
    ]
)
data class PageCacheEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "comic_hash")
    val comicHash: String,          // SHA256 of CBZ file or unique comic ID

    @ColumnInfo(name = "page_number")
    val pageNumber: Int,

    @ColumnInfo(name = "page_name")
    val pageName: String,           // Original filename in CBZ

    @ColumnInfo(name = "ocr_result")
    val ocrResult: String,          // JSON array of text blocks

    @ColumnInfo(name = "translation_result")
    val translationResult: String,  // JSON array of translations

    @ColumnInfo(name = "processed_image_path")
    val processedImagePath: String?, // Path to processed image

    @ColumnInfo(name = "bubble_data")
    val bubbleData: String?,        // JSON array of bubble positions

    @ColumnInfo(name = "source_language")
    val sourceLanguage: String,

    @ColumnInfo(name = "target_language")
    val targetLanguage: String,

    @ColumnInfo(name = "processing_date")
    val processingDate: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "ocr_engine")
    val ocrEngine: String,          // Which OCR was used

    @ColumnInfo(name = "translation_provider")
    val translationProvider: String, // Which translator was used

    @ColumnInfo(name = "version")
    val version: Int = 1            // Cache version for invalidation
)
