package com.comictrans.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction

/**
 * DAO for page cache operations.
 */
@Dao
interface PageCacheDao {

    @Query("SELECT * FROM page_cache WHERE comic_hash = :comicHash AND page_number = :pageNumber LIMIT 1")
    suspend fun getCachedPage(comicHash: String, pageNumber: Int): PageCacheEntity?

    @Query("""
        SELECT * FROM page_cache 
        WHERE comic_hash = :comicHash 
        AND source_language = :sourceLang 
        AND target_language = :targetLang
        ORDER BY page_number
    """)
    suspend fun getCachedComic(
        comicHash: String, 
        sourceLang: String, 
        targetLang: String
    ): List<PageCacheEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(cache: PageCacheEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(caches: List<PageCacheEntity>)

    @Query("DELETE FROM page_cache WHERE comic_hash = :comicHash")
    suspend fun clearComicCache(comicHash: String)

    @Query("DELETE FROM page_cache WHERE processing_date < :olderThan")
    suspend fun clearOldCache(olderThan: Long)

    @Query("SELECT COUNT(*) FROM page_cache WHERE comic_hash = :comicHash")
    suspend fun getCacheCount(comicHash: String): Int

    @Query("SELECT SUM(LENGTH(processed_image_path)) FROM page_cache WHERE comic_hash = :comicHash")
    suspend fun getCacheSize(comicHash: String): Long?

    @Query("DELETE FROM page_cache")
    suspend fun clearAll()

    @Transaction
    suspend fun isPageCached(
        comicHash: String, 
        pageNumber: Int,
        sourceLang: String,
        targetLang: String
    ): Boolean {
        val cached = getCachedPage(comicHash, pageNumber)
        return cached != null && 
               cached.sourceLanguage == sourceLang && 
               cached.targetLanguage == targetLang
    }
}
