package com.comictrans.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * App database with translation and cache tables.
 */
@Database(
    entities = [TranslationEntity::class, PageCacheEntity::class],
    version = 2,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun translationDao(): TranslationDao
    abstract fun pageCacheDao(): PageCacheDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS page_cache (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        comic_hash TEXT NOT NULL,
                        page_number INTEGER NOT NULL,
                        page_name TEXT NOT NULL,
                        ocr_result TEXT NOT NULL,
                        translation_result TEXT NOT NULL,
                        processed_image_path TEXT,
                        bubble_data TEXT,
                        source_language TEXT NOT NULL,
                        target_language TEXT NOT NULL,
                        processing_date INTEGER NOT NULL DEFAULT 0,
                        ocr_engine TEXT NOT NULL,
                        translation_provider TEXT NOT NULL,
                        version INTEGER NOT NULL DEFAULT 1
                    )
                """)
                db.execSQL("CREATE UNIQUE INDEX index_page_cache_comic_page ON page_cache(comic_hash, page_number)")
                db.execSQL("CREATE INDEX index_page_cache_date ON page_cache(processing_date)")
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "comic_translator_db"
                )
                .addMigrations(MIGRATION_1_2)
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
