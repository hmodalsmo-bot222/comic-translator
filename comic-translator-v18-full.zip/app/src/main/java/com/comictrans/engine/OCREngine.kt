package com.comictrans.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import com.comictrans.error.AppError
import com.comictrans.error.AppResult
import com.comictrans.error.ErrorManager
import com.comictrans.model.BlockData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.opencv.android.Utils
import org.opencv.core.Mat
import org.opencv.core.MatOfText
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.imgproc.Imgproc
import org.opencv.text.Text
import java.io.File

/**
 * Enhanced OCR engine with preprocessing pipeline and bubble detection.
 */
class OCREngine(private val context: Context) {

    enum class OCRBackend {
        PADDLE,     // PaddleOCR - best accuracy
        MLKIT,      // Google ML Kit - fast, no extra models
        TESSERACT   // Tesseract - fallback
    }

    data class OCRConfig(
        val backend: OCRBackend = OCRBackend.MLKIT,
        val usePreprocessing: Boolean = true,
        val useBubbleDetection: Boolean = true,
        val fastMode: Boolean = false,
        val language: String = "en"
    )

    data class OCRResult(
        val blocks: List<BlockData>,
        val bubbles: List<BubbleDetector.Bubble> = emptyList(),
        val processingTimeMs: Long = 0
    )

    private var paddleInitialized = false
    private var tesseractInitialized = false

    /**
     * Main OCR pipeline.
     */
    suspend fun recognize(
        bitmap: Bitmap,
        config: OCRConfig = OCRConfig()
    ): AppResult<OCRResult> = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()

        try {
            // Step 1: Preprocess image
            val processedBitmap = if (config.usePreprocessing) {
                val preprocessResult = if (config.fastMode) {
                    ImagePreprocessingPipeline.processFast(bitmap)
                } else {
                    ImagePreprocessingPipeline.processAccurate(bitmap)
                }

                when (preprocessResult) {
                    is AppResult.Success -> preprocessResult.data
                    is AppResult.Error -> {
                        ErrorManager.report(preprocessResult.error, android.util.Log.WARN)
                        bitmap // Fallback to original
                    }
                }
            } else {
                bitmap
            }

            // Step 2: Detect speech bubbles (optional)
            val bubbles = if (config.useBubbleDetection && !config.fastMode) {
                when (val result = BubbleDetector.detectBubbles(processedBitmap)) {
                    is AppResult.Success -> result.data
                    is AppResult.Error -> {
                        ErrorManager.report(result.error, android.util.Log.WARN)
                        emptyList()
                    }
                }
            } else {
                emptyList()
            }

            // Step 3: Perform OCR
            val blocks = when (config.backend) {
                OCRBackend.PADDLE -> recognizePaddle(processedBitmap, config)
                OCRBackend.MLKIT -> recognizeMLKit(processedBitmap, config)
                OCRBackend.TESSERACT -> recognizeTesseract(processedBitmap, config)
            }

            // Step 4: Group text by bubbles if detected
            val groupedBlocks = if (bubbles.isNotEmpty()) {
                groupBlocksByBubbles(blocks, bubbles)
            } else {
                sortReadingOrder(blocks)
            }

            // Cleanup processed bitmap if different from original
            if (processedBitmap != bitmap && !processedBitmap.isRecycled) {
                processedBitmap.recycle()
            }

            val elapsed = System.currentTimeMillis() - startTime
            AppResult.Success(OCRResult(groupedBlocks, bubbles, elapsed))

        } catch (e: OutOfMemoryError) {
            AppResult.Error(AppError.ImageOutOfMemory("${bitmap.width}x${bitmap.height}"))
        } catch (e: Exception) {
            AppResult.Error(AppError.OCRError(e.message ?: "Unknown"))
        }
    }

    /**
     * PaddleOCR recognition.
     */
    private fun recognizePaddle(bitmap: Bitmap, config: OCRConfig): List<BlockData> {
        // Placeholder for PaddleOCR integration
        // Would use PaddleOCR Android library or ONNX model
        return recognizeMLKit(bitmap, config) // Fallback for now
    }

    /**
     * ML Kit Text Recognition.
     */
    private fun recognizeMLKit(bitmap: Bitmap, config: OCRConfig): List<BlockData> {
        // Integration with ML Kit would go here
        // For now, return empty list as placeholder
        // Actual implementation would use:
        // val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        // val result = recognizer.process(InputImage.fromBitmap(bitmap, 0)).await()

        return emptyList()
    }

    /**
     * Tesseract OCR fallback.
     */
    private fun recognizeTesseract(bitmap: Bitmap, config: OCRConfig): List<BlockData> {
        // Tesseract integration placeholder
        return emptyList()
    }

    /**
     * Group text blocks by detected bubbles.
     * Ensures text inside same bubble stays together.
     */
    private fun groupBlocksByBubbles(
        blocks: List<BlockData>,
        bubbles: List<BubbleDetector.Bubble>
    ): List<BlockData> {
        val grouped = mutableListOf<BlockData>()
        val assigned = mutableSetOf<Int>()

        for (bubble in bubbles) {
            val bubbleBlocks = mutableListOf<BlockData>()

            for ((index, block) in blocks.withIndex()) {
                if (index in assigned) continue

                // Check if block center is inside bubble
                val blockCenterX = block.block.centerX()
                val blockCenterY = block.block.centerY()

                if (bubble.bounds.contains(blockCenterX, blockCenterY)) {
                    bubbleBlocks.add(block)
                    assigned.add(index)
                }
            }

            if (bubbleBlocks.isNotEmpty()) {
                // Merge blocks in same bubble
                val mergedText = bubbleBlocks.joinToString(" ") { it.text }
                val mergedBounds = bubbleBlocks.map { it.block }.reduce { acc, rect ->
                    acc.apply {
                        left = minOf(left, rect.left)
                        top = minOf(top, rect.top)
                        right = maxOf(right, rect.right)
                        bottom = maxOf(bottom, rect.bottom)
                    }
                }

                grouped.add(BlockData(mergedText, mergedBounds))
            }
        }

        // Add unassigned blocks
        for ((index, block) in blocks.withIndex()) {
            if (index !in assigned) {
                grouped.add(block)
            }
        }

        return sortReadingOrder(grouped)
    }

    /**
     * Sort blocks in reading order (top-to-bottom, left-to-right).
     */
    private fun sortReadingOrder(blocks: List<BlockData>): List<BlockData> {
        return blocks.sortedWith(compareBy(
            { it.block.top / 100 }, // Group by rough vertical position
            { it.block.left }
        ))
    }

    /**
     * Quick OCR for preview mode.
     */
    suspend fun recognizeFast(bitmap: Bitmap): AppResult<List<BlockData>> {
        return recognize(bitmap, OCRConfig(
            backend = OCRBackend.MLKIT,
            usePreprocessing = true,
            useBubbleDetection = false,
            fastMode = true
        )).map { it.blocks }
    }

    /**
     * Accurate OCR with full pipeline.
     */
    suspend fun recognizeAccurate(bitmap: Bitmap): AppResult<List<BlockData>> {
        return recognize(bitmap, OCRConfig(
            backend = OCRBackend.PADDLE,
            usePreprocessing = true,
            useBubbleDetection = true,
            fastMode = false
        )).map { it.blocks }
    }

    /**
     * Release resources.
     */
    fun release() {
        // Release any native resources
    }
}
