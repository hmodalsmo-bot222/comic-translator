package com.comictrans.engine

import android.content.Context
import android.util.Log
import com.comictrans.error.AppError
import com.comictrans.error.AppResult
import com.comictrans.error.ErrorManager
import com.comictrans.model.BlockData
import com.comictrans.translation.PromptManager
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Enhanced translation engine with batch support, context awareness, and local LLM support.
 */
class TranslationEngine(private val context: Context) {

    private val gson = Gson()
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val fastHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    enum class Provider {
        GOOGLE_FREE,      // Free Google Translate (unofficial)
        GOOGLE_GEMINI,    // Google Gemini API
        OPENAI,           // OpenAI GPT
        OPENROUTER,       // OpenRouter.ai
        DEEPL,            // DeepL API
        CUSTOM            // Local/custom OpenAI-compatible
    }

    data class TranslationConfig(
        val provider: Provider = Provider.GOOGLE_FREE,
        val apiKey: String = "",
        val sourceLanguage: String = "auto",
        val targetLanguage: String = "en",
        val model: String = "gpt-3.5-turbo",
        val temperature: Float = 0.7f,
        val maxTokens: Int = 1000,
        val useBatch: Boolean = true,
        val retryCount: Int = 3,
        val retryDelayMs: Long = 1000,
        // Custom provider settings
        val customApiUrl: String = "",
        val customApiKey: String = "",
        val customModel: String = ""
    )

    /**
     * Translate a full page with context (batch mode).
     */
    suspend fun translatePage(
        blocks: List<BlockData>,
        config: TranslationConfig,
        context: PromptManager.PageContext = PromptManager.PageContext()
    ): AppResult<List<BlockData>> = withContext(Dispatchers.IO) {
        if (blocks.isEmpty()) return@withContext AppResult.Success(emptyList())

        try {
            if (config.useBatch && blocks.size > 1 && config.provider != Provider.GOOGLE_FREE) {
                // Batch translation for AI providers
                translateBatch(blocks, config, context)
            } else {
                // Individual translation
                translateIndividual(blocks, config, context)
            }
        } catch (e: Exception) {
            ErrorManager.reportException(e, "translatePage")
            AppResult.Error(AppError.TranslationError(config.provider.name, e.message ?: "Unknown"))
        }
    }

    /**
     * Batch translation - sends all bubbles in one request.
     */
    private suspend fun translateBatch(
        blocks: List<BlockData>,
        config: TranslationConfig,
        pageContext: PromptManager.PageContext
    ): AppResult<List<BlockData>> {
        val systemPrompt = PromptManager.buildSystemPrompt(pageContext.comicType, pageContext.dictionary)
        val userPrompt = PromptManager.buildBatchPrompt(blocks, pageContext, config.targetLanguage)

        val response = when (config.provider) {
            Provider.OPENAI -> callOpenAI(systemPrompt, userPrompt, config)
            Provider.OPENROUTER -> callOpenRouter(systemPrompt, userPrompt, config)
            Provider.GOOGLE_GEMINI -> callGemini(systemPrompt, userPrompt, config)
            Provider.CUSTOM -> callCustomProvider(systemPrompt, userPrompt, config)
            else -> return translateIndividual(blocks, config, pageContext)
        }

        return response.map { rawResponse ->
            val translations = PromptManager.parseBatchResponse(rawResponse, blocks.size)
            blocks.mapIndexed { index, block ->
                block.copy(text = translations.getOrElse(index) { block.text })
            }
        }
    }

    /**
     * Individual bubble translation with retry logic.
     */
    private suspend fun translateIndividual(
        blocks: List<BlockData>,
        config: TranslationConfig,
        pageContext: PromptManager.PageContext
    ): AppResult<List<BlockData>> {
        val results = mutableListOf<BlockData>()

        for ((index, block) in blocks.withIndex()) {
            var lastError: AppError? = null

            // Retry loop
            for (attempt in 0 until config.retryCount) {
                if (attempt > 0) delay(config.retryDelayMs * attempt)

                val result = translateSingle(block, config, pageContext, index, blocks.size)

                when (result) {
                    is AppResult.Success -> {
                        results.add(result.data)
                        lastError = null
                        break
                    }
                    is AppResult.Error -> {
                        lastError = result.error
                        if (result.error is AppError.TranslationRateLimited) {
                            delay(config.retryDelayMs * 5) // Longer delay for rate limits
                        }
                    }
                }
            }

            if (lastError != null) {
                // Keep original text on failure
                results.add(block)
                ErrorManager.report(lastError, Log.WARN)
            }
        }

        return AppResult.Success(results)
    }

    /**
     * Translate a single text block.
     */
    private suspend fun translateSingle(
        block: BlockData,
        config: TranslationConfig,
        pageContext: PromptManager.PageContext,
        index: Int,
        total: Int
    ): AppResult<BlockData> {
        return when (config.provider) {
            Provider.GOOGLE_FREE -> translateGoogleFree(block.text, config)
            Provider.OPENAI -> {
                val prompt = PromptManager.buildSinglePrompt(block.text, pageContext, config.targetLanguage, index, total)
                callOpenAI(PromptManager.buildSystemPrompt(pageContext.comicType, pageContext.dictionary), prompt, config)
                    .map { block.copy(text = it.trim()) }
            }
            Provider.OPENROUTER -> {
                val prompt = PromptManager.buildSinglePrompt(block.text, pageContext, config.targetLanguage, index, total)
                callOpenRouter(PromptManager.buildSystemPrompt(pageContext.comicType, pageContext.dictionary), prompt, config)
                    .map { block.copy(text = it.trim()) }
            }
            Provider.GOOGLE_GEMINI -> {
                val prompt = PromptManager.buildSinglePrompt(block.text, pageContext, config.targetLanguage, index, total)
                callGemini(PromptManager.buildSystemPrompt(pageContext.comicType, pageContext.dictionary), prompt, config)
                    .map { block.copy(text = it.trim()) }
            }
            Provider.DEEPL -> translateDeepL(block.text, config)
            Provider.CUSTOM -> {
                val prompt = PromptManager.buildSinglePrompt(block.text, pageContext, config.targetLanguage, index, total)
                callCustomProvider(PromptManager.buildSystemPrompt(pageContext.comicType, pageContext.dictionary), prompt, config)
                    .map { block.copy(text = it.trim()) }
            }
        }
    }

    /**
     * Google Free Translate (unofficial API).
     */
    private suspend fun translateGoogleFree(
        text: String,
        config: TranslationConfig
    ): AppResult<BlockData> = withContext(Dispatchers.IO) {
        try {
            val encodedText = URLEncoder.encode(text, "UTF-8")
            val url = "https://translate.googleapis.com/translate_a/single?" +
                    "client=gtx&sl=${config.sourceLanguage}&tl=${config.targetLanguage}&dt=t&q=$encodedText"

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0")
                .build()

            val response = fastHttpClient.newCall(request).execute()

            if (!response.isSuccessful) {
                return@withContext AppResult.Error(
                    AppError.TranslationNetworkError("Google Translate: HTTP ${response.code}")
                )
            }

            val json = gson.fromJson(response.body?.string(), JsonArray::class.java)
            val translatedText = StringBuilder()

            json.get(0)?.asJsonArray?.forEach { item ->
                translatedText.append(item.asJsonArray.get(0).asString)
            }

            AppResult.Success(BlockData(translatedText.toString(), block = block))
        } catch (e: Exception) {
            AppResult.Error(AppError.fromException(e, "Google Free Translate"))
        }
    }

    /**
     * DeepL API translation.
     */
    private suspend fun translateDeepL(
        text: String,
        config: TranslationConfig
    ): AppResult<BlockData> = withContext(Dispatchers.IO) {
        try {
            val host = if (config.apiKey.endsWith(":fx")) "api-free.deepl.com" else "api.deepl.com"
            val url = "https://$host/v2/translate"

            val jsonBody = JsonObject().apply {
                addProperty("text", text)
                addProperty("target_lang", config.targetLanguage.uppercase())
                if (config.sourceLanguage != "auto") {
                    addProperty("source_lang", config.sourceLanguage.uppercase())
                }
            }

            val request = Request.Builder()
                .url(url)
                .header("Authorization", "DeepL-Auth-Key ${config.apiKey}")
                .header("Content-Type", "application/json")
                .post(gson.toJson(jsonBody).toRequestBody("application/json".toMediaType()))
                .build()

            val response = httpClient.newCall(request).execute()

            if (response.code == 429) {
                return@withContext AppResult.Error(AppError.TranslationRateLimited("DeepL"))
            }

            if (!response.isSuccessful) {
                return@withContext AppResult.Error(
                    AppError.TranslationError("DeepL", "HTTP ${response.code}")
                )
            }

            val json = gson.fromJson(response.body?.string(), JsonObject::class.java)
            val translations = json.getAsJsonArray("translations")
            val translatedText = translations.get(0).asJsonObject.get("text").asString

            AppResult.Success(BlockData(translatedText, block = block))
        } catch (e: Exception) {
            AppResult.Error(AppError.fromException(e, "DeepL"))
        }
    }

    /**
     * OpenAI API call.
     */
    private suspend fun callOpenAI(
        systemPrompt: String,
        userPrompt: String,
        config: TranslationConfig
    ): AppResult<String> = withContext(Dispatchers.IO) {
        callOpenAICompatible(
            url = "https://api.openai.com/v1/chat/completions",
            apiKey = config.apiKey,
            model = config.model,
            systemPrompt = systemPrompt,
            userPrompt = userPrompt,
            temperature = config.temperature,
            maxTokens = config.maxTokens
        )
    }

    /**
     * OpenRouter API call.
     */
    private suspend fun callOpenRouter(
        systemPrompt: String,
        userPrompt: String,
        config: TranslationConfig
    ): AppResult<String> = withContext(Dispatchers.IO) {
        callOpenAICompatible(
            url = "https://openrouter.ai/api/v1/chat/completions",
            apiKey = config.apiKey,
            model = config.model,
            systemPrompt = systemPrompt,
            userPrompt = userPrompt,
            temperature = config.temperature,
            maxTokens = config.maxTokens,
            extraHeaders = mapOf("HTTP-Referer" to "https://comictrans.app", "X-Title" to "Comic Translator")
        )
    }

    /**
     * Google Gemini API call.
     */
    private suspend fun callGemini(
        systemPrompt: String,
        userPrompt: String,
        config: TranslationConfig
    ): AppResult<String> = withContext(Dispatchers.IO) {
        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/${config.model}:generateContent?key=${config.apiKey}"

            val jsonBody = JsonObject().apply {
                add("contents", JsonArray().apply {
                    add(JsonObject().apply {
                        add("parts", JsonArray().apply {
                            add(JsonObject().apply {
                                addProperty("text", "$systemPrompt\n\n$userPrompt")
                            })
                        })
                    })
                })
                add("generationConfig", JsonObject().apply {
                    addProperty("temperature", config.temperature)
                    addProperty("maxOutputTokens", config.maxTokens)
                })
            }

            val request = Request.Builder()
                .url(url)
                .post(gson.toJson(jsonBody).toRequestBody("application/json".toMediaType()))
                .build()

            val response = httpClient.newCall(request).execute()

            if (!response.isSuccessful) {
                return@withContext AppResult.Error(
                    AppError.TranslationError("Gemini", "HTTP ${response.code}")
                )
            }

            val json = gson.fromJson(response.body?.string(), JsonObject::class.java)
            val candidates = json.getAsJsonArray("candidates")
            val content = candidates.get(0).asJsonObject.getAsJsonObject("content")
            val parts = content.getAsJsonArray("parts")
            val text = parts.get(0).asJsonObject.get("text").asString

            AppResult.Success(text)
        } catch (e: Exception) {
            AppResult.Error(AppError.fromException(e, "Gemini"))
        }
    }

    /**
     * Custom OpenAI-compatible provider (Ollama, LM Studio, etc.).
     */
    private suspend fun callCustomProvider(
        systemPrompt: String,
        userPrompt: String,
        config: TranslationConfig
    ): AppResult<String> = withContext(Dispatchers.IO) {
        val url = config.customApiUrl.ifEmpty { "http://localhost:11434/v1/chat/completions" }
        val model = config.customModel.ifEmpty { "llama2" }

        callOpenAICompatible(
            url = url,
            apiKey = config.customApiKey,
            model = model,
            systemPrompt = systemPrompt,
            userPrompt = userPrompt,
            temperature = config.temperature,
            maxTokens = config.maxTokens
        )
    }

    /**
     * Generic OpenAI-compatible API caller.
     * Works with: OpenAI, OpenRouter, Ollama, LM Studio, LocalAI, etc.
     */
    private suspend fun callOpenAICompatible(
        url: String,
        apiKey: String,
        model: String,
        systemPrompt: String,
        userPrompt: String,
        temperature: Float,
        maxTokens: Int,
        extraHeaders: Map<String, String> = emptyMap()
    ): AppResult<String> = withContext(Dispatchers.IO) {
        try {
            val messages = JsonArray().apply {
                add(JsonObject().apply {
                    addProperty("role", "system")
                    addProperty("content", systemPrompt)
                })
                add(JsonObject().apply {
                    addProperty("role", "user")
                    addProperty("content", userPrompt)
                })
            }

            val jsonBody = JsonObject().apply {
                addProperty("model", model)
                add("messages", messages)
                addProperty("temperature", temperature)
                addProperty("max_tokens", maxTokens)
            }

            val requestBuilder = Request.Builder()
                .url(url)
                .post(gson.toJson(jsonBody).toRequestBody("application/json".toMediaType()))

            if (apiKey.isNotEmpty()) {
                requestBuilder.header("Authorization", "Bearer $apiKey")
            }

            extraHeaders.forEach { (key, value) ->
                requestBuilder.header(key, value)
            }

            val response = httpClient.newCall(requestBuilder.build()).execute()

            if (response.code == 429) {
                return@withContext AppResult.Error(AppError.TranslationRateLimited("OpenAI-Compatible"))
            }

            if (!response.isSuccessful) {
                return@withContext AppResult.Error(
                    AppError.TranslationError("OpenAI-Compatible", "HTTP ${response.code}: ${response.body?.string()}")
                )
            }

            val json = gson.fromJson(response.body?.string(), JsonObject::class.java)
            val choices = json.getAsJsonArray("choices")

            if (choices == null || choices.size() == 0) {
                return@withContext AppResult.Error(
                    AppError.TranslationInvalidResponse("OpenAI-Compatible")
                )
            }

            val message = choices.get(0).asJsonObject.getAsJsonObject("message")
            val content = message.get("content")?.asString ?: ""

            AppResult.Success(content)
        } catch (e: java.net.SocketTimeoutException) {
            AppResult.Error(AppError.NetworkTimeout(url, 60000))
        } catch (e: java.net.UnknownHostException) {
            AppResult.Error(AppError.NetworkNoConnection())
        } catch (e: Exception) {
            AppResult.Error(AppError.fromException(e, "OpenAI-Compatible: $url"))
        }
    }

    fun release() {
        httpClient.dispatcher.executorService.shutdown()
        fastHttpClient.dispatcher.executorService.shutdown()
    }
}
