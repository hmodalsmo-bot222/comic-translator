package com.comictrans.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.comictrans.error.AppError
import com.comictrans.error.AppResult
import com.comictrans.error.ErrorManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * Enhanced sync engine using native CBZ processing.
 * Replaces JavaScript bridge with Kotlin-native implementation.
 */
class SyncEngine(private val context: Context) {

    private val cacheDir = File(context.cacheDir, "comic_pages")
    private var currentCBZPath: String? = null
    private var currentPages: List<CBZProcessor.CBZPage> = emptyList()

    companion object {
        private const val TAG = "SyncEngine"
        private const val PREVIEW_SAMPLE_SIZE = 4 // 1/4 resolution for preview
        private const val FULL_SAMPLE_SIZE = 1 // Full resolution
    }

    /**
     * Load CBZ file and extract page list.
     */
    suspend fun loadCBZ(uri: Uri): AppResult<CBZInfo> = withContext(Dispatchers.IO) {
        try {
            // Copy to internal storage for reliable access
            val internalFile = copyToInternal(uri)
            currentCBZPath = internalFile.absolutePath

            val result = CBZProcessor.inspectCBZ(internalFile.absolutePath)

            result.onSuccess { info ->
                // Pre-extract page list for quick access
                cacheDir.mkdirs()
            }

            result
        } catch (e: SecurityException) {
            AppResult.Error(AppError.FilePermissionDenied(uri.toString()))
        } catch (e: Exception) {
            AppResult.Error(AppError.CBZParseError(uri.lastPathSegment ?: "unknown", e.message ?: "Unknown"))
        }
    }

    /**
     * Load CBZ from file path directly.
     */
    suspend fun loadCBZ(filePath: String): AppResult<CBZInfo> = withContext(Dispatchers.IO) {
        currentCBZPath = filePath
        CBZProcessor.inspectCBZ(filePath)
    }

    /**
     * Get page as Bitmap for display.
     */
    suspend fun getPageBitmap(
        pageIndex: Int,
        fullResolution: Boolean = false
    ): AppResult<Bitmap> = withContext(Dispatchers.IO) {
        val cbzPath = currentCBZPath ?: return@withContext AppResult.Error(
            AppError.CBZParseError("none", "No CBZ loaded")
        )

        val sampleSize = if (fullResolution) FULL_SAMPLE_SIZE else PREVIEW_SAMPLE_SIZE

        CBZProcessor.extractPageByIndex(cbzPath, pageIndex, sampleSize).map { page ->
            page.bitmap ?: throw IllegalStateException("Bitmap not loaded")
        }
    }

    /**
     * Get page with caching support.
     */
    suspend fun getCachedPage(
        pageIndex: Int,
        comicHash: String,
        cacheDao: com.comictrans.db.PageCacheDao,
        sourceLang: String,
        targetLang: String
    ): AppResult<Bitmap> = withContext(Dispatchers.IO) {
        // Check cache first
        val cached = cacheDao.getCachedPage(comicHash, pageIndex)

        if (cached != null && cached.processedImagePath != null) {
            val cachedFile = File(cached.processedImagePath)
            if (cachedFile.exists()) {
                val bitmap = BitmapFactory.decodeFile(cached.processedImagePath)
                if (bitmap != null) {
                    return@withContext AppResult.Success(bitmap)
                }
            }
        }

        // Load from CBZ
        getPageBitmap(pageIndex, true)
    }

    /**
     * Extract all pages to cache directory.
     */
    suspend fun extractAllPages(
        progressCallback: ((current: Int, total: Int) -> Unit)? = null
    ): AppResult<List<CBZProcessor.CBZPage>> = withContext(Dispatchers.IO) {
        val cbzPath = currentCBZPath ?: return@withContext AppResult.Error(
            AppError.CBZParseError("none", "No CBZ loaded")
        )

        cacheDir.mkdirs()
        CBZProcessor.extractAllPages(cbzPath, cacheDir, progressCallback)
    }

    /**
     * Get total page count.
     */
    fun getPageCount(): Int {
        return currentPages.size
    }

    /**
     * Get page name by index.
     */
    fun getPageName(pageIndex: Int): String? {
        return currentPages.getOrNull(pageIndex)?.name
    }

    /**
     * Save processed page to cache.
     */
    suspend fun saveProcessedPage(
        pageIndex: Int,
        bitmap: Bitmap,
        comicHash: String
    ): AppResult<String> = withContext(Dispatchers.IO) {
        try {
            val fileName = "${comicHash}_page_${pageIndex.toString().padStart(4, '0')}.png"
            val file = File(cacheDir, fileName)

            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 95, out)
            }

            AppResult.Success(file.absolutePath)
        } catch (e: Exception) {
            AppResult.Error(AppError.FileWriteError("cache", e.message ?: "Unknown"))
        }
    }

    /**
     * Clear cache directory.
     */
    suspend fun clearCache(): AppResult<Unit> = withContext(Dispatchers.IO) {
        try {
            cacheDir.listFiles()?.forEach { it.delete() }
            AppResult.Success(Unit)
        } catch (e: Exception) {
            AppResult.Error(AppError.FileWriteError(cacheDir.absolutePath, e.message ?: "Unknown"))
        }
    }

    /**
     * Copy URI content to internal file.
     */
    private suspend fun copyToInternal(uri: Uri): File = withContext(Dispatchers.IO) {
        val fileName = uri.lastPathSegment ?: "comic.cbz"
        val internalFile = File(context.filesDir, "imports/$fileName")
        internalFile.parentFile?.mkdirs()

        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(internalFile).use { output ->
                input.copyTo(output)
            }
        }

        internalFile
    }

    /**
     * Generate hash for comic file.
     */
    suspend fun generateComicHash(filePath: String): String = withContext(Dispatchers.IO) {
        try {
            val digest = java.security.MessageDigest.getInstance("SHA-256")
            File(filePath).inputStream().use { input ->
                val buffer = ByteArray(8192)
                var read: Int
                while (input.read(buffer).also { read = it } != -1) {
                    digest.update(buffer, 0, read)
                }
            }
            digest.digest().joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            // Fallback to file path + size + modified time
            val file = File(filePath)
            "${file.name}_${file.length()}_${file.lastModified()}"
        }
    }

    /**
     * Release resources.
     */
    fun release() {
        currentCBZPath = null
        currentPages = emptyList()
    }
}

/**
 * Alias for CBZ info from processor.
 */
typealias CBZInfo = CBZProcessor.CBZInfo
