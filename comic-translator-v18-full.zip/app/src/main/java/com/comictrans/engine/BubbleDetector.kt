package com.comictrans.engine

import android.graphics.Bitmap
import android.graphics.Rect
import com.comictrans.error.AppError
import com.comictrans.error.AppResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Detects speech bubbles in comic pages using OpenCV.
 * Supports: circular, irregular, and rectangular bubbles.
 */
object BubbleDetector {

    private const val MIN_BUBBLE_AREA = 500
    private const val MAX_BUBBLE_AREA = 500000
    private const val MIN_BUBBLE_RATIO = 0.3
    private const val MAX_BUBBLE_RATIO = 3.0
    private const val WHITE_THRESHOLD = 240

    data class Bubble(
        val bounds: Rect,
        val contour: MatOfPoint,
        val confidence: Float,
        val shape: BubbleShape,
        val mask: Mat? = null
    ) {
        fun release() {
            contour.release()
            mask?.release()
        }
    }

    enum class BubbleShape {
        CIRCULAR,       // Classic round speech bubble
        IRREGULAR,      // Cloud-like or jagged bubble
        RECTANGULAR,    // Square/rectangular bubble
        UNKNOWN         // Could not determine
    }

    /**
     * Main detection pipeline.
     */
    suspend fun detectBubbles(bitmap: Bitmap): AppResult<List<Bubble>> = withContext(Dispatchers.Default) {
        try {
            val src = Mat()
            Utils.bitmapToMat(bitmap, src)

            // Step 1: Preprocess - find white/light regions
            val gray = Mat()
            Imgproc.cvtColor(src, gray, Imgproc.COLOR_BGR2GRAY)

            // Step 2: Threshold to find light areas (potential bubbles)
            val binary = Mat()
            Imgproc.threshold(gray, binary, WHITE_THRESHOLD.toDouble(), 255.0, Imgproc.THRESH_BINARY)

            // Step 3: Morphological operations to close gaps
            val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(5.0, 5.0))
            val closed = Mat()
            Imgproc.morphologyEx(binary, closed, Imgproc.MORPH_CLOSE, kernel)

            // Step 4: Find contours
            val contours = ArrayList<MatOfPoint>()
            val hierarchy = Mat()
            Imgproc.findContours(closed, contours, hierarchy, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)

            // Step 5: Filter and classify bubbles
            val bubbles = ArrayList<Bubble>()
            for (contour in contours) {
                val area = Imgproc.contourArea(contour)
                if (area < MIN_BUBBLE_AREA || area > MAX_BUBBLE_AREA) continue

                val bounds = Imgproc.boundingRect(contour)
                val ratio = bounds.width.toFloat() / bounds.height.toFloat()
                if (ratio < MIN_BUBBLE_RATIO || ratio > MAX_BUBBLE_RATIO) continue

                // Check if region is mostly white/light (bubble characteristic)
                val roi = Mat(gray, bounds)
                val mean = Core.mean(roi)
                roi.release()

                if (mean.`val`[0] < 200) continue // Too dark to be a bubble

                val shape = classifyShape(contour)
                val confidence = calculateConfidence(contour, area, bounds, mean.`val`[0])

                // Create mask for this bubble
                val mask = Mat.zeros(src.size(), CvType.CV_8UC1)
                Imgproc.drawContours(mask, listOf(contour), -1, Scalar(255.0), -1)

                bubbles.add(Bubble(bounds, contour, confidence, shape, mask))
            }

            // Sort by reading order (top-to-bottom, left-to-right)
            bubbles.sortWith(compareBy({ it.bounds.top }, { it.bounds.left }))

            // Cleanup
            src.release()
            gray.release()
            binary.release()
            closed.release()
            hierarchy.release()
            kernel.release()

            AppResult.Success(bubbles)
        } catch (e: OutOfMemoryError) {
            AppResult.Error(AppError.ImageOutOfMemory("${bitmap.width}x${bitmap.height}"))
        } catch (e: Exception) {
            AppResult.Error(AppError.ImageProcessingError("Bubble Detection", e.message ?: "Unknown"))
        }
    }

    /**
     * Detect bubbles with text inside them (more accurate).
     */
    suspend fun detectTextBubbles(bitmap: Bitmap, textBlocks: List<Rect>): AppResult<List<Bubble>> = withContext(Dispatchers.Default) {
        detectBubbles(bitmap).map { bubbles ->
            // Filter bubbles that contain text blocks
            bubbles.filter { bubble ->
                textBlocks.any { text ->
                    val intersection = Rect(
                        max(bubble.bounds.left, text.left),
                        max(bubble.bounds.top, text.top),
                        min(bubble.bounds.right, text.right),
                        min(bubble.bounds.bottom, text.bottom)
                    )
                    val intersectionArea = intersection.width() * intersection.height()
                    val textArea = text.width() * text.height()
                    intersectionArea > textArea * 0.5 // 50% overlap
                }
            }
        }
    }

    /**
     * Create a combined mask for all bubbles.
     */
    fun createCombinedMask(bubbles: List<Bubble>, width: Int, height: Int): Mat {
        val mask = Mat.zeros(Size(width.toDouble(), height.toDouble()), CvType.CV_8UC1)
        for (bubble in bubbles) {
            bubble.mask?.let {
                Core.bitwise_or(mask, it, mask)
            }
        }
        return mask
    }

    /**
     * Classify bubble shape based on contour analysis.
     */
    private fun classifyShape(contour: MatOfPoint): BubbleShape {
        val points = MatOfPoint2f(*contour.toArray())
        val perimeter = Imgproc.arcLength(points, true)
        val area = Imgproc.contourArea(contour)

        // Circularity: 4π*area/perimeter² (1.0 = perfect circle)
        val circularity = (4 * Math.PI * area) / (perimeter * perimeter)

        // Approximate polygon
        val approx = MatOfPoint2f()
        Imgproc.approxPolyDP(points, approx, 0.02 * perimeter, true)
        val vertices = approx.toArray().size

        points.release()
        approx.release()

        return when {
            circularity > 0.75 -> BubbleShape.CIRCULAR
            vertices <= 6 -> BubbleShape.RECTANGULAR
            else -> BubbleShape.IRREGULAR
        }
    }

    /**
     * Calculate confidence score for detected bubble.
     */
    private fun calculateConfidence(contour: MatOfPoint, area: Double, bounds: Rect, brightness: Double): Float {
        val points = MatOfPoint2f(*contour.toArray())
        val perimeter = Imgproc.arcLength(points, true)
        val circularity = ((4 * Math.PI * area) / (perimeter * perimeter)).toFloat()
        points.release()

        // Size score: prefer medium bubbles
        val areaScore = 1.0f - abs((area - 50000) / 500000).toFloat().coerceIn(0f, 1f)

        // Brightness score: prefer white bubbles
        val brightnessScore = (brightness / 255.0).toFloat()

        // Shape score: prefer recognizable shapes
        val shapeScore = if (circularity > 0.5) circularity else 0.3f

        return (areaScore * 0.3f + brightnessScore * 0.3f + shapeScore * 0.4f).coerceIn(0f, 1f)
    }

    /**
     * Release all bubble resources.
     */
    fun releaseBubbles(bubbles: List<Bubble>) {
        bubbles.forEach { it.release() }
    }
}
