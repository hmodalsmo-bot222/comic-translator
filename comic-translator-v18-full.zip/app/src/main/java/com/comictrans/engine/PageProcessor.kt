package com.comictrans.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import com.comictrans.db.PageCacheDao
import com.comictrans.db.PageCacheEntity
import com.comictrans.error.AppError
import com.comictrans.error.AppResult
import com.comictrans.error.ErrorManager
import com.comictrans.model.BlockData
import com.comictrans.model.SettingsData
import com.comictrans.translation.PromptManager
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

/**
 * Dedicated page processor that handles the full OCR → Translation → Erasure → Render pipeline.
 * Extracted from AppInterface to reduce God Class size.
 */
class PageProcessor(
    private val context: Context,
    private val ocrEngine: OCREngine,
    private val translationEngine: TranslationEngine,
    private val erasureEngine: ErasureEngine,
    private val syncEngine: SyncEngine,
    private val cacheDao: PageCacheDao,
    private val gson: Gson
) {

    data class ProcessingResult(
        val pageIndex: Int,
        val originalBitmap: Bitmap,
        val processedBitmap: Bitmap,
        val blocks: List<BlockData>,
        val bubbles: List<BubbleDetector.Bubble>,
        val ocrTimeMs: Long,
        val translateTimeMs: Long,
        val eraseTimeMs: Long,
        val isFromCache: Boolean = false
    )

    data class ProcessingConfig(
        val translationConfig: TranslationEngine.TranslationConfig,
        val comicType: PromptManager.ComicType,
        val dictionary: PromptManager.ComicDictionary,
        val pageContext: PromptManager.PageContext,
        val erasureLevel: ErasureEngine.ErasureLevel,
        val useBubbleMask: Boolean,
        val fontSize: Float,
        val forceReprocess: Boolean
    )

    /**
     * Process a single page through the full pipeline.
     */
    suspend fun processPage(
        pageIndex: Int,
        bitmap: Bitmap,
        comicHash: String,
        settings: SettingsData
    ): AppResult<ProcessingResult> = withContext(Dispatchers.Default) {

        val config = createConfig(settings, pageIndex)

        // Check cache first
        if (!config.forceReprocess) {
            val cached = checkCache(comicHash, pageIndex, settings)
            if (cached != null) {
                return@withContext AppResult.Success(cached.copy(isFromCache = true))
            }
        }

        try {
            // Step 1: OCR
            val ocrStart = System.currentTimeMillis()
            val ocrConfig = OCREngine.OCRConfig(
                backend = OCREngine.OCRBackend.valueOf(settings.ocrEngine.uppercase()),
                usePreprocessing = settings.usePreprocessing,
                useBubbleDetection = settings.detectBubbles,
                fastMode = settings.fastMode,
                language = settings.sourceLanguage
            )

            val ocrResult = ocrEngine.recognize(bitmap, ocrConfig)
            val (blocks, bubbles, ocrTime) = when (ocrResult) {
                is AppResult.Success -> Triple(
                    ocrResult.data.blocks,
                    ocrResult.data.bubbles,
                    ocrResult.data.processingTimeMs
                )
                is AppResult.Error -> {
                    ErrorManager.report(ocrResult.error, android.util.Log.WARN)
                    return@withContext AppResult.Error(ocrResult.error)
                }
            }

            if (blocks.isEmpty()) {
                return@withContext AppResult.Success(
                    ProcessingResult(
                        pageIndex = pageIndex,
                        originalBitmap = bitmap,
                        processedBitmap = bitmap,
                        blocks = emptyList(),
                        bubbles = bubbles,
                        ocrTimeMs = ocrTime,
                        translateTimeMs = 0,
                        eraseTimeMs = 0
                    )
                )
            }

            // Step 2: Translation
            val translateStart = System.currentTimeMillis()
            val translatedResult = translationEngine.translatePage(blocks, config.translationConfig, config.pageContext)
            val translatedBlocks = when (translatedResult) {
                is AppResult.Success -> translatedResult.data
                is AppResult.Error -> {
                    ErrorManager.report(translatedResult.error, android.util.Log.WARN)
                    blocks // Fallback to original
                }
            }
            val translateTime = System.currentTimeMillis() - translateStart

            // Step 3: Erasure
            val eraseStart = System.currentTimeMillis()
            val textBounds = blocks.map { it.block }

            val eraseResult = if (config.useBubbleMask && bubbles.isNotEmpty()) {
                erasureEngine.eraseWithBubbleMask(bitmap, bubbles)
            } else {
                erasureEngine.eraseText(bitmap, textBounds, config.erasureLevel)
            }

            val erasedBitmap = when (eraseResult) {
                is AppResult.Success -> eraseResult.data
                is AppResult.Error -> {
                    ErrorManager.report(eraseResult.error, android.util.Log.WARN)
                    // Fallback
                    erasureEngine.fallbackErase(bitmap, textBounds).getOrNull() ?: bitmap
                }
            }
            val eraseTime = System.currentTimeMillis() - eraseStart

            // Step 4: Render
            val finalBitmap = renderTranslatedText(erasedBitmap, translatedBlocks, config.fontSize)

            // Cleanup intermediate bitmap
            if (erasedBitmap != bitmap && erasedBitmap != finalBitmap) {
                erasedBitmap.recycle()
            }

            val result = ProcessingResult(
                pageIndex = pageIndex,
                originalBitmap = bitmap,
                processedBitmap = finalBitmap,
                blocks = translatedBlocks,
                bubbles = bubbles,
                ocrTimeMs = ocrTime,
                translateTimeMs = translateTime,
                eraseTimeMs = eraseTime
            )

            // Save to cache
            saveToCache(result, comicHash, settings)

            AppResult.Success(result)

        } catch (e: OutOfMemoryError) {
            AppResult.Error(AppError.ImageOutOfMemory("${bitmap.width}x${bitmap.height}"))
        } catch (e: Exception) {
            AppResult.Error(AppError.ImageProcessingError("Page Processing", e.message ?: "Unknown"))
        }
    }

    /**
     * Check if page exists in cache and return it.
     */
    private suspend fun checkCache(
        comicHash: String,
        pageIndex: Int,
        settings: SettingsData
    ): ProcessingResult? = withContext(Dispatchers.IO) {
        val cached = cacheDao.getCachedPage(comicHash, pageIndex) ?: return@withContext null

        // Verify language match
        if (cached.sourceLanguage != settings.sourceLanguage ||
            cached.targetLanguage != settings.targetLanguage) {
            return@withContext null
        }

        // Load processed image
        cached.processedImagePath?.let { path ->
            val file = java.io.File(path)
            if (file.exists()) {
                val bitmap = android.graphics.BitmapFactory.decodeFile(path)
                if (bitmap != null) {
                    val blocks = try {
                        gson.fromJson(cached.translationResult, Array<BlockData>::class.java)?.toList() ?: emptyList()
                    } catch (e: Exception) {
                        emptyList()
                    }

                    return@withContext ProcessingResult(
                        pageIndex = pageIndex,
                        originalBitmap = bitmap,
                        processedBitmap = bitmap,
                        blocks = blocks,
                        bubbles = emptyList(),
                        ocrTimeMs = 0,
                        translateTimeMs = 0,
                        eraseTimeMs = 0,
                        isFromCache = true
                    )
                }
            }
        }

        null
    }

    /**
     * Save processed result to cache.
     */
    private suspend fun saveToCache(
        result: ProcessingResult,
        comicHash: String,
        settings: SettingsData
    ) = withContext(Dispatchers.IO) {
        // Save image
        val pathResult = syncEngine.saveProcessedPage(result.pageIndex, result.processedBitmap, comicHash)
        val imagePath = (pathResult as? AppResult.Success)?.data

        val entity = PageCacheEntity(
            comicHash = comicHash,
            pageNumber = result.pageIndex,
            pageName = "page_${result.pageIndex}",
            ocrResult = gson.toJson(result.blocks),
            translationResult = gson.toJson(result.blocks),
            processedImagePath = imagePath,
            bubbleData = gson.toJson(result.bubbles.map {
                mapOf(
                    "left" to it.bounds.left,
                    "top" to it.bounds.top,
                    "right" to it.bounds.right,
                    "bottom" to it.bounds.bottom
                )
            }),
            sourceLanguage = settings.sourceLanguage,
            targetLanguage = settings.targetLanguage,
            ocrEngine = settings.ocrEngine,
            translationProvider = settings.provider
        )

        cacheDao.insertOrUpdate(entity)
    }

    /**
     * Render translated text onto image.
     */
    private fun renderTranslatedText(
        bitmap: Bitmap,
        blocks: List<BlockData>,
        fontSize: Float
    ): Bitmap {
        val result = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = fontSize
            typeface = Typeface.DEFAULT
            textAlign = Paint.Align.CENTER
        }

        for (block in blocks) {
            val rect = block.block
            val text = block.text

            // Calculate optimal text size
            val targetWidth = rect.width() * 0.9f
            val targetHeight = rect.height() * 0.9f

            var currentSize = fontSize
            paint.textSize = currentSize

            val bounds = android.graphics.Rect()
            paint.getTextBounds(text, 0, text.length, bounds)

            while ((bounds.width() > targetWidth || bounds.height() > targetHeight) && currentSize > 8) {
                currentSize -= 1
                paint.textSize = currentSize
                paint.getTextBounds(text, 0, text.length, bounds)
            }

            val x = rect.centerX().toFloat()
            val y = rect.centerY().toFloat() + bounds.height() / 2f

            canvas.drawText(text, x, y, paint)
        }

        return result
    }

    /**
     * Create processing config from settings.
     */
    private fun createConfig(settings: SettingsData, pageIndex: Int): ProcessingConfig {
        val comicType = when (settings.comicType.lowercase()) {
            "manga" -> PromptManager.ComicType.MANGA
            "manhwa" -> PromptManager.ComicType.MANHWA
            else -> PromptManager.ComicType.WESTERN
        }

        val dictionary = PromptManager.ComicDictionary(
            seriesName = settings.seriesName,
            characterNames = settings.characterMap,
            specialTerms = settings.termMap
        )

        val pageContext = PromptManager.PageContext(
            seriesName = settings.seriesName,
            chapterNumber = settings.chapterNumber,
            pageNumber = pageIndex,
            previousSummary = settings.previousSummary,
            charactersPresent = settings.charactersPresent,
            comicType = comicType,
            dictionary = dictionary
        )

        val erasureLevel = when (settings.erasureLevel.lowercase()) {
            "fast" -> ErasureEngine.ErasureLevel.FAST
            "medium" -> ErasureEngine.ErasureLevel.MEDIUM
            "high" -> ErasureEngine.ErasureLevel.HIGH
            "ultra" -> ErasureEngine.ErasureLevel.ULTRA
            else -> erasureEngine.autoSelectLevel()
        }

        val translationConfig = TranslationEngine.TranslationConfig(
            provider = TranslationEngine.Provider.valueOf(settings.provider.uppercase()),
            apiKey = settings.apiKey,
            sourceLanguage = settings.sourceLanguage,
            targetLanguage = settings.targetLanguage,
            model = settings.model,
            temperature = settings.temperature,
            useBatch = settings.batchMode,
            customApiUrl = settings.customApiUrl,
            customApiKey = settings.customApiKey,
            customModel = settings.customModel
        )

        return ProcessingConfig(
            translationConfig = translationConfig,
            comicType = comicType,
            dictionary = dictionary,
            pageContext = pageContext,
            erasureLevel = erasureLevel,
            useBubbleMask = settings.useBubbleMask,
            fontSize = settings.fontSize,
            forceReprocess = settings.forceReprocess
        )
    }

    /**
     * Release resources.
     */
    fun release() {
        // Engines released by AppInterface
    }
}
