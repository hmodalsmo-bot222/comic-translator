package com.comictrans.engine

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.comictrans.error.AppError
import com.comictrans.error.AppResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

/**
 * Native Kotlin CBZ processor using ZipInputStream.
 * Replaces JavaScript-based extraction.
 */
object CBZProcessor {

    private const val BUFFER_SIZE = 8192
    private const val MAX_IMAGE_DIMENSION = 4096
    private val SUPPORTED_EXTENSIONS = setOf("jpg", "jpeg", "png", "webp", "bmp", "gif")

    data class CBZPage(
        val index: Int,
        val name: String,
        val bitmap: Bitmap? = null,
        val path: String? = null,
        val width: Int = 0,
        val height: Int = 0,
        val sizeBytes: Long = 0
    )

    data class CBZInfo(
        val fileName: String,
        val totalPages: Int,
        val totalSize: Long,
        val pageList: List<String>,
        val isValid: Boolean,
        val errorMessage: String? = null
    )

    /**
     * Validate and inspect CBZ file without extracting.
     */
    suspend fun inspectCBZ(filePath: String): AppResult<CBZInfo> = withContext(Dispatchers.IO) {
        try {
            val file = File(filePath)
            if (!file.exists()) {
                return@withContext AppResult.Error(AppError.FileNotFound(filePath))
            }

            if (!file.canRead()) {
                return@withContext AppResult.Error(AppError.FilePermissionDenied(filePath))
            }

            val pages = mutableListOf<String>()
            var totalSize = 0L
            var isValid = false

            ZipInputStream(BufferedInputStream(FileInputStream(file), BUFFER_SIZE)).use { zis ->
                var entry: ZipEntry?
                while (zis.nextEntry.also { entry = it } != null) {
                    val entryName = entry!!.name

                    // Skip directories and hidden files
                    if (entry!!.isDirectory || entryName.startsWith("__") || entryName.startsWith(".")) {
                        continue
                    }

                    // Check if it's an image
                    val ext = entryName.substringAfterLast('.', "").lowercase()
                    if (ext in SUPPORTED_EXTENSIONS) {
                        pages.add(entryName)
                        totalSize += entry!!.size
                    }

                    isValid = true
                }
            }

            if (pages.isEmpty()) {
                return@withContext AppResult.Error(
                    AppError.CBZCorrupted(file.name)
                )
            }

            // Sort pages naturally (page_1, page_2, page_10 instead of page_1, page_10, page_2)
            val sortedPages = pages.sortedWith(naturalOrder())

            AppResult.Success(CBZInfo(
                fileName = file.name,
                totalPages = sortedPages.size,
                totalSize = totalSize,
                pageList = sortedPages,
                isValid = true
            ))

        } catch (e: java.util.zip.ZipException) {
            AppResult.Error(AppError.CBZCorrupted(File(filePath).name))
        } catch (e: Exception) {
            AppResult.Error(AppError.CBZParseError(File(filePath).name, e.message ?: "Unknown"))
        }
    }

    /**
     * Extract a specific page as Bitmap.
     */
    suspend fun extractPage(
        filePath: String,
        pageName: String,
        sampleSize: Int = 1
    ): AppResult<CBZPage> = withContext(Dispatchers.IO) {
        try {
            val file = File(filePath)

            ZipInputStream(BufferedInputStream(FileInputStream(file), BUFFER_SIZE)).use { zis ->
                var entry: ZipEntry?
                while (zis.nextEntry.also { entry = it } != null) {
                    if (entry!!.name == pageName) {
                        // Decode with options to prevent OOM
                        val options = BitmapFactory.Options().apply {
                            inSampleSize = sampleSize
                            inJustDecodeBounds = false
                        }

                        val bitmap = BitmapFactory.decodeStream(zis, null, options)
                            ?: return@withContext AppResult.Error(
                                AppError.ImageDecodeError(pageName)
                            )

                        // Check dimensions
                        if (bitmap.width > MAX_IMAGE_DIMENSION || bitmap.height > MAX_IMAGE_DIMENSION) {
                            bitmap.recycle()
                            return@withContext AppResult.Error(
                                AppError.ImageOutOfMemory("${bitmap.width}x${bitmap.height}")
                            )
                        }

                        return@withContext AppResult.Success(CBZPage(
                            index = -1,
                            name = pageName,
                            bitmap = bitmap,
                            width = bitmap.width,
                            height = bitmap.height,
                            sizeBytes = entry!!.size
                        ))
                    }
                }
            }

            AppResult.Error(AppError.CBZExtractionError(file.name, pageName))

        } catch (e: OutOfMemoryError) {
            AppResult.Error(AppError.ImageOutOfMemory("CBZ page extraction"))
        } catch (e: Exception) {
            AppResult.Error(AppError.CBZExtractionError(File(filePath).name, pageName))
        }
    }

    /**
     * Extract page by index.
     */
    suspend fun extractPageByIndex(
        filePath: String,
        pageIndex: Int,
        sampleSize: Int = 1
    ): AppResult<CBZPage> {
        val infoResult = inspectCBZ(filePath)
        return infoResult.flatMap { info ->
            if (pageIndex < 0 || pageIndex >= info.pageList.size) {
                AppResult.Error(AppError.CBZExtractionError(info.fileName, "Index $pageIndex out of bounds"))
            } else {
                extractPage(filePath, info.pageList[pageIndex], sampleSize)
                    .map { it.copy(index = pageIndex) }
            }
        }
    }

    /**
     * Extract all pages to cache directory.
     */
    suspend fun extractAllPages(
        filePath: String,
        outputDir: File,
        progressCallback: ((Int, Int) -> Unit)? = null
    ): AppResult<List<CBZPage>> = withContext(Dispatchers.IO) {
        try {
            val infoResult = inspectCBZ(filePath)
            val info = when (infoResult) {
                is AppResult.Success -> infoResult.data
                is AppResult.Error -> return@withContext AppResult.Error(infoResult.error)
            }

            outputDir.mkdirs()
            val results = mutableListOf<CBZPage>()

            val file = File(filePath)
            ZipInputStream(BufferedInputStream(FileInputStream(file), BUFFER_SIZE)).use { zis ->
                var entry: ZipEntry?
                var pageIndex = 0

                while (zis.nextEntry.also { entry = it } != null) {
                    val entryName = entry!!.name

                    if (entry!!.isDirectory || !info.pageList.contains(entryName)) {
                        continue
                    }

                    // Extract to file
                    val outputFile = File(outputDir, "page_${pageIndex.toString().padStart(4, '0')}.jpg")
                    FileOutputStream(outputFile).use { fos ->
                        val buffer = ByteArray(BUFFER_SIZE)
                        var read: Int
                        while (zis.read(buffer).also { read = it } != -1) {
                            fos.write(buffer, 0, read)
                        }
                    }

                    // Decode bounds only
                    val options = BitmapFactory.Options().apply {
                        inJustDecodeBounds = true
                    }
                    BitmapFactory.decodeFile(outputFile.absolutePath, options)

                    results.add(CBZPage(
                        index = pageIndex,
                        name = entryName,
                        path = outputFile.absolutePath,
                        width = options.outWidth,
                        height = options.outHeight,
                        sizeBytes = entry!!.size
                    ))

                    progressCallback?.invoke(pageIndex + 1, info.totalPages)
                    pageIndex++
                }
            }

            AppResult.Success(results.sortedBy { it.index })

        } catch (e: Exception) {
            AppResult.Error(AppError.CBZExtractionError(File(filePath).name, e.message ?: "Unknown"))
        }
    }

    /**
     * Get page dimensions without full decode (memory efficient).
     */
    suspend fun getPageDimensions(filePath: String, pageName: String): AppResult<Pair<Int, Int>> = withContext(Dispatchers.IO) {
        try {
            val file = File(filePath)

            ZipInputStream(BufferedInputStream(FileInputStream(file), BUFFER_SIZE)).use { zis ->
                var entry: ZipEntry?
                while (zis.nextEntry.also { entry = it } != null) {
                    if (entry!!.name == pageName) {
                        val options = BitmapFactory.Options().apply {
                            inJustDecodeBounds = true
                        }
                        BitmapFactory.decodeStream(zis, null, options)

                        return@withContext AppResult.Success(
                            Pair(options.outWidth, options.outHeight)
                        )
                    }
                }
            }

            AppResult.Error(AppError.CBZExtractionError(File(filePath).name, pageName))

        } catch (e: Exception) {
            AppResult.Error(AppError.CBZExtractionError(File(filePath).name, e.message ?: "Unknown"))
        }
    }

    /**
     * Natural sort comparator for page names.
     * Handles: page_1, page_2, page_10 correctly.
     */
    private fun naturalOrder(): Comparator<String> {
        return Comparator { a, b ->
            val regex = Regex("""(\d+)|(\D+)""")
            val aTokens = regex.findAll(a).map { it.value }.toList()
            val bTokens = regex.findAll(b).map { it.value }.toList()

            for (i in 0 until minOf(aTokens.size, bTokens.size)) {
                val aNum = aTokens[i].toIntOrNull()
                val bNum = bTokens[i].toIntOrNull()

                val cmp = when {
                    aNum != null && bNum != null -> aNum.compareTo(bNum)
                    aNum != null -> -1
                    bNum != null -> 1
                    else -> aTokens[i].compareTo(bTokens[i], ignoreCase = true)
                }

                if (cmp != 0) return@Comparator cmp
            }

            aTokens.size.compareTo(bTokens.size)
        }
    }
}
