package com.comictrans.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import com.comictrans.error.AppError
import com.comictrans.error.AppResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

/**
 * Enhanced text erasure engine with performance levels and AI support.
 */
class ErasureEngine(private val context: Context) {

    enum class ErasureLevel {
        FAST,       // OpenCV Telea - fastest, lowest quality
        MEDIUM,     // OpenCV NS - balanced
        HIGH,       // TFLite Lite Model - good quality, offline
        ULTRA       // ONNX Model - best quality, requires download
    }

    private var tfliteInterpreter: Interpreter? = null
    private var currentLevel: ErasureLevel = ErasureLevel.MEDIUM

    companion object {
        private const val TFLITE_MODEL_PATH = "models/inpaint_lite.tflite"
        private const val ONNX_MODEL_PATH = "models/inpaint_ultra.onnx"
        private const val INPAINT_RADIUS = 3
        private const val SAMPLE_SIZE = 11 // For background color analysis
    }

    /**
     * Initialize with appropriate level based on device capabilities.
     */
    fun initialize(preferredLevel: ErasureLevel = ErasureLevel.MEDIUM): AppResult<Unit> {
        currentLevel = preferredLevel

        return when (preferredLevel) {
            ErasureLevel.FAST, ErasureLevel.MEDIUM -> AppResult.Success(Unit)
            ErasureLevel.HIGH -> loadTFLiteModel()
            ErasureLevel.ULTRA -> AppResult.Success(Unit) // ONNX loaded on-demand
        }
    }

    /**
     * Auto-select level based on device specs.
     */
    fun autoSelectLevel(): ErasureLevel {
        val runtime = Runtime.getRuntime()
        val maxMemoryMB = runtime.maxMemory() / (1024 * 1024)
        val availableProcessors = Runtime.getRuntime().availableProcessors()

        return when {
            maxMemoryMB < 512 || availableProcessors < 4 -> ErasureLevel.FAST
            maxMemoryMB < 1024 -> ErasureLevel.MEDIUM
            maxMemoryMB < 2048 -> ErasureLevel.HIGH
            else -> ErasureLevel.ULTRA
        }
    }

    /**
     * Main erasure function with level selection.
     */
    suspend fun eraseText(
        bitmap: Bitmap,
        textBounds: List<Rect>,
        level: ErasureLevel = currentLevel
    ): AppResult<Bitmap> = withContext(Dispatchers.Default) {
        try {
            when (level) {
                ErasureLevel.FAST -> eraseFast(bitmap, textBounds)
                ErasureLevel.MEDIUM -> eraseMedium(bitmap, textBounds)
                ErasureLevel.HIGH -> eraseHigh(bitmap, textBounds)
                ErasureLevel.ULTRA -> eraseUltra(bitmap, textBounds)
            }
        } catch (e: OutOfMemoryError) {
            // Fallback to lower level
            if (level != ErasureLevel.FAST) {
                eraseText(bitmap, textBounds, ErasureLevel.FAST)
            } else {
                AppResult.Error(AppError.ImageOutOfMemory("${bitmap.width}x${bitmap.height}"))
            }
        } catch (e: Exception) {
            AppResult.Error(AppError.ImageProcessingError("Text Erasure", e.message ?: "Unknown"))
        }
    }

    /**
     * FAST: OpenCV Telea inpainting.
     * Fastest method, suitable for simple backgrounds.
     */
    private fun eraseFast(bitmap: Bitmap, bounds: List<Rect>): AppResult<Bitmap> {
        return performInpaint(bitmap, bounds, Photo.INPAINT_TELEA)
    }

    /**
     * MEDIUM: OpenCV Navier-Stokes inpainting.
     * Better for complex backgrounds.
     */
    private fun eraseMedium(bitmap: Bitmap, bounds: List<Rect>): AppResult<Bitmap> {
        return performInpaint(bitmap, bounds, Photo.INPAINT_NS)
    }

    /**
     * HIGH: TFLite inpainting model.
     * Good quality, works offline.
     */
    private fun eraseHigh(bitmap: Bitmap, bounds: List<Rect>): AppResult<Bitmap> {
        val interpreter = tfliteInterpreter ?: return eraseMedium(bitmap, bounds)

        // For now, use OpenCV as TFLite model processes patches
        // Full TFLite integration would process 512x512 patches
        return eraseMedium(bitmap, bounds)
    }

    /**
     * ULTRA: ONNX model (placeholder for future integration).
     */
    private fun eraseUltra(bitmap: Bitmap, bounds: List<Rect>): AppResult<Bitmap> {
        // ONNX Runtime integration would go here
        // For now, fallback to HIGH
        return eraseHigh(bitmap, bounds)
    }

    /**
     * Core inpainting logic with mask creation.
     */
    private fun performInpaint(
        bitmap: Bitmap,
        bounds: List<Rect>,
        method: Int
    ): AppResult<Bitmap> {
        val src = Mat()
        Utils.bitmapToMat(bitmap, src)

        // Create mask from text bounds
        val mask = Mat.zeros(src.size(), CvType.CV_8UC1)
        for (bound in bounds) {
            // Expand slightly to catch text edges
            val expanded = Rect(
                (bound.left - 2).coerceAtLeast(0),
                (bound.top - 2).coerceAtLeast(0),
                (bound.right + 2).coerceAtMost(bitmap.width),
                (bound.bottom + 2).coerceAtMost(bitmap.height)
            )
            Imgproc.rectangle(
                mask,
                org.opencv.core.Point(expanded.left.toDouble(), expanded.top.toDouble()),
                org.opencv.core.Point(expanded.right.toDouble(), expanded.bottom.toDouble()),
                Scalar(255.0),
                -1
            )
        }

        // Perform inpainting
        val result = Mat()
        Photo.inpaint(src, mask, result, INPAINT_RADIUS.toDouble(), method)

        // Convert back to bitmap
        val output = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(result, output)

        // Cleanup
        src.release()
        mask.release()
        result.release()

        if (output != bitmap) bitmap.recycle()

        return AppResult.Success(output)
    }

    /**
     * Enhanced fallback erasure with background color analysis.
     * Analyzes surrounding pixels to match background instead of white.
     */
    suspend fun fallbackErase(
        bitmap: Bitmap,
        textBounds: List<Rect>
    ): AppResult<Bitmap> = withContext(Dispatchers.Default) {
        try {
            val output = bitmap.copy(Bitmap.Config.ARGB_8888, true)
            val canvas = Canvas(output)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)

            for (bound in textBounds) {
                // Analyze background color from surrounding area
                val bgColor = analyzeBackgroundColor(bitmap, bound)

                // Create smooth transition
                paint.color = bgColor
                paint.style = Paint.Style.FILL

                // Draw with slight expansion for text edges
                val expanded = Rect(
                    (bound.left - 1).coerceAtLeast(0),
                    (bound.top - 1).coerceAtLeast(0),
                    (bound.right + 1).coerceAtMost(bitmap.width),
                    (bound.bottom + 1).coerceAtMost(bitmap.height)
                )

                // Use PorterDuff for smooth blending
                paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC)
                canvas.drawRect(expanded, paint)

                // Add subtle texture by sampling nearby colors
                if (bound.width() > 20 && bound.height() > 20) {
                    addBackgroundTexture(canvas, bitmap, bound, paint)
                }
            }

            paint.xfermode = null
            if (output != bitmap) bitmap.recycle()

            AppResult.Success(output)
        } catch (e: Exception) {
            AppResult.Error(AppError.ImageProcessingError("Fallback Erase", e.message ?: "Unknown"))
        }
    }

    /**
     * Analyze background color from pixels surrounding the text area.
     */
    private fun analyzeBackgroundColor(bitmap: Bitmap, bound: Rect): Int {
        val samplePoints = mutableListOf<Int>()

        // Sample from top edge
        for (x in bound.left until bound.right step maxOf(1, bound.width() / SAMPLE_SIZE)) {
            val y = (bound.top - 5).coerceAtLeast(0)
            samplePoints.add(bitmap.getPixel(x.coerceIn(0, bitmap.width - 1), y))
        }

        // Sample from bottom edge
        for (x in bound.left until bound.right step maxOf(1, bound.width() / SAMPLE_SIZE)) {
            val y = (bound.bottom + 5).coerceAtMost(bitmap.height - 1)
            samplePoints.add(bitmap.getPixel(x.coerceIn(0, bitmap.width - 1), y))
        }

        // Sample from left edge
        for (y in bound.top until bound.bottom step maxOf(1, bound.height() / SAMPLE_SIZE)) {
            val x = (bound.left - 5).coerceAtLeast(0)
            samplePoints.add(bitmap.getPixel(x, y.coerceIn(0, bitmap.height - 1)))
        }

        // Sample from right edge
        for (y in bound.top until bound.bottom step maxOf(1, bound.height() / SAMPLE_SIZE)) {
            val x = (bound.right + 5).coerceAtMost(bitmap.width - 1)
            samplePoints.add(bitmap.getPixel(x, y.coerceIn(0, bitmap.height - 1)))
        }

        if (samplePoints.isEmpty()) return Color.WHITE

        // Calculate median color (more robust than mean)
        val sortedR = samplePoints.map { Color.red(it) }.sorted()
        val sortedG = samplePoints.map { Color.green(it) }.sorted()
        val sortedB = samplePoints.map { Color.blue(it) }.sorted()

        val medianIdx = samplePoints.size / 2
        return Color.rgb(sortedR[medianIdx], sortedG[medianIdx], sortedB[medianIdx])
    }

    /**
     * Add subtle background texture to make erasure less obvious.
     */
    private fun addBackgroundTexture(
        canvas: Canvas,
        bitmap: Bitmap,
        bound: Rect,
        paint: Paint
    ) {
        val noisePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        noisePaint.alpha = 30 // Very subtle

        // Sample random points around the area
        val random = java.util.Random(bound.hashCode().toLong()) // Deterministic

        for (i in 0 until 20) {
            val x = bound.left + random.nextInt(bound.width())
            val y = bound.top + random.nextInt(bound.height())

            if (x in 0 until bitmap.width && y in 0 until bitmap.height) {
                noisePaint.color = bitmap.getPixel(x, y)
                canvas.drawPoint(x.toFloat(), y.toFloat(), noisePaint)
            }
        }
    }

    /**
     * Erase using bubble mask for more accurate text removal.
     */
    suspend fun eraseWithBubbleMask(
        bitmap: Bitmap,
        bubbles: List<BubbleDetector.Bubble>
    ): AppResult<Bitmap> = withContext(Dispatchers.Default) {
        try {
            val src = Mat()
            Utils.bitmapToMat(bitmap, src)

            // Create combined mask from bubbles
            val mask = BubbleDetector.createCombinedMask(bubbles, bitmap.width, bitmap.height)

            // Erode mask slightly to preserve bubble edges
            val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(3.0, 3.0))
            val erodedMask = Mat()
            Imgproc.erode(mask, erodedMask, kernel)

            // Inpaint
            val result = Mat()
            Photo.inpaint(src, erodedMask, result, INPAINT_RADIUS.toDouble(), Photo.INPAINT_NS)

            val output = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(result, output)

            src.release()
            mask.release()
            erodedMask.release()
            kernel.release()
            result.release()

            if (output != bitmap) bitmap.recycle()

            AppResult.Success(output)
        } catch (e: Exception) {
            AppResult.Error(AppError.ImageProcessingError("Bubble Mask Erasure", e.message ?: "Unknown"))
        }
    }

    /**
     * Load TFLite model for HIGH quality mode.
     */
    private fun loadTFLiteModel(): AppResult<Unit> {
        return try {
            val modelFile = context.getFileStreamPath(TFLITE_MODEL_PATH)
            if (!modelFile.exists()) {
                return AppResult.Error(AppError.ModelLoadError("inpaint_lite", "Model file not found"))
            }

            val buffer = loadModelFile(modelFile.absolutePath)
            val options = Interpreter.Options().apply {
                setNumThreads(2)
                setUseXNNPACK(true)
            }

            tfliteInterpreter = Interpreter(buffer, options)
            AppResult.Success(Unit)
        } catch (e: Exception) {
            AppResult.Error(AppError.ModelLoadError("inpaint_lite", e.message ?: "Unknown"))
        }
    }

    private fun loadModelFile(path: String): MappedByteBuffer {
        val fileDescriptor = FileInputStream(path).channel
        return fileDescriptor.map(FileChannel.MapMode.READ_ONLY, 0, fileDescriptor.size())
    }

    /**
     * Release resources.
     */
    fun release() {
        tfliteInterpreter?.close()
        tfliteInterpreter = null
    }
}
