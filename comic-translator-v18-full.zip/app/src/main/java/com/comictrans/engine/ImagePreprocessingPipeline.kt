package com.comictrans.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Rect
import com.comictrans.error.AppError
import com.comictrans.error.AppResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo

/**
 * Image preprocessing pipeline for OCR optimization.
 * Handles: resize, noise reduction, sharpening, contrast enhancement.
 */
object ImagePreprocessingPipeline {

    private const val MAX_IMAGE_DIMENSION = 2048
    private const val MIN_TEXT_HEIGHT = 8
    private const val SHARPEN_KERNEL_SIZE = 3

    /**
     * Main pipeline entry point.
     * Returns processed bitmap or error.
     */
    suspend fun processForOCR(
        source: Bitmap,
        options: PreprocessOptions = PreprocessOptions()
    ): AppResult<Bitmap> = withContext(Dispatchers.Default) {
        try {
            var current = source

            // Step 1: Resize if too large
            current = resizeIfNeeded(current)

            // Step 2: Noise reduction
            if (options.denoise) {
                current = denoise(current)
            }

            // Step 3: Sharpen
            if (options.sharpen) {
                current = sharpen(current)
            }

            // Step 4: Contrast enhancement
            if (options.enhanceContrast) {
                current = enhanceContrast(current)
            }

            // Step 5: Optional binarization for clean text
            if (options.binarize) {
                current = adaptiveBinarize(current)
            }

            AppResult.Success(current)
        } catch (e: OutOfMemoryError) {
            AppResult.Error(AppError.ImageOutOfMemory("${source.width}x${source.height}"))
        } catch (e: Exception) {
            AppResult.Error(AppError.ImageProcessingError("OCR Pipeline", e.message ?: "Unknown"))
        }
    }

    /**
     * Resize image while maintaining aspect ratio.
     * Prevents OOM and improves OCR speed.
     */
    private fun resizeIfNeeded(bitmap: Bitmap): Bitmap {
        val maxDim = maxOf(bitmap.width, bitmap.height)
        if (maxDim <= MAX_IMAGE_DIMENSION) return bitmap

        val scale = MAX_IMAGE_DIMENSION.toFloat() / maxDim
        val newWidth = (bitmap.width * scale).toInt()
        val newHeight = (bitmap.height * scale).toInt()

        return Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true).also {
            if (it != bitmap) bitmap.recycle()
        }
    }

    /**
     * Non-local means denoising using OpenCV.
     * Preserves text edges while removing noise.
     */
    private fun denoise(bitmap: Bitmap): Bitmap {
        val src = Mat()
        val dst = Mat()
        Utils.bitmapToMat(bitmap, src)

        // Convert to grayscale for denoising
        val gray = Mat()
        Imgproc.cvtColor(src, gray, Imgproc.COLOR_BGR2GRAY)

        // Non-local means denoising
        Photo.fastNlMeansDenoising(gray, dst, 10f, 7, 21)

        // Convert back to RGB if needed
        val result = if (src.channels() > 1) {
            val colored = Mat()
            Imgproc.cvtColor(dst, colored, Imgproc.COLOR_GRAY2BGR)
            colored
        } else dst

        val output = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(result, output)

        src.release()
        gray.release()
        dst.release()
        result.release()

        if (output != bitmap) bitmap.recycle()
        return output
    }

    /**
     * Unsharp masking for text sharpness.
     * Critical for small and slanted text.
     */
    private fun sharpen(bitmap: Bitmap): Bitmap {
        val src = Mat()
        Utils.bitmapToMat(bitmap, src)

        // Gaussian blur
        val blurred = Mat()
        Imgproc.GaussianBlur(src, blurred, Size(0.0, 0.0), 3.0)

        // Unsharp mask: original + (original - blurred) * amount
        val sharpened = Mat()
        Core.addWeighted(src, 1.5, blurred, -0.5, 0.0, sharpened)

        val output = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(sharpened, output)

        src.release()
        blurred.release()
        sharpened.release()

        if (output != bitmap) bitmap.recycle()
        return output
    }

    /**
     * CLAHE (Contrast Limited Adaptive Histogram Equalization).
     * Handles complex backgrounds and varying lighting.
     */
    private fun enhanceContrast(bitmap: Bitmap): Bitmap {
        val src = Mat()
        Utils.bitmapToMat(bitmap, src)

        val gray = Mat()
        Imgproc.cvtColor(src, gray, Imgproc.COLOR_BGR2GRAY)

        val clahe = Imgproc.createCLAHE(2.0, Size(8.0, 8.0))
        val enhanced = Mat()
        clahe.apply(gray, enhanced)

        val result = if (src.channels() > 1) {
            val colored = Mat()
            Imgproc.cvtColor(enhanced, colored, Imgproc.COLOR_GRAY2BGR)
            colored
        } else enhanced

        val output = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(result, output)

        src.release()
        gray.release()
        enhanced.release()
        result.release()

        if (output != bitmap) bitmap.recycle()
        return output
    }

    /**
     * Adaptive thresholding for clean binary image.
     * Best for text extraction.
     */
    private fun adaptiveBinarize(bitmap: Bitmap): Bitmap {
        val src = Mat()
        Utils.bitmapToMat(bitmap, src)

        val gray = Mat()
        Imgproc.cvtColor(src, gray, Imgproc.COLOR_BGR2GRAY)

        val binary = Mat()
        Imgproc.adaptiveThreshold(
            gray, binary, 255.0,
            Imgproc.ADAPTIVE_THRESH_GAUSSIAN_C,
            Imgproc.THRESH_BINARY,
            11, 2.0
        )

        val output = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(binary, output)

        src.release()
        gray.release()
        binary.release()

        if (output != bitmap) bitmap.recycle()
        return output
    }

    /**
     * Quick preprocessing for fast mode (less memory).
     */
    suspend fun processFast(bitmap: Bitmap): AppResult<Bitmap> = 
        processForOCR(bitmap, PreprocessOptions(denoise = false, sharpen = true, enhanceContrast = true, binarize = false))

    /**
     * Full preprocessing for accuracy mode.
     */
    suspend fun processAccurate(bitmap: Bitmap): AppResult<Bitmap> = 
        processForOCR(bitmap, PreprocessOptions(denoise = true, sharpen = true, enhanceContrast = true, binarize = true))
}

/**
 * Configuration for preprocessing steps.
 */
data class PreprocessOptions(
    val denoise: Boolean = true,
    val sharpen: Boolean = true,
    val enhanceContrast: Boolean = true,
    val binarize: Boolean = false
)
