package com.comictrans.engine

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.comictrans.error.AppError
import com.comictrans.error.AppResult
import com.comictrans.error.ErrorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Enhanced model manager with resume download, verification, and queue management.
 */
class ModelManager(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val prefs: SharedPreferences = context.getSharedPreferences("model_manager", Context.MODE_PRIVATE)
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    // Thread-safe download tracking
    private val activeDownloads = ConcurrentHashMap<String, DownloadJob>()
    private val downloadQueue = ArrayDeque<String>()
    private val queueMutex = Mutex()
    private val maxConcurrentDownloads = 2

    companion object {
        private const val TAG = "ModelManager"
        private const val PREFS_DOWNLOAD_STATE = "download_state_"
        private const val PREFS_DOWNLOAD_PROGRESS = "download_progress_"
        private const val PREFS_DOWNLOAD_TOTAL = "download_total_"
        private const val PREFS_DOWNLOAD_SHA = "download_sha_"
        private const val CHUNK_SIZE = 8192 // 8KB
    }

    /**
     * Download states for UI and logic.
     */
    enum class DownloadState {
        IDLE,
        QUEUED,
        DOWNLOADING,
        PAUSED,
        VERIFYING,
        COMPLETED,
        FAILED,
        CANCELLED
    }

    /**
     * Model information.
     */
    data class ModelInfo(
        val id: String,
        val name: String,
        val description: String,
        val url: String,
        val sizeBytes: Long,
        val sha256: String,
        val fileName: String,
        val isOptional: Boolean = false
    )

    /**
     * Download progress data class.
     */
    data class DownloadProgress(
        val modelId: String,
        val state: DownloadState,
        val downloadedBytes: Long,
        val totalBytes: Long,
        val speedBps: Long = 0,
        val errorMessage: String? = null
    ) {
        val progressPercent: Int
            get() = if (totalBytes > 0) ((downloadedBytes * 100) / totalBytes).toInt() else 0

        val isActive: Boolean
            get() = state == DownloadState.DOWNLOADING || state == DownloadState.VERIFYING
    }

    private val _downloadProgress = MutableStateFlow<Map<String, DownloadProgress>>(emptyMap())
    val downloadProgress: StateFlow<Map<String, DownloadProgress>> = _downloadProgress.asStateFlow()

    private val _availableModels = MutableStateFlow<List<ModelInfo>>(emptyList())
    val availableModels: StateFlow<List<ModelInfo>> = _availableModels.asStateFlow()

    /**
     * Register available models.
     */
    fun registerModels(models: List<ModelInfo>) {
        _availableModels.value = models
    }

    /**
     * Start or resume model download.
     */
    suspend fun downloadModel(modelId: String): AppResult<Unit> {
        val model = _availableModels.value.find { it.id == modelId }
            ?: return AppResult.Error(AppError.ModelDownloadError(modelId, "Model not found in registry"))

        // Check if already downloading
        queueMutex.withLock {
            if (activeDownloads.containsKey(modelId)) {
                val existing = activeDownloads[modelId]!!
                if (existing.state.value == DownloadState.DOWNLOADING) {
                    return AppResult.Success(Unit) // Already downloading
                }
                if (existing.state.value == DownloadState.QUEUED) {
                    return AppResult.Success(Unit) // Already queued
                }
            }

            // Check if already completed
            if (isModelDownloaded(modelId)) {
                return AppResult.Success(Unit)
            }

            // Add to queue
            val job = DownloadJob(model)
            activeDownloads[modelId] = job
            downloadQueue.add(modelId)

            updateProgress(modelId, DownloadState.QUEUED, 0, model.sizeBytes)
        }

        // Process queue
        processQueue()

        return AppResult.Success(Unit)
    }

    /**
     * Pause a download.
     */
    suspend fun pauseDownload(modelId: String) {
        queueMutex.withLock {
            activeDownloads[modelId]?.let { job ->
                job.pause()
                updateProgress(modelId, DownloadState.PAUSED, job.downloadedBytes, job.model.sizeBytes)
            }
        }
    }

    /**
     * Resume a paused download.
     */
    suspend fun resumeDownload(modelId: String) {
        queueMutex.withLock {
            activeDownloads[modelId]?.let { job ->
                if (job.state.value == DownloadState.PAUSED || job.state.value == DownloadState.FAILED) {
                    job.state.value = DownloadState.QUEUED
                    downloadQueue.add(modelId)
                    updateProgress(modelId, DownloadState.QUEUED, job.downloadedBytes, job.model.sizeBytes)
                }
            }
        }
        processQueue()
    }

    /**
     * Cancel a download.
     */
    suspend fun cancelDownload(modelId: String) {
        queueMutex.withLock {
            activeDownloads[modelId]?.let { job ->
                job.cancel()
                downloadQueue.remove(modelId)
                activeDownloads.remove(modelId)
                updateProgress(modelId, DownloadState.CANCELLED, 0, 0)
            }
        }
    }

    /**
     * Process download queue with concurrency limit.
     */
    private fun processQueue() {
        scope.launch {
            queueMutex.withLock {
                val activeCount = activeDownloads.count { it.value.state.value == DownloadState.DOWNLOADING }
                val slotsAvailable = maxConcurrentDownloads - activeCount

                if (slotsAvailable <= 0) return@withLock

                var started = 0
                while (downloadQueue.isNotEmpty() && started < slotsAvailable) {
                    val modelId = downloadQueue.removeFirstOrNull() ?: break
                    val job = activeDownloads[modelId] ?: continue

                    if (job.state.value == DownloadState.QUEUED) {
                        started++
                        launch { executeDownload(job) }
                    }
                }
            }
        }
    }

    /**
     * Execute actual download with resume support.
     */
    private suspend fun executeDownload(job: DownloadJob) {
        val model = job.model
        val outputFile = getModelFile(model.fileName)

        try {
            job.state.value = DownloadState.DOWNLOADING
            updateProgress(model.id, DownloadState.DOWNLOADING, job.downloadedBytes, model.sizeBytes)

            // Check for partial file to resume
            val resumeFrom = if (outputFile.exists() && outputFile.length() > 0) {
                outputFile.length()
            } else 0L

            val requestBuilder = Request.Builder()
                .url(model.url)
                .header("User-Agent", "ComicTranslator/1.0")

            // Add Range header for resume
            if (resumeFrom > 0) {
                requestBuilder.header("Range", "bytes=$resumeFrom-")
                Log.d(TAG, "Resuming ${model.id} from $resumeFrom bytes")
            }

            val response = httpClient.newCall(requestBuilder.build()).execute()

            if (!response.isSuccessful && response.code != 206) {
                throw IOException("HTTP ${response.code}")
            }

            val body = response.body ?: throw IOException("Empty response body")
            val totalBytes = if (resumeFrom > 0 && response.code == 206) {
                // Parse Content-Range header
                val contentRange = response.header("Content-Range")
                contentRange?.let {
                    Regex("""bytes\s+\d+-\d+/(\d+)""").find(it)?.groupValues?.get(1)?.toLong()
                } ?: (resumeFrom + body.contentLength())
            } else {
                body.contentLength()
            }

            // Save total size
            prefs.edit().putLong(PREFS_DOWNLOAD_TOTAL + model.id, totalBytes).apply()

            // Open file for append (resume) or create new
            val accessFile = RandomAccessFile(outputFile, "rw")
            if (resumeFrom > 0) {
                accessFile.seek(resumeFrom)
            }

            val inputStream = body.byteStream()
            val buffer = ByteArray(CHUNK_SIZE)
            var downloaded = resumeFrom
            var lastUpdateTime = System.currentTimeMillis()
            var lastDownloaded = resumeFrom

            while (!job.isCancelled) {
                val read = inputStream.read(buffer)
                if (read == -1) break

                if (job.isPaused) {
                    // Wait until resumed or cancelled
                    while (job.isPaused && !job.isCancelled) {
                        kotlinx.coroutines.delay(100)
                    }
                    if (job.isCancelled) break
                }

                accessFile.write(buffer, 0, read)
                downloaded += read
                job.downloadedBytes = downloaded

                // Update progress every 500ms
                val now = System.currentTimeMillis()
                if (now - lastUpdateTime > 500) {
                    val elapsed = (now - lastUpdateTime) / 1000.0
                    val bytesSinceLast = downloaded - lastDownloaded
                    val speed = if (elapsed > 0) (bytesSinceLast / elapsed).toLong() else 0

                    updateProgress(model.id, DownloadState.DOWNLOADING, downloaded, totalBytes, speed)

                    // Save progress for resume
                    prefs.edit().putLong(PREFS_DOWNLOAD_PROGRESS + model.id, downloaded).apply()

                    lastUpdateTime = now
                    lastDownloaded = downloaded
                }
            }

            inputStream.close()
            accessFile.close()

            if (job.isCancelled) {
                updateProgress(model.id, DownloadState.CANCELLED, downloaded, totalBytes)
                return
            }

            // Verify download
            job.state.value = DownloadState.VERIFYING
            updateProgress(model.id, DownloadState.VERIFYING, downloaded, totalBytes)

            val verified = verifyModel(model, outputFile)

            if (verified) {
                job.state.value = DownloadState.COMPLETED
                updateProgress(model.id, DownloadState.COMPLETED, downloaded, totalBytes)

                // Clear resume data
                prefs.edit()
                    .remove(PREFS_DOWNLOAD_PROGRESS + model.id)
                    .remove(PREFS_DOWNLOAD_TOTAL + model.id)
                    .putString(PREFS_DOWNLOAD_STATE + model.id, DownloadState.COMPLETED.name)
                    .apply()

                Log.i(TAG, "Model ${model.id} downloaded and verified successfully")
            } else {
                throw IOException("SHA256 verification failed")
            }

        } catch (e: Exception) {
            Log.e(TAG, "Download failed for ${model.id}", e)
            job.state.value = DownloadState.FAILED
            updateProgress(
                model.id, 
                DownloadState.FAILED, 
                job.downloadedBytes, 
                model.sizeBytes,
                errorMessage = e.message
            )
            ErrorManager.reportException(e, "ModelManager.download: ${model.id}")
        } finally {
            queueMutex.withLock {
                activeDownloads.remove(model.id)
            }
            processQueue() // Start next in queue
        }
    }

    /**
     * Verify downloaded model using SHA256.
     */
    private suspend fun verifyModel(model: ModelInfo, file: File): Boolean = withContext(Dispatchers.Default) {
        if (model.sha256.isBlank()) {
            // No hash provided, just check file size
            return@withContext file.length() == model.sizeBytes
        }

        try {
            val digest = MessageDigest.getInstance("SHA-256")
            file.inputStream().use { input ->
                val buffer = ByteArray(8192)
                var read: Int
                while (input.read(buffer).also { read = it } != -1) {
                    digest.update(buffer, 0, read)
                }
            }

            val hash = digest.digest().joinToString("") { "%02x".format(it) }
            val verified = hash.equals(model.sha256, ignoreCase = true)

            if (!verified) {
                Log.e(TAG, "SHA mismatch for ${model.id}: expected ${model.sha256}, got $hash")
            }

            verified
        } catch (e: Exception) {
            Log.e(TAG, "Verification failed for ${model.id}", e)
            false
        }
    }

    /**
     * Check if model is downloaded and verified.
     */
    fun isModelDownloaded(modelId: String): Boolean {
        val model = _availableModels.value.find { it.id == modelId } ?: return false
        val file = getModelFile(model.fileName)

        if (!file.exists() || file.length() != model.sizeBytes) return false

        val state = prefs.getString(PREFS_DOWNLOAD_STATE + modelId, null)
        return state == DownloadState.COMPLETED.name
    }

    /**
     * Get model file path.
     */
    fun getModelFile(fileName: String): File {
        return File(context.filesDir, "models/$fileName")
    }

    /**
     * Delete a model.
     */
    fun deleteModel(modelId: String) {
        val model = _availableModels.value.find { it.id == modelId } ?: return
        val file = getModelFile(model.fileName)
        if (file.exists()) {
            file.delete()
        }
        prefs.edit()
            .remove(PREFS_DOWNLOAD_STATE + modelId)
            .remove(PREFS_DOWNLOAD_PROGRESS + modelId)
            .remove(PREFS_DOWNLOAD_TOTAL + modelId)
            .apply()
    }

    /**
     * Get download state from preferences (for app restart recovery).
     */
    fun getSavedState(modelId: String): DownloadState {
        val stateName = prefs.getString(PREFS_DOWNLOAD_STATE + modelId, DownloadState.IDLE.name)
        return try {
            DownloadState.valueOf(stateName!!)
        } catch (e: Exception) {
            DownloadState.IDLE
        }
    }

    /**
     * Get saved progress for resume after app restart.
     */
    fun getSavedProgress(modelId: String): Pair<Long, Long> {
        val progress = prefs.getLong(PREFS_DOWNLOAD_PROGRESS + modelId, 0)
        val total = prefs.getLong(PREFS_DOWNLOAD_TOTAL + modelId, 0)
        return progress to total
    }

    /**
     * Clean up completed/failed downloads from tracking.
     */
    fun cleanupFinishedDownloads() {
        scope.launch {
            queueMutex.withLock {
                val toRemove = activeDownloads.filter { 
                    it.value.state.value == DownloadState.COMPLETED || 
                    it.value.state.value == DownloadState.FAILED ||
                    it.value.state.value == DownloadState.CANCELLED
                }.keys
                toRemove.forEach { activeDownloads.remove(it) }
            }
        }
    }

    /**
     * Update progress flow.
     */
    private fun updateProgress(
        modelId: String,
        state: DownloadState,
        downloaded: Long,
        total: Long,
        speed: Long = 0,
        errorMessage: String? = null
    ) {
        val current = _downloadProgress.value.toMutableMap()
        current[modelId] = DownloadProgress(modelId, state, downloaded, total, speed, errorMessage)
        _downloadProgress.value = current
    }

    /**
     * Release resources.
     */
    fun release() {
        scope.cancel()
        httpClient.dispatcher.executorService.shutdown()
    }

    /**
     * Internal download job tracking.
     */
    private inner class DownloadJob(val model: ModelInfo) {
        val state = MutableStateFlow(DownloadState.QUEUED)
        @Volatile var downloadedBytes: Long = 0
        @Volatile var isPaused: Boolean = false
        @Volatile var isCancelled: Boolean = false

        fun pause() {
            isPaused = true
            state.value = DownloadState.PAUSED
        }

        fun cancel() {
            isCancelled = true
            isPaused = false
        }
    }
}
