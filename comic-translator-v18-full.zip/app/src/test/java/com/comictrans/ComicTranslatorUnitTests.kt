package com.comictrans

import com.comictrans.error.AppError
import com.comictrans.error.AppResult
import com.comictrans.error.ErrorManager
import com.comictrans.translation.PromptManager
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

/**
 * Unit tests for core components.
 */
class ComicTranslatorUnitTests {

    // ==================== ERROR HANDLING TESTS ====================

    @Test
    fun `AppResult success should contain data`() {
        val result = AppResult.Success("test")
        assertTrue(result.isSuccess)
        assertEquals("test", result.getOrNull())
    }

    @Test
    fun `AppResult error should contain error`() {
        val error = AppError.OCRError("test error")
        val result = AppResult.Error(error)
        assertTrue(result.isError)
        assertEquals(error, result.errorOrNull())
    }

    @Test
    fun `AppResult map should transform success`() {
        val result = AppResult.Success(5)
        val mapped = result.map { it * 2 }
        assertEquals(10, mapped.getOrNull())
    }

    @Test
    fun `AppResult map should not transform error`() {
        val error = AppError.TranslationError("test", "error")
        val result = AppResult.Error(error)
        val mapped = result.map { it.toString() }
        assertTrue(mapped.isError)
    }

    @Test
    fun `AppResult flatMap should chain operations`() {
        val result = AppResult.Success(5)
        val chained = result.flatMap { AppResult.Success(it + 3) }
        assertEquals(8, chained.getOrNull())
    }

    @Test
    fun `ErrorManager should track errors`() = runTest {
        val error = AppError.NetworkNoConnection()
        ErrorManager.report(error)

        val lastError = ErrorManager.lastError.value
        assertNotNull(lastError)
        assertEquals("NET_002", lastError?.code)
    }

    @Test
    fun `ErrorManager runCatchingApp should catch exceptions`() {
        val result = ErrorManager.runCatchingApp {
            throw IllegalStateException("test")
        }
        assertTrue(result.isError)
    }

    // ==================== PROMPT MANAGER TESTS ====================

    @Test
    fun `PromptManager should build system prompt for manga`() {
        val prompt = PromptManager.buildSystemPrompt(
            PromptManager.ComicType.MANGA,
            PromptManager.ComicDictionary()
        )
        assertTrue(prompt.contains("manga"))
        assertTrue(prompt.contains("right-to-left"))
    }

    @Test
    fun `PromptManager should build system prompt for manhwa`() {
        val prompt = PromptManager.buildSystemPrompt(
            PromptManager.ComicType.MANHWA,
            PromptManager.ComicDictionary()
        )
        assertTrue(prompt.contains("manhwa"))
        assertTrue(prompt.contains("webtoon"))
    }

    @Test
    fun `PromptManager should include dictionary terms`() {
        val dictionary = PromptManager.ComicDictionary(
            seriesName = "Test Series",
            characterNames = mapOf("太郎" to "Taro"),
            specialTerms = mapOf("必殺技" to "Special Move")
        )
        val prompt = PromptManager.buildSystemPrompt(
            PromptManager.ComicType.MANGA,
            dictionary
        )
        assertTrue(prompt.contains("Taro"))
        assertTrue(prompt.contains("Special Move"))
    }

    @Test
    fun `PromptManager should parse batch response`() {
        val response = """
            [Bubble 1] Hello there
            [Bubble 2] How are you?
            [Bubble 3] Goodbye
        """.trimIndent()

        val translations = PromptManager.parseBatchResponse(response, 3)
        assertEquals(3, translations.size)
        assertEquals("Hello there", translations[0])
        assertEquals("How are you?", translations[1])
        assertEquals("Goodbye", translations[2])
    }

    @Test
    fun `PromptManager should handle missing bubbles in response`() {
        val response = "[Bubble 1] Only one"
        val translations = PromptManager.parseBatchResponse(response, 3)
        assertEquals(3, translations.size)
        assertEquals("Only one", translations[0])
        assertEquals("", translations[1])
        assertEquals("", translations[2])
    }

    @Test
    fun `PromptManager should build batch prompt with context`() {
        val blocks = listOf(
            com.comictrans.model.BlockData("Hello", android.graphics.Rect(0, 0, 100, 50)),
            com.comictrans.model.BlockData("World", android.graphics.Rect(0, 60, 100, 110))
        )

        val context = PromptManager.PageContext(
            seriesName = "Test Comic",
            chapterNumber = 1,
            pageNumber = 5
        )

        val prompt = PromptManager.buildBatchPrompt(blocks, context, "ar")
        assertTrue(prompt.contains("Test Comic"))
        assertTrue(prompt.contains("Chapter: 1"))
        assertTrue(prompt.contains("Page: 5"))
        assertTrue(prompt.contains("[Bubble 1]"))
        assertTrue(prompt.contains("[Bubble 2]"))
    }

    // ==================== APP ERROR TESTS ====================

    @Test
    fun `AppError fromException should handle network errors`() {
        val exception = java.net.SocketTimeoutException("timeout")
        val error = AppError.fromException(exception, "test")
        assertTrue(error is AppError.NetworkTimeout)
    }

    @Test
    fun `AppError fromException should handle unknown host`() {
        val exception = java.net.UnknownHostException("no host")
        val error = AppError.fromException(exception)
        assertTrue(error is AppError.NetworkNoConnection)
    }

    @Test
    fun `AppError fromException should handle OOM`() {
        val exception = OutOfMemoryError("oom")
        val error = AppError.fromException(exception, "1024x1024")
        assertTrue(error is AppError.ImageOutOfMemory)
    }

    @Test
    fun `AppError should have user-friendly messages`() {
        val error = AppError.OCRError("detection failed")
        assertNotNull(error.userMessage)
        assertTrue(error.userMessage.isNotEmpty())
        assertNotEquals(error.code, error.userMessage)
    }

    // ==================== SETTINGS DATA TESTS ====================

    @Test
    fun `SettingsData should have defaults`() {
        val settings = com.comictrans.model.SettingsData()
        assertEquals("google_free", settings.provider)
        assertEquals("mlkit", settings.ocrEngine)
        assertEquals("manga", settings.comicType)
        assertTrue(settings.usePreprocessing)
        assertTrue(settings.batchMode)
    }

    @Test
    fun `SettingsData should support custom provider`() {
        val settings = com.comictrans.model.SettingsData(
            customApiUrl = "http://localhost:11434",
            customModel = "llama2"
        )
        assertEquals("http://localhost:11434", settings.customApiUrl)
        assertEquals("llama2", settings.customModel)
    }
}
