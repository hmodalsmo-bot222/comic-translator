package com.comictrans.feature_ai.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Log
import com.comictrans.engine.ModelManager
import com.comictrans.engine.OpenCVStatus
import com.comictrans.engine.contracts.IOcrEngine
import com.comictrans.model.BlockData
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.equationl.paddleocr4android.OCR
import com.equationl.paddleocr4android.OcrConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Rect as CvRect
import org.tensorflow.lite.Interpreter
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.max
import kotlin.math.min

class OCREngine(
    private val context: Context,
    private val modelManager: ModelManager
) : IOcrEngine {

    private val paddleOcr = OCR(context)
    @Volatile private var paddleInitialized = false
    private val paddleLock = Any()

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    // 1. ML Kit (works fully)
    override suspend fun recognizeMLKit(bitmap: Bitmap): List<BlockData> = withContext(Dispatchers.IO) {
        suspendCancellableCoroutine { continuation ->
            val image = InputImage.fromBitmap(bitmap, 0)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    val blocks = visionText.textBlocks.flatMap { block ->
                        block.lines.map { line ->
                            val rect = line.boundingBox
                            BlockData(
                                text = line.text,
                                x = rect?.left ?: 0,
                                y = rect?.top ?: 0,
                                width = rect?.width() ?: 100,
                                height = rect?.height() ?: 30,
                                confidence = line.confidence
                            )
                        }
                    }
                    continuation.resume(mergeIntoComicBlocks(blocks, bitmap.width, bitmap.height))
                    recognizer.close()
                }
                .addOnFailureListener { e ->
                    recognizer.close()
                    continuation.resumeWithException(e)
                }
        }
    }

    // ============ CRAFT Mobile — "نموذج كشف مناطق النص" (بند منفصل، مستقل عن ocrEngine) ============
    // CRAFT (Character-Region Awareness For Text detection) نموذج **كشف فقط** — يخرج خريطتي
    // احتمال (region score لكل حرف + affinity score للربط بين حرفين متجاورين)، ولا يقرأ أي
    // نص بنفسه. النموذج المرجعي: tulasiram58827/craft_tflite (تصدير TFLite رسمي منشور على
    // TensorFlow Hub/Kaggle Models، تنزيل مباشر بدون تسجيل دخول عبر رابط ?lite-format=tflite
    // — راجع ModelManager.DEFAULT_CRAFT_MOBILE_URL). الاستراتيجية هنا: CRAFT يحدد *أين* النص
    // (صناديق)، ثم كل صندوق يُقص ويُمرَّر لـML Kit للقراءة الفعلية (recognizeTextInRegion تحت)
    // — لأن CRAFT التصدير المتاح هنا كاشف فقط، لا محرك قراءة كامل بديل لـML Kit.
    //
    // ⚠️⚠️ لم يُختبَر فعلياً وقت التشغيل إطلاقاً (بيئة الكتابة بدون Android SDK/جهاز/إنترنت
    // فعلي وقت كتابة هذا الكود، فقط بحث ويب لتوثيق النموذج). أبعاد المدخل/التطبيع والمعالجة
    // اللاحقة مبنية على توثيق GitHub الرسمي للنموذج (normalizeMeanVariance بمتوسط/تباين
    // ImageNet القياسي، وresize_aspect_ratio بحجم قماش 1280 ونسبة تكبير 1 — نفس المرجع
    // بالضبط)، **وليس على تجربة فعلية لهذا الملف بالذات**. أول اختبار حقيقي يجب أن يقارن
    // نتيجة الصناديق مع كشف ML Kit/PaddleLite العادي على نفس الصفحة.
    //
    // ✅ تحديث لاحق مهم (بعد بحث ويب إضافي أكَّد خللاً حقيقياً كان موجوداً هنا): تحقَّقت من
    // كود forward() الرسمي بـclovaai/CRAFT-pytorch (craft.py) — النموذج **يُرجِع مخرَجين
    // اثنين** (`y.permute(0,2,3,1)` وهو خريطتا region/affinity اللي نحتاجها، و`feature` خريطة
    // سمات وسيطة أكبر لا نحتاجها إطلاقاً هنا)، وهذا يطابق توثيق مدوَّنة تحويل النموذج الرسمية
    // (`output_details[0]`='y'، `output_details[1]`='feature'). كود سابق هنا كان يستخدم
    // `interpreter.run(input, output)` (دالة اختصار لمخرَج واحد فقط) على نموذج له مخرَجان
    // فعلياً — هذا يفشل بصمت بكل استدعاء (يُلتقَط كـException ويرجع تلقائياً لـML Kit)،
    // فـCRAFT Mobile ما كان يعمل إطلاقاً رغم نجاح البناء. أُصلِح باستخدام
    // `runForMultipleInputsOutputs` بخريطة جزئية (index 0 فقط) — راجع التعليق عند
    // `outputBuffer` تحت لتفاصيل الدليل والإصلاح. **هذا يرفع الثقة بشكل ملموس** (خطأ توثيقي +
    // برمجي حقيقي تم تأكيده وإصلاحه، لا مجرد افتراض)، لكن **شكل قناتَي region/affinity نفسها
    // [1,H/2,W/2,2] لسا غير مُختبَر فعلياً على الملف الثنائي بالذات** — الدليل النظري قوي
    // (`y.permute(0,2,3,1)` بكود PyTorch الرسمي يعطي بالضبط NHWC بقناتين أخيرتين) لكن التحويل
    // عبر ONNX (`onnx2tf`) نظرياً قد يُعيد ترتيب المحاور رغم أن التوثيق لا يشير لذلك. أول
    // اختبار حقيقي بعد البناء يبقى نفسه: قارن صناديق CRAFT بصرياً مقابل كشف عادي.
    private val craftLock = Any()
    @Volatile private var craftInterpreter: Interpreter? = null

    // EAST Text Detector
    private val eastLock = Any()
    @Volatile private var eastInterpreter: Interpreter? = null
    @Volatile private var eastModelSize: Int = 0

    // ⭐ EasyOCR
    private val easyocrLock = Any()
    @Volatile private var easyocrInterpreter: Interpreter? = null
    @Volatile private var easyocrRecInterpreter: Interpreter? = null

    // 🔍 أداة تشخيص (بحث ويب 2026-08-15): بما أن بيئة التطوير الحالية بلا Android SDK/جهاز
    // حقيقي/Netron، لا يمكن التأكد من شكل مدخل/مخرج أي نموذج .tflite فعلياً قبل تشغيله على
    // جهاز حقيقي. بدل تخمين الشكل بالكود (نفس الفخ الموثَّق بـHANDOFF مع CRAFT/EAST)، هذه
    // الدالة تطبع شكل ونوع كل Tensor مدخل/مخرج فعلياً بـLogcat أول مرة يُحمَّل بها أي مفسِّر —
    // المستخدم يقدر يبني، يشغّل صفحة كوميكس حقيقية بنموذج EAST أو EasyOCR، وينسخ سطور اللوق
    // هذه (فلتر Logcat بوسم "ModelShape") ويرسلها — هذا **يغني عن Netron فعلياً** لأنه يعطي
    // الشكل الحقيقي المُنفَّذ فعلاً وقت التشغيل، لا افتراضاً نظرياً من توثيق قد يختلف عن نتيجة
    // التحويل الفعلية لهذا الملف بالذات.
    private fun logInterpreterShapes(tag: String, interpreter: Interpreter) {
        try {
            val sb = StringBuilder("=== $tag — شكل الـTensors الفعلي (بعد التحميل) ===\n")
            for (i in 0 until interpreter.inputTensorCount) {
                val t = interpreter.getInputTensor(i)
                sb.append("  مدخل[$i] name=${t.name()} shape=${t.shape().joinToString(",")} dtype=${t.dataType()}\n")
            }
            for (i in 0 until interpreter.outputTensorCount) {
                val t = interpreter.getOutputTensor(i)
                sb.append("  مخرج[$i] name=${t.name()} shape=${t.shape().joinToString(",")} dtype=${t.dataType()}\n")
            }
            Log.i("ModelShape", sb.toString())
        } catch (e: Throwable) {
            Log.w("ModelShape", "تعذّر قراءة شكل الـTensors لـ$tag", e)
        }
    }

    override suspend fun recognizeCraftMobile(bitmap: Bitmap): List<BlockData> = withContext(Dispatchers.IO) {
        val modelFile = modelManager.availableModels.find { it.id == "det_craft_mobile" }
            ?.let { modelManager.modelFile(it) }
        if (modelFile == null || !modelFile.exists()) {
            Log.w("CRAFT", "نموذج CRAFT Mobile (.tflite) غير مُنزَّل — رجوع كامل لـML Kit")
            return@withContext recognizeMLKit(bitmap)
        }
        if (!OpenCVStatus.isAvailable) {
            Log.w("CRAFT", "OpenCV غير محمّلة — لازمة لمعالجة خرائط CRAFT اللاحقة — رجوع لـML Kit")
            return@withContext recognizeMLKit(bitmap)
        }

        val boxes = try {
            runCraftDetection(bitmap, modelFile)
        } catch (e: Throwable) {
            Log.e("CRAFT", "فشل استدلال CRAFT Mobile — رجوع كامل لـML Kit", e)
            null
        }

        if (boxes.isNullOrEmpty()) {
            Log.w("CRAFT", "CRAFT لم يكتشف أي صندوق نص — رجوع لـML Kit كخطة احتياطية")
            return@withContext recognizeMLKit(bitmap)
        }

        val blocks = boxes.mapNotNull { rect ->
            val text = recognizeTextInRegion(bitmap, rect)?.trim()
            if (text.isNullOrBlank()) null
            else BlockData(text = text, x = rect.left, y = rect.top, width = rect.width(), height = rect.height())
        }
        mergeIntoComicBlocks(blocks, bitmap.width, bitmap.height)
    }

    /** يشغّل ML Kit على منطقة مقصوصة فقط (بعكس recognizeMLKit اللي يعالج الصفحة كاملة). */
    private suspend fun recognizeTextInRegion(bitmap: Bitmap, rect: Rect): String? = suspendCancellableCoroutine { continuation ->
        val crop = try {
            Bitmap.createBitmap(bitmap, rect.left, rect.top, rect.width(), rect.height())
        } catch (e: Throwable) {
            continuation.resume(null)
            return@suspendCancellableCoroutine
        }
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(InputImage.fromBitmap(crop, 0))
            .addOnSuccessListener { visionText ->
                recognizer.close()
                continuation.resume(visionText.text)
            }
            .addOnFailureListener { e ->
                recognizer.close()
                Log.w("CRAFT", "فشل قراءة صندوق CRAFT عبر ML Kit", e)
                continuation.resume(null)
            }
    }

    // حجم القماش الأقصى (canvasSize) لتصغير الصورة قبل الاستدلال — نفس القيمة الافتراضية
    // بالمرجع الرسمي لـCRAFT (1280). mag_ratio=1 (بدون تكبير إضافي، فقط تصغير عند الحاجة).
    private val CRAFT_CANVAS_SIZE = 1280
    private val CRAFT_LOW_TEXT = 0.4
    private val CRAFT_TEXT_THRESHOLD = 0.7
    private val CRAFT_LINK_THRESHOLD = 0.4
    private val CRAFT_MIN_BOX_SIDE = 4

    private fun runCraftDetection(bitmap: Bitmap, modelFile: File): List<Rect> {
        val interpreter = synchronized(craftLock) {
            craftInterpreter ?: Interpreter(loadCraftModelFile(modelFile)).also { craftInterpreter = it }
        }

        val origW = bitmap.width
        val origH = bitmap.height
        val targetSize = min(max(origW, origH), CRAFT_CANVAS_SIZE)
        val ratio = targetSize.toFloat() / max(origW, origH)
        val targetW = (origW * ratio).toInt().coerceAtLeast(1)
        val targetH = (origH * ratio).toInt().coerceAtLeast(1)
        // يُكمَّل لأقرب مضاعف 32 (متطلَّب بنية الشبكة — نفس resize_aspect_ratio بالمرجع الرسمي)
        val paddedW = if (targetW % 32 == 0) targetW else targetW + (32 - targetW % 32)
        val paddedH = if (targetH % 32 == 0) targetH else targetH + (32 - targetH % 32)

        val resized = Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)

        // ImageNet mean/variance مضروبة بـ255 (نفس normalizeMeanVariance بمرجع CRAFT الرسمي)
        val meanR = 0.485f * 255f; val meanG = 0.456f * 255f; val meanB = 0.406f * 255f
        val stdR = 0.229f * 255f; val stdG = 0.224f * 255f; val stdB = 0.225f * 255f

        val inputBuffer = ByteBuffer.allocateDirect(4 * paddedH * paddedW * 3).order(ByteOrder.nativeOrder())
        val pixels = IntArray(targetW * targetH)
        resized.getPixels(pixels, 0, targetW, 0, 0, targetW, targetH)
        for (y in 0 until paddedH) {
            for (x in 0 until paddedW) {
                if (x < targetW && y < targetH) {
                    val p = pixels[y * targetW + x]
                    inputBuffer.putFloat((((p shr 16) and 0xFF).toFloat() - meanR) / stdR)
                    inputBuffer.putFloat((((p shr 8) and 0xFF).toFloat() - meanG) / stdG)
                    inputBuffer.putFloat(((p and 0xFF).toFloat() - meanB) / stdB)
                } else {
                    // حشو أسود خارج المنطقة الفعلية (نفس المرجع الرسمي: صفر قبل التطبيع)
                    inputBuffer.putFloat((0f - meanR) / stdR)
                    inputBuffer.putFloat((0f - meanG) / stdG)
                    inputBuffer.putFloat((0f - meanB) / stdB)
                }
            }
        }
        inputBuffer.rewind()
        resized.recycle()

        interpreter.resizeInput(0, intArrayOf(1, paddedH, paddedW, 3))
        interpreter.allocateTensors()

        // ⚠️ النموذج له مخرَجان اثنان، ليس واحداً — تأكَّدت من هذا بقراءة forward() الرسمية
        // بـclovaai/CRAFT-pytorch (craft.py): `return y.permute(0,2,3,1), feature`. المخرَج
        // الأول (index 0) هو "y" — خريطتا region/affinity بالشكل [1, paddedH/2, paddedW/2, 2]
        // اللي نحتاجه فعلياً. المخرَج الثاني (index 1) هو "feature" — خريطة سمات وسيطة أكبر
        // (تُستخدَم فقط بشبكة Refiner الاختيارية غير المُستخدَمة هنا)، **لا نحتاج قراءتها
        // إطلاقاً**. الدليل: نفس ترتيب الاستدعاء موثَّق بمدوَّنة تحويل النموذج الرسمية
        // (tulasi.dev/craft-in-tflite): `y = interpreter.get_tensor(output_details[0]['index'])`
        // ثم `feature = interpreter.get_tensor(output_details[1]['index'])`.
        // الخطأ القديم هنا: `interpreter.run(input, output)` هي دالة الاختصار الرسمية *لنموذج
        // بمخرَج واحد فقط* (توثيق TFLite: تستدعي داخلياً runForMultipleInputsOutputs بخريطة
        // فيها index=0 فقط، لكنها مصمَّمة أصلاً لنموذج بمخرَج واحد إجمالاً) — استدعاؤها هنا على
        // نموذج له مخرَجان فعلياً يفشل (IllegalArgumentException: عدد المخرَجات المتوقَّع لا
        // يطابق) في كل استدعاء، فيرجع دائماً وبصمت (يُلتقَط بـcatch بـrecognizeCraftMobile)
        // لـML Kit العادي — أي أن CRAFT Mobile لم يكن يعمل إطلاقاً رغم عدم ظهور أي خطأ واضح
        // للمستخدم (الفشل يُبتلَع كخطة احتياطية آمنة، لا Exception يظهر بالواجهة).
        // الإصلاح: runForMultipleInputsOutputs مع خريطة جزئية (index 0 فقط) — التوثيق الرسمي
        // (ai.google.dev/edge/api/tflite/java) يؤكد أن الخريطة لا يلزم أن تغطي كل المخرَجات؛
        // أي مخرَج غير موجود بالخريطة يُحسَب داخلياً بلا مشكلة لكن لا يُنسَخ لأي ByteBuffer،
        // فلا حاجة لمعرفة حجم/شكل "feature" إطلاقاً.
        val outH = paddedH / 2
        val outW = paddedW / 2
        val outputBuffer = ByteBuffer.allocateDirect(4 * outH * outW * 2).order(ByteOrder.nativeOrder())
        val outputs: MutableMap<Int, Any> = HashMap()
        outputs[0] = outputBuffer
        interpreter.runForMultipleInputsOutputs(arrayOf<Any>(inputBuffer), outputs)
        outputBuffer.rewind()

        val regionMat = Mat(outH, outW, CvType.CV_32F)
        val affinityMat = Mat(outH, outW, CvType.CV_32F)
        val regionArr = FloatArray(outH * outW)
        val affinityArr = FloatArray(outH * outW)
        for (i in 0 until outH * outW) {
            regionArr[i] = outputBuffer.float
            affinityArr[i] = outputBuffer.float
        }
        regionMat.put(0, 0, regionArr)
        affinityMat.put(0, 0, affinityArr)

        // خريطة نص مدمَجة مبسّطة: أي بكسل يتجاوز عتبة المنطقة أو عتبة الربط يُعتبر جزءاً من
        // نص محتمل. هذا تبسيط متعمَّد لخوارزمية getDetBoxes الأصلية (Connected Components +
        // watershed دقيق لكل حرف) — بديل أخف باستخدام findContours العادي بدل حساب صندوق
        // مُدوَّر (rotated rect) لكل كلمة، كافٍ لقص مستطيلات تُمرَّر لـML Kit لاحقاً لكن أقل
        // دقة من الصناديق المائلة الأصلية لنص مائل بزاوية كبيرة.
        val combined = Mat()
        Core.max(regionMat, affinityMat, combined)
        val binary = Mat()
        org.opencv.imgproc.Imgproc.threshold(combined, binary, CRAFT_LOW_TEXT, 255.0, org.opencv.imgproc.Imgproc.THRESH_BINARY)
        val binary8u = Mat()
        binary.convertTo(binary8u, CvType.CV_8UC1)

        val contours = ArrayList<org.opencv.core.MatOfPoint>()
        val hierarchy = Mat()
        org.opencv.imgproc.Imgproc.findContours(
            binary8u, contours, hierarchy,
            org.opencv.imgproc.Imgproc.RETR_EXTERNAL, org.opencv.imgproc.Imgproc.CHAIN_APPROX_SIMPLE
        )

        // كل بكسل بخريطة المخرَج يقابل بكسلين بالصورة المصغَّرة المحشوّة (نصف الدقة)، ثم
        // نقسم على ratio لإرجاعها لمقياس الصورة الأصلية.
        val toOriginalScale = 2f / ratio
        val result = mutableListOf<Rect>()
        for (c in contours) {
            val rect = org.opencv.imgproc.Imgproc.boundingRect(c)
            c.release()
            if (rect.width < CRAFT_MIN_BOX_SIDE || rect.height < CRAFT_MIN_BOX_SIDE) continue
            // مربع نصي بلا أي بكسل يتجاوز عتبة النص الأعلى (TEXT_THRESHOLD) على الأرجح ضوضاء
            // خط ربط (affinity) منفرد بلا حرف فعلي — نتجاهله.
            val sub = Mat(regionMat, CvRect(rect.x, rect.y, rect.width, rect.height))
            val maxVal = Core.minMaxLoc(sub).maxVal
            if (maxVal < CRAFT_TEXT_THRESHOLD) continue

            val left = (rect.x * toOriginalScale).toInt().coerceIn(0, origW - 1)
            val top = (rect.y * toOriginalScale).toInt().coerceIn(0, origH - 1)
            val right = ((rect.x + rect.width) * toOriginalScale).toInt().coerceIn(left + 1, origW)
            val bottom = ((rect.y + rect.height) * toOriginalScale).toInt().coerceIn(top + 1, origH)
            result.add(Rect(left, top, right, bottom))
        }

        regionMat.release(); affinityMat.release(); combined.release(); binary.release(); binary8u.release(); hierarchy.release()
        return result
    }

    private fun loadCraftModelFile(file: File): MappedByteBuffer {
        val stream = FileInputStream(file)
        val channel = stream.channel
        return channel.map(FileChannel.MapMode.READ_ONLY, 0, file.length())
    }

    // ========== EAST Text Detector ==========
    override suspend fun recognizeEast(bitmap: Bitmap, modelId: String): List<BlockData> = withContext(Dispatchers.IO) {
        val modelFile = modelManager.availableModels.find { it.id == modelId }?.let { modelManager.modelFile(it) }
        if (modelFile == null || !modelFile.exists()) {
            Log.w("EAST", "نموذج EAST ($modelId) غير مُنزَّل — رجوع لـML Kit")
            return@withContext recognizeMLKit(bitmap)
        }
        if (!OpenCVStatus.isAvailable) {
            Log.w("EAST", "OpenCV غير محمّلة — رجوع لـML Kit")
            return@withContext recognizeMLKit(bitmap)
        }

        val boxes = try { runEastDetection(bitmap, modelFile, modelId) } catch (e: Throwable) {
            Log.e("EAST", "فشل استدلال EAST — رجوع لـML Kit", e)
            null
        }
        if (boxes.isNullOrEmpty()) {
            Log.w("EAST", "EAST لم يكتشف نصوصاً — رجوع لـML Kit")
            return@withContext recognizeMLKit(bitmap)
        }

        val blocks = boxes.mapNotNull { rect ->
            val text = recognizeTextInRegion(bitmap, rect)?.trim()
            if (text.isNullOrBlank()) null
            else BlockData(text = text, x = rect.left, y = rect.top, width = rect.width(), height = rect.height())
        }
        mergeIntoComicBlocks(blocks, bitmap.width, bitmap.height)
    }

    private val EAST_INPUT_320 = Pair(320, 320)
    private val EAST_INPUT_640 = Pair(640, 416)
    private val EAST_INPUT_1280 = Pair(1280, 800)
    private val EAST_SCORE_THRESH = 0.5f
    private val EAST_NMS_THRESH = 0.2f

    private fun runEastDetection(bitmap: Bitmap, modelFile: File, modelId: String): List<Rect> {
        val interpreter = synchronized(eastLock) {
            val expectedSize = when (modelId) { "det_east_320" -> 320; "det_east_640" -> 640; "det_east_1280" -> 1280; else -> 320 }
            if (eastInterpreter != null && eastModelSize != expectedSize) { eastInterpreter?.close(); eastInterpreter = null }
            eastInterpreter ?: Interpreter(loadCraftModelFile(modelFile)).also {
                eastInterpreter = it; eastModelSize = expectedSize
                logInterpreterShapes("EAST ($modelId)", it)
            }
        }

        val (inputW, inputH) = when (modelId) { "det_east_320" -> EAST_INPUT_320; "det_east_640" -> EAST_INPUT_640; "det_east_1280" -> EAST_INPUT_1280; else -> EAST_INPUT_320 }
        val origW = bitmap.width; val origH = bitmap.height
        val resized = Bitmap.createScaledBitmap(bitmap, inputW, inputH, true)

        val meanR = 0.485f * 255f; val meanG = 0.456f * 255f; val meanB = 0.406f * 255f
        val stdR = 0.229f * 255f; val stdG = 0.224f * 255f; val stdB = 0.225f * 255f

        val inputBuffer = ByteBuffer.allocateDirect(4 * inputH * inputW * 3).order(ByteOrder.nativeOrder())
        val pixels = IntArray(inputW * inputH)
        resized.getPixels(pixels, 0, inputW, 0, 0, inputW, inputH)
        for (y in 0 until inputH) {
            for (x in 0 until inputW) {
                val p = pixels[y * inputW + x]
                inputBuffer.putFloat((((p shr 16) and 0xFF).toFloat() - meanR) / stdR)
                inputBuffer.putFloat((((p shr 8) and 0xFF).toFloat() - meanG) / stdG)
                inputBuffer.putFloat(((p and 0xFF).toFloat() - meanB) / stdB)
            }
        }
        inputBuffer.rewind(); resized.recycle()

        val outH = inputH / 4; val outW = inputW / 4
        val scoreBuffer = ByteBuffer.allocateDirect(4 * outH * outW * 1).order(ByteOrder.nativeOrder())
        val geometryBuffer = ByteBuffer.allocateDirect(4 * outH * outW * 5).order(ByteOrder.nativeOrder())
        val outputs: MutableMap<Int, Any> = HashMap()
        outputs[0] = scoreBuffer; outputs[1] = geometryBuffer
        interpreter.runForMultipleInputsOutputs(arrayOf<Any>(inputBuffer), outputs)
        scoreBuffer.rewind(); geometryBuffer.rewind()

        val boxes = ArrayList<EastBox>()
        for (y in 0 until outH) {
            for (x in 0 until outW) {
                val score = scoreBuffer.float
                if (score < EAST_SCORE_THRESH) { repeat(5) { geometryBuffer.float }; continue }
                val dTop = geometryBuffer.float; val dRight = geometryBuffer.float
                val dBottom = geometryBuffer.float; val dLeft = geometryBuffer.float
                val angle = geometryBuffer.float

                val cx = (x * 4 + 2).toFloat(); val cy = (y * 4 + 2).toFloat()
                val top = (cy - dTop * inputH).coerceIn(0f, inputH.toFloat())
                val right = (cx + dRight * inputW).coerceIn(0f, inputW.toFloat())
                val bottom = (cy + dBottom * inputH).coerceIn(0f, inputH.toFloat())
                val left = (cx - dLeft * inputW).coerceIn(0f, inputW.toFloat())

                val scaleX = origW.toFloat() / inputW; val scaleY = origH.toFloat() / inputH
                val ol = (left * scaleX).toInt().coerceIn(0, origW - 1)
                val ot = (top * scaleY).toInt().coerceIn(0, origH - 1)
                val or_ = (right * scaleX).toInt().coerceIn(ol + 1, origW)
                val ob = (bottom * scaleY).toInt().coerceIn(ot + 1, origH)
                boxes.add(EastBox(Rect(ol, ot, or_, ob), score, angle))
            }
        }

        boxes.sortByDescending { it.score }
        val result = mutableListOf<Rect>()
        for (box in boxes) {
            var keep = true
            for (kept in result) { if (iou(box.rect, kept) > EAST_NMS_THRESH) { keep = false; break } }
            if (keep) result.add(box.rect)
        }
        return result
    }

    private data class EastBox(val rect: Rect, val score: Float, val angle: Float)
    private fun iou(a: Rect, b: Rect): Float {
        val l = maxOf(a.left, b.left); val t = maxOf(a.top, b.top)
        val r = minOf(a.right, b.right); val bo = minOf(a.bottom, b.bottom)
        if (r <= l || bo <= t) return 0f
        val inter = (r - l) * (bo - t)
        val union = a.width() * a.height() + b.width() * b.height() - inter
        return if (union > 0) inter.toFloat() / union else 0f
    }

    // ========== ⭐ EasyOCR ==========
    // ⚠️ تصحيح مرجع (2026-08-15): "ocr_easyocr" (ملف واحد) لم يعد موجوداً في
    // ModelManager.availableModels — استُبدل بملفين منفصلين "ocr_easyocr_det"/
    // "ocr_easyocr_rec" (راجع تعليق ModelManager.kt الطويل). كود سابق هنا كان يبحث عن
    // "ocr_easyocr" فقط، وهذا الـid لم يعد موجوداً إطلاقاً بالقائمة، فـ`find` كانت سترجع
    // null دائماً بصمت (فشل صامت آخر، لا Exception، فقط رجوع تلقائي دائم لـML Kit بنفس
    // النتيجة الظاهرية كالسابق تماماً لكن لسبب مختلف تماماً عن السبب المذكور برسالة
    // اللوق القديمة). عُدِّل هنا ليتحقق من الملفين الصحيحين، لكن **لا يزال بدون فك تشفير
    // فعلي لمُخرَج Recognizer** — هذا يبقى TODO حقيقي غير منجَز (راجع ملاحظة الصدق
    // بالواجهة index.html، الخيار مُعلَّم "🔬 تجريبي" الآن بدل الإيحاء بأنه يعمل كاملاً).
    // تنفيذ فك التشفير الكامل (detection boxes من Detector + CTC/attention decoding من
    // Recognizer لكل صندوق) عمل مستقبلي غير مؤكَّد كفاية للتنفيذ الأعمى بدون جهاز حقيقي
    // للاختبار — نفس منطق الحذر المُتَّبع بهذا المشروع تاريخياً (راجع أقسام CRAFT/EAST
    // بـHANDOFF_NEXT_ASSISTANT.md لأمثلة فشل صامت ناتج عن افتراضات شكل مُخرَج غير مُختبَرة).
    override suspend fun recognizeEasyOCR(bitmap: Bitmap): List<BlockData> = withContext(Dispatchers.IO) {
        val detFile = modelManager.availableModels.find { it.id == "ocr_easyocr_det" }?.let { modelManager.modelFile(it) }
        val recFile = modelManager.availableModels.find { it.id == "ocr_easyocr_rec" }?.let { modelManager.modelFile(it) }
        if (detFile == null || !detFile.exists() || recFile == null || !recFile.exists()) {
            Log.w("EasyOCR", "نموذج EasyOCR (Detector أو Recognizer) غير مُنزَّل بالكامل — رجوع لـML Kit")
            return@withContext recognizeMLKit(bitmap)
        }

        val interpreter = synchronized(easyocrLock) {
            easyocrInterpreter ?: Interpreter(loadCraftModelFile(detFile)).also {
                easyocrInterpreter = it
                logInterpreterShapes("EasyOCR Detector", it)
            }
        }
        // 🔍 بحث ويب (2026-08-15، صفحة Detector رسمية بـHugging Face + قسم AI Hub Models):
        // Detector نموذج EasyOCR هو فعلياً نفس معمارية CRAFT (نفس Detector المُستخدَم بمكتبة
        // EasyOCR الأصلية حسب توثيقها الرسمي: "Detection execution uses the CRAFT algorithm").
        // مدخله الموثَّق رسمياً لتشغيل QNN هو float32 [1, 3, 608, 800] — أي NCHW صراحة (قناة
        // أولاً)، بخلاف الافتراض NHWC (RGB متتالٍ لكل بكسل) المُستخدَم بالكود تحت حالياً. هذا
        // موثَّق لمخرَج QNN تحديداً وليس تصدير .tflite بالضرورة (قد يختلف ترتيب المحاور بينهما
        // فعلياً)، لذا لم أُغيّر ترتيب الكتابة تخميناً — سطر logInterpreterShapes أعلاه سيطبع
        // شكل مدخل الـtflite الحقيقي فعلياً أول تشغيل، وهذا يحسم الأمر بيقين بدل تخمين. لو
        // طلع الشكل [1,3,608,800] فعلاً بالـtflite أيضاً، الحل وقتها: نفس الحلقة لكن تُكتب كل
        // قناة (R كاملة، ثم G كاملة، ثم B كاملة) بدل تشابك RGB لكل بكسل.
        // Recognizer نموذج EasyOCR هو CRNN + فك تشفير CTC (توثيق EasyOCR الرسمي: "recognition
        // model is a CRNN"). خوارزمية فك تشفير CTC الجشعة (argmax لكل خطوة زمنية، ثم دمج
        // التكرارات المتتالية، ثم حذف رمز blank) خوارزمية قياسية معروفة سلوكها **مستقل عن شكل
        // الملف الثنائي بالذات** طالما عدد الأصناف (حجم القاموس) واتجاه محور الزمن صحيحان —
        // وهذان تحديداً يحتاجان القراءة الفعلية من logInterpreterShapes تحت (مخرج الـRecognizer)
        // قبل ربطها بجدول حروف فعلي، فحجم القاموس (عدد الأصناف بالمحور الأخير) يحدد أي قائمة
        // حروف EasyOCR (رقمية/رمزية/إنجليزية إلخ حسب en_filtered_config.yaml الرسمي) تُطابقه.
        val recInterpreter = try {
            synchronized(easyocrLock) {
                easyocrRecInterpreter ?: Interpreter(loadCraftModelFile(recFile)).also {
                    easyocrRecInterpreter = it
                    logInterpreterShapes("EasyOCR Recognizer", it)
                }
            }
        } catch (e: Throwable) {
            Log.e("EasyOCR", "فشل تحميل Recognizer", e)
            null
        }

        try {
            // EasyOCR Detector TFLite input: 608×800 (من توثيق Qualcomm)
            val inputW = 800; val inputH = 608
            val resized = Bitmap.createScaledBitmap(bitmap, inputW, inputH, true)
            val inputBuffer = ByteBuffer.allocateDirect(4 * inputH * inputW * 3).order(ByteOrder.nativeOrder())
            val pixels = IntArray(inputW * inputH)
            resized.getPixels(pixels, 0, inputW, 0, 0, inputW, inputH)
            for (y in 0 until inputH) {
                for (x in 0 until inputW) {
                    val p = pixels[y * inputW + x]
                    inputBuffer.putFloat(((p shr 16) and 0xFF) / 255f)
                    inputBuffer.putFloat(((p shr 8) and 0xFF) / 255f)
                    inputBuffer.putFloat((p and 0xFF) / 255f)
                }
            }
            inputBuffer.rewind(); resized.recycle()

            // TODO حقيقي وغير منجَز: فك تشفير مُخرَج Detector لصناديق + تمرير كل صندوق
            // لـRecognizer لقراءة النص (فك تشفير CTC). نستخدم ML Kit كخطة احتياطية دائمة حتى
            // يُنفَّذ هذا فعلياً. الآن (بعد هذه الدفعة) الملفان يُحمَّلان فعلياً كمفسِّرَين
            // (interpreter) صالحَين، وسطور logInterpreterShapes أعلاه تطبع بـLogcat (وسم
            // "ModelShape") شكل مدخل/مخرج كل منهما الحقيقي أول تشغيل — هذا يحسم بدقة شكل
            // مخرَج Detector (صناديق CRAFT-style) وحجم قاموس Recognizer (لازم لمطابقة جدول
            // الحروف) بدل تخمينهما، وهي المعلومة الناقصة الوحيدة فعلياً لإكمال فك التشفير
            // الحقيقي بدفعة لاحقة. راجع Logcat بعد تشغيل الميزة على صفحة كوميكس حقيقية.
            Log.w("EasyOCR", "ملفا Detector/Recognizer محمَّلان فعلياً كمفسِّرَين — لكن فك التشفير الفعلي غير مُنفَّذ بعد (راجع لوق ModelShape للمخرجات الحقيقية) — رجوع لـML Kit")
            recognizeMLKit(bitmap)
        } catch (e: Throwable) {
            Log.e("EasyOCR", "فشل — رجوع لـML Kit", e)
            recognizeMLKit(bitmap)
        }
    }

    // 2. PaddleOCR Lite — on-device detection + angle classification + recognition.
    // المكتبة تحتاج فعلياً ملفات det.nb/rec.nb/cls.nb + قاموس الرموز لكي تعمل. هذه الحزمة
    // (كما استُلمت) لا تحتوي هذه الملفات فعلياً في assets/paddle (فقط README يفترض خطوة CI
    // غير موجودة هنا). buildPaddleConfig() تتحقق أولاً من وجودها الفعلي في assets، وإلا
    // تستخدم أي نسخة نزّلها المستخدم عبر ⚙️ إدارة النماذج (ModelManager) من تخزين الجهاز.
    // لو الاثنان غير متوفرين، نرجع تلقائياً وبوضوح لـ ML Kit بدل الفشل الصامت.
    override suspend fun recognizePaddleLite(bitmap: Bitmap): List<BlockData> = withContext(Dispatchers.IO) {
        try {
            synchronized(paddleLock) {
                if (!paddleInitialized) {
                    val config = buildPaddleConfig()
                        ?: throw IllegalStateException(
                            "نماذج PaddleOCR Lite غير متوفرة — نزّلها من ⚙️ إدارة النماذج، أو أضِفها في assets/paddle عند البناء"
                        )
                    paddleOcr.initModelSync(config).getOrThrow()
                    paddleInitialized = true
                }
            }

            val result = paddleOcr.runSync(bitmap).getOrThrow()
            val labels = paddleOcr.getWordLabels()
            result.outputRawResult.mapNotNull { raw ->
                val points = raw.points
                if (points == null || points.size < 4) return@mapNotNull null
                val xs = points.map { it.x }
                val ys = points.map { it.y }
                val left = xs.minOrNull()?.toInt() ?: return@mapNotNull null
                val top = ys.minOrNull()?.toInt() ?: return@mapNotNull null
                val right = xs.maxOrNull()?.toInt() ?: return@mapNotNull null
                val bottom = ys.maxOrNull()?.toInt() ?: return@mapNotNull null
                val text = raw.wordIndex.joinToString("") { labels.getOrNull(it) ?: "" }.trim()
                if (text.isBlank()) return@mapNotNull null
                BlockData(
                    text = text,
                    x = left.coerceIn(0, bitmap.width - 1),
                    y = top.coerceIn(0, bitmap.height - 1),
                    width = (right - left).coerceAtLeast(1).coerceAtMost(bitmap.width),
                    height = (bottom - top).coerceAtLeast(1).coerceAtMost(bitmap.height),
                    confidence = raw.confidence.toFloat(),
                    angle = if (raw.clsLabel == "180") 180f else 0f
                )
            }.let { mergeIntoComicBlocks(it, bitmap.width, bitmap.height) }
        } catch (e: Throwable) {
            Log.e("PaddleOCR", "PaddleOCR Lite failed; falling back to ML Kit", e)
            recognizeMLKit(bitmap)
        }
    }

    // يبني إعدادات paddleocr4android حسب مصدر الملفات المتوفر فعلياً:
    // 1) assets/paddle (لو أُضيفت وقت البناء) — modelPath بدون "/" في البداية يعني مسار
    //    داخل assets حسب توثيق المكتبة.
    // 2) ملفات نزّلها المستخدم عبر ModelManager إلى تخزين الجهاز — modelPath هنا مسار مطلق
    //    يبدأ بـ "/"، وهو ما تفسّره المكتبة كقراءة من تخزين الجهاز بدل assets (موثّق في
    //    doc/paddlelite.md الخاص بمكتبة paddleocr4android).
    // ترجع null لو ما توفر أي مصدر كامل (الأربعة ملفات معاً)، بدل افتراض التوفر دائماً.
    private fun buildPaddleConfig(): OcrConfig? {
        val requiredAssets = setOf("det.nb", "rec.nb", "cls.nb", "ppocr_keys_v1.txt")
        val bundledInAssets = try {
            val listed = context.assets.list("paddle")?.toSet() ?: emptySet()
            requiredAssets.all { it in listed }
        } catch (e: Exception) {
            false
        }
        if (bundledInAssets) {
            return OcrConfig().apply {
                modelPath = "paddle"
                labelPath = "paddle/ppocr_keys_v1.txt"
                detModelFilename = "det.nb"
                recModelFilename = "rec.nb"
                clsModelFilename = "cls.nb"
                isRunDet = true
                isRunCls = true
                isRunRec = true
                isDrwwTextPositionBox = false
            }
        }

        val models = modelManager.availableModels
        val det = models.find { it.id == "paddle_det" } ?: return null
        val rec = models.find { it.id == "paddle_rec" } ?: return null
        val cls = models.find { it.id == "paddle_cls" } ?: return null
        val dict = models.find { it.id == "paddle_dict" } ?: return null
        if (!modelManager.isDownloaded(det) || !modelManager.isDownloaded(rec) ||
            !modelManager.isDownloaded(cls) || !modelManager.isDownloaded(dict)
        ) return null

        return OcrConfig().apply {
            modelPath = modelManager.paddleModelsDir.absolutePath
            labelPath = modelManager.modelFile(dict).absolutePath
            detModelFilename = det.fileName
            recModelFilename = rec.fileName
            clsModelFilename = cls.fileName
            isRunDet = true
            isRunCls = true
            isRunRec = true
            isDrwwTextPositionBox = false
        }
    }

    // 2. Tesseract (stub - requires integration with Tesseract4Android or similar)
    override suspend fun recognizeTesseract(bitmap: Bitmap): List<BlockData> {
        // TODO: Integrate Tesseract4Android library
        // For now, fallback to ML Kit
        Log.w("OCR", "Tesseract not yet integrated, falling back to ML Kit")
        return recognizeMLKit(bitmap)
    }

    // 4. OCR.space (cloud)
    override suspend fun recognizeOCRSpace(bitmap: Bitmap, apiKey: String): List<BlockData> = withContext(Dispatchers.IO) {
        try {
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream)
            val byteArray = stream.toByteArray()

            val requestBody = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("apikey", apiKey)
                .addFormDataPart("isOverlayRequired", "true")
                .addFormDataPart("OCREngine", "2")
                .addFormDataPart("filetype", "jpg")
                .addFormDataPart(
                    "file", "image.jpg",
                    byteArray.toRequestBody("image/jpeg".toMediaType())
                )
                .build()

            val request = Request.Builder()
                .url("https://api.ocr.space/parse/image")
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return@withContext emptyList()
            val json = JSONObject(body)

            if (json.optBoolean("IsErroredOnProcessing", false)) {
                Log.e("OCRSpace", json.optString("ErrorMessage"))
                return@withContext emptyList()
            }

            val results = json.optJSONArray("ParsedResults") ?: return@withContext emptyList()
            val lines = results.getJSONObject(0).optJSONObject("TextOverlay")?.optJSONArray("Lines") ?: return@withContext emptyList()

            val blocks = mutableListOf<BlockData>()
            for (i in 0 until lines.length()) {
                val line = lines.getJSONObject(i)
                val words = line.optJSONArray("Words")
                if (words != null && words.length() > 0) {
                    val first = words.getJSONObject(0)
                    val totalWidth = (0 until words.length()).sumOf { words.getJSONObject(it).optInt("Width", 0) }
                    blocks.add(BlockData(
                        text = line.optString("LineText", ""),
                        x = first.optInt("Left", 0),
                        y = first.optInt("Top", 0),
                        width = totalWidth,
                        height = line.optInt("MaxHeight", 30)
                    ))
                }
            }
            blocks
        } catch (e: Exception) {
            Log.e("OCRSpace", "Error", e)
            emptyList()
        }
    }

    // 5. Cloud API (generic)
    override suspend fun recognizeCloud(bitmap: Bitmap, apiUrl: String): List<BlockData> = withContext(Dispatchers.IO) {
        try {
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream)
            val base64 = android.util.Base64.encodeToString(stream.toByteArray(), android.util.Base64.DEFAULT)

            val jsonBody = JSONObject().put("image", "data:image/jpeg;base64,$base64").toString()
            val request = Request.Builder()
                .url(apiUrl)
                .post(jsonBody.toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return@withContext emptyList()
            val json = JSONObject(body)

            val results = json.optJSONArray("results") ?: json.optJSONArray("words") ?: json.optJSONArray("texts") ?: return@withContext emptyList()
            val blocks = mutableListOf<BlockData>()
            for (i in 0 until results.length()) {
                val item = results.getJSONObject(i)
                blocks.add(BlockData(
                    text = item.optString("text", ""),
                    x = item.optInt("x", 0),
                    y = item.optInt("y", 0),
                    width = item.optInt("width", 100),
                    height = item.optInt("height", 30),
                    confidence = item.optDouble("confidence", 80.0).toFloat()
                ))
            }
            blocks
        } catch (e: Exception) {
            Log.e("CloudOCR", "Error", e)
            emptyList()
        }
    }

    /**
     * ML Kit returns text lines. Comic speech bubbles often contain several lines that
     * belong to one sentence/bubble. Merge nearby lines using geometry rather than blindly
     * concatenating the entire page. This keeps translation requests at bubble level.
     */
    private fun mergeIntoComicBlocks(
        input: List<BlockData>,
        imageWidth: Int,
        imageHeight: Int
    ): List<BlockData> {
        if (input.isEmpty()) return emptyList()

        val sorted = input
            .filter { it.text.isNotBlank() && it.width > 0 && it.height > 0 }
            .sortedWith(compareBy<BlockData> { it.y }.thenBy { it.x })

        val groups = mutableListOf<MutableList<BlockData>>()
        for (line in sorted) {
            var best: MutableList<BlockData>? = null
            var bestScore = Float.NEGATIVE_INFINITY

            for (group in groups) {
                val g = group.reduce { a, b -> mergeGeometry(a, b) }
                val overlapX = horizontalOverlapRatio(line, g)
                val centerDx = kotlin.math.abs((line.x + line.width / 2f) - (g.x + g.width / 2f))
                val centerLimit = maxOf(line.width, g.width) * 0.65f
                val gapY = maxOf(0, maxOf(line.y, g.y) - minOf(line.y + line.height, g.y + g.height))
                val gapLimit = maxOf(14f, maxOf(line.height, g.height) * 1.35f)

                // Strong horizontal alignment or center alignment + a small vertical gap.
                val compatible = (overlapX >= 0.25f || centerDx <= centerLimit) && gapY <= gapLimit
                if (!compatible) continue

                val score = overlapX * 2f + (1f - (gapY / gapLimit).coerceIn(0f, 1f))
                if (score > bestScore) {
                    bestScore = score
                    best = group
                }
            }

            if (best != null) best!!.add(line) else groups.add(mutableListOf(line))
        }

        return groups.mapNotNull { group ->
            val box = group.reduce { a, b -> mergeGeometry(a, b) }
            val ordered = group.sortedWith(compareBy<BlockData> { it.y }.thenBy { it.x })
            val text = ordered.joinToString(" ") { it.text.trim() }.replace(Regex("\\s+"), " ").trim()
            if (text.isBlank()) null
            else box.copy(
                text = text,
                confidence = ordered.map { it.confidence }.filter { it > 0f }.average()
                    .takeIf { !it.isNaN() }?.toFloat() ?: box.confidence,
                x = box.x.coerceIn(0, maxOf(0, imageWidth - 1)),
                y = box.y.coerceIn(0, maxOf(0, imageHeight - 1)),
                width = box.width.coerceAtMost(imageWidth),
                height = box.height.coerceAtMost(imageHeight)
            )
        }.sortedWith(compareBy<BlockData> { it.y }.thenBy { it.x })
    }

    private fun mergeGeometry(a: BlockData, b: BlockData): BlockData {
        val x1 = minOf(a.x, b.x)
        val y1 = minOf(a.y, b.y)
        val x2 = maxOf(a.x + a.width, b.x + b.width)
        val y2 = maxOf(a.y + a.height, b.y + b.height)
        return a.copy(x = x1, y = y1, width = x2 - x1, height = y2 - y1)
    }

    private fun horizontalOverlapRatio(a: BlockData, b: BlockData): Float {
        val left = maxOf(a.x, b.x)
        val right = minOf(a.x + a.width, b.x + b.width)
        val overlap = maxOf(0, right - left)
        val base = minOf(a.width, b.width).coerceAtLeast(1)
        return overlap.toFloat() / base
    }

}
