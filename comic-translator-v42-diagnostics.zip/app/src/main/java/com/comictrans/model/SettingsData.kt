package com.comictrans.model

data class SettingsData(
    // بند جديد: نموذج كشف مناطق النص (Detection) — منفصل مفاهيمياً عن "قارئ النصوص"
    // (ocrEngine) أدناه. خمس قيم مُفعَّلة فعلياً بأنبوب المعالجة (AppInterface.processPage):
    // "ppocr_det_slim" (تستخدم det.nb الموجود أصلاً — يعمل تلقائياً كل مرة يُختار
    // ocrEngine="paddle_lite")، "craft_mobile" (كاشف CRAFT مستقل + قراءة عبر ML Kit)،
    // و"det_east_320"/"det_east_640"/"det_east_1280" (كاشف EAST بثلاثة أحجام — القيمة هنا
    // يجب أن تطابق id النموذج بالضبط بـModelManager.availableModels، بعكس "craft_mobile"
    // اللي له تعيين منفصل لـ"det_craft_mobile"). ⚠️ تصحيح توثيقي (2026-08-15): القيم
    // الثلاث القديمة (yolov8n_seg/dbnet_mobilenetv3/rtdetr_v2_mobile) حُذفت بالكامل من
    // ModelManager.availableModels دفعة سابقة (استُبدلت بـEAST) لكن index.html بقي بدون
    // تحديث لفترة (سبب البلاغ الأخير من المستخدم) — أُصلح الآن، القيم الثلاث القديمة لم
    // تعد موجودة لا بالخلفية ولا بالواجهة.
    val textDetectionModel: String = "ppocr_det_slim",
    val ocrEngine: String = "mlkit",
    val erasureMode: String = "fill",
    val translateEngine: String = "google",
    val sourceLang: String = "en",
    val targetLang: String = "ar",
    val useMemory: Boolean = true,
    val enhanceImage: Boolean = true, // افتراضي مفعّل الآن — يحسّن دقة قراءة OCR لخطوط الكوميك بدون أي نموذج إضافي (راجع الشرح في index.html)
    val enhanceMethod: String = "opencv",
    val ocrSpaceKey: String = "",
    val cloudApiUrl: String = "",
    val geminiKey: String = "",
    val geminiModel: String = "gemini-2.0-flash",
    val openaiKey: String = "",
    val openaiModel: String = "gpt-4o-mini",
    val openrouterKey: String = "",
    val openrouterModel: String = "openai/gpt-4o-mini",
    val deeplKey: String = "",
    // بند 8: Local LLM (Ollama / LM Studio / أي سيرفر متوافق مع OpenAI API). translateEngine
    // = "custom" يستخدم هذه الحقول. مثال customApiUrl لـOllama محلي:
    // "http://127.0.0.1:11434/v1/chat/completions" — والـcustomApiKey يُترَك فارغاً غالباً
    // (Ollama/LM Studio لا يتطلبان مفتاحاً افتراضياً).
    val customApiUrl: String = "",
    val customApiKey: String = "",
    val customModel: String = "",
    // بند 7: نظام Prompts حسب نوع الكوميكس + سياق السلسلة — يُستخدَمان في PromptManager
    // لبناء system prompt مناسب (نبرة/أسلوب حوار يختلف بين مانجا يابانية ومانهوا كورية
    // وكوميكس غربي)، ويُمرَّران فقط للمحركات القائمة على LLM (custom/openai/gemini/openrouter).
    val comicType: String = "manga", // "manga" | "manhwa" | "western"
    val seriesName: String = "",
    // بند 3: كشف فقاعات الكلام — لو true (افتراضي false)، وضع الطمس "opencv" يحاول قناع
    // طمس بحدود الفقاعة الفعلية (Imgproc.findContours) بدل مستطيل النص الخام. راجع
    // BubbleDetector.kt وErasureEngine.inpaintOpenCV للتفاصيل. افتراضي false عمداً حتى
    // يبقى سلوك "opencv" كما كان تماماً ما لم يُفعَّل المستخدم هذا صراحة من الإعدادات.
    val bubbleAwareErasure: Boolean = false,
    // ⚠️ توضيح (2026-08-15): هذا الحقل يُحفَظ/يُقرأ من الإعدادات فقط — لا يوجد أي كود
    // Kotlin آخر بالمشروع يقرأ قيمته (تحقّقت بـgrep على كامل app/ وfeature_ai/، صفر
    // نتائج غير هذا التعريف). القيمتان "freetype_harfbuzz"/"skia" مُدرَجتان بواجهة
    // index.html كخيارات مستقبلية (تحتاج كوداً أصلياً NDK لم يُكتب بعد) — اختيارهما لا
    // يُغيّر أي سلوك رسم فعلي حالياً، يبقى الرسم دائماً عبر Android Canvas بصمت.
    val textRendererEngine: String = "android_canvas"
)
