package com.comictrans.model

data class SettingsData(
    // بند جديد: نموذج كشف مناطق النص (Detection) — منفصل مفاهيمياً عن "قارئ النصوص"
    // (ocrEngine) أدناه. قيمتان مُفعَّلتان فعلياً: "ppocr_det_slim" (تستخدم det.nb
    // الموجود أصلاً — يعمل تلقائياً كل مرة يُختار ocrEngine="paddle_lite"، هذا الحقل فقط
    // يجعله ظاهراً/قابلاً للاختيار صراحة بدل ضمنياً)، و"craft_mobile" (كاشف CRAFT مستقل +
    // قراءة عبر ML Kit، راجع OCREngine.recognizeCraftMobile — غير مُختبَر وقت التشغيل بعد).
    // القيم الثلاث الباقية (yolov8n_seg / dbnet_mobilenetv3 / rtdetr_v2_mobile) مُسجَّلة
    // بمركز تحميل النماذج (راجع ModelManager.availableModels) لكن غير موصولة بأنبوب
    // المعالجة بعد — اختيارها يُظهر تحذيراً واضحاً بدل فشل صامت (AppInterface.processPage).
    val textDetectionModel: String = "ppocr_det_slim",
    val ocrEngine: String = "mlkit",
    val erasureMode: String = "fill",
    val translateEngine: String = "google",
    val sourceLang: String = "en",
    val targetLang: String = "ar",
    val useMemory: Boolean = true,
    val enhanceImage: Boolean = true, // افتراضي مفعّل الآن — يحسّن دقة قراءة OCR لخطوط الكوميك بدون أي نموذج إضافي (راجع الشرح في index.html)
    val enhanceMethod: String = "opencv",
    val ocrSpaceKey: String = "",
    val cloudApiUrl: String = "",
    val geminiKey: String = "",
    val geminiModel: String = "gemini-2.0-flash",
    val openaiKey: String = "",
    val openaiModel: String = "gpt-4o-mini",
    val openrouterKey: String = "",
    val openrouterModel: String = "openai/gpt-4o-mini",
    val deeplKey: String = "",
    // بند 8: Local LLM (Ollama / LM Studio / أي سيرفر متوافق مع OpenAI API). translateEngine
    // = "custom" يستخدم هذه الحقول. مثال customApiUrl لـOllama محلي:
    // "http://127.0.0.1:11434/v1/chat/completions" — والـcustomApiKey يُترَك فارغاً غالباً
    // (Ollama/LM Studio لا يتطلبان مفتاحاً افتراضياً).
    val customApiUrl: String = "",
    val customApiKey: String = "",
    val customModel: String = "",
    // بند 7: نظام Prompts حسب نوع الكوميكس + سياق السلسلة — يُستخدَمان في PromptManager
    // لبناء system prompt مناسب (نبرة/أسلوب حوار يختلف بين مانجا يابانية ومانهوا كورية
    // وكوميكس غربي)، ويُمرَّران فقط للمحركات القائمة على LLM (custom/openai/gemini/openrouter).
    val comicType: String = "manga", // "manga" | "manhwa" | "western"
    val seriesName: String = "",
    // بند 3: كشف فقاعات الكلام — لو true (افتراضي false)، وضع الطمس "opencv" يحاول قناع
    // طمس بحدود الفقاعة الفعلية (Imgproc.findContours) بدل مستطيل النص الخام. راجع
    // BubbleDetector.kt وErasureEngine.inpaintOpenCV للتفاصيل. افتراضي false عمداً حتى
    // يبقى سلوك "opencv" كما كان تماماً ما لم يُفعَّل المستخدم هذا صراحة من الإعدادات.
    val bubbleAwareErasure: Boolean = false,
    val textRendererEngine: String = "android_canvas"
)
