package com.comictrans.engine

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest

data class ModelInfo(
    val id: String,          // يطابق قيمة erasureMode: "ai_lite" أو "ai_pro"، أو أحد ملفات
                              // PaddleOCR Lite: "paddle_det" / "paddle_rec" / "paddle_cls" / "paddle_dict"
    val displayName: String,
    val fileName: String,
    val url: String,         // فارغ = لا يوجد رابط تنزيل رسمي معروف؛ يحتاج المستخدم يوفّر رابط بديل
    val approxSizeMB: Int,
    val sha256: String? = null,
    // حد أدنى لحجم الملف (بايت) لاعتباره "محمّلاً بنجاح" — منخفض لملفات PaddleOCR الصغيرة
    // نسبياً (القاموس نص عادي بضع كيلوبايت فقط، cls.nb صغير أيضاً) بدل الحد الافتراضي
    // 1MB المناسب فقط لنماذج AI Lite/Pro الكبيرة.
    val minValidBytes: Long = 1_000_000L
)

/**
 * يدير تنزيل/تخزين/التحقق من نماذج الطمس بالذكاء الاصطناعي (AI Lite / AI Pro).
 * الملفات تُخزَّن في: <external-files>/models/
 *
 * مصدر AI Pro (ONNX): Carve/LaMa-ONNX على Hugging Face (lama_fp32.onnx) — نموذج LaMa
 * الأصلي محوّل لـ ONNX، مرخّص Apache-2.0، حجمه ~208MB، مُدخلاته: image float32[1,3,512,512]
 * (RGB مقسومة على 255) + mask float32[1,1,512,512] (1=امسح، 0=أبقِ)، ومُخرجه صورة RGB
 * [0..255] جاهزة مباشرة بنفس المقاس. هذا معروف وموثّق من صفحة النموذج، وتم التحقق منه.
 *
 * مصدر AI Lite (TFLite): لا يوجد حالياً رابط تنزيل مباشر عام موثوق لنموذج LaMa بصيغة
 * .tflite بدون تسجيل دخول (نسخة Qualcomm AI Hub تتطلب حساب). لذلك رابطها فارغ افتراضياً؛
 * المستخدم يقدر يضيف رابط .tflite خاص به (مُصدَّر بنفس فكرة LaMa: مُدخل صورة + قناع، مُخرج
 * صورة) عبر setCustomUrl، وستُستخدم تلقائياً بمجرد توفرها.
 */
class ModelManager(private val context: Context) {

    private val TAG = "ModelManager"
    private val client = OkHttpClient.Builder().build()

    private val modelsDir: File by lazy {
        File(context.getExternalFilesDir(null), "models").apply { mkdirs() }
    }

    // ملفات PaddleOCR Lite (det/rec/cls/dict) تُخزَّن في مجلد فرعي مستقل حتى نستطيع تمرير
    // مساره كاملاً لمكتبة paddleocr4android عبر OcrConfig.modelPath (المكتبة تفهم أي مسار
    // يبدأ بـ "/" كمسار مباشر على تخزين الجهاز بدل مجلد assets داخل الحزمة — موثّق في
    // doc/paddlelite.md الخاص بالمكتبة). راجع OCREngine.recognizePaddleLite لتفاصيل الاستخدام.
    val paddleModelsDir: File by lazy {
        File(modelsDir, "paddle").apply { mkdirs() }
    }

    // روابط قابلة للتعديل من المستخدم (تُخزَّن في SharedPreferences) — تسمح بإضافة نموذج
    // TFLite بديل لـ AI Lite لو ما توفر رابط رسمي، أو استبدال رابط AI Pro لو تغيّر.
    private val prefs by lazy { context.getSharedPreferences("model_urls", Context.MODE_PRIVATE) }

    val availableModels: List<ModelInfo>
        get() = listOf(
            ModelInfo(
                id = "ai_pro",
                displayName = "AI Pro (ONNX — LaMa)",
                fileName = "lama-pro.onnx",
                url = prefs.getString("url_ai_pro", DEFAULT_ONNX_URL) ?: DEFAULT_ONNX_URL,
                approxSizeMB = 208,
                sha256 = "1faef5301d78db7dda502fe59966957ec4b79dd64e16f03ed96913c7a4eb68d6"
            ),
            ModelInfo(
                id = "ai_lite",
                displayName = "AI Lite (TFLite)",
                fileName = "lama-lite.tflite",
                url = prefs.getString("url_ai_lite", "") ?: "",
                approxSizeMB = 45
            ),
            // ============ PaddleOCR Lite (det/rec/cls/dict) ============
            // ملاحظة صريحة: هذه الحزمة الحالية (كما استُلمت) لا تحتوي فعلياً على ملفات
            // det.nb/rec.nb/cls.nb/ppocr_keys_v1.txt داخل assets/paddle — الموجود هناك هو
            // README فقط يفترض وجود خطوة GitHub Actions تجلبها وقت البناء، لكن لا يوجد أي
            // ملف workflow (.github/workflows) داخل هذه الحزمة كما استُلمت. كانت واجهة
            // index.html تعرض "✅ مضمّن مع التطبيق" بشكل ثابت (hardcoded) بغض النظر عن الواقع،
            // وهذا مضلِّل. الحل: نعاملها كنماذج قابلة للتنزيل تماماً مثل AI Lite/AI Pro، تظهر
            // بشكل صحيح كـ"غير محمّلة" إن لم توجد فعلياً (لا في assets ولا تم تنزيلها)، ولا
            // نضع رابط تنزيل افتراضي مباشر لأن ملفات .nb الجاهزة من PaddleOCR الرسمية تأتي
            // كأرشيف .tar يحتاج تحويلاً بأداة opt (raw .nb الجاهزة غير مستضافة فردياً بشكل
            // رسمي وموثوق التوافق مع نسخة Paddle-Lite المُضمَّنة في paddleocr4android v1.3.0؛
            // ملفات .nb غير متوافقة الإصدار تُسبب انهيار تحميل النموذج - موثّق كمشكلة معروفة
            // في مستودع PaddleOCR). المستخدم يقدر يلصق رابط ملف مباشر (بعد تجهيزه بنفسه عبر
            // أداة opt الرسمية، أو من مصدر تحقق توافقه) عبر setCustomUrl، بنفس آلية AI Lite.
            ModelInfo(
                id = "paddle_det",
                displayName = "PaddleOCR — DET (كشف النص)",
                fileName = "det.nb",
                url = prefs.getString("url_paddle_det", "") ?: "",
                approxSizeMB = 3,
                minValidBytes = 50_000L
            ),
            ModelInfo(
                id = "paddle_rec",
                displayName = "PaddleOCR — REC (التعرف على النص)",
                fileName = "rec.nb",
                url = prefs.getString("url_paddle_rec", "") ?: "",
                approxSizeMB = 10,
                minValidBytes = 50_000L
            ),
            ModelInfo(
                id = "paddle_cls",
                displayName = "PaddleOCR — CLS (اتجاه النص)",
                fileName = "cls.nb",
                url = prefs.getString("url_paddle_cls", "") ?: "",
                approxSizeMB = 1,
                minValidBytes = 10_000L
            ),
            ModelInfo(
                id = "paddle_dict",
                displayName = "PaddleOCR — قاموس الرموز (dict)",
                fileName = "ppocr_keys_v1.txt",
                url = prefs.getString("url_paddle_dict", DEFAULT_PADDLE_DICT_URL) ?: DEFAULT_PADDLE_DICT_URL,
                approxSizeMB = 1,
                minValidBytes = 1_000L
            ),
            // نموذج تعزيز الصورة بالذكاء الاصطناعي (ImageEnhanceEngine، وضع "ai" في تعزيز
            // الصورة قبل OCR). لم يكن مسجَّلاً هنا سابقاً إطلاقاً، فلا زر تنزيل كان يظهر له
            // بأي مكان بالتطبيق رغم أن كود الاستدلال (tryAIEnhance) جاهز ويحتاج فقط الملف.
            // لا رابط افتراضي: بنية المدخل/المخرج (NHWC float32 0-255، تكبير x2 بالضبط)
            // يجب أن تطابق أي ملف .tflite يوضع هنا بدقة، ولا يوجد رابط تنزيل مباشر واحد
            // موثوق نضمن مطابقته لهذا الشكل تحديداً — يحتاج المستخدم رابط ملف .tflite
            // متوافق فعلياً (Real-ESRGAN x2 بمدخل/مخرج NHWC float32).
            ModelInfo(
                id = "enhance_ai",
                displayName = "تعزيز الصورة AI (Real-ESRGAN x2)",
                fileName = "realesrgan-x2.tflite",
                url = prefs.getString("url_enhance_ai", "") ?: "",
                approxSizeMB = 6,
                minValidBytes = 500_000L
            )
        )

    fun setCustomUrl(modelId: String, url: String) {
        prefs.edit().putString("url_$modelId", url).apply()
    }

    fun modelFile(model: ModelInfo): File =
        if (model.id.startsWith("paddle_")) File(paddleModelsDir, model.fileName)
        else File(modelsDir, model.fileName)

    fun isDownloaded(model: ModelInfo): Boolean {
        val f = modelFile(model)
        return f.exists() && f.length() >= model.minValidBytes // أصغر من الحد = غالباً تنزيل ناقص/فاشل
    }

    fun delete(model: ModelInfo): Boolean = modelFile(model).delete()

    /**
     * ينزّل النموذج مع تقدّم دوري، ويتحقق من sha256 إن كان معروفاً.
     * يكتب أولاً لملف .part ثم يعيد تسميته بعد اكتمال ونجاح التحقق، حتى لا يظهر
     * النموذج "محمّل" لو انقطع التنزيل منتصف الطريق.
     */
    suspend fun download(model: ModelInfo, onProgress: (Int) -> Unit): Result<Unit> = withContext(Dispatchers.IO) {
        if (model.url.isBlank()) {
            return@withContext Result.failure(IllegalStateException("لا يوجد رابط تنزيل لهذا النموذج — أضف رابطاً مخصصاً أولاً"))
        }
        val tmp = File(modelsDir, model.fileName + ".part")
        try {
            val request = Request.Builder().url(model.url).build()
            client.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) {
                    return@withContext Result.failure(java.io.IOException("HTTP ${resp.code}"))
                }
                val body = resp.body ?: return@withContext Result.failure(java.io.IOException("استجابة فارغة"))
                val total = body.contentLength()
                val digest = if (model.sha256 != null) MessageDigest.getInstance("SHA-256") else null

                body.byteStream().use { input ->
                    FileOutputStream(tmp).use { output ->
                        val buffer = ByteArray(64 * 1024)
                        var downloaded = 0L
                        var lastReportedPct = -1
                        while (true) {
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            digest?.update(buffer, 0, read)
                            downloaded += read
                            if (total > 0) {
                                val pct = ((downloaded * 100) / total).toInt()
                                if (pct != lastReportedPct) {
                                    lastReportedPct = pct
                                    onProgress(pct)
                                }
                            }
                        }
                    }
                }

                if (digest != null) {
                    val hex = digest.digest().joinToString("") { "%02x".format(it) }
                    if (!hex.equals(model.sha256, ignoreCase = true)) {
                        tmp.delete()
                        return@withContext Result.failure(java.io.IOException("فشل التحقق من سلامة الملف (checksum) — أُعيد التنزيل مطلوب"))
                    }
                }
            }
            val finalFile = modelFile(model)
            finalFile.delete()
            if (!tmp.renameTo(finalFile)) {
                return@withContext Result.failure(java.io.IOException("فشل حفظ النموذج على التخزين"))
            }
            onProgress(100)
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Model download failed: ${model.id}", e)
            tmp.delete()
            Result.failure(e)
        }
    }

    companion object {
        private const val DEFAULT_ONNX_URL =
            "https://huggingface.co/Carve/LaMa-ONNX/resolve/main/lama_fp32.onnx"

        // ملف القاموس نص عادي (UTF-8) بدون أي تبعية لإصدار Paddle-Lite، لذلك آمن وضع رابط
        // افتراضي رسمي مباشر له من مستودع PaddleOCR (بعكس ملفات .nb الثنائية التي يعتمد
        // نجاح تحميلها على توافق إصدار opset/runtime — انظر التعليق أعلى paddle_det).
        private const val DEFAULT_PADDLE_DICT_URL =
            "https://raw.githubusercontent.com/PaddlePaddle/PaddleOCR/main/ppocr/utils/ppocr_keys_v1.txt"
    }
}
