package com.comictrans.engine

import android.content.Context
import android.util.Log
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class TranslationEngine(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    // *** ملاحظة مهمة حول كل دوال الترجمة أدناه ***
    // سابقاً كانت كل دالة تلتقط أي استثناء وترجع النص الأصلي بصمت (`return text`)، بدون أي
    // أثر يصل للمستخدم. هذا يعني أنه لو مفتاح API خاطئ، أو الحصة (quota) انتهت، أو اسم
    // الموديل غير موجود، أو الشبكة فشلت — كانت النتيجة "الترجمة لم تتغيّر" بدون أي تفسير،
    // ما يجعل أي محرك يبدو "معطّلاً" عند اختباره دون معرفة السبب الحقيقي. الآن كل دالة
    // ترمي استثناءً واضح الرسالة عند الفشل، ويلتقطه AppInterface.processPage ليعرض تحذيراً
    // فعلياً في سجل الواجهة (⚠️) قبل الرجوع للنص الأصلي كحل احتياطي — بدل فشل صامت تماماً.

    // 1. ML Kit Translation (works offline after model download)
    suspend fun translateMLKit(text: String, source: String, target: String): String = withContext(Dispatchers.IO) {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.fromLanguageTag(source) ?: TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.fromLanguageTag(target) ?: TranslateLanguage.ARABIC)
            .build()
        val translator = Translation.getClient(options)

        // Ensure model is downloaded
        suspendCancellableCoroutine { continuation ->
            val conditions = DownloadConditions.Builder().build()
            translator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener { continuation.resume(Unit) }
                .addOnFailureListener { continuation.resumeWithException(
                    IllegalStateException("ML Kit: تعذر تنزيل نموذج اللغة (تأكد من الاتصال بالإنترنت أول مرة): ${it.message}", it)
                ) }
        }

        suspendCancellableCoroutine { continuation ->
            translator.translate(text)
                .addOnSuccessListener { continuation.resume(it) }
                .addOnFailureListener { continuation.resumeWithException(
                    IllegalStateException("ML Kit: فشلت الترجمة: ${it.message}", it)
                ) }
        }
    }

    // 2. Google Translate (free, no key)
    suspend fun translateGoogle(text: String, source: String, target: String): String = withContext(Dispatchers.IO) {
        val src = if (source == "auto") "auto" else source
        val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=${src}&tl=${target}&dt=t&q=${URLEncoder.encode(text, "UTF-8")}"
        val request = Request.Builder().url(url)
            // بعض الشبكات/المناطق ترفض الطلب بدون User-Agent شبيه بمتصفح فعلي — عميل OkHttp
            // الافتراضي (okhttp/x.x) أحياناً يُرفض من هذا الـendpoint غير الرسمي.
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36")
            .build()
        val response = client.newCall(request).execute()
        if (!response.isSuccessful) {
            throw IllegalStateException("Google Translate: HTTP ${response.code}")
        }
        val body = response.body?.string() ?: throw IllegalStateException("Google Translate: استجابة فارغة")

        // Parse JSON array response
        val jsonArray = org.json.JSONArray(body)
        val sentences = jsonArray.getJSONArray(0)
        val sb = StringBuilder()
        for (i in 0 until sentences.length()) {
            val sentence = sentences.getJSONArray(i)
            sb.append(sentence.getString(0))
        }
        sb.toString()
    }

    // 3. Gemini
    suspend fun translateGemini(text: String, source: String, target: String, apiKey: String, model: String): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) throw IllegalArgumentException("Gemini: مفتاح API فارغ")
        val targetName = if (target == "ar") "Arabic" else target
        val prompt = "Translate this comic text into $targetName naturally. Return only the translation:\n\n$text"
        val jsonBody = JSONObject().apply {
            put("contents", org.json.JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", org.json.JSONArray().apply {
                        put(JSONObject().put("text", prompt))
                    })
                })
            })
        }
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .build()
        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: throw IllegalStateException("Gemini: استجابة فارغة")
        if (!response.isSuccessful) {
            throw IllegalStateException("Gemini: HTTP ${response.code}: ${body.take(200)}")
        }
        val json = JSONObject(body)
        json.getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
            .getString("text").trim()
    }

    // 4. OpenAI
    suspend fun translateOpenAI(text: String, source: String, target: String, apiKey: String, model: String): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) throw IllegalArgumentException("OpenAI: مفتاح API فارغ")
        val targetName = if (target == "ar") "Arabic" else target
        val prompt = "Translate this comic text into $targetName naturally. Return only the translation:\n\n$text"
        val jsonBody = JSONObject().apply {
            put("model", model)
            put("messages", org.json.JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", prompt)
                })
            })
            put("temperature", 0.3)
        }
        val request = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .header("Authorization", "Bearer $apiKey")
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .build()
        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: throw IllegalStateException("OpenAI: استجابة فارغة")
        if (!response.isSuccessful) {
            throw IllegalStateException("OpenAI: HTTP ${response.code}: ${body.take(200)}")
        }
        val json = JSONObject(body)
        json.getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content").trim()
    }

    // 5. OpenRouter — OpenAI-compatible chat completions endpoint.
    // The model is a provider/model slug such as "openai/gpt-4o-mini" or a :free variant.
    suspend fun translateOpenRouter(text: String, source: String, target: String, apiKey: String, model: String): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) throw IllegalArgumentException("OpenRouter: مفتاح API فارغ")
        val targetName = when (target.lowercase()) {
            "ar" -> "Arabic"
            "en" -> "English"
            else -> target
        }
        val prompt = "Translate this comic text into $targetName naturally. Preserve names, tone, and line meaning. Return only the translation, with no explanation:\n\n$text"
        val jsonBody = JSONObject().apply {
            put("model", model.ifBlank { "openai/gpt-4o-mini" })
            put("messages", org.json.JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "system")
                    put("content", "You are a professional comic/manga translator. Translate naturally and concisely.")
                })
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", prompt)
                })
            })
            put("temperature", 0.3)
        }
        val request = Request.Builder()
            .url("https://openrouter.ai/api/v1/chat/completions")
            .header("Authorization", "Bearer $apiKey")
            .header("Content-Type", "application/json")
            .header("X-Title", "Comic Translator")
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .build()
        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: throw IllegalStateException("OpenRouter: استجابة فارغة")
        if (!response.isSuccessful) {
            throw IllegalStateException("OpenRouter: HTTP ${response.code}: ${body.take(200)}")
        }
        val json = JSONObject(body)
        json.getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content").trim()
    }

    // 6. DeepL
    // *** إصلاح: اختيار الـhost كان ثابتاً دائماً على api-free.deepl.com ***
    // مفاتيح DeepL Free تنتهي بـ ":fx" وتعمل فقط مع api-free.deepl.com؛ مفاتيح DeepL Pro لا
    // تحمل هذا اللاحقة وتعمل فقط مع api.deepl.com — استخدام الـhost الخاطئ يرجع 403 Forbidden
    // دائماً لمستخدمي الحسابات المدفوعة (Pro)، فيبدو DeepL "لا يعمل" رغم أن المفتاح صحيح.
    suspend fun translateDeepL(text: String, source: String, target: String, apiKey: String): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) throw IllegalArgumentException("DeepL: مفتاح API فارغ")
        val host = if (apiKey.trim().endsWith(":fx")) "api-free.deepl.com" else "api.deepl.com"
        // DeepL يرفض "EN" المجرّد كـ target_lang منذ فترة (يتطلب EN-US/EN-GB)، لكنه يقبل
        // اللغات الأخرى (مثل AR) بصيغتها المجرّدة بشكل طبيعي.
        val targetLang = if (target.equals("en", ignoreCase = true)) "EN-US" else target.uppercase()
        val body = java.net.URLEncoder.encode("text", "UTF-8") + "=" + java.net.URLEncoder.encode(text, "UTF-8") +
                "&" + java.net.URLEncoder.encode("target_lang", "UTF-8") + "=" + java.net.URLEncoder.encode(targetLang, "UTF-8")
        val request = Request.Builder()
            .url("https://$host/v2/translate")
            .header("Authorization", "DeepL-Auth-Key $apiKey")
            .header("Content-Type", "application/x-www-form-urlencoded")
            .post(body.toRequestBody("application/x-www-form-urlencoded".toMediaType()))
            .build()
        val response = client.newCall(request).execute()
        val resBody = response.body?.string() ?: throw IllegalStateException("DeepL: استجابة فارغة")
        if (!response.isSuccessful) {
            throw IllegalStateException("DeepL: HTTP ${response.code}: ${resBody.take(200)}")
        }
        val json = JSONObject(resBody)
        json.getJSONArray("translations").getJSONObject(0).getString("text")
    }
}
