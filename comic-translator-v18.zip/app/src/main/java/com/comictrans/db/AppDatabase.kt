package com.comictrans.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [TranslationEntity::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun translationDao(): TranslationDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        // v1 → v2: إضافة عمود engine (راجع شرح السبب في TranslationEntity.kt) + إعادة بناء
        // الفهرس الفريد ليشمله، بدل فقدان "الذاكرة الذكية" القديمة بالكامل عبر
        // fallbackToDestructiveMigration. الصفوف القديمة (بدون معرفة أي محرك أنتجها) تُعطى
        // القيمة الافتراضية "unknown" — تبقى محفوظة لكنها لن تتصادم صامتة مع أي محرك حقيقي.
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE translations ADD COLUMN engine TEXT NOT NULL DEFAULT 'unknown'")
                db.execSQL("DROP INDEX IF EXISTS index_translations_sourceText_sourceLang_targetLang")
                db.execSQL(
                    "CREATE UNIQUE INDEX IF NOT EXISTS " +
                        "index_translations_sourceText_sourceLang_targetLang_engine " +
                        "ON translations (sourceText, sourceLang, targetLang, engine)"
                )
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "comic_translator.db"
                ).addMigrations(MIGRATION_1_2).build().also { INSTANCE = it }
            }
        }
    }
}
