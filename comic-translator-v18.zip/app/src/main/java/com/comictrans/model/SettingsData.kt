package com.comictrans.model

data class SettingsData(
    val ocrEngine: String = "mlkit",
    val erasureMode: String = "fill",
    val translateEngine: String = "google",
    val sourceLang: String = "en",
    val targetLang: String = "ar",
    val useMemory: Boolean = true,
    val enhanceImage: Boolean = true, // افتراضي مفعّل الآن — يحسّن دقة قراءة OCR لخطوط الكوميك بدون أي نموذج إضافي (راجع الشرح في index.html)
    val enhanceMethod: String = "opencv",
    val ocrSpaceKey: String = "",
    val cloudApiUrl: String = "",
    val geminiKey: String = "",
    val geminiModel: String = "gemini-2.0-flash",
    val openaiKey: String = "",
    val openaiModel: String = "gpt-4o-mini",
    val openrouterKey: String = "",
    val openrouterModel: String = "openai/gpt-4o-mini",
    val deeplKey: String = ""
)
