package com.comictrans.engine

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

data class ModelInfo(
    val id: String,          // يطابق قيمة erasureMode: "ai_lite" أو "ai_pro"، أو أحد ملفات
                              // PaddleOCR Lite: "paddle_det" / "paddle_rec" / "paddle_cls" / "paddle_dict"
    val displayName: String,
    val fileName: String,
    val url: String,         // فارغ = لا يوجد رابط تنزيل رسمي معروف؛ يحتاج المستخدم يوفّر رابط بديل
    val approxSizeMB: Int,
    val sha256: String? = null,
    // حد أدنى لحجم الملف (بايت) لاعتباره "محمّلاً بنجاح" — منخفض لملفات PaddleOCR الصغيرة
    // نسبياً (القاموس نص عادي بضع كيلوبايت فقط، cls.nb صغير أيضاً) بدل الحد الافتراضي
    // 1MB المناسب فقط لنماذج AI Lite/Pro الكبيرة.
    val minValidBytes: Long = 1_000_000L
)

/** حالة تنزيل نموذج واحد — تطابق مواصفة "Download State Management". */
enum class DownloadState { NONE, DOWNLOADING, PAUSED, VERIFYING, COMPLETED, FAILED }

/** تحديث لحظي عن تقدّم/حالة تنزيل نموذج، يُرسَل عبر onUpdate في startDownload(). */
data class DownloadStatus(
    val modelId: String,
    val state: DownloadState,
    val progressPct: Int = 0,
    val message: String? = null
)

/**
 * يدير تنزيل/تخزين/التحقق من نماذج الطمس بالذكاء الاصطناعي (AI Lite / AI Pro) وملفات
 * PaddleOCR وتعزيز الصورة. الملفات تُخزَّن في: <external-files>/models/
 *
 * يدعم:
 * - **Resume Download**: لو توقف التنزيل (إغلاق التطبيق، انقطاع شبكة، Pause يدوي)، يُكمَل
 *   من آخر بايت مكتوب فعلياً في ملف .part عبر HTTP Range، بدل إعادة التنزيل من الصفر.
 *   لو رفض الخادم Range (رجع 200 كامل بدل 206 Partial Content)، يُكتشَف ذلك تلقائياً
 *   ويُعاد الكتابة من الصفر بأمان بدل ملف تالف بترقيع خاطئ.
 * - **Download State Management**: كل نموذج له حالة صريحة NONE/DOWNLOADING/PAUSED/
 *   VERIFYING/COMPLETED/FAILED عبر stateOf(modelId)، بدل الاعتماد فقط على وجود/عدم وجود
 *   الملف على القرص.
 * - **منع التنزيل المكرر**: startDownload() لنموذج قيد التنزيل فعلاً لا يبدأ نسخة ثانية
 *   (activeJobs)، وحتى مع سباق نادر، قفل Mutex مستقل لكل معرّف نموذج يمنع كتابتين متزامنتين
 *   لنفس الملف.
 * - **التحقق من سلامة الملف**: بعد اكتمال الكتابة الكاملة (وليس أثناءها — حتى يعمل بشكل
 *   صحيح مع الاستئناف الجزئي)، يُتحقَّق من الحجم الأدنى، ثم SHA256 إن كان معروفاً.
 *
 * مصدر AI Pro (ONNX): Carve/LaMa-ONNX على Hugging Face (lama_fp32.onnx) — نموذج LaMa
 * الأصلي محوّل لـ ONNX، مرخّص Apache-2.0، حجمه ~208MB، مُدخلاته: image float32[1,3,512,512]
 * (RGB مقسومة على 255) + mask float32[1,1,512,512] (1=امسح، 0=أبقِ)، ومُخرجه صورة RGB
 * [0..255] جاهزة مباشرة بنفس المقاس. هذا معروف وموثّق من صفحة النموذج، وتم التحقق منه.
 *
 * مصدر AI Lite (TFLite): لا يوجد حالياً رابط تنزيل مباشر عام موثوق لنموذج LaMa بصيغة
 * .tflite بدون تسجيل دخول (نسخة Qualcomm AI Hub تتطلب حساب). لذلك رابطها فارغ افتراضياً؛
 * المستخدم يقدر يضيف رابط .tflite خاص به (مُصدَّر بنفس فكرة LaMa: مُدخل صورة + قناع، مُخرج
 * صورة) عبر setCustomUrl، وستُستخدم تلقائياً بمجرد توفرها.
 */
class ModelManager(private val context: Context) {

    private val TAG = "ModelManager"
    private val client = OkHttpClient.Builder().build()

    private val modelsDir: File by lazy {
        File(context.getExternalFilesDir(null), "models").apply { mkdirs() }
    }

    // ملفات PaddleOCR Lite (det/rec/cls/dict) تُخزَّن في مجلد فرعي مستقل حتى نستطيع تمرير
    // مساره كاملاً لمكتبة paddleocr4android عبر OcrConfig.modelPath (المكتبة تفهم أي مسار
    // يبدأ بـ "/" كمسار مباشر على تخزين الجهاز بدل مجلد assets داخل الحزمة — موثّق في
    // doc/paddlelite.md الخاص بالمكتبة). راجع OCREngine.recognizePaddleLite لتفاصيل الاستخدام.
    val paddleModelsDir: File by lazy {
        File(modelsDir, "paddle").apply { mkdirs() }
    }

    // روابط قابلة للتعديل من المستخدم (تُخزَّن في SharedPreferences) — تسمح بإضافة نموذج
    // TFLite بديل لـ AI Lite لو ما توفر رابط رسمي، أو استبدال رابط AI Pro لو تغيّر.
    private val prefs by lazy { context.getSharedPreferences("model_urls", Context.MODE_PRIVATE) }

    val availableModels: List<ModelInfo>
        get() = listOf(
            ModelInfo(
                id = "ai_pro",
                displayName = "AI Pro (ONNX — LaMa)",
                fileName = "lama-pro.onnx",
                url = prefs.getString("url_ai_pro", DEFAULT_ONNX_URL) ?: DEFAULT_ONNX_URL,
                approxSizeMB = 208,
                sha256 = "1faef5301d78db7dda502fe59966957ec4b79dd64e16f03ed96913c7a4eb68d6"
            ),
            ModelInfo(
                id = "ai_lite",
                displayName = "AI Lite (TFLite)",
                fileName = "lama-lite.tflite",
                url = prefs.getString("url_ai_lite", "") ?: "",
                approxSizeMB = 45
            ),
            ModelInfo(
                id = "paddle_det",
                displayName = "PaddleOCR — DET (كشف النص)",
                fileName = "det.nb",
                url = prefs.getString("url_paddle_det", DEFAULT_PADDLE_DET_URL) ?: DEFAULT_PADDLE_DET_URL,
                approxSizeMB = 3,
                minValidBytes = 50_000L
            ),
            ModelInfo(
                id = "paddle_rec",
                displayName = "PaddleOCR — REC (التعرف على النص)",
                fileName = "rec.nb",
                url = prefs.getString("url_paddle_rec", DEFAULT_PADDLE_REC_URL) ?: DEFAULT_PADDLE_REC_URL,
                approxSizeMB = 10,
                minValidBytes = 50_000L
            ),
            ModelInfo(
                id = "paddle_cls",
                displayName = "PaddleOCR — CLS (اتجاه النص)",
                fileName = "cls.nb",
                url = prefs.getString("url_paddle_cls", DEFAULT_PADDLE_CLS_URL) ?: DEFAULT_PADDLE_CLS_URL,
                approxSizeMB = 1,
                minValidBytes = 10_000L
            ),
            ModelInfo(
                id = "paddle_dict",
                displayName = "PaddleOCR — قاموس الرموز (dict)",
                fileName = "ppocr_keys_v1.txt",
                url = prefs.getString("url_paddle_dict", DEFAULT_PADDLE_DICT_URL) ?: DEFAULT_PADDLE_DICT_URL,
                approxSizeMB = 1,
                minValidBytes = 1_000L
            ),
            ModelInfo(
                id = "enhance_ai",
                displayName = "تعزيز الصورة AI (Real-ESRGAN x2)",
                fileName = "realesrgan-x2.tflite",
                url = prefs.getString("url_enhance_ai", "") ?: "",
                approxSizeMB = 6,
                minValidBytes = 500_000L
            )
        )

    fun setCustomUrl(modelId: String, url: String) {
        prefs.edit().putString("url_$modelId", url).apply()
    }

    fun modelFile(model: ModelInfo): File =
        if (model.id.startsWith("paddle_")) File(paddleModelsDir, model.fileName)
        else File(modelsDir, model.fileName)

    private fun partFile(model: ModelInfo): File =
        File(modelFile(model).parentFile, model.fileName + ".part")

    fun isDownloaded(model: ModelInfo): Boolean {
        val f = modelFile(model)
        return f.exists() && f.length() >= model.minValidBytes // أصغر من الحد = غالباً تنزيل ناقص/فاشل
    }

    fun delete(model: ModelInfo): Boolean {
        partFile(model).delete()
        return modelFile(model).delete()
    }

    // ============== إدارة حالة التنزيل: Resume / Pause / منع التكرار ==============

    // نطاق تعاوني خاص بالمنزّل، مستقل عن lifecycleScope الخاص بالـActivity — بهذا نقدر
    // نلغي/نوقف تنزيلاً معيّناً بمعرّفه دون التأثير على أي عملية أخرى، وبدون أن يُقتَل
    // التنزيل تلقائياً لمجرد إعادة إنشاء الواجهة. يُحرَّر عبر release() من AppInterface.
    private val downloadScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val activeJobs = ConcurrentHashMap<String, Job>()
    private val states = ConcurrentHashMap<String, DownloadState>()
    private val locks = ConcurrentHashMap<String, Mutex>()

    private fun lockFor(id: String): Mutex = locks.getOrPut(id) { Mutex() }

    fun stateOf(modelId: String): DownloadState = states[modelId] ?: DownloadState.NONE
    fun isDownloading(modelId: String): Boolean = activeJobs[modelId]?.isActive == true

    /**
     * يبدأ تنزيل نموذج، أو يستأنفه تلقائياً لو وجد ملف .part من محاولة سابقة متوقفة.
     * لو نفس النموذج قيد التنزيل فعلاً، لا يبدأ نسخة ثانية بصمت — يمنع تشغيل أكثر من
     * Download Task واحد لنفس النموذج بالتوازي.
     */
    fun startDownload(model: ModelInfo, onUpdate: (DownloadStatus) -> Unit) {
        if (isDownloading(model.id)) return
        val job = downloadScope.launch {
            lockFor(model.id).withLock { doDownload(model, onUpdate) }
        }
        activeJobs[model.id] = job
        job.invokeOnCompletion { activeJobs.remove(model.id) }
    }

    /** يوقف التنزيل مؤقتاً مع الحفاظ على الملف الجزئي (.part) — يُستأنف لاحقاً من نفس النقطة. */
    fun pauseDownload(modelId: String) {
        states[modelId] = DownloadState.PAUSED
        activeJobs[modelId]?.cancel()
    }

    /** يلغي التنزيل نهائياً ويحذف الملف الجزئي — بعكس pauseDownload لا يمكن استئنافه. */
    fun cancelDownload(modelId: String) {
        val job = activeJobs[modelId]
        val model = availableModels.find { it.id == modelId }
        downloadScope.launch {
            job?.cancelAndJoin() // ننتظر توقف الكتابة الفعلي قبل حذف الملف لتفادي تعارض I/O
            model?.let { partFile(it).delete() }
            states[modelId] = DownloadState.NONE
        }
    }

    /** يُستدعى عند إغلاق التطبيق/الشاشة — يلغي كل التنزيلات الجارية بدون حذف الملفات الجزئية. */
    fun release() {
        downloadScope.cancel()
    }

    private suspend fun doDownload(model: ModelInfo, onUpdate: (DownloadStatus) -> Unit) {
        if (model.url.isBlank()) {
            states[model.id] = DownloadState.FAILED
            onUpdate(DownloadStatus(model.id, DownloadState.FAILED, 0, "لا يوجد رابط تنزيل لهذا النموذج — أضف رابطاً مخصصاً أولاً"))
            return
        }
        if (isDownloaded(model)) {
            states[model.id] = DownloadState.COMPLETED
            onUpdate(DownloadStatus(model.id, DownloadState.COMPLETED, 100, "محمّل مسبقاً"))
            return
        }

        val tmp = partFile(model)
        val resumeOffset = if (tmp.exists()) tmp.length() else 0L
        states[model.id] = DownloadState.DOWNLOADING
        onUpdate(
            DownloadStatus(
                model.id, DownloadState.DOWNLOADING,
                if (resumeOffset > 0) 1 else 0,
                if (resumeOffset > 0) "استئناف التنزيل من ${resumeOffset / 1024}KB..." else null
            )
        )

        try {
            val reqBuilder = Request.Builder().url(model.url)
            if (resumeOffset > 0) reqBuilder.addHeader("Range", "bytes=$resumeOffset-")

            client.newCall(reqBuilder.build()).execute().use { resp ->
                if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
                val isPartial = resp.code == 206
                // لو طلبنا Range لكن الخادم رجّع 200 كامل (لا يدعم Range)، لازم نكتب من
                // الصفر بدل إلحاق المحتوى الكامل فوق بيانات قديمة (ينتج ملف تالف مضاعَف).
                val append = resumeOffset > 0 && isPartial
                val startAt = if (append) resumeOffset else 0L
                val body = resp.body ?: throw IOException("استجابة فارغة")
                val newBytes = body.contentLength()
                val total = if (newBytes > 0) startAt + newBytes else -1L

                body.byteStream().use { input ->
                    FileOutputStream(tmp, append).use { output ->
                        val buffer = ByteArray(64 * 1024)
                        var downloaded = startAt
                        var lastReportedPct = -1
                        while (true) {
                            if (!currentCoroutineContext().isActive) return // Pause: نخرج بأمان، .part محفوظ كما هو
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            downloaded += read
                            if (total > 0) {
                                val pct = ((downloaded * 100) / total).toInt().coerceIn(0, 99)
                                if (pct != lastReportedPct) {
                                    lastReportedPct = pct
                                    onUpdate(DownloadStatus(model.id, DownloadState.DOWNLOADING, pct))
                                }
                            }
                        }
                    }
                }
            }

            // التحقق من السلامة بعد اكتمال الكتابة كاملة (وليس تدريجياً أثناء التنزيل) —
            // هذا يدعم الاستئناف الجزئي بشكل صحيح: حساب SHA256 تدريجياً أثناء التنزيل كان
            // سيُنتِج هاشاً خاطئاً لو جزء من الملف أتى من محاولة سابقة قبل الاستئناف.
            states[model.id] = DownloadState.VERIFYING
            onUpdate(DownloadStatus(model.id, DownloadState.VERIFYING, 100, "جارٍ التحقق من سلامة الملف..."))

            if (tmp.length() < model.minValidBytes) {
                tmp.delete()
                states[model.id] = DownloadState.FAILED
                onUpdate(DownloadStatus(model.id, DownloadState.FAILED, 0, "الملف الناتج أصغر من المتوقع — قد يكون تالفاً، أُعيد التنزيل مطلوب"))
                return
            }
            if (model.sha256 != null) {
                val digest = MessageDigest.getInstance("SHA-256")
                tmp.inputStream().use { ins ->
                    val buf = ByteArray(128 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n == -1) break
                        digest.update(buf, 0, n)
                    }
                }
                val hex = digest.digest().joinToString("") { "%02x".format(it) }
                if (!hex.equals(model.sha256, ignoreCase = true)) {
                    tmp.delete()
                    states[model.id] = DownloadState.FAILED
                    onUpdate(DownloadStatus(model.id, DownloadState.FAILED, 0, "فشل التحقق من سلامة الملف (checksum) — أُعيد التنزيل مطلوب"))
                    return
                }
            }

            val finalFile = modelFile(model)
            finalFile.delete()
            if (!tmp.renameTo(finalFile)) {
                states[model.id] = DownloadState.FAILED
                onUpdate(DownloadStatus(model.id, DownloadState.FAILED, 0, "فشل حفظ النموذج على التخزين"))
                return
            }
            states[model.id] = DownloadState.COMPLETED
            onUpdate(DownloadStatus(model.id, DownloadState.COMPLETED, 100, "تم تنزيل ${model.displayName} بنجاح"))
        } catch (e: CancellationException) {
            // إلغاء تعاوني (Pause أو Cancel) — الحالة مضبوطة مسبقاً من pauseDownload/
            // cancelDownload، فلا نُعيد كتابتها هنا بحالة خاطئة (مثل FAILED).
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Model download failed: ${model.id}", e)
            states[model.id] = DownloadState.FAILED
            onUpdate(DownloadStatus(model.id, DownloadState.FAILED, 0, e.message ?: "فشل التنزيل"))
        }
    }

    companion object {
        private const val DEFAULT_ONNX_URL =
            "https://huggingface.co/Carve/LaMa-ONNX/resolve/main/lama_fp32.onnx"

        // ملف القاموس نص عادي (UTF-8) بدون أي تبعية لإصدار Paddle-Lite، لذلك آمن وضع رابط
        // افتراضي رسمي مباشر له من مستودع PaddleOCR (بعكس ملفات .nb الثنائية التي يعتمد
        // نجاح تحميلها على توافق إصدار opset/runtime — انظر التعليق أعلى paddle_det).
        private const val DEFAULT_PADDLE_DICT_URL =
            "https://raw.githubusercontent.com/PaddlePaddle/PaddleOCR/main/ppocr/utils/ppocr_keys_v1.txt"

        // مصدر ملفات det.nb/rec.nb/cls.nb — راجع الملاحظة الطويلة أعلى ModelInfo الخاصة
        // بـpaddle_det لتفاصيل سبب اختيار هذا المصدر بالذات (توافق نسخة Paddle-Lite).
        private const val PADDLE4ANDROID_DEMO_MODELS_BASE =
            "https://raw.githubusercontent.com/equationl/paddleocr4android/master/app/src/main/assets/models/ch_PP-OCRv4"
        private const val DEFAULT_PADDLE_DET_URL = "$PADDLE4ANDROID_DEMO_MODELS_BASE/det.nb"
        private const val DEFAULT_PADDLE_REC_URL = "$PADDLE4ANDROID_DEMO_MODELS_BASE/rec.nb"
        private const val DEFAULT_PADDLE_CLS_URL = "$PADDLE4ANDROID_DEMO_MODELS_BASE/cls.nb"
    }
}
