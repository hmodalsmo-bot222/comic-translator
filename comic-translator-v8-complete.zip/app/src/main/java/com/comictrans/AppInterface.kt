package com.comictrans

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.lifecycle.lifecycleScope
import com.comictrans.engine.OCREngine
import com.comictrans.engine.TranslationEngine
import com.comictrans.engine.ErasureEngine
import com.comictrans.engine.ImageEnhanceEngine
import com.comictrans.db.AppDatabase
import com.comictrans.model.BlockData
import com.comictrans.model.SettingsData
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import kotlin.coroutines.resume

class AppInterface(
    private val context: Context,
    private val webView: WebView
) {

    private val gson = Gson()
    @Volatile
    private var isProcessing = false
    @Volatile
    private var shouldStop = false

    private val ocrEngine = OCREngine(context)
    private val translateEngine = TranslationEngine(context)
    private val erasureEngine = ErasureEngine(context)
    private val imageEnhanceEngine = ImageEnhanceEngine(context)
    private val db = AppDatabase.getInstance(context)

    @JavascriptInterface
    fun startProcessing(pageIndex: Int, settingsJson: String) {
        if (isProcessing) return
        isProcessing = true
        shouldStop = false

        val settings = gson.fromJson(settingsJson, SettingsData::class.java)
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            processPage(pageIndex, settings)
        }
    }

    @JavascriptInterface
    fun stopProcessing() {
        shouldStop = true
        isProcessing = false
    }

    @JavascriptInterface
    fun logFromJS(message: String) {
        Log.d("ComicJS", message)
    }

    private suspend fun processPage(pageIndex: Int, settings: SettingsData) {
        try {
            // 1. OCR
            sendStatus(pageIndex, "ocr", 0)
            val imageBase64 = requestImageFromJS(pageIndex) ?: run {
                sendError(pageIndex, "No image data")
                isProcessing = false
                return
            }

            val bitmap = MainActivity.base64ToBitmap(imageBase64) ?: run {
                sendError(pageIndex, "Invalid image")
                isProcessing = false
                return
            }

            // Auto-detect language if set to "auto"
            val detectedLang = if (settings.sourceLang == "auto") {
                "en" // Will be updated after OCR
            } else settings.sourceLang

            // Enhance image
            val enhanceResult = if (settings.enhanceImage) {
                sendStatus(pageIndex, "enhance", 0)
                val r = imageEnhanceEngine.enhance(bitmap, settings.enhanceMethod)
                sendStatus(pageIndex, "enhance", 100)
                r
            } else null
            val ocrBitmap = enhanceResult?.bitmap ?: bitmap
            val enhanceScale = enhanceResult?.scale ?: 1f

            val rawBlocks = when (settings.ocrEngine) {
                "mlkit" -> ocrEngine.recognizeMLKit(ocrBitmap)
                "tesseract" -> ocrEngine.recognizeTesseract(ocrBitmap)
                "ocrspace" -> ocrEngine.recognizeOCRSpace(ocrBitmap, settings.ocrSpaceKey)
                "cloud" -> ocrEngine.recognizeCloud(ocrBitmap, settings.cloudApiUrl)
                else -> ocrEngine.recognizeMLKit(ocrBitmap)
            }

            // Auto-detect from first block if needed
            val actualSourceLang = if (settings.sourceLang == "auto" && rawBlocks.isNotEmpty()) {
                val detected = translateEngine.detectLanguage(rawBlocks.first().text)
                Log.d("ComicApp", "Auto-detected language: $detected")
                detected
            } else settings.sourceLang

            val blocks = if (enhanceScale != 1f) {
                rawBlocks.map {
                    it.copy(
                        x = (it.x / enhanceScale).toInt(),
                        y = (it.y / enhanceScale).toInt(),
                        width = (it.width / enhanceScale).toInt(),
                        height = (it.height / enhanceScale).toInt()
                    )
                }
            } else rawBlocks

            if (shouldStop) { sendStopped(pageIndex); isProcessing = false; return }
            sendStatus(pageIndex, "ocr", 100)

            // 2. Translation with auto-detect
            sendStatus(pageIndex, "translate", 0)
            val translatedBlocks = blocks.mapIndexed { idx, block ->
                if (shouldStop) return@mapIndexed block

                // Check memory first
                val memoryResult = if (settings.useMemory) {
                    db.translationDao().findExact(block.text.trim())
                } else null

                val translated = if (memoryResult != null) {
                    memoryResult.translatedText
                } else {
                    when (settings.translateEngine) {
                        "mlkit" -> translateEngine.translateMLKit(block.text, actualSourceLang, settings.targetLang)
                        "google" -> translateEngine.translateGoogle(block.text, actualSourceLang, settings.targetLang)
                        "gemini" -> translateEngine.translateGemini(block.text, actualSourceLang, settings.targetLang, settings.geminiKey, settings.geminiModel)
                        "openai" -> translateEngine.translateOpenAI(block.text, actualSourceLang, settings.targetLang, settings.openaiKey, settings.openaiModel)
                        "deepl" -> translateEngine.translateDeepL(block.text, actualSourceLang, settings.targetLang, settings.deeplKey)
                        else -> translateEngine.translateGoogle(block.text, actualSourceLang, settings.targetLang)
                    }
                }

                // Save to memory
                if (settings.useMemory && memoryResult == null && translated.isNotBlank()) {
                    db.translationDao().insert(
                        com.comictrans.db.TranslationEntity(
                            sourceText = block.text.trim(),
                            translatedText = translated.trim(),
                            sourceLang = actualSourceLang,
                            targetLang = settings.targetLang
                        )
                    )
                }

                sendStatus(pageIndex, "translate", ((idx + 1) * 100 / blocks.size.coerceAtLeast(1)))
                block.copy(translatedText = translated)
            }

            if (shouldStop) { sendStopped(pageIndex); isProcessing = false; return }

            // 3. Erasure
            sendStatus(pageIndex, "erasure", 0)
            val erasureData = when (settings.erasureMode) {
                "fill", "blur" -> {
                    translatedBlocks.map { block ->
                        JSONObject().apply {
                            put("x", block.x)
                            put("y", block.y)
                            put("width", block.width)
                            put("height", block.height)
                            put("translatedText", block.translatedText ?: "")
                            put("mode", settings.erasureMode)
                            put("type", "block_coords")
                        }
                    }
                }
                "opencv", "lama", "aotgan" -> {
                    val result = erasureEngine.processBlocks(bitmap, translatedBlocks, settings.erasureMode)
                    val textData = JSONArray().apply {
                        translatedBlocks.forEach { block ->
                            put(JSONObject().apply {
                                put("x", block.x)
                                put("y", block.y)
                                put("width", block.width)
                                put("height", block.height)
                                put("translatedText", block.translatedText ?: "")
                            })
                        }
                    }
                    listOf(JSONObject().apply {
                        put("type", "full_page")
                        put("imageBase64", result.firstOrNull()?.optString("imageBase64", "") ?: "")
                        put("textBlocks", textData)
                        put("mode", settings.erasureMode)
                    })
                }
                else -> emptyList()
            }
            sendStatus(pageIndex, "erasure", 100)

            // 4. Send result
            val blocksArray = JSONArray()
            translatedBlocks.forEach { block ->
                blocksArray.put(JSONObject().apply {
                    put("text", block.text)
                    put("translatedText", block.translatedText ?: "")
                    put("x", block.x)
                    put("y", block.y)
                    put("width", block.width)
                    put("height", block.height)
                    put("confidence", block.confidence)
                    put("angle", block.angle)
                })
            }

            val result = JSONObject().apply {
                put("pageIndex", pageIndex)
                put("blocks", blocksArray)
                put("erasureData", JSONArray(erasureData))
                put("settings", JSONObject(gson.toJson(settings)))
                put("detectedLang", actualSourceLang)
            }

            sendToWebView("onPageReady", result.toString())
            isProcessing = false

        } catch (e: Exception) {
            Log.e("ComicApp", "Process error", e)
            sendError(pageIndex, e.message ?: "Unknown error")
            isProcessing = false
        }
    }

    private suspend fun requestImageFromJS(pageIndex: Int): String? = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine { continuation ->
            webView.evaluateJavascript(
                "window.getPageImageBase64($pageIndex)",
                android.webkit.ValueCallback { value ->
                    val result = value?.removeSurrounding(""")?.replace("\\"", """)
                    continuation.resume(result)
                }
            )
        }
    }

    private fun sendStatus(pageIndex: Int, stage: String, progress: Int) {
        val json = JSONObject().apply {
            put("pageIndex", pageIndex)
            put("stage", stage)
            put("progress", progress)
        }
        sendToWebView("onStatusUpdate", json.toString())
    }

    private fun sendError(pageIndex: Int, message: String) {
        val json = JSONObject().apply {
            put("pageIndex", pageIndex)
            put("error", message)
        }
        sendToWebView("onError", json.toString())
    }

    private fun sendWarning(pageIndex: Int, message: String) {
        val json = JSONObject().apply {
            put("pageIndex", pageIndex)
            put("warning", message)
        }
        sendToWebView("onWarning", json.toString())
    }

    private fun sendStopped(pageIndex: Int) {
        val json = JSONObject().apply {
            put("pageIndex", pageIndex)
            put("stopped", true)
        }
        sendToWebView("onStopped", json.toString())
    }

    private fun sendToWebView(functionName: String, data: String) {
        (context as MainActivity).runOnUiThread {
            val safeData = JSONObject.quote(data)
            webView.evaluateJavascript("window.$functionName($safeData)", null)
        }
    }
}
