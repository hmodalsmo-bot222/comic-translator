package com.comictrans

import android.content.Context
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.net.Uri
import java.io.File
import java.io.FileInputStream
import java.util.zip.ZipInputStream
import java.util.Locale
import androidx.lifecycle.lifecycleScope
import com.comictrans.engine.OCREngine
import com.comictrans.engine.TranslationEngine
import com.comictrans.engine.ErasureEngine
import com.comictrans.engine.ImageEnhanceEngine
import com.comictrans.engine.SyncEngine
import com.comictrans.db.AppDatabase
import com.comictrans.db.TranslationEntity
import com.comictrans.model.BlockData
import com.comictrans.model.SettingsData
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class AppInterface(
    private val context: Context,
    private val webView: WebView
) {

    private val gson = Gson()
    private var isProcessing = false
    private var shouldStop = false
    private var nativePageFiles: List<File> = emptyList()
    private var nativeComicTitle: String = ""
    private val processedPageRoot: File by lazy { File(context.cacheDir, "processed_pages") }

    private val ocrEngine = OCREngine(context)
    private val translateEngine = TranslationEngine(context)
    private val modelManager = com.comictrans.engine.ModelManager(context)
    private val erasureEngine = ErasureEngine(context, modelManager)
    private val imageEnhanceEngine = ImageEnhanceEngine(context)
    private val syncEngine = SyncEngine()
    private val db = AppDatabase.getInstance(context)

    // ================= إدارة نماذج AI Lite / AI Pro =================

    @JavascriptInterface
    fun listModels() {
        val arr = JSONArray()
        modelManager.availableModels.forEach { m ->
            arr.put(JSONObject().apply {
                put("id", m.id)
                put("displayName", m.displayName)
                put("approxSizeMB", m.approxSizeMB)
                put("hasUrl", m.url.isNotBlank())
                put("downloaded", modelManager.isDownloaded(m))
            })
        }
        sendToWebView("onModelList", arr.toString())
    }

    @JavascriptInterface
    fun downloadModel(modelId: String) {
        val model = modelManager.availableModels.find { it.id == modelId } ?: run {
            sendModelStatus(modelId, false, "نموذج غير معروف")
            return
        }
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            val result = modelManager.download(model) { pct ->
                sendModelProgress(modelId, pct)
            }
            result.fold(
                onSuccess = { sendModelStatus(modelId, true, "تم تنزيل ${model.displayName} بنجاح") },
                onFailure = { err -> sendModelStatus(modelId, false, err.message ?: "فشل التنزيل") }
            )
        }
    }

    @JavascriptInterface
    fun deleteModel(modelId: String) {
        val model = modelManager.availableModels.find { it.id == modelId } ?: return
        modelManager.delete(model)
        sendModelStatus(modelId, true, "تم حذف ${model.displayName}")
    }

    @JavascriptInterface
    fun setModelUrl(modelId: String, url: String) {
        modelManager.setCustomUrl(modelId, url)
        listModels()
    }

    private fun sendModelProgress(modelId: String, pct: Int) {
        val json = JSONObject().apply { put("id", modelId); put("progress", pct) }
        sendToWebView("onModelProgress", json.toString())
    }

    private fun sendModelStatus(modelId: String, success: Boolean, message: String) {
        val json = JSONObject().apply {
            put("id", modelId); put("success", success); put("message", message)
        }
        sendToWebView("onModelStatus", json.toString())
    }

    // Performance architecture: CBZ pages are extracted once by Kotlin and served from
    // the local comic.local URL. startProcessing receives only the page index + settings;
    // the page Bitmap is decoded directly from the native cache.
    @JavascriptInterface
    fun isNativeFileImportEnabled(): Boolean = true

    /** Native CBZ/ZIP reader. JavaScript only renders the pages; it never unpacks the archive. */
    fun loadComicFromUri(uri: Uri, displayName: String) {
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            try {
                val root = File(context.cacheDir, "comic_pages")
                root.deleteRecursively()
                root.mkdirs()
                processedPageRoot.deleteRecursively()
                processedPageRoot.mkdirs()
                val extracted = ArrayList<Pair<String, File>>()
                var totalBytes = 0L
                context.contentResolver.openInputStream(uri)?.use { input ->
                    ZipInputStream(input.buffered(128 * 1024)).use { zip ->
                        var entry = zip.nextEntry
                        while (entry != null) {
                            if (!entry.isDirectory && isImageEntry(entry.name)) {
                                val safeName = "page_${extracted.size.toString().padStart(6, '0')}_${safeExtension(entry.name)}"
                                val outFile = File(root, safeName)
                                var written = 0L
                                outFile.outputStream().buffered(128 * 1024).use { out ->
                                    val buffer = ByteArray(128 * 1024)
                                    while (true) {
                                        val n = zip.read(buffer)
                                        if (n <= 0) break
                                        written += n
                                        totalBytes += n
                                        if (totalBytes > 512L * 1024L * 1024L) throw IllegalStateException("CBZ كبير جداً (الحد 512MB)")
                                        out.write(buffer, 0, n)
                                    }
                                }
                                if (written > 0) extracted.add(entry.name to outFile)
                            }
                            zip.closeEntry()
                            entry = zip.nextEntry
                        }
                    }
                } ?: throw IllegalStateException("تعذرت قراءة ملف CBZ")

                val sorted = extracted.sortedWith { p1, p2 -> compareByNatural(p1.first, p2.first) }
                nativePageFiles = sorted.map { it.second }
                nativeComicTitle = displayName
                if (nativePageFiles.isEmpty()) throw IllegalStateException("لم يتم العثور على صور داخل CBZ")

                val json = JSONObject().apply {
                    put("title", nativeComicTitle)
                    put("count", nativePageFiles.size)
                    put("baseUrl", "https://comic.local/page/")
                }
                sendToWebView("onNativeComicLoaded", json.toString())
            } catch (e: Exception) {
                Log.e("ComicApp", "Native CBZ error", e)
                sendError(-1, e.message ?: "فشل فتح CBZ")
            }
        }
    }

    private fun isImageEntry(name: String): Boolean =
        !name.contains("__MACOSX", ignoreCase = true) &&
            name.substringAfterLast('/').matches(Regex("(?i).+\\.(jpg|jpeg|png|webp|gif|bmp)$"))

    private fun safeExtension(name: String): String {
        val ext = name.substringAfterLast('.', "jpg").lowercase(Locale.ROOT)
        return if (ext in setOf("jpg", "jpeg", "png", "webp", "gif", "bmp")) ext else "jpg"
    }

    private fun compareByNatural(a: String, b: String): Int {
        val pattern = Regex("\\d+")
        val at = pattern.findAll(a).toList()
        val bt = pattern.findAll(b).toList()
        var posA = 0
        var posB = 0
        val parts = maxOf(at.size, bt.size)
        for (i in 0 until parts) {
            val aNum = at.getOrNull(i)?.value?.toLongOrNull()
            val bNum = bt.getOrNull(i)?.value?.toLongOrNull()
            if (aNum != null && bNum != null && aNum != bNum) return aNum.compareTo(bNum)
            val aText = if (i < at.size) a.substring(posA, at[i].range.first) else a.substring(posA)
            val bText = if (i < bt.size) b.substring(posB, bt[i].range.first) else b.substring(posB)
            val textCmp = aText.compareTo(bText, ignoreCase = true)
            if (textCmp != 0) return textCmp
            if (i < at.size) posA = at[i].range.last + 1
            if (i < bt.size) posB = bt[i].range.last + 1
        }
        return a.substring(posA).compareTo(b.substring(posB), ignoreCase = true)
    }

    fun getNativePageFile(index: Int): File? = nativePageFiles.getOrNull(index)

    fun getProcessedPageFile(index: Int): File? {
        val file = File(processedPageRoot, "page_${index}.jpg")
        return file.takeIf { it.exists() && it.isFile && it.length() > 0L }
    }

    @JavascriptInterface
    fun startProcessing(pageIndex: Int, settingsJson: String) {
        if (isProcessing) return
        isProcessing = true
        shouldStop = false
        val settings = gson.fromJson(settingsJson, SettingsData::class.java)
        val file = nativePageFiles.getOrNull(pageIndex)
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            if (file == null || !file.exists()) {
                sendError(pageIndex, "صورة الصفحة غير متوفرة")
                isProcessing = false
                return@launch
            }
            processPage(pageIndex, file, settings)
        }
    }

    @JavascriptInterface
    fun stopProcessing() {
        shouldStop = true
        isProcessing = false
    }

    @JavascriptInterface
    fun logFromJS(message: String) {
        Log.d("ComicJS", message)
    }

    // ================= خلفية المجتمع (مزامنة ذاكرة الترجمة) =================

    @JavascriptInterface
    fun pushMemorySync(backend: String, config: String) {
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            try {
                if (backend == "local") {
                    val entries = db.translationDao().getAll()
                    val json = gson.toJson(entries)
                    withContext(Dispatchers.Main) {
                        (context as MainActivity).exportJsonToFile(json, "comictrans_memory.json")
                    }
                    return@launch
                }
                val entries = db.translationDao().getAll()
                val json = gson.toJson(entries)
                val result = syncEngine.push(backend, config, json)
                result.fold(
                    onSuccess = { msg -> sendSyncResult(true, msg) },
                    onFailure = { err -> sendSyncResult(false, err.message ?: "فشل غير معروف") }
                )
            } catch (e: Exception) {
                sendSyncResult(false, e.message ?: "فشل غير معروف")
            }
        }
    }

    @JavascriptInterface
    fun pullMemorySync(backend: String, config: String) {
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            try {
                if (backend == "local") {
                    withContext(Dispatchers.Main) { (context as MainActivity).importJsonFromFile() }
                    return@launch
                }
                val result = syncEngine.pull(backend, config)
                result.fold(
                    onSuccess = { json -> importEntriesAndReport(json) },
                    onFailure = { err -> sendSyncResult(false, err.message ?: "فشل غير معروف") }
                )
            } catch (e: Exception) {
                sendSyncResult(false, e.message ?: "فشل غير معروف")
            }
        }
    }

    // يُستدعى من MainActivity بعد نجاح/فشل تصدير أو استيراد ملف محلي (Local Sync، بدون إنترنت)
    fun onLocalSyncResult(success: Boolean, message: String, importedJson: String?) {
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            if (success && importedJson != null) {
                importEntriesAndReport(importedJson)
            } else {
                sendSyncResult(success, message)
            }
        }
    }

    private suspend fun importEntriesAndReport(json: String) {
        try {
            val type = object : TypeToken<List<TranslationEntity>>() {}.type
            val entries: List<TranslationEntity> = gson.fromJson(json, type) ?: emptyList()
            // نصفّر id عشان autoGenerate يعطي معرفات جديدة محلياً، ونعتمد على unique index
            // (sourceText+sourceLang+targetLang) لمنع التكرار بدل تصادم PK
            val cleaned = entries.map { it.copy(id = 0) }
            db.translationDao().insertAll(cleaned)
            sendSyncResult(true, "تم استيراد ${cleaned.size} عبارة إلى الذاكرة الذكية بنجاح")
        } catch (e: Exception) {
            sendSyncResult(false, "فشل تفسير البيانات المستوردة: ${e.message}")
        }
    }

    private fun sendSyncResult(success: Boolean, message: String) {
        val json = JSONObject().apply {
            put("success", success)
            put("message", message)
        }
        sendToWebView("onSyncResult", json.toString())
    }

    private suspend fun processPage(pageIndex: Int, imageFile: File, settings: SettingsData) {
        try {
            // 1. OCR
            sendStatus(pageIndex, "ocr", 0)
            val bitmap = android.graphics.BitmapFactory.decodeFile(imageFile.absolutePath) ?: run {
                sendError(pageIndex, "تعذر قراءة صورة الصفحة")
                return
            }

            // تعزيز الصورة قبل OCR (اختياري) — يُستخدم فقط لتحسين دقة القراءة، والصورة
            // الأصلية تبقى كما هي لخطوات الطمس والعرض لاحقاً.
            val enhanceResult = if (settings.enhanceImage) {
                sendStatus(pageIndex, "enhance", 0)
                val r = imageEnhanceEngine.enhance(bitmap, settings.enhanceMethod)
                sendStatus(pageIndex, "enhance", 100)
                r
            } else null
            val ocrBitmap = enhanceResult?.bitmap ?: bitmap
            val enhanceScale = enhanceResult?.scale ?: 1f

            val rawBlocks = when (settings.ocrEngine) {
                "paddle_lite" -> ocrEngine.recognizePaddleLite(ocrBitmap)
                "mlkit" -> ocrEngine.recognizeMLKit(ocrBitmap)
                "tesseract" -> ocrEngine.recognizeTesseract(ocrBitmap)
                "ocrspace" -> ocrEngine.recognizeOCRSpace(ocrBitmap, settings.ocrSpaceKey)
                "cloud" -> ocrEngine.recognizeCloud(ocrBitmap, settings.cloudApiUrl)
                else -> ocrEngine.recognizeMLKit(ocrBitmap)
            }
            // لو التعزيز كبّر أبعاد الصورة (وضع AI)، نرجّع إحداثيات الكتل لمقياس الصورة الأصلية
            val blocks = if (enhanceScale != 1f) {
                rawBlocks.map {
                    it.copy(
                        x = (it.x / enhanceScale).toInt(),
                        y = (it.y / enhanceScale).toInt(),
                        width = (it.width / enhanceScale).toInt(),
                        height = (it.height / enhanceScale).toInt()
                    )
                }
            } else rawBlocks

            if (shouldStop) { sendStopped(pageIndex); return }
            sendStatus(pageIndex, "ocr", 100)

            // 2. Translation
            // قبل التعديل: كل فقاعة نص كانت تُترجم بطلب شبكة منفصل (Google/Gemini/OpenAI/DeepL)
            // ضمن حلقة تسلسلية واحدة تلو الأخرى — لصفحة فيها 15-20 فقاعة، وكل طلب ياخذ ثانية
            // لعدة ثواني، الوقت الكلي كان يتراكم لدقيقة أو أكثر لكل صفحة. هذا هو التأخير الحقيقي
            // بخطوة الترجمة تحديداً. الحل: نشغّل الترجمات بالتوازي (بحد أقصى 5 بنفس الوقت عبر
            // Semaphore) بدل التسلسل الكامل — نفس عدد الطلبات لكن بوقت انتظار أقل بكثير.
            sendStatus(pageIndex, "translate", 0)
            val translateSemaphore = Semaphore(5)
            val completedCount = java.util.concurrent.atomic.AtomicInteger(0)
            val translatedBlocks = coroutineScope {
                blocks.map { block ->
                    async(Dispatchers.IO) {
                        if (shouldStop) return@async block

                        val memoryResult = if (settings.useMemory) {
                            db.translationDao().findExact(block.text.trim())
                        } else null

                        val translated = if (memoryResult != null) {
                            memoryResult.translatedText
                        } else {
                            translateSemaphore.withPermit {
                                when (settings.translateEngine) {
                                    "mlkit" -> translateEngine.translateMLKit(block.text, settings.sourceLang, settings.targetLang)
                                    "google" -> translateEngine.translateGoogle(block.text, settings.sourceLang, settings.targetLang)
                                    "gemini" -> translateEngine.translateGemini(block.text, settings.sourceLang, settings.targetLang, settings.geminiKey, settings.geminiModel)
                                    "openai" -> translateEngine.translateOpenAI(block.text, settings.sourceLang, settings.targetLang, settings.openaiKey, settings.openaiModel)
                                    "openrouter" -> translateEngine.translateOpenRouter(block.text, settings.sourceLang, settings.targetLang, settings.openrouterKey, settings.openrouterModel)
                                    "deepl" -> translateEngine.translateDeepL(block.text, settings.sourceLang, settings.targetLang, settings.deeplKey)
                                    else -> translateEngine.translateGoogle(block.text, settings.sourceLang, settings.targetLang)
                                }
                            }
                        }

                        if (settings.useMemory && memoryResult == null && translated.isNotBlank()) {
                            db.translationDao().insert(
                                com.comictrans.db.TranslationEntity(
                                    sourceText = block.text.trim(),
                                    translatedText = translated.trim(),
                                    sourceLang = settings.sourceLang,
                                    targetLang = settings.targetLang
                                )
                            )
                        }

                        val done = completedCount.incrementAndGet()
                        sendStatus(pageIndex, "translate", (done * 100 / blocks.size.coerceAtLeast(1)))
                        block.copy(translatedText = translated)
                    }
                }.map { it.await() }
            }

            if (shouldStop) { sendStopped(pageIndex); return }

            // 3. Erasure
            sendStatus(pageIndex, "erasure", 0)
            val erasureData = when (settings.erasureMode) {
                "fill", "blur" -> {
                    // HTML handles these simple modes
                    translatedBlocks.map { block ->
                        JSONObject().apply {
                            put("x", block.x)
                            put("y", block.y)
                            put("width", block.width)
                            put("height", block.height)
                            put("translatedText", block.translatedText)
                            put("mode", settings.erasureMode)
                            put("type", "block_coords")
                        }
                    }
                }
                "opencv", "ai_lite", "ai_pro" -> {
                    // Native processing returns a Bitmap. Store it in cache and expose only a
                    // local WebView URL, never a multi-megabyte Base64 string over the JS bridge.
                    val processed = erasureEngine.processBitmap(bitmap, translatedBlocks, settings.erasureMode)
                    val processedFile = File(processedPageRoot, "page_${pageIndex}.jpg")
                    if (processed != null) {
                        processedFile.outputStream().buffered(128 * 1024).use { out ->
                            if (!processed.compress(android.graphics.Bitmap.CompressFormat.JPEG, 92, out)) {
                                throw IllegalStateException("تعذر حفظ الصورة المعالجة")
                            }
                        }
                        processed.recycle()
                    }
                    val textData = translatedBlocks.map { block ->
                        JSONObject().apply {
                            put("x", block.x)
                            put("y", block.y)
                            put("width", block.width)
                            put("height", block.height)
                            put("translatedText", block.translatedText)
                        }
                    }
                    listOf(JSONObject().apply {
                        put("type", "full_page")
                        put("processedUrl", "https://comic.local/processed/$pageIndex?v=${System.currentTimeMillis()}")
                        put("textBlocks", JSONArray(textData))
                        put("mode", settings.erasureMode)
                    })
                }
                else -> emptyList()
            }
            sendStatus(pageIndex, "erasure", 100)

            // 4. Send result back to HTML
            val result = JSONObject().apply {
                put("pageIndex", pageIndex)
                put("blocks", JSONArray(translatedBlocks.map { gson.toJson(it) }))
                put("erasureData", JSONArray(erasureData))
                put("settings", gson.toJson(settings))
            }

            sendToWebView("onPageReady", result.toString())
            isProcessing = false

        } catch (e: Exception) {
            Log.e("ComicApp", "Process error", e)
            sendError(pageIndex, e.message ?: "Unknown error")
            isProcessing = false
        }
    }

    private fun sendStatus(pageIndex: Int, stage: String, progress: Int) {
        val json = JSONObject().apply {
            put("pageIndex", pageIndex)
            put("stage", stage)
            put("progress", progress)
        }
        sendToWebView("onStatusUpdate", json.toString())
    }

    private fun sendError(pageIndex: Int, message: String) {
        val json = JSONObject().apply {
            put("pageIndex", pageIndex)
            put("error", message)
        }
        sendToWebView("onError", json.toString())
    }

    private fun sendWarning(pageIndex: Int, message: String) {
        val json = JSONObject().apply {
            put("pageIndex", pageIndex)
            put("warning", message)
        }
        sendToWebView("onWarning", json.toString())
    }

    private fun sendStopped(pageIndex: Int) {
        val json = JSONObject().apply {
            put("pageIndex", pageIndex)
            put("stopped", true)
        }
        sendToWebView("onStopped", json.toString())
    }

    private fun sendToWebView(functionName: String, data: String) {
        (context as MainActivity).runOnUiThread {
            // JSONObject.quote() ينتج نص JS/JSON آمن (يهرب الاقتباسات والأسطر الجديدة وغيرها)
            // بدل تضمين data مباشرة داخل اقتباس أحادي، لتفادي انكسار الاستدعاء لو النص يحتوي على '
            val safeData = JSONObject.quote(data)
            webView.evaluateJavascript("window.$functionName($safeData)", null)
        }
    }
}
