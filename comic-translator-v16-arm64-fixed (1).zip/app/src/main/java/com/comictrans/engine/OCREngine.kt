package com.comictrans.engine

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.comictrans.model.BlockData
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.equationl.paddleocr4android.OCR
import com.equationl.paddleocr4android.OcrConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class OCREngine(private val context: Context) {

    private val paddleOcr = OCR(context)
    @Volatile private var paddleInitialized = false
    private val paddleLock = Any()

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    // 1. ML Kit (works fully)
    suspend fun recognizeMLKit(bitmap: Bitmap): List<BlockData> = withContext(Dispatchers.IO) {
        suspendCancellableCoroutine { continuation ->
            val image = InputImage.fromBitmap(bitmap, 0)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    val blocks = visionText.textBlocks.flatMap { block ->
                        block.lines.map { line ->
                            val rect = line.boundingBox
                            BlockData(
                                text = line.text,
                                x = rect?.left ?: 0,
                                y = rect?.top ?: 0,
                                width = rect?.width() ?: 100,
                                height = rect?.height() ?: 30,
                                confidence = line.confidence
                            )
                        }
                    }
                    continuation.resume(mergeIntoComicBlocks(blocks, bitmap.width, bitmap.height))
                    recognizer.close()
                }
                .addOnFailureListener { e ->
                    recognizer.close()
                    continuation.resumeWithException(e)
                }
        }
    }

    // 2. PaddleOCR Lite — on-device detection + angle classification + recognition.
    // The bundled library provides the Paddle-Lite runtime. Models are expected in:
    // assets/paddle/ (det.nb, rec.nb, cls.nb) and assets/paddle/ppocr_keys_v1.txt.
    suspend fun recognizePaddleLite(bitmap: Bitmap): List<BlockData> = withContext(Dispatchers.IO) {
        try {
            synchronized(paddleLock) {
                if (!paddleInitialized) {
                    val config = OcrConfig().apply {
                        modelPath = "paddle"
                        labelPath = "paddle/ppocr_keys_v1.txt"
                        detModelFilename = "det.nb"
                        recModelFilename = "rec.nb"
                        clsModelFilename = "cls.nb"
                        isRunDet = true
                        isRunCls = true
                        isRunRec = true
                        isDrwwTextPositionBox = false
                    }
                    paddleOcr.initModelSync(config).getOrThrow()
                    paddleInitialized = true
                }
            }

            val result = paddleOcr.runSync(bitmap).getOrThrow()
            val labels = paddleOcr.getWordLabels()
            result.outputRawResult.mapNotNull { raw ->
                val points = raw.points
                if (points == null || points.size < 4) return@mapNotNull null
                val xs = points.map { it.x }
                val ys = points.map { it.y }
                val left = xs.minOrNull()?.toInt() ?: return@mapNotNull null
                val top = ys.minOrNull()?.toInt() ?: return@mapNotNull null
                val right = xs.maxOrNull()?.toInt() ?: return@mapNotNull null
                val bottom = ys.maxOrNull()?.toInt() ?: return@mapNotNull null
                val text = raw.wordIndex.joinToString("") { labels.getOrNull(it) ?: "" }.trim()
                if (text.isBlank()) return@mapNotNull null
                BlockData(
                    text = text,
                    x = left.coerceIn(0, bitmap.width - 1),
                    y = top.coerceIn(0, bitmap.height - 1),
                    width = (right - left).coerceAtLeast(1).coerceAtMost(bitmap.width),
                    height = (bottom - top).coerceAtLeast(1).coerceAtMost(bitmap.height),
                    confidence = raw.confidence.toFloat(),
                    angle = if (raw.clsLabel == "180") 180f else 0f
                )
            }.let { mergeIntoComicBlocks(it, bitmap.width, bitmap.height) }
        } catch (e: Throwable) {
            Log.e("PaddleOCR", "PaddleOCR Lite failed; falling back to ML Kit", e)
            recognizeMLKit(bitmap)
        }
    }

    // 2. Tesseract (stub - requires integration with Tesseract4Android or similar)
    suspend fun recognizeTesseract(bitmap: Bitmap): List<BlockData> {
        // TODO: Integrate Tesseract4Android library
        // For now, fallback to ML Kit
        Log.w("OCR", "Tesseract not yet integrated, falling back to ML Kit")
        return recognizeMLKit(bitmap)
    }

    // 4. OCR.space (cloud)
    suspend fun recognizeOCRSpace(bitmap: Bitmap, apiKey: String): List<BlockData> = withContext(Dispatchers.IO) {
        try {
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream)
            val byteArray = stream.toByteArray()

            val requestBody = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("apikey", apiKey)
                .addFormDataPart("isOverlayRequired", "true")
                .addFormDataPart("OCREngine", "2")
                .addFormDataPart("filetype", "jpg")
                .addFormDataPart(
                    "file", "image.jpg",
                    byteArray.toRequestBody("image/jpeg".toMediaType())
                )
                .build()

            val request = Request.Builder()
                .url("https://api.ocr.space/parse/image")
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return@withContext emptyList()
            val json = JSONObject(body)

            if (json.optBoolean("IsErroredOnProcessing", false)) {
                Log.e("OCRSpace", json.optString("ErrorMessage"))
                return@withContext emptyList()
            }

            val results = json.optJSONArray("ParsedResults") ?: return@withContext emptyList()
            val lines = results.getJSONObject(0).optJSONObject("TextOverlay")?.optJSONArray("Lines") ?: return@withContext emptyList()

            val blocks = mutableListOf<BlockData>()
            for (i in 0 until lines.length()) {
                val line = lines.getJSONObject(i)
                val words = line.optJSONArray("Words")
                if (words != null && words.length() > 0) {
                    val first = words.getJSONObject(0)
                    val totalWidth = (0 until words.length()).sumOf { words.getJSONObject(it).optInt("Width", 0) }
                    blocks.add(BlockData(
                        text = line.optString("LineText", ""),
                        x = first.optInt("Left", 0),
                        y = first.optInt("Top", 0),
                        width = totalWidth,
                        height = line.optInt("MaxHeight", 30)
                    ))
                }
            }
            blocks
        } catch (e: Exception) {
            Log.e("OCRSpace", "Error", e)
            emptyList()
        }
    }

    // 5. Cloud API (generic)
    suspend fun recognizeCloud(bitmap: Bitmap, apiUrl: String): List<BlockData> = withContext(Dispatchers.IO) {
        try {
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream)
            val base64 = android.util.Base64.encodeToString(stream.toByteArray(), android.util.Base64.DEFAULT)

            val jsonBody = JSONObject().put("image", "data:image/jpeg;base64,$base64").toString()
            val request = Request.Builder()
                .url(apiUrl)
                .post(jsonBody.toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return@withContext emptyList()
            val json = JSONObject(body)

            val results = json.optJSONArray("results") ?: json.optJSONArray("words") ?: json.optJSONArray("texts") ?: return@withContext emptyList()
            val blocks = mutableListOf<BlockData>()
            for (i in 0 until results.length()) {
                val item = results.getJSONObject(i)
                blocks.add(BlockData(
                    text = item.optString("text", ""),
                    x = item.optInt("x", 0),
                    y = item.optInt("y", 0),
                    width = item.optInt("width", 100),
                    height = item.optInt("height", 30),
                    confidence = item.optDouble("confidence", 80.0).toFloat()
                ))
            }
            blocks
        } catch (e: Exception) {
            Log.e("CloudOCR", "Error", e)
            emptyList()
        }
    }

    /**
     * ML Kit returns text lines. Comic speech bubbles often contain several lines that
     * belong to one sentence/bubble. Merge nearby lines using geometry rather than blindly
     * concatenating the entire page. This keeps translation requests at bubble level.
     */
    private fun mergeIntoComicBlocks(
        input: List<BlockData>,
        imageWidth: Int,
        imageHeight: Int
    ): List<BlockData> {
        if (input.isEmpty()) return emptyList()

        val sorted = input
            .filter { it.text.isNotBlank() && it.width > 0 && it.height > 0 }
            .sortedWith(compareBy<BlockData> { it.y }.thenBy { it.x })

        val groups = mutableListOf<MutableList<BlockData>>()
        for (line in sorted) {
            var best: MutableList<BlockData>? = null
            var bestScore = Float.NEGATIVE_INFINITY

            for (group in groups) {
                val g = group.reduce { a, b -> mergeGeometry(a, b) }
                val overlapX = horizontalOverlapRatio(line, g)
                val centerDx = kotlin.math.abs((line.x + line.width / 2f) - (g.x + g.width / 2f))
                val centerLimit = maxOf(line.width, g.width) * 0.65f
                val gapY = maxOf(0, maxOf(line.y, g.y) - minOf(line.y + line.height, g.y + g.height))
                val gapLimit = maxOf(14f, maxOf(line.height, g.height) * 1.35f)

                // Strong horizontal alignment or center alignment + a small vertical gap.
                val compatible = (overlapX >= 0.25f || centerDx <= centerLimit) && gapY <= gapLimit
                if (!compatible) continue

                val score = overlapX * 2f + (1f - (gapY / gapLimit).coerceIn(0f, 1f))
                if (score > bestScore) {
                    bestScore = score
                    best = group
                }
            }

            if (best != null) best!!.add(line) else groups.add(mutableListOf(line))
        }

        return groups.mapNotNull { group ->
            val box = group.reduce { a, b -> mergeGeometry(a, b) }
            val ordered = group.sortedWith(compareBy<BlockData> { it.y }.thenBy { it.x })
            val text = ordered.joinToString(" ") { it.text.trim() }.replace(Regex("\\s+"), " ").trim()
            if (text.isBlank()) null
            else box.copy(
                text = text,
                confidence = ordered.map { it.confidence }.filter { it > 0f }.average()
                    .takeIf { !it.isNaN() }?.toFloat() ?: box.confidence,
                x = box.x.coerceIn(0, maxOf(0, imageWidth - 1)),
                y = box.y.coerceIn(0, maxOf(0, imageHeight - 1)),
                width = box.width.coerceAtMost(imageWidth),
                height = box.height.coerceAtMost(imageHeight)
            )
        }.sortedWith(compareBy<BlockData> { it.y }.thenBy { it.x })
    }

    private fun mergeGeometry(a: BlockData, b: BlockData): BlockData {
        val x1 = minOf(a.x, b.x)
        val y1 = minOf(a.y, b.y)
        val x2 = maxOf(a.x + a.width, b.x + b.width)
        val y2 = maxOf(a.y + a.height, b.y + b.height)
        return a.copy(x = x1, y = y1, width = x2 - x1, height = y2 - y1)
    }

    private fun horizontalOverlapRatio(a: BlockData, b: BlockData): Float {
        val left = maxOf(a.x, b.x)
        val right = minOf(a.x + a.width, b.x + b.width)
        val overlap = maxOf(0, right - left)
        val base = minOf(a.width, b.width).coerceAtLeast(1)
        return overlap.toFloat() / base
    }

}
