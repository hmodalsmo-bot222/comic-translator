package com.comictrans.engine

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest

data class ModelInfo(
    val id: String,          // يطابق قيمة erasureMode: "ai_lite" أو "ai_pro"
    val displayName: String,
    val fileName: String,
    val url: String,         // فارغ = لا يوجد رابط تنزيل رسمي معروف؛ يحتاج المستخدم يوفّر رابط بديل
    val approxSizeMB: Int,
    val sha256: String? = null
)

/**
 * يدير تنزيل/تخزين/التحقق من نماذج الطمس بالذكاء الاصطناعي (AI Lite / AI Pro).
 * الملفات تُخزَّن في: <external-files>/models/
 *
 * مصدر AI Pro (ONNX): Carve/LaMa-ONNX على Hugging Face (lama_fp32.onnx) — نموذج LaMa
 * الأصلي محوّل لـ ONNX، مرخّص Apache-2.0، حجمه ~208MB، مُدخلاته: image float32[1,3,512,512]
 * (RGB مقسومة على 255) + mask float32[1,1,512,512] (1=امسح، 0=أبقِ)، ومُخرجه صورة RGB
 * [0..255] جاهزة مباشرة بنفس المقاس. هذا معروف وموثّق من صفحة النموذج، وتم التحقق منه.
 *
 * مصدر AI Lite (TFLite): لا يوجد حالياً رابط تنزيل مباشر عام موثوق لنموذج LaMa بصيغة
 * .tflite بدون تسجيل دخول (نسخة Qualcomm AI Hub تتطلب حساب). لذلك رابطها فارغ افتراضياً؛
 * المستخدم يقدر يضيف رابط .tflite خاص به (مُصدَّر بنفس فكرة LaMa: مُدخل صورة + قناع، مُخرج
 * صورة) عبر setCustomUrl، وستُستخدم تلقائياً بمجرد توفرها.
 */
class ModelManager(private val context: Context) {

    private val TAG = "ModelManager"
    private val client = OkHttpClient.Builder().build()

    private val modelsDir: File by lazy {
        File(context.getExternalFilesDir(null), "models").apply { mkdirs() }
    }

    // روابط قابلة للتعديل من المستخدم (تُخزَّن في SharedPreferences) — تسمح بإضافة نموذج
    // TFLite بديل لـ AI Lite لو ما توفر رابط رسمي، أو استبدال رابط AI Pro لو تغيّر.
    private val prefs by lazy { context.getSharedPreferences("model_urls", Context.MODE_PRIVATE) }

    val availableModels: List<ModelInfo>
        get() = listOf(
            ModelInfo(
                id = "ai_pro",
                displayName = "AI Pro (ONNX — LaMa)",
                fileName = "lama-pro.onnx",
                url = prefs.getString("url_ai_pro", DEFAULT_ONNX_URL) ?: DEFAULT_ONNX_URL,
                approxSizeMB = 208,
                sha256 = "1faef5301d78db7dda502fe59966957ec4b79dd64e16f03ed96913c7a4eb68d6"
            ),
            ModelInfo(
                id = "ai_lite",
                displayName = "AI Lite (TFLite)",
                fileName = "lama-lite.tflite",
                url = prefs.getString("url_ai_lite", "") ?: "",
                approxSizeMB = 45
            )
        )

    fun setCustomUrl(modelId: String, url: String) {
        prefs.edit().putString("url_$modelId", url).apply()
    }

    fun modelFile(model: ModelInfo): File = File(modelsDir, model.fileName)

    fun isDownloaded(model: ModelInfo): Boolean {
        val f = modelFile(model)
        return f.exists() && f.length() > 1_000_000L // أصغر من ميجا = غالباً تنزيل ناقص/فاشل
    }

    fun delete(model: ModelInfo): Boolean = modelFile(model).delete()

    /**
     * ينزّل النموذج مع تقدّم دوري، ويتحقق من sha256 إن كان معروفاً.
     * يكتب أولاً لملف .part ثم يعيد تسميته بعد اكتمال ونجاح التحقق، حتى لا يظهر
     * النموذج "محمّل" لو انقطع التنزيل منتصف الطريق.
     */
    suspend fun download(model: ModelInfo, onProgress: (Int) -> Unit): Result<Unit> = withContext(Dispatchers.IO) {
        if (model.url.isBlank()) {
            return@withContext Result.failure(IllegalStateException("لا يوجد رابط تنزيل لهذا النموذج — أضف رابطاً مخصصاً أولاً"))
        }
        val tmp = File(modelsDir, model.fileName + ".part")
        try {
            val request = Request.Builder().url(model.url).build()
            client.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) {
                    return@withContext Result.failure(java.io.IOException("HTTP ${resp.code}"))
                }
                val body = resp.body ?: return@withContext Result.failure(java.io.IOException("استجابة فارغة"))
                val total = body.contentLength()
                val digest = if (model.sha256 != null) MessageDigest.getInstance("SHA-256") else null

                body.byteStream().use { input ->
                    FileOutputStream(tmp).use { output ->
                        val buffer = ByteArray(64 * 1024)
                        var downloaded = 0L
                        var lastReportedPct = -1
                        while (true) {
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            digest?.update(buffer, 0, read)
                            downloaded += read
                            if (total > 0) {
                                val pct = ((downloaded * 100) / total).toInt()
                                if (pct != lastReportedPct) {
                                    lastReportedPct = pct
                                    onProgress(pct)
                                }
                            }
                        }
                    }
                }

                if (digest != null) {
                    val hex = digest.digest().joinToString("") { "%02x".format(it) }
                    if (!hex.equals(model.sha256, ignoreCase = true)) {
                        tmp.delete()
                        return@withContext Result.failure(java.io.IOException("فشل التحقق من سلامة الملف (checksum) — أُعيد التنزيل مطلوب"))
                    }
                }
            }
            val finalFile = modelFile(model)
            finalFile.delete()
            if (!tmp.renameTo(finalFile)) {
                return@withContext Result.failure(java.io.IOException("فشل حفظ النموذج على التخزين"))
            }
            onProgress(100)
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Model download failed: ${model.id}", e)
            tmp.delete()
            Result.failure(e)
        }
    }

    companion object {
        private const val DEFAULT_ONNX_URL =
            "https://huggingface.co/Carve/LaMa-ONNX/resolve/main/lama_fp32.onnx"
    }
}
