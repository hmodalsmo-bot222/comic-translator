# PaddleOCR Lite (offline Android)

This directory is populated by the GitHub Actions build before Gradle runs.

Runtime:
- `com.github.equationl.paddleocr4android:paddleocr4android:v1.2.0` (Paddle-Lite artifact)
- Official PP-OCR mobile `.nb` models compatible with the Paddle-Lite v2.10-era deployment documented by PaddleOCR.

Files expected at build time:
- `det.nb` — text detection
- `cls.nb` — text direction classification
- `rec.nb` — text recognition
- `ppocr_keys_v1.txt` — Chinese/English recognition dictionary

The workflow downloads the real model files from PaddleOCR's official model host and the dictionary from the PaddleOCR repository. No fake or zero-byte model files are committed. PaddleOCR documents `.nb` models as the mobile Paddle-Lite deployment format.


## Build fix (V15)
- Updated PaddleOCR4Android Paddle-Lite dependency from v1.2.0 to v1.3.0. The upstream v1.3.0 tag contains a JitPack build fix; v1.2.0 could not be resolved by GitHub Actions.
