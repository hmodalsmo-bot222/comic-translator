# تسليم المهمة — Comic Translator (تكملة التطوير)

هذا ملف تسليم لمساعد آخر يكمل من هنا. المشروع Android (Kotlin + WebView) لتطبيق ترجمة
كوميكس. الطلب الأصلي كان 12 بنداً كبيراً. هذا الملف يوثّق **بالضبط** أي بند تم وأي بند لم
يُلمَس، وأين بالضبط، حتى ما تحتاج تعيد اكتشاف شيء.

⚠️ **قيد بيئي مهم (ما زال قائماً في هذه الجلسة أيضاً)**: كل التعديلات لهذه اللحظة — بما
فيها تعديلات هذه الجلسة (بند 6 وبند 2) — كُتبت في بيئة **بدون Android SDK وبدون إنترنت**
(نفس القيد الموصوف سابقاً). لم يُبنَ المشروع فعلياً هنا إلا مرة واحدة تاريخياً (عبر GitHub
Actions رفعها المستخدم بنفسه). **هذه الجلسة راجعت الكود الموجود مسبقاً (بند 5/7/8) مراجعة
يدوية دقيقة سطراً بسطر (لا بناء فعلي) ولم تجد أي خطأ استيراد/توقيع/تطابق أعمدة قاعدة
بيانات** — لكن هذا لا يغني عن بناء فعلي واختبار حسب خطوات كل بند تحت. أي تعديل جديد **لازم
يُبنى ويُختبر فعلياً عبر GitHub Actions** قبل الثقة فيه.

## حالة الـ12 بنداً بالضبط

| # | البند | الحالة | التفاصيل |
|---|-------|--------|----------|
| 1 | نظام الأخطاء الموحّد | ✅ **تم كاملاً ومبني بنجاح** | `error/AppError.kt`, `error/ErrorManager.kt` |
| 9 | Model Manager (Resume/Pause/تحقق) | ✅ **تم كاملاً ومبني بنجاح** | `engine/ModelManager.kt` (أعيدت كتابته بالكامل) |
| 5 | Cache للصفحات (Room) | ⚠️ **الكود مكتمل، رُوجع يدوياً هذه الجلسة، لم يُبنَ بعد** | انظر قسم "بند 5" تحت |
| 8 | Local LLM (Custom OpenAI-Compatible) | ⚠️ **الكود مكتمل، رُوجع يدوياً هذه الجلسة، لم يُبنَ بعد** | انظر قسم "بند 8" تحت |
| 7 | نظام Prompts + Comic Dictionary | ⚠️ **الكود مكتمل، رُوجع يدوياً هذه الجلسة، لم يُبنَ بعد** | انظر قسم "بند 7" تحت |
| 6 | سياق الصفحة للترجمة (Batch) | ✅ **الكود مكتمل هذه الجلسة، لم يُبنَ بعد** | انظر قسم "بند 6 (جديد)" تحت |
| 2 | تحسين OCR (Noise Reduction) | ✅ **جزء Noise Reduction أُضيف هذه الجلسة، لم يُبنَ بعد** | انظر قسم "بند 2 (جديد — جزئي)" تحت — باقي بنود OCR الأخرى لم تُلمَس |
| 3 | كشف فقاعات الكلام (BubbleDetector.kt) | ❌ لم يُلمَس | ملف جديد مطلوب، لم يُنشأ |
| 4 | تحسين إزالة النص (مستويات + Inpainting صغير + fallbackErase محسّن) | ❌ لم يُلمَس | `engine/ErasureEngine.kt` موجود (fill/blur/opencv/ai_lite/ai_pro) لكن fallbackErase لسا أبيض بسيط |
| 10 | تحسين CBZ | ⚠️ **موجود مسبقاً من قبل** | `AppInterface.loadComicFromUri` يستخدم Kotlin/ZipInputStream فعلاً (مو JS) — لم يُعدَّل هذه الجلسة |
| 11 | تقسيم Modules (تقليل حجم APK) | ❌ **لم يُحاوَل عمداً** | راجع "لماذا لم يُنفَّذ" تحت |
| 12 | Unit/Integration Tests | ❌ لم يُلمَس | لا يوجد مجلد test/ حالياً |

`versionCode`/`versionName` رُفعا هذه الجلسة إلى 17 / "1.7.0" (`app/build.gradle`) ليعكسا
دفعة التعديلات (بند 6 + بند 2).

## بند 7 (Prompt Management + Comic Dictionary) — تفاصيل التنفيذ الدقيقة لمن يكمل

الملفات:
- `engine/PromptManager.kt` (جديد): `object PromptManager { fun buildSystemPrompt(comicType,
  seriesName, dictionary: Map<String,String>, targetLangName): String }` — نبرة مختلفة
  حسب manga/manhwa/western + سياق اسم السلسلة + قاموس المصطلحات مدمج بالكامل بنص واحد.
- `db/DictionaryEntity.kt` + `db/DictionaryDao.kt` (جديدان): جدول `comic_dictionary`
  (comicHash, term, translation) بفهرس فريد (comicHash+term).
- `db/AppDatabase.kt`: version 3→4 + `MIGRATION_3_4` تنشئ الجدول + `dictionaryDao()`.
- `model/SettingsData.kt`: حقلان جديدان `comicType` ("manga"/"manhwa"/"western"، افتراضي
  "manga") و `seriesName`.
- `engine/TranslationEngine.kt`: `translateGemini`/`translateOpenAI`/`translateOpenRouter`
  الآن تقبل بارامتر إضافي اختياري `systemPrompt: String? = null` (كان موجوداً فقط بـ
  `translateCustom` من الجولة السابقة). **ملاحظة**: `translateDeepL`/`translateGoogle`/
  `translateMLKit` لا تدعم system prompt أصلاً (خدمات ترجمة تقليدية مو LLM) — متوقَّع.
- `AppInterface.kt` (`processPage`): قبل حلقة الترجمة، يُبنى `systemPrompt` مرة واحدة لكل
  صفحة (استعلام `db.dictionaryDao().getAll(nativeComicHash)` + `PromptManager.
  buildSystemPrompt`)، ويُمرَّر لاستدعاءات gemini/openai/openrouter/custom. `pageSettings
  Fingerprint()` (كاش بند 5) عُدِّلت لتشمل `comicType`+`seriesName` — تغييرهما يُبطل كاش
  الصفحة تلقائياً (سلوك صحيح ومطلوب).
- ثلاث دوال JS جديدة: `requestComicDictionary()` (رد غير متزامن عبر `onComicDictionary` —
  تعمّدنا تجنّب دالة synchronous ترجع String مباشرة لأن ذلك يحتاج `runBlocking` على الترد
  اللي يستدعيها من WebView، وهذا خطر تجميد UI)، `setDictionaryTerm(term, translation)`,
  `deleteDictionaryTerm(term)`.
- `index.html`: قائمة اختيار نوع الكوميكس + حقل اسم السلسلة، زر "📖 قاموس مصطلحات
  الكوميكس" يفتح لوحة (نفس نمط لوحة النماذج) لإضافة/حذف مصطلحات بصرياً.

**ما يحتاج اختباراً فعلياً بعد البناء (لم يُختبَر):**
1. أضف مصطلحاً في لوحة القاموس (مثال: "Luffy" ⟵ "لوفي") مع محرك ترجمة LLM، عالج صفحة فيها
   هذا الاسم، تأكد أن الترجمة استخدمت بالضبط "لوفي".
2. غيّر نوع الكوميكس لنفس الصفحة، تأكد أنها تُعاد معالجتها (fingerprint اختلف) وأن الأسلوب يتغيّر.
3. تأكد DeepL/Google/ML Kit ما زالت تعمل عادي (بدون تأثير من القاموس — متوقَّع).
4. تأكد أن دوال القاموس ما تعلّق الواجهة (كلها async عبر lifecycleScope، بدون runBlocking).

## بند 8 (Local LLM) — تفاصيل التنفيذ الدقيقة لمن يكمل

الملفات:
- `model/SettingsData.kt`: حقول جديدة `customApiUrl`, `customApiKey`, `customModel`.
- `engine/TranslationEngine.kt`: دالة جديدة `translateCustom(text, source, target, apiUrl,
  apiKey, model, systemPrompt = null)` — نفس تنسيق OpenAI Chat Completions، لكن
  `Authorization` header يُرسَل فقط لو المفتاح غير فارغ (Ollama/LM Studio عادة بلا مفتاح).
  فيها بارامتر `systemPrompt` اختياري جاهز مسبقاً — يفيد بند 7 (Prompt Management) لاحقاً
  بدون تعديل التوقيع.
- `AppInterface.kt`: أُضيفت حالة `"custom" -> translateEngine.translateCustom(...)` في
  الـ`when (settings.translateEngine)` الموجودة (ابحث عن `translateSemaphore.withPermit`).
- `index.html`: خيار جديد "🖥️ محلي (Ollama / LM Studio)" في `<select id="translateEngine">`
  + 3 حقول إدخال (`customApiUrl`, `customApiKey`, `customModel`) + ربطها بالحفظ/التحميل.

**ما يحتاج اختباراً فعلياً بعد البناء (لم يُختبَر):**
1. شغّل Ollama محلياً (`ollama serve` + `ollama pull llama3.1`)، على نفس شبكة الهاتف.
2. أدخل `http://<IP-الجهاز-اللي-شغال-عليه-Ollama>:11434/v1/chat/completions` في `customApiUrl`
   واسم النموذج `llama3.1` في `customModel`، اترك `customApiKey` فارغاً.
3. اختر محرك الترجمة "محلي" وجرّب صفحة — تأكد من نجاح الترجمة وعدم رفض السيرفر للطلب.
4. جرّب نفس الشيء مع LM Studio (المنفذ الافتراضي عادة 1234) للتأكد من التوافق العام.

## بند 5 (Cache) — تفاصيل التنفيذ الدقيقة لمن يكمل

الملفات:
- `app/src/main/java/com/comictrans/db/PageCacheEntity.kt` (جديد)
- `app/src/main/java/com/comictrans/db/PageCacheDao.kt` (جديد)
- `app/src/main/java/com/comictrans/db/AppDatabase.kt` (عُدِّل: version 2→3 + MIGRATION_2_3 + إضافة `pageCacheDao()`)
- `app/src/main/java/com/comictrans/AppInterface.kt` (عُدِّل، عدة مواضع):
  - متغير جديد `nativeComicHash` (بجانب `nativeComicTitle` تقريباً السطر 42-46)
  - حساب `nativeComicHash` داخل `loadComicFromUri` بعد بناء `nativePageFiles` (SHA-256 لـ `displayName + عدد الصفحات + totalBytes` — بصمة خفيفة، مو هاش كامل للملف)
  - `processPage()`: أول شيء يحسب `fingerprint` عبر دالة جديدة `pageSettingsFingerprint(settings)`، يفحص الكاش عبر `db.pageCacheDao().find(...)`، ولو موجود يستدعي `serveFromCache()` الجديدة (ترجع true لو نجحت = تخرج processPage فوراً بدون أي OCR/ترجمة/طمس فعلي)
  - نهاية `processPage()` الناجحة: كتابة النتيجة في الكاش (بند غير حرج، بtry/catch منفصل عبر errorManager)
  - الصور المُعالَجة (أوضاع opencv/ai_lite/ai_pro) تُنسَخ لمجلد دائم `context.filesDir/page_cache_images/` (بخلاف `processedPageRoot` اللي يُمسَح بالكامل عند فتح أي كوميك جديد)

**ما يحتاج اختباراً فعلياً بعد البناء (لم يُختبَر):**
1. افتح كوميك، عالج صفحة، أغلق التطبيق، افتحه، أعد فتح **نفس** الكوميك، تأكد أن الصفحة تظهر فوراً بدون أي شريط تقدّم OCR/ترجمة (يعني الكاش اشتغل).
2. غيّر إعداد واحد (مثلاً engine الترجمة)، أعد نفس الصفحة، تأكد أنها تُعاد معالجتها من الصفر (الكاش يُتجاهَل بسبب اختلاف fingerprint) — هذا سلوك مقصود ومطلوب.
3. تأكد ملفات `page_cache_images/` ما تتراكم بلا حدود (فيه `trimOld()` يبقي آخر 2000 سطر فقط بقاعدة البيانات، لكن الملفات الفعلية على القرص المرتبطة بسطور محذوفة **لا تُحذَف تلقائياً حالياً** — هذه ثغرة صغيرة معروفة، تحتاج دالة تنظيف دورية تحذف ملفات `page_cache_images/` غير المُشار لها من أي سطر في الجدول. لم تُنفَّذ بعد).

## بند 6 (سياق الصفحة/Batch) — تفاصيل التنفيذ الدقيقة، أُضيف هذه الجلسة

الملفات:
- `engine/TranslationEngine.kt` (عُدِّل، أُضيف بالنهاية): دالتان جديدتان
  `translateBatchOpenAIStyle(texts: List<String>, target, systemPrompt, endpointUrl, apiKey,
  model, extraHeaders = emptyMap())` (تُستخدَم لـopenai/openrouter/custom — الثلاثة نفس
  تنسيق OpenAI Chat Completions، يختلفون فقط بالـendpoint/المفتاح/رؤوس إضافية مثل
  `X-Title` لـopenrouter) و`translateBatchGemini(...)` (تنسيق Gemini مختلف: `contents`/
  `parts` بدل `messages`). كلتاهما تبني prompt واحد يطلب من النموذج ترجمة مصفوفة JSON من
  النصوص وإرجاع مصفوفة JSON من الترجمات **بنفس الترتيب والعدد بالضبط**، وتفسّر الرد عبر
  `parseBatchResponse()` (خاصة، تُزيل ```json fences لو النموذج لفّ الرد بها رغم التعليمات،
  وترمي استثناء واضح لو عدد عناصر الرد ≠ عدد النصوص المُرسَلة — هذا يضمن عدم قبول رد غير
  موثوق بصمت).
- `AppInterface.kt`:
  - دالة جديدة `translatePageBlocks(pageIndex, blocks, settings, systemPrompt,
    warnedThisPage): List<BlockData>` تحل محل الحلقة القديمة مباشرة داخل `processPage`
    (ابحث عن `// 2. Translation`).
  - منطقها: (1) تفحص ذاكرة الترجمة لكل فقاعة تسلسلياً أولاً (قراءات Room محلية سريعة). (2)
    لو فيه أكثر من فقاعة معلّقة واحدة **والمحرك من `BATCH_CAPABLE_ENGINES` (gemini/openai/
    openrouter/custom)** تحاول batch واحد لكل الفقاعات المعلّقة معاً. (3) لو الـbatch نجح
    (لا استثناء + `parseBatchResponse` قبل عدد العناصر) تُحفَظ كل ترجمة في ذاكرة الترجمة
    وتنتهي الدالة. (4) لو الـbatch **فشل** (أي استثناء — شبكة/مفتاح خاطئ/رد مش JSON/عدد
    عناصر غير مطابق) **أو** المحرك لا يدعم batch أصلاً (mlkit/google/deepl) **أو** فقاعة
    معلّقة واحدة بس، تُستخدَم نفس آلية فقاعة-فقاعة القديمة بالضبط (متوازية عبر
    `Semaphore(5)`) كرجوع تلقائي — **الصفحة لا تفشل كاملة أبداً بسبب فشل batch**.
  - `pageIndex`/`sendStatus`/`sendWarning`/`shouldStop`/`db` كلها مُستخدَمة من داخل
    `AppInterface` نفسه (الدالة الجديدة عضو في نفس الكلاس، ليست top-level) فلا حاجة لتمرير
    أي منها كبارامتر إضافي غير الموجود فعلاً.

**ملاحظة سلوك بسيطة متعمَّدة**: لو المستخدم ضغط "إيقاف" أثناء batch شبكي قيد التنفيذ فعلياً
(الطلب الواحد الكبير)، لا يوجد إلغاء فوري لذلك الطلب تحديداً (بعكس فقاعة-فقاعة حيث كل فقاعة
تتحقق من `shouldStop` قبل بدء طلبها الخاص) — الطلب يكمل ثم يُتجاهَل الناتج لأن الفحص
`if (shouldStop)` بعد نهاية `processPage` translation section ما زال موجوداً كما كان. هذا
تنازل بسيط مقبول (batch أصلاً طلب واحد سريع نسبياً، مو N طلب) لكن يستحق الذكر.

**ما يحتاج اختباراً فعلياً بعد البناء (لم يُختبَر إطلاقاً):**
1. صفحة فيها 3+ فقاعات نص، محرك ترجمة Gemini أو OpenAI أو OpenRouter، تأكد من ترجمة كل
   الفقاعات بنجاح وبنفس الترتيب الصحيح (فقاعة X تقابل ترجمة X، مو مبعثرة).
2. راقب الشبكة (أو أضف log مؤقت) للتأكد أن الصفحة أرسلت طلباً شبكياً **واحداً** للترجمة
   (batch) بدل N طلب — هذا هو جوهر بند 6.
3. جرّب صفحة فيها فقاعة واحدة فقط — تأكد أنها تترجم عادي (تتجاوز batch تلقائياً لأنه بدون
   فائدة لفقاعة وحيدة، تذهب مباشرة للمسار الفردي).
4. اختبار الفشل: أدخل مفتاح API خاطئ عمداً لمحرك LLM، تأكد أن الصفحة تفشل بنفس رسالة
   التحذير القديمة (⚠️) بدل تجمّد أو خطأ غير مفهوم — batch يفشل، فيرجع تلقائياً للمسار
   الفردي، الذي يفشل أيضاً (نفس المفتاح الخاطئ) لكن برسالة واضحة، لا صفحة معلّقة.
5. تأكد أن `useMemory` ما زال يعمل: افتح نفس الصفحة مرة ثانية (بعد أول ترجمة ناجحة)، تأكد
   أنها لا تستدعي الشبكة إطلاقاً (كل الفقاعات موجودة بذاكرة الترجمة، `pending` تصير فارغة).
6. جرّب DeepL/Google/ML Kit (محركات غير LLM) — تأكد أنها ما زالت تترجم فقاعة-فقاعة عادي
   بدون أي تأثير من كود الـbatch (المسار الفردي هو المسار الوحيد المتاح لها أصلاً).

## بند 2 (تحسين OCR — Noise Reduction) — تفاصيل التنفيذ الدقيقة، أُضيف هذه الجلسة (جزئي)

**ملاحظة نطاق**: هذا ينفّذ فقط الجزء الأول من بند 2 حسب الخطة المقترحة سابقاً
(`Imgproc.bilateralFilter` قبل CLAHE). بقية تحسينات OCR المحتملة (مثلاً Deskew/تصحيح ميلان
الصفحة، Binarization تكيّفي، إلخ) لم تُلمَس ولا تزال مفتوحة لمن يكمل لاحقاً لو رأى حاجة لها.

الملف: `engine/ImageEnhanceEngine.kt`، دالة `enhanceOpenCV()` الخاصة (تعمل فقط لو
`settings.enhanceMethod == "opencv"` أو كـfallback من وضع `"ai"` لو نموذج Real-ESRGAN غير
منزَّل — راجع `enhance()` بالأعلى منها). التعديل: بعد تحويل RGBA→RGB مباشرة، أُضيف
`Imgproc.bilateralFilter(rgb, denoised, 9, 75.0, 75.0)` **قبل** تحويل Lab وCLAHE — الترتيب
مهم: bilateralFilter يزيل ضوضاء التحبب/الضغط JPEG مع الحفاظ على حواف الحروف حادة (بعكس
Gaussian blur العادي)، ولازم يُنفَّذ قبل رفع التباين (CLAHE) وإلا CLAHE يكبّر الضوضاء نفسها
بدل إزالتها. باقي الأنبوب (CLAHE على قناة L في Lab، ثم unsharp mask) لم يتغيّر — فقط أُدخلت
خطوة الـdenoising قبله وأُضيفت `denoised`/`rgb` لقائمة `Mat.release()` بالنهاية (تسريب
ذاكرة OpenCV لو نُسيت).

**ما يحتاج اختباراً فعلياً بعد البناء (لم يُختبَر):**
1. فعّل "تحسين الصورة" (`enhanceImage=true`) بوضع `enhanceMethod="opencv"`، عالج صفحة
   ممسوحة ضوئياً بها تحبب/ضوضاء واضحة (مثال: صورة ملتقطة بكاميرا هاتف بإضاءة ضعيفة)، قارن
   دقة قراءة OCR (خصوصاً عدد/نسبة الأخطاء بالحروف) قبل وبعد — يفترض تحسّن ملموس.
2. تأكد الأداء (زمن معالجة الصفحة) لم يرتفع بشكل غير مقبول — bilateralFilter أبطأ نسبياً من
   عمليات OpenCV الأخرى المستخدمة هنا (Gaussian blur, CLAHE)، خصوصاً على صفحات كبيرة
   (تذكّر: الصورة محدودة أصلاً بـ`MAX_PAGE_DIMENSION=3000` قبل وصولها هنا عبر
   `decodeBitmapBounded`، فلا يجب أن تكون المشكلة كبيرة، لكن يستحق قياساً فعلياً على جهاز
   ضعيف نسبياً).
3. جرّب صفحة نظيفة جداً (سكان عالي الجودة، بلا ضوضاء) للتأكد أن bilateralFilter لا "يطمس"
   حروفاً دقيقة كانت واضحة أصلاً (لو لاحظت ذلك، القيم `d=9, sigmaColor=75, sigmaSpace=75`
   بحاجة لتخفيف — مثلاً `sigmaColor`/`sigmaSpace` أقل).
4. تأكد وضع `enhanceMethod="ai"` (Real-ESRGAN) غير متأثر — التعديل فقط داخل
   `enhanceOpenCV()`، ووضع "ai" يستدعيها فقط كـfallback لو النموذج غير موجود، فيجب أن يبقى
   سلوكه كما كان تماماً لو النموذج موجود فعلياً.

## لماذا لم يُنفَّذ بند 11 (تقسيم Modules) عمداً

تقسيم APK لـ Dynamic Feature Modules (Base + OCR + AI + Models) عبر Play Feature Delivery
هو إعادة هيكلة كاملة لبنية Gradle (build.gradle متعددة، AndroidManifest لكل module،
SplitInstallManager في الكود لتحميل الموديولات عند الحاجة). هذا تغيير بمخاطرة عالية جداً
لو تم "تخميناً" بدون قدرة فعلية على بناء واختبار كل خطوة — احتمال كسر البناء بالكامل كبير.
**يُفضَّل تأجيله لبيئة فيها Android Studio فعلي**، أو تنفيذه بحذر شديد خطوة بخطوة مع بناء
واختبار بعد كل خطوة، مو دفعة وحدة.

## خطة مقترحة للمتابعة (بالترتيب المنطقي)

1. **ابنِ عبر GitHub Actions أولاً — كل شيء دفعة واحدة** (بند 5 + بند 7 + بند 8 من قبل
   هذه الجلسة، وبند 6 + بند 2 الجديدان هذه الجلسة). كلها لم تُبنَ فعلياً بعد. لو صار خطأ
   بناء، أرسل اللوق كاملاً — الأخطاء المتوقَّعة غالباً استيراد ناقص بسيط (نفس نمط V18
   السابق) وليست منطقية، لأن كل الملفات رُوجعت يدوياً سطراً بسطر هذه الجلسة بلا SDK.
2. **اختبر حسب خطوات كل بند فعلياً على جهاز/محاكي** — القوائم مفصَّلة في قسم كل بند أعلاه
   (بند 5، بند 6، بند 7، بند 8، بند 2). لا تفترض النجاح لمجرد نجاح البناء — بناء ناجح ≠
   سلوك صحيح وقت التشغيل.
3. **بند 3 (BubbleDetector)**: ملف جديد `engine/BubbleDetector.kt` باستخدام
   `Imgproc.findContours` — الأصعب تقنياً في القائمة، يحتاج تجربة فعلية على صور كوميكس
   حقيقية لضبط العتبات (thresholds).
4. **بند 4 (تحسين fallbackErase)**: في `ErasureEngine.kt`، بدل تعبئة أبيض ثابت، خذ متوسط
   لون البكسلات على حدود منطقة النص (مو داخلها) واملأ بذلك اللون بدل الأبيض.
5. **بند 12 (Tests)**: أسهل جزء يُضاف بأي وقت — أضف `app/src/test/` وابدأ باختبارات
   للمنطق الصرف (PromptManager.buildSystemPrompt، pageSettingsFingerprint،
   TranslationEngine.parseBatchResponse لو صارت internal/تُعرَّض للاختبار، إلخ) لأنها لا
   تحتاج Android Instrumented Test (تعمل بـJUnit عادي بدون جهاز/محاكي).
6. **بند 11 (Module Split)**: أخيراً، وبحذر شديد، فقط لو فيه بيئة بناء فعلية متاحة.

## ملاحظة تقنية عامة لمن يكمل

- البيئة الحالية بدون Android SDK/إنترنت — **لازم تبني بنفسك بعد كل دفعة تعديلات** (نفس ما
  فعل المستخدم بجولة V18: بنى عبر GitHub Actions ولقى خطأ استيراد ناقص واحد `import
  kotlinx.coroutines.cancel` في `ModelManager.kt`، وتم إصلاحه). توقّع نفس النمط: أخطاء
  استيراد بسيطة أكثر من أخطاء منطقية، لأن الكود يُكتب بعناية لكن بدون تحقق الترجمة الفعلي.
- `AppInterface.kt` هو أكبر ملف وأكثرها حساسية (كل الجسر بين WebView والكود الأصلي) —
  أي تعديل فيه يحتاج مراجعة دقيقة للـbraces/imports قبل تسليمه. تحقّقت هذه الجلسة يدوياً من
  توازن الأقواس `{}`/`()` بعدّها برمجياً (228/228 و666/666 بالترتيب) بعد كل تعديل — أداة
  تحقق سريعة مفيدة لأي تعديل مستقبلي كبير بنفس الملف.
- **هذه الجلسة تحديداً** راجعت بند 5/7/8 (المكتوبين مسبقاً) مراجعة يدوية كاملة (لا أدوات
  بناء) عبر قراءة كل الملفات المعنية سطراً بسطر: `AppInterface.kt` كاملاً،
  `TranslationEngine.kt`، `PromptManager.kt`، `AppDatabase.kt` + كل migration، `SettingsData.kt`،
  `PageCacheDao/Entity.kt`، `DictionaryDao/Entity.kt`، وتأكدت من تطابق أسماء دوال `index.html`
  (`onComicDictionary`, `setDictionaryTerm`, `deleteDictionaryTerm`, حقول `customApiUrl/
  customApiKey/customModel`, `comicType/seriesName`) مع ما تكشفه `AppInterface.kt` فعلياً —
  لم يظهر أي خلل. هذا **يرفع الثقة لكنه ليس بديلاً عن بناء فعلي**.
- الأرشيف المرفق هو **حالة المشروع الكاملة حتى الآن** (بعد بند 1، 9، 5، 7، 8، وبند 6+2 من
  هذه الجلسة) — ابدأ منه مباشرة. `versionCode`/`versionName`: 17 / "1.7.0".
