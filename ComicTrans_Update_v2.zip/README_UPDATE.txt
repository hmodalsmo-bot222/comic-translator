تجهيز التحديث الجديد لمشروع ComicTrans v1.1.0:

إعدادات التحديث (Update Configuration):
- applicationId: "com.comictrans" (نفس اسم الحزمة السابقة)
- versionCode: 2 (تم رفعه من 1 إلى 2 ليتم قبوله كتحديث مباشر فوق التطبيق)
- versionName: "1.1.0"

الإصلاحات الشاملة المضمنة في الأرشيف:
1. إصلاح التكبير اللمسي بالإصبعين (Pinch-to-Zoom) عبر JS Matrix وفي WebView settings.
2. حماية الذاكرة عند قراءة ملفات CBZ / ZIP الكبيرة لمنع الانهيار.
3. معالجة التفتيش لـ EasyOCR Part 2 وتثبيته في SharedPreferences.
4. إزالة AOT-GAN، وخيارات (نوع الكوميكس، اسم السلسلة، قاموس المصطلحات، Real-ESRGAN، وخلفية المجتمع).
