package com.comictrans.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.util.zip.ZipInputStream

object ComicFileReader {

    fun loadComicPages(context: Context, uri: Uri): List<Bitmap> {
        val fileName = getFileName(context, uri) ?: ""
        return if (fileName.endsWith(".cbz", ignoreCase = true) || fileName.endsWith(".zip", ignoreCase = true)) {
            extractImagesFromZip(context, uri)
        } else {
            loadSingleImage(context, uri)
        }
    }

    private fun extractImagesFromZip(context: Context, uri: Uri): List<Bitmap> {
        val bitmaps = mutableListOf<Bitmap>()
        val options = BitmapFactory.Options().apply {
            inSampleSize = 2 // آمن للذاكرة لمنع OutOfMemoryError
        }

        try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                ZipInputStream(inputStream).use { zipStream ->
                    var entry = zipStream.nextEntry
                    while (entry != null) {
                        if (!entry.isDirectory && isSupportedImage(entry.name)) {
                            val bitmap = BitmapFactory.decodeStream(zipStream, null, options)
                            bitmap?.let { bitmaps.add(it) }
                        }
                        zipStream.closeEntry()
                        entry = zipStream.nextEntry
                    }
                }
            }
        } catch (e: OutOfMemoryError) {
            System.gc()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return bitmaps
    }

    private fun loadSingleImage(context: Context, uri: Uri): List<Bitmap> {
        val list = mutableListOf<Bitmap>()
        try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                BitmapFactory.decodeStream(inputStream)?.let { list.add(it) }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    private fun isSupportedImage(filename: String): Boolean {
        val lower = filename.lowercase()
        return lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") || lower.endsWith(".webp")
    }

    private fun getFileName(context: Context, uri: Uri): String? {
        return uri.lastPathSegment
    }
}
