package com.comictrans.model

import com.comictrans.engine.ErasureEngineType

data class TranslationSettings(
    val targetLanguage: String = "ar",
    val autoDetectSource: Boolean = true
)

data class ImageProcessingSettings(
    val erasureEngine: ErasureEngineType = ErasureEngineType.OPENCV_TELEA,
    val enableClaheEnhancer: Boolean = true,
    val sharpenResult: Boolean = true
)
