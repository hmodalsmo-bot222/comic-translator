package com.comictrans.engine

import android.content.Context
import android.content.SharedPreferences
import java.io.File

class ModelManager(private val context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("model_prefs", Context.MODE_PRIVATE)

    fun isModelDownloaded(modelId: String): Boolean {
        return when (modelId) {
            "EASYOCR_RECOGNIZER_PART2" -> {
                val modelFile = File(context.filesDir, "models/easyocr/recognizer_p2.onnx")
                val isSavedInPrefs = prefs.getBoolean("EASYOCR_RECOGNIZER_PART2_DOWNLOADED", false)
                modelFile.exists() && modelFile.length() > 0 && isSavedInPrefs
            }
            "EASYOCR_RECOGNIZER_PART1" -> {
                val modelFile = File(context.filesDir, "models/easyocr/recognizer_p1.onnx")
                val isSavedInPrefs = prefs.getBoolean("EASYOCR_RECOGNIZER_PART1_DOWNLOADED", false)
                modelFile.exists() && modelFile.length() > 0 && isSavedInPrefs
            }
            else -> {
                val genericFile = File(context.filesDir, "models/$modelId.bin")
                val isSavedInPrefs = prefs.getBoolean("${modelId}_DOWNLOADED", false)
                (genericFile.exists() && genericFile.length() > 0) || isSavedInPrefs
            }
        }
    }

    fun onModelDownloadComplete(modelId: String) {
        when (modelId) {
            "EASYOCR_RECOGNIZER_PART2" -> {
                prefs.edit().putBoolean("EASYOCR_RECOGNIZER_PART2_DOWNLOADED", true).apply()
            }
            "EASYOCR_RECOGNIZER_PART1" -> {
                prefs.edit().putBoolean("EASYOCR_RECOGNIZER_PART1_DOWNLOADED", true).apply()
            }
            else -> {
                prefs.edit().putBoolean("${modelId}_DOWNLOADED", true).apply()
            }
        }
    }
}
