package com.comictrans.engine

import android.graphics.Bitmap

enum class ErasureEngineType {
    OPENCV_TELEA,
    OPENCV_NS,
    LAMA
    // AOT_GAN_MOBILE removed
}

class ErasureEngine {

    fun eraseText(
        originalBitmap: Bitmap,
        maskBitmap: Bitmap,
        engineType: ErasureEngineType = ErasureEngineType.OPENCV_TELEA
    ): Bitmap {
        return when (engineType) {
            ErasureEngineType.OPENCV_TELEA -> runOpenCVInpainting(originalBitmap, maskBitmap, method = 0)
            ErasureEngineType.OPENCV_NS -> runOpenCVInpainting(originalBitmap, maskBitmap, method = 1)
            ErasureEngineType.LAMA -> runLaMaInpainting(originalBitmap, maskBitmap)
        }
    }

    private fun runOpenCVInpainting(original: Bitmap, mask: Bitmap, method: Int): Bitmap {
        return original
    }

    private fun runLaMaInpainting(original: Bitmap, mask: Bitmap): Bitmap {
        return original
    }
}
