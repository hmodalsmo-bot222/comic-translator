/**
 * ComicTrans Application Logic & Smooth Touch Zoom (v1.1.0)
 */

let scale = 1, currentScale = 1;
let pointX = 0, pointY = 0, startX = 0, startY = 0;
let distStart = 0;

const zoomViewport = document.getElementById('zoom-container');
const workspace = document.getElementById('workspace');

if (zoomViewport && workspace) {
    zoomViewport.addEventListener('touchstart', (e) => {
        if (e.touches.length === 2) {
            distStart = Math.hypot(
                e.touches[0].pageX - e.touches[1].pageX,
                e.touches[0].pageY - e.touches[1].pageY
            );
        } else if (e.touches.length === 1) {
            startX = e.touches[0].clientX - pointX;
            startY = e.touches[0].clientY - pointY;
        }
    }, { passive: false });

    zoomViewport.addEventListener('touchmove', (e) => {
        if (e.touches.length === 2) {
            e.preventDefault();
            const distCurrent = Math.hypot(
                e.touches[0].pageX - e.touches[1].pageX,
                e.touches[0].pageY - e.touches[1].pageY
            );
            scale = Math.min(Math.max(1, currentScale * (distCurrent / distStart)), 5);
            updateTransform();
        } else if (e.touches.length === 1 && scale > 1) {
            e.preventDefault();
            pointX = e.touches[0].clientX - startX;
            pointY = e.touches[0].clientY - startY;
            updateTransform();
        }
    }, { passive: false });

    zoomViewport.addEventListener('touchend', (e) => {
        if (e.touches.length < 2) {
            currentScale = scale;
        }
        if (scale <= 1) {
            scale = 1;
            currentScale = 1;
            pointX = 0;
            pointY = 0;
            updateTransform();
        }
    });
}

function updateTransform() {
    if (workspace) {
        workspace.style.transform = `translate(${pointX}px, ${pointY}px) scale(${scale})`;
        workspace.style.transformOrigin = 'center center';
    }
}

function buildTranslationPayload(extractedText) {
    const targetLang = document.getElementById('targetLanguage') ? document.getElementById('targetLanguage').value : 'ar';
    return {
        text: extractedText,
        target_lang: targetLang,
        prompt: `Translate the following text accurately into Arabic:\n\n${extractedText}`
    };
}

async function onTranslateClick() {
    const rawText = getExtractedText();
    if (!rawText) return;
    const payload = buildTranslationPayload(rawText);
    if (window.AndroidInterface && window.AndroidInterface.processTranslation) {
        window.AndroidInterface.processTranslation(JSON.stringify(payload));
    }
}

function getExtractedText() {
    const textElement = document.getElementById('extractedText');
    return textElement ? (textElement.value || textElement.innerText) : "";
}
