package com.comictrans.feature_ai.engine

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.comictrans.engine.ModelManager
import com.comictrans.engine.contracts.IOcrEngine
import com.comictrans.model.BlockData
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.equationl.paddleocr4android.OCR
import com.equationl.paddleocr4android.OcrConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class OCREngine(
    private val context: Context,
    private val modelManager: ModelManager
) : IOcrEngine {

    private val paddleOcr = OCR(context)
    @Volatile private var paddleInitialized = false
    private val paddleLock = Any()

    // 🔍 (2026-08-15) نفس نسخة ErrorManager المُستخدَمة بـAppInterface بالضبط (singleton
    // مشترك عبر موديولات — راجع AppErrorLog بـErrorManager.kt) — أي رسالة هنا تظهر فعلياً
    // بشاشة "السجل" داخل التطبيق، لا فقط بـLogcat غير المرئي للمستخدم.
    private val errorManager by lazy { com.comictrans.error.AppErrorLog.get(context) }

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    // 1. ML Kit (works fully)
    override suspend fun recognizeMLKit(bitmap: Bitmap): List<BlockData> = withContext(Dispatchers.IO) {
        suspendCancellableCoroutine { continuation ->
            val image = InputImage.fromBitmap(bitmap, 0)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    val blocks = visionText.textBlocks.flatMap { block ->
                        block.lines.map { line ->
                            val rect = line.boundingBox
                            BlockData(
                                text = line.text,
                                x = rect?.left ?: 0,
                                y = rect?.top ?: 0,
                                width = rect?.width() ?: 100,
                                height = rect?.height() ?: 30,
                                confidence = line.confidence
                            )
                        }
                    }
                    continuation.resume(mergeIntoComicBlocks(blocks, bitmap.width, bitmap.height, bitmap))
                    recognizer.close()
                }
                .addOnFailureListener { e ->
                    recognizer.close()
                    continuation.resumeWithException(e)
                }
        }
    }

    // 🔍 (2026-08-21) حُذفت CRAFT Mobile وEAST وEasyOCR بالكامل من هذا الملف نهائياً بطلب
    // المستخدم — راجع feature_ai/build.gradle وAiEngineContracts.kt وSettingsData.kt
    // وAppInterface.kt وModelManager.kt لبقية أجزاء الحذف.

    // 2. PaddleOCR Lite — on-device detection + angle classification + recognition.
    // المكتبة تحتاج فعلياً ملفات det.nb/rec.nb/cls.nb + قاموس الرموز لكي تعمل. هذه الحزمة
    // (كما استُلمت) لا تحتوي هذه الملفات فعلياً في assets/paddle (فقط README يفترض خطوة CI
    // غير موجودة هنا). buildPaddleConfig() تتحقق أولاً من وجودها الفعلي في assets، وإلا
    // تستخدم أي نسخة نزّلها المستخدم عبر ⚙️ إدارة النماذج (ModelManager) من تخزين الجهاز.
    // لو الاثنان غير متوفرين، نرجع تلقائياً وبوضوح لـ ML Kit بدل الفشل الصامت.
    override suspend fun recognizePaddleLite(bitmap: Bitmap): List<BlockData> = withContext(Dispatchers.IO) {
        try {
            synchronized(paddleLock) {
                if (!paddleInitialized) {
                    val config = buildPaddleConfig()
                        ?: throw IllegalStateException(
                            "نماذج PaddleOCR Lite غير متوفرة — نزّلها من ⚙️ إدارة النماذج، أو أضِفها في assets/paddle عند البناء"
                        )
                    paddleOcr.initModelSync(config).getOrThrow()
                    paddleInitialized = true
                }
            }

            val result = paddleOcr.runSync(bitmap).getOrThrow()
            val labels = paddleOcr.getWordLabels()
            result.outputRawResult.mapNotNull { raw ->
                val points = raw.points
                if (points == null || points.size < 4) return@mapNotNull null
                val xs = points.map { it.x }
                val ys = points.map { it.y }
                val left = xs.minOrNull()?.toInt() ?: return@mapNotNull null
                val top = ys.minOrNull()?.toInt() ?: return@mapNotNull null
                val right = xs.maxOrNull()?.toInt() ?: return@mapNotNull null
                val bottom = ys.maxOrNull()?.toInt() ?: return@mapNotNull null
                val text = raw.wordIndex.joinToString("") { labels.getOrNull(it) ?: "" }.trim()
                if (text.isBlank()) return@mapNotNull null
                BlockData(
                    text = text,
                    x = left.coerceIn(0, bitmap.width - 1),
                    y = top.coerceIn(0, bitmap.height - 1),
                    width = (right - left).coerceAtLeast(1).coerceAtMost(bitmap.width),
                    height = (bottom - top).coerceAtLeast(1).coerceAtMost(bitmap.height),
                    confidence = raw.confidence.toFloat(),
                    angle = if (raw.clsLabel == "180") 180f else 0f
                )
            }.let { mergeIntoComicBlocks(it, bitmap.width, bitmap.height, bitmap) }
        } catch (e: Throwable) {
            Log.e("PaddleOCR", "PaddleOCR Lite failed; falling back to ML Kit", e)
            recognizeMLKit(bitmap)
        }
    }

    // يبني إعدادات paddleocr4android حسب مصدر الملفات المتوفر فعلياً:
    // 1) assets/paddle (لو أُضيفت وقت البناء) — modelPath بدون "/" في البداية يعني مسار
    //    داخل assets حسب توثيق المكتبة.
    // 2) ملفات نزّلها المستخدم عبر ModelManager إلى تخزين الجهاز — modelPath هنا مسار مطلق
    //    يبدأ بـ "/"، وهو ما تفسّره المكتبة كقراءة من تخزين الجهاز بدل assets (موثّق في
    //    doc/paddlelite.md الخاص بمكتبة paddleocr4android).
    // ترجع null لو ما توفر أي مصدر كامل (الأربعة ملفات معاً)، بدل افتراض التوفر دائماً.
    private fun buildPaddleConfig(): OcrConfig? {
        val requiredAssets = setOf("det.nb", "rec.nb", "cls.nb", "ppocr_keys_v1.txt")
        val bundledInAssets = try {
            val listed = context.assets.list("paddle")?.toSet() ?: emptySet()
            requiredAssets.all { it in listed }
        } catch (e: Exception) {
            false
        }
        if (bundledInAssets) {
            return OcrConfig().apply {
                modelPath = "paddle"
                labelPath = "paddle/ppocr_keys_v1.txt"
                detModelFilename = "det.nb"
                recModelFilename = "rec.nb"
                clsModelFilename = "cls.nb"
                isRunDet = true
                isRunCls = true
                isRunRec = true
                isDrwwTextPositionBox = false
            }
        }

        val models = modelManager.availableModels
        val det = models.find { it.id == "paddle_det" } ?: return null
        val rec = models.find { it.id == "paddle_rec" } ?: return null
        val cls = models.find { it.id == "paddle_cls" } ?: return null
        val dict = models.find { it.id == "paddle_dict" } ?: return null
        if (!modelManager.isDownloaded(det) || !modelManager.isDownloaded(rec) ||
            !modelManager.isDownloaded(cls) || !modelManager.isDownloaded(dict)
        ) return null

        return OcrConfig().apply {
            modelPath = modelManager.paddleModelsDir.absolutePath
            labelPath = modelManager.modelFile(dict).absolutePath
            detModelFilename = det.fileName
            recModelFilename = rec.fileName
            clsModelFilename = cls.fileName
            isRunDet = true
            isRunCls = true
            isRunRec = true
            isDrwwTextPositionBox = false
        }
    }

    // 🔍 (2026-08-21) حُذف Tesseract4Android بالكامل من هذا الملف نهائياً بطلب المستخدم —
    // راجع feature_ai/build.gradle وAiEngineContracts.kt وSettingsData.kt وAppInterface.kt
    // لبقية أجزاء الحذف.


    // 4. 🔍 (استبدال OCR.space) محلي — Ollama/LM Studio/أي سيرفر متوافق مع OpenAI Chat
    // Completions Vision API. نرسل الصورة كـbase64 داخل content من نوع "image_url" (نفس
    // تنسيق OpenAI الرسمي لمُدخلات الصور بـchat/completions — مدعوم من Ollama وLM Studio
    // لأي نموذج رؤية مُحمَّل)، مع تعليمة تطلب إرجاع JSON فيه كل سطر نص + موقعه بالبكسل. نفس
    // بنية JSON المتوقَّعة بـrecognizeCloud (results/words/texts × text/x/y/width/height)
    // لتوحيد المنطق. ⚠️ دقة الإحداثيات تعتمد كلياً على قدرة النموذج المحلي على "رؤية"
    // الإحداثيات فعلياً — نماذج رؤية ضعيفة أو بلا دعم توطين مكاني قد ترجع تخمينات تقريبية أو
    // نصاً عادياً بلا JSON؛ بالحالة الأخيرة نُرجع الصفحة كبلوك واحد (نفس فلسفة تراجع
    // Tesseract) بدل فشل كامل.
    override suspend fun recognizeLocalLlm(bitmap: Bitmap, apiUrl: String, apiKey: String, model: String): List<BlockData> = withContext(Dispatchers.IO) {
        if (apiUrl.isBlank()) {
            Log.w("OCRLocalLLM", "رابط السيرفر المحلي فارغ — رجوع لـML Kit")
            errorManager.handleMessage("OCR المحلي: رابط السيرفر فارغ — رجوع لـML Kit", com.comictrans.error.ErrorCategory.OCR, com.comictrans.error.ErrorSeverity.WARNING)
            return@withContext recognizeMLKit(bitmap)
        }
        if (model.isBlank()) {
            Log.w("OCRLocalLLM", "اسم النموذج فارغ — رجوع لـML Kit")
            errorManager.handleMessage("OCR المحلي: اسم النموذج فارغ — رجوع لـML Kit", com.comictrans.error.ErrorCategory.OCR, com.comictrans.error.ErrorSeverity.WARNING)
            return@withContext recognizeMLKit(bitmap)
        }
        try {
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream)
            val base64 = android.util.Base64.encodeToString(stream.toByteArray(), android.util.Base64.NO_WRAP)

            val prompt = "This image is ${bitmap.width}x${bitmap.height} pixels, a page from a comic book. " +
                "Find every text line/speech bubble in it. Respond with ONLY a JSON object of the exact " +
                "shape {\"results\":[{\"text\":\"...\",\"x\":0,\"y\":0,\"width\":0,\"height\":0}]} where x/y/width/height " +
                "are pixel coordinates within this image (top-left origin). No explanation, no markdown, JSON only."

            val content = org.json.JSONArray().apply {
                put(JSONObject().apply { put("type", "text"); put("text", prompt) })
                put(JSONObject().apply {
                    put("type", "image_url")
                    put("image_url", JSONObject().apply { put("url", "data:image/jpeg;base64,$base64") })
                })
            }
            val jsonBody = JSONObject().apply {
                put("model", model)
                put("messages", org.json.JSONArray().apply {
                    put(JSONObject().apply { put("role", "user"); put("content", content) })
                })
                put("temperature", 0.1)
            }
            val reqBuilder = Request.Builder()
                .url(apiUrl)
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            if (apiKey.isNotBlank()) reqBuilder.header("Authorization", "Bearer $apiKey")

            val response = client.newCall(reqBuilder.build()).execute()
            val body = response.body?.string()
            if (!response.isSuccessful || body.isNullOrBlank()) {
                Log.e("OCRLocalLLM", "HTTP ${response.code} — رجوع لـML Kit")
                errorManager.handleMessage("OCR المحلي: HTTP ${response.code} من $apiUrl — رجوع لـML Kit", com.comictrans.error.ErrorCategory.OCR, com.comictrans.error.ErrorSeverity.WARNING)
                return@withContext recognizeMLKit(bitmap)
            }

            val replyText = try {
                JSONObject(body).getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").getString("content").trim()
            } catch (e: Throwable) {
                Log.w("OCRLocalLLM", "شكل استجابة غير متوقَّع (ليس OpenAI chat/completions قياسي) — رجوع لـML Kit", e)
                errorManager.handle(e, com.comictrans.error.ErrorCategory.OCR, "OCR المحلي: شكل استجابة غير متوقَّع من السيرفر — رجوع لـML Kit", com.comictrans.error.ErrorSeverity.WARNING)
                return@withContext recognizeMLKit(bitmap)
            }

            // النموذج مُطالَب بإرجاع JSON خالص، لكن بعض النماذج المحلية تُحيط الرد بسياج
            // ماركداون (```json ... ```) رغم التعليمة — نزيله لو موجوداً قبل التحليل.
            val cleaned = replyText.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()

            val blocks = try {
                val json = JSONObject(cleaned)
                val results = json.optJSONArray("results") ?: json.optJSONArray("words") ?: json.optJSONArray("texts")
                if (results == null) null
                else (0 until results.length()).mapNotNull { i ->
                    val item = results.getJSONObject(i)
                    val text = item.optString("text", "")
                    if (text.isBlank()) null
                    else BlockData(
                        text = text,
                        x = item.optInt("x", 0).coerceIn(0, bitmap.width - 1),
                        y = item.optInt("y", 0).coerceIn(0, bitmap.height - 1),
                        width = item.optInt("width", 100).coerceAtLeast(1),
                        height = item.optInt("height", 30).coerceAtLeast(1)
                    )
                }
            } catch (e: Throwable) {
                null
            }

            if (blocks.isNullOrEmpty()) {
                // النموذج لم يُرجع JSON صالحاً — نتعامل مع الرد كنص عادي (بلوك صفحة كاملة)
                // بدل فشل كامل، بنفس فلسفة تراجع Tesseract أعلاه.
                errorManager.handleMessage("OCR المحلي: الرد لم يكن JSON صالحاً — استُخدم كنص صفحة كاملة", com.comictrans.error.ErrorCategory.OCR, com.comictrans.error.ErrorSeverity.WARNING)
                if (cleaned.isBlank()) emptyList()
                else listOf(BlockData(text = cleaned, x = 0, y = 0, width = bitmap.width, height = bitmap.height))
            } else {
                errorManager.handleMessage("OCR المحلي: ${blocks.size} صندوق نص مقروء بنجاح", com.comictrans.error.ErrorCategory.OCR, com.comictrans.error.ErrorSeverity.WARNING)
                mergeIntoComicBlocks(blocks, bitmap.width, bitmap.height, bitmap)
            }
        } catch (e: Throwable) {
            Log.e("OCRLocalLLM", "فشل الاتصال بالسيرفر المحلي — رجوع لـML Kit", e)
            errorManager.handle(e, com.comictrans.error.ErrorCategory.OCR, "OCR المحلي: فشل الاتصال بالسيرفر — رجوع لـML Kit")
            recognizeMLKit(bitmap)
        }
    }

    // 5. Cloud API (generic)
    override suspend fun recognizeCloud(bitmap: Bitmap, apiUrl: String): List<BlockData> = withContext(Dispatchers.IO) {
        try {
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream)
            val base64 = android.util.Base64.encodeToString(stream.toByteArray(), android.util.Base64.DEFAULT)

            val jsonBody = JSONObject().put("image", "data:image/jpeg;base64,$base64").toString()
            val request = Request.Builder()
                .url(apiUrl)
                .post(jsonBody.toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return@withContext emptyList()
            val json = JSONObject(body)

            val results = json.optJSONArray("results") ?: json.optJSONArray("words") ?: json.optJSONArray("texts") ?: return@withContext emptyList()
            val blocks = mutableListOf<BlockData>()
            for (i in 0 until results.length()) {
                val item = results.getJSONObject(i)
                blocks.add(BlockData(
                    text = item.optString("text", ""),
                    x = item.optInt("x", 0),
                    y = item.optInt("y", 0),
                    width = item.optInt("width", 100),
                    height = item.optInt("height", 30),
                    confidence = item.optDouble("confidence", 80.0).toFloat()
                ))
            }
            blocks
        } catch (e: Exception) {
            Log.e("CloudOCR", "Error", e)
            emptyList()
        }
    }

    /**
     * ML Kit returns text lines. Comic speech bubbles often contain several lines that
     * belong to one sentence/bubble. Merge nearby lines using geometry rather than blindly
     * concatenating the entire page. This keeps translation requests at bubble level.
     *
     * 🔍 (2026-08-20) إصلاح جذري لبلاغ "فقاعات صغيرة ومتقاربة وكثيرة → الترجمة تندمج/
     * تتراكب فوق بعضها، والخط يصغر جداً ويتكرر كثيراً": السبب الجذري المؤكَّد بمراجعة هذا
     * المنطق هو أن التوافق (`compatible`) كان يعتمد **فقط على المسافة الهندسية** (تراكب أفقي
     * أو محاذاة مركز + فجوة رأسية صغيرة) بدون أي فحص لوجود **حد فقاعة فعلي** (outline) بين
     * السطرين. في صفحة بها فقاعات صغيرة متلاصقة (شائع بالمانجا خصوصاً)، يكفي أن يكون سطر من
     * فقاعة وسطر من فقاعة **مجاورة تماماً تحتها** بفجوة رأسية أصغر من `gapLimit` (والذي أصلاً
     * يكبر تلقائياً مع طول السطر: `maxOf(line.height, g.height) * 1.35f`) ليُدمَجا خطأً في
     * بلوك نص واحد. نتيجة ذلك: صندوق النص المُدمَج (`mergeGeometry`) يمتد فعلياً عبر فقاعتين
     * منفصلتين، والنص المترجم المُجمَّع (فقرتان مختلفتان دُمجتا بمسافة) يُحشَر داخل `fitTextToBox`
     * (بـTextRenderer.kt أو JS) الذي يخفّض حجم الخط تدريجياً حتى 8px محاولاً إدخال كل هذا
     * النص الزائد داخل ما يُفتَرض أنه مساحة فقاعة واحدة صغيرة — هذا بالضبط عرض "الخط صغير جداً
     * ويتكرر كثيراً" (أسطر ملتفة كثيرة بخط صغير جداً، تمتد بصرياً فوق الفقاعتين معاً).
     *
     * الإصلاح: [hasVisualSeparator] يفحص الشريط الأفقي الرقيق الفاصل بين السطرين فعلياً على
     * البكسلات — لو وُجد خط غامق كافٍ (حد الفقاعة، أو حتى مجرد خلفية غير بيضاء بين فقاعتين
     * متجاورتين) يُمنَع الدمج نهائياً بغض النظر عن قرب المسافة الهندسية. هذا يستخدم نفس فكرة
     * `BubbleDetector.kt` (كشف حدود الفقاعة بالإضاءة) لكن بفحص أخف بكثير (بدون OpenCV/
     * findContours) مناسب لتشغيله على كل زوج سطور مرشَّح للدمج أثناء OCR مباشرة.
     */
    private fun mergeIntoComicBlocks(
        input: List<BlockData>,
        imageWidth: Int,
        imageHeight: Int,
        bitmap: Bitmap? = null
    ): List<BlockData> {
        if (input.isEmpty()) return emptyList()

        val sorted = input
            .filter { it.text.isNotBlank() && it.width > 0 && it.height > 0 }
            .sortedWith(compareBy<BlockData> { it.y }.thenBy { it.x })

        val groups = mutableListOf<MutableList<BlockData>>()
        for (line in sorted) {
            var best: MutableList<BlockData>? = null
            var bestScore = Float.NEGATIVE_INFINITY

            for (group in groups) {
                val g = group.reduce { a, b -> mergeGeometry(a, b) }
                val overlapX = horizontalOverlapRatio(line, g)
                val centerDx = kotlin.math.abs((line.x + line.width / 2f) - (g.x + g.width / 2f))
                // 🔧 (2026-08-21) خُفِّف الشرط الهندسي شوي (المسافة العمودية المسموحة من 1.35×
                // إلى 1.6×، ومركز المحاذاة من 0.65 إلى 0.75) بطلب المستخدم — الدمج صار متشدداً
                // أكثر من اللازم بعد آخر تشديد.
                val centerLimit = maxOf(line.width, g.width) * 0.75f
                val gapY = maxOf(0, maxOf(line.y, g.y) - minOf(line.y + line.height, g.y + g.height))
                val gapLimit = maxOf(14f, maxOf(line.height, g.height) * 1.6f)

                // Strong horizontal alignment or center alignment + a small vertical gap.
                val compatible = (overlapX >= 0.25f || centerDx <= centerLimit) && gapY <= gapLimit &&
                    (bitmap == null || !hasVisualSeparator(bitmap, line, g))
                if (!compatible) continue

                val score = overlapX * 2f + (1f - (gapY / gapLimit).coerceIn(0f, 1f))
                if (score > bestScore) {
                    bestScore = score
                    best = group
                }
            }

            if (best != null) best!!.add(line) else groups.add(mutableListOf(line))
        }

        return groups.mapNotNull { group ->
            val box = group.reduce { a, b -> mergeGeometry(a, b) }
            val ordered = group.sortedWith(compareBy<BlockData> { it.y }.thenBy { it.x })
            val text = ordered.joinToString(" ") { it.text.trim() }.replace(Regex("\\s+"), " ").trim()
            if (text.isBlank()) null
            else box.copy(
                text = text,
                confidence = ordered.map { it.confidence }.filter { it > 0f }.average()
                    .takeIf { !it.isNaN() }?.toFloat() ?: box.confidence,
                x = box.x.coerceIn(0, maxOf(0, imageWidth - 1)),
                y = box.y.coerceIn(0, maxOf(0, imageHeight - 1)),
                width = box.width.coerceAtMost(imageWidth),
                height = box.height.coerceAtMost(imageHeight)
            )
        }.sortedWith(compareBy<BlockData> { it.y }.thenBy { it.x })
    }

    private fun mergeGeometry(a: BlockData, b: BlockData): BlockData {
        val x1 = minOf(a.x, b.x)
        val y1 = minOf(a.y, b.y)
        val x2 = maxOf(a.x + a.width, b.x + b.width)
        val y2 = maxOf(a.y + a.height, b.y + b.height)
        return a.copy(x = x1, y = y1, width = x2 - x1, height = y2 - y1)
    }

    private fun horizontalOverlapRatio(a: BlockData, b: BlockData): Float {
        val left = maxOf(a.x, b.x)
        val right = minOf(a.x + a.width, b.x + b.width)
        val overlap = maxOf(0, right - left)
        val base = minOf(a.width, b.width).coerceAtLeast(1)
        return overlap.toFloat() / base
    }

    // 🔍 (2026-08-20) راجع التعليق الطويل أعلى mergeIntoComicBlocks لسياق سبب إضافة هذا الفحص.
    // يفحص الشريط الأفقي الفاصل رأسياً بين [a] و[b] (منطقة تراكب عرضهما فقط، لا الصفحة
    // كاملة) بحثاً عن صف بكسلات غامق كافٍ — إن وُجد، الأرجح أن هذا حد فقاعة فعلي (outline)
    // أو خلفية غير بيضاء تفصل فقاعتين متجاورتين، لا مجرد تباعد أسطر طبيعي داخل نفس الفقاعة
    // (المسافة بين سطرين بنفس الفقاعة عادة بيضاء/فاتحة بالكامل بلا أي خط يقطعها).
    private fun hasVisualSeparator(bitmap: Bitmap, a: BlockData, b: BlockData): Boolean {
        val top = if (a.y <= b.y) a else b
        val bottom = if (a.y <= b.y) b else a
        val gapTop = top.y + top.height
        val gapBottom = bottom.y
        if (gapBottom <= gapTop) return false // متراكبان فعلياً بلا فجوة — لا مجال لخط فاصل
        val left = maxOf(a.x, b.x).coerceIn(0, bitmap.width - 1)
        val right = minOf(a.x + a.width, b.x + b.width).coerceIn(left + 1, bitmap.width)
        if (right <= left) return false
        return try {
            // 🔧 (2026-08-21) بطلب المستخدم: الدمج صار متشدداً أكثر من اللازم (يقسم الفقاعة
            // الكبيرة الواحدة لعدة أقسام). رفعت عتبة "الصف الغامق" من 0.4 إلى 0.6، وصار لازم
            // صفّين متتاليين (مو صف واحد بس) عشان يُعتبَر فاصلاً حقيقياً — يقلل من صف بكسل
            // ضجيج/تباين طفيف داخل نفس الفقاعة يُفسَّر خطأً كحد فقاعة.
            var consecutiveSeparatorRows = 0
            var y = gapTop.coerceIn(0, bitmap.height - 1)
            val yEnd = gapBottom.coerceIn(0, bitmap.height - 1)
            while (y <= yEnd) {
                var darkCount = 0
                var sampled = 0
                var px = left
                while (px < right) {
                    val pixel = bitmap.getPixel(px, y)
                    val lum = (android.graphics.Color.red(pixel) + android.graphics.Color.green(pixel) + android.graphics.Color.blue(pixel)) / 3
                    if (lum < 150) darkCount++
                    sampled++
                    px += 3 // تخطي بكسلات لتسريع الفحص — الدقة الكاملة غير ضرورية لخط حدّي واضح
                }
                // صف يُعتبَر "فاصلاً" لو أغلبه غامق نسبياً — نص عربي/إنجليزي منفرد لا يملأ
                // شريطاً كاملاً بهذا الشكل، بعكس خط حدّي مستمر لفقاعة.
                if (sampled > 0 && darkCount.toFloat() / sampled > 0.6f) {
                    consecutiveSeparatorRows++
                    if (consecutiveSeparatorRows >= 2) return true
                } else {
                    consecutiveSeparatorRows = 0
                }
                y++
            }

            // 🆕 (2026-08-21) إصلاح لبلاغ "فقاعات منفصلة بصرياً لسه تُدمَج/تُطمَس كوحدة واحدة
            // بشكل ملحوظ بصور المستخدم": حد الفقاعة ليس دائماً خطاً غامقاً (lum<150) — أحياناً
            // يكون مجرد اختلاف لون بين داخل الفقاعة (أبيض/فاتح غالباً) وما بين الفقاعتين
            // (خلفية اللوحة، جزء من الرسم، أو فقاعة أخرى ملوّنة). الفحص أعلاه وحده كان يفوّت
            // هذه الحالات فيسمح بالدمج رغم عدم وجود استمرارية بصرية فعلية بين الفقاعتين —
            // نتيجته المشاهَدة: مستطيل تعبئة/طمس واحد يمتد فوق الفقاعتين معاً (شكل "طرفين
            // متصلين بجسر" بدل فقاعتين منفصلتين). الإصلاح: نقارن متوسط لون شريط الفجوة بمتوسط
            // لون داخل كل فقاعة قرب حافتها الداخلية — فرق واضح بالاثنين معاً يعني الفجوة ليست
            // استمراراً لنفس داخل الفقاعة (حتى لو لا يوجد خط غامق حدّي واحد)، فنمنع الدمج.
            val gapColor = averageRowColor(bitmap, left, right, gapTop, gapBottom)
            val topInteriorTop = (top.y + top.height - 4).coerceIn(top.y, bitmap.height - 1)
            val topColor = averageRowColor(bitmap, left, right, topInteriorTop, gapTop)
            val bottomInteriorBottom = (bottom.y + 4).coerceIn(0, bottom.y + bottom.height)
            val bottomColor = averageRowColor(bitmap, left, right, gapBottom, bottomInteriorBottom)
            // 🔧 (2026-08-21) رُفعت عتبة فرق اللون من 45 إلى 70 بنفس سياق تخفيف التشدد أعلاه.
            colorDistance(gapColor, topColor) > 70 && colorDistance(gapColor, bottomColor) > 70
        } catch (e: Exception) {
            false // أي فشل بالقراءة (نادر، إحداثيات حافة) — لا نمنع الدمج بلا داعٍ، نرجع لسلوك الهندسة فقط
        }
    }

    // متوسط لون (R,G,B) لشريط أفقي [yStart, yEnd) ضمن العمود [left, right) — تُستخدَم من
    // hasVisualSeparator لمقارنة لون الفجوة بين فقاعتين بلون داخل كل فقاعة قرب حافتها.
    private fun averageRowColor(bitmap: Bitmap, left: Int, right: Int, yStart: Int, yEnd: Int): IntArray {
        var r = 0L; var g = 0L; var b = 0L; var n = 0L
        var y = yStart.coerceIn(0, bitmap.height - 1)
        val end = yEnd.coerceIn(y, bitmap.height - 1)
        while (y <= end) {
            var px = left
            while (px < right) {
                val pixel = bitmap.getPixel(px, y)
                r += android.graphics.Color.red(pixel)
                g += android.graphics.Color.green(pixel)
                b += android.graphics.Color.blue(pixel)
                n++
                px += 3
            }
            y++
        }
        return if (n == 0L) intArrayOf(255, 255, 255) else intArrayOf((r / n).toInt(), (g / n).toInt(), (b / n).toInt())
    }

    private fun colorDistance(c1: IntArray, c2: IntArray): Int {
        return kotlin.math.abs(c1[0] - c2[0]) + kotlin.math.abs(c1[1] - c2[1]) + kotlin.math.abs(c1[2] - c2[2])
    }

}
