package com.comictrans.engine

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * اختبارات وحدة لـPromptManager — منطق Kotlin صرف (لا استيراد android.* إطلاقاً)، فيعمل
 * تحت JUnit عادي (`./gradlew test`) بدون جهاز/محاكي/Robolectric.
 *
 * 🔍 (2026-08-19) أُعيدت كتابة هذه الاختبارات بالكامل بعد تبسيط PromptManager بطلب
 * المستخدم: التوقيع الجديد buildSystemPrompt(targetLangName) فقط — حُذفت مدخلات
 * comicType/seriesName/dictionary وكل الاختبارات المرتبطة بها.
 *
 * ⚠️ هذه الاختبارات **لم تُشغَّل فعلياً** (بيئة الكتابة بلا Android SDK/Gradle) — تحقّقت من
 * صحتها منطقياً فقط بقراءة PromptManager.kt سطراً بسطر ومطابقة كل توقّع هنا مع السلوك
 * الفعلي المكتوب هناك.
 */
class PromptManagerTest {

    @Test
    fun `target language name is interpolated into the prompt`() {
        assertTrue(PromptManager.buildSystemPrompt("Arabic").contains("into Arabic"))
        assertTrue(PromptManager.buildSystemPrompt("French").contains("into French"))
    }

    @Test
    fun `prompt asks for natural idiomatic translation with consistency`() {
        val prompt = PromptManager.buildSystemPrompt("Arabic")
        assertTrue(prompt.contains("professional comic translator"))
        assertTrue(prompt.contains("idiomatically"))
        assertTrue(prompt.contains("consistent across all pages"))
    }

    @Test
    fun `always ends with translation-only instruction`() {
        val tail = "Return ONLY the translation, with no explanation, no quotes, no notes."
        assertTrue(PromptManager.buildSystemPrompt("Arabic").endsWith(tail))
        assertTrue(PromptManager.buildSystemPrompt("English").endsWith(tail))
    }

    @Test
    fun `prompt contains no leftover series or dictionary placeholders`() {
        val prompt = PromptManager.buildSystemPrompt("Arabic")
        assertFalse(prompt.contains("Series:"))
        assertFalse(prompt.contains("Term dictionary"))
        assertFalse(prompt.contains("honorifics"))
    }
}
