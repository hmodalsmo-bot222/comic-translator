package com.comictrans.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * بند 12: SettingsData/BlockData هما data class صرفتان بلا أي اعتماد Android — قيمهما
 * الافتراضية مهمة فعلياً (أول تشغيل للتطبيق يعتمد عليها بالكامل قبل أي حفظ إعدادات من
 * المستخدم)، فهذا الاختبار يقفلها كتوثيق تنفيذي (executable documentation): أي تغيير غير
 * مقصود لقيمة افتراضية مستقبلاً يكسر هذا الاختبار فوراً بدل أن يمر بصمت.
 *
 * ⚠️ لم يُشغَّل فعلياً (نفس القيد بكل ملفات هذه الدفعة) — تحقّقت من مطابقته لـ
 * SettingsData.kt/BlockData.kt الفعليين سطراً بسطر وقت الكتابة.
 */
class SettingsDataTest {

    @Test
    fun `default settings are safe for a first run with no saved config`() {
        val s = SettingsData()
        assertEquals("mlkit", s.ocrEngine) // محلي بلا مفتاح API — أول تشغيل يعمل بدون إعداد
        assertEquals("fill", s.erasureMode)
        assertEquals("google", s.translateEngine)
        assertEquals("en", s.sourceLang)
        assertEquals("ar", s.targetLang)
        assertTrue(s.useMemory)
        assertTrue(s.enhanceImage)
        assertEquals("opencv", s.enhanceMethod)
    }

    @Test
    fun `bubble aware erasure defaults to disabled (بند 3 safety requirement)`() {
        // هذا الاختبار يحمي تحديداً القرار المتعمَّد بند 3: الميزة الجديدة يجب أن تبقى
        // معطّلة افتراضياً حتى لا تتغيّر نتيجة وضع OpenCV Inpaint للمستخدمين الحاليين
        // بدون علمهم. لو هذا الاختبار فشل مستقبلاً، معناه القيمة الافتراضية تغيّرت بالخطأ.
        assertFalse(SettingsData().bubbleAwareErasure)
    }

    @Test
    fun `custom llm fields default to blank (no accidental network calls)`() {
        val s = SettingsData()
        assertEquals("", s.customApiUrl)
        assertEquals("", s.customApiKey)
        assertEquals("", s.customModel)
    }

    @Test
    fun `block data defaults translated text to empty string`() {
        val block = BlockData(text = "hello", x = 0, y = 0, width = 10, height = 10)
        assertEquals("", block.translatedText)
        assertEquals(0.0, block.confidence.toDouble(), 0.0001)
        assertEquals(0.0, block.angle.toDouble(), 0.0001)
    }

    @Test
    fun `block data copy preserves geometry while updating translation`() {
        val block = BlockData(text = "hello", x = 5, y = 6, width = 100, height = 20)
        val translated = block.copy(translatedText = "مرحبا")
        assertEquals("مرحبا", translated.translatedText)
        assertEquals(block.x, translated.x)
        assertEquals(block.y, translated.y)
        assertEquals(block.width, translated.width)
        assertEquals(block.height, translated.height)
    }
}
