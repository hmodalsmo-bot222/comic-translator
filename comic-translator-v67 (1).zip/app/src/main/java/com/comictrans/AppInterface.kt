package com.comictrans

import android.content.Context
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.net.Uri
import java.io.File
import java.util.zip.ZipInputStream
import java.util.Locale
import androidx.lifecycle.lifecycleScope
import com.comictrans.engine.TranslationEngine
import com.comictrans.engine.TextRenderer
import com.comictrans.engine.contracts.FeatureAiLoader
import com.comictrans.engine.contracts.IErasureEngine
import com.comictrans.engine.contracts.IImageEnhanceEngine
import com.comictrans.engine.contracts.IOcrEngine
import com.comictrans.db.AppDatabase
import com.comictrans.model.BlockData
import com.comictrans.model.SettingsData
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONArray
import org.json.JSONObject

class AppInterface(
    private val context: Context,
    private val webView: WebView
) {

    private val gson = Gson()
    private var isProcessing = false
    private var shouldStop = false
    private var nativePageFiles: List<File> = emptyList()
    // 🔍 (2026-08-19، V60) مراجع فعلية للمهام الجارية — بدونها لم يكن هناك أي وسيلة
    // حقيقية لإيقاف عملية جارية (shouldStop كان يُفحَص فقط بين خطوات المعالجة، وفك CBZ
    // لم يكن قابلاً للإيقاف إطلاقاً). تُستخدم من stopAllOperations() ومن loadComicFromUri
    // لمنع فك أرشيفين على نفس المجلد بالتوازي (سبب مباشر لتلف الملفات/الانهيار عند فتح
    // ملف ثانٍ قبل انتهاء الأول).
    private var processingJob: kotlinx.coroutines.Job? = null
    private var loadJob: kotlinx.coroutines.Job? = null
    private var nativeComicTitle: String = ""
    // بصمة الكوميك الحالي (بند 5: Cache) — تُستخدم كمفتاح جزئي في page_cache حتى لا تختلط
    // نتائج صفحة من كوميك بنفس رقم صفحة من كوميك آخر. راجع حساب القيمة في loadComicFromUri.
    private var nativeComicHash: String = ""
    private val processedPageRoot: File by lazy { File(context.cacheDir, "processed_pages") }

    private val modelManager = com.comictrans.engine.ModelManager(context)
    private val mlkitModelManager = com.comictrans.engine.MlkitModelManager(context)
    // معرّفات حزم ML Kit قيد التنزيل حالياً — تمنع إطلاق طلبين لنفس الحزمة بضغطتين متتاليتين.
    private val mlkitDownloading = java.util.Collections.synchronizedSet(mutableSetOf<String>())
    private val translateEngine = TranslationEngine(context)

    init {
        // 🔍 (2026-08-18) يربط TextRenderer بمجلد النماذج نفسه (font_amiri_regular/
        // font_amiri_bold يُنزَّلان هناك مباشرة عبر ModelManager العادي — راجع تعليق
        // TextRenderer.fontsDir للتفاصيل). modelFile() لأي ModelInfo عادي (بدون مجلد فرعي
        // خاص كـTesseract/Paddle) يرجع مساراً داخل نفس المجلد، فنأخذ .parentFile منه بدل
        // تكرار منطق بناء المسار هنا يدوياً.
        val sampleModel = modelManager.availableModels.find { it.id == "font_amiri_regular" }
        if (sampleModel != null) {
            TextRenderer.fontsDir = modelManager.modelFile(sampleModel).parentFile
        }
    }

    // بند 11 (Module Split): OCREngine/ErasureEngine/ImageEnhanceEngine انتقلوا لموديول
    // feature_ai (Dynamic Feature) — app ما يقدر يعتمد عليهم مباشرة وقت الترجمة بعد الآن.
    // يُحمَّلون هنا وقت التشغيل عبر FeatureAiLoader (Reflection)، ونحتفظ بمرجع nullable
    // بدل `by lazy` عادي عمداً — عشان releaseResources() يقدر يتحقق "هل تم إنشاؤه فعلاً؟"
    // بدون إجبار إنشائه فقط عشان يغلقه (لو المستخدم أغلق التطبيق بدون معالجة أي صفحة).
    private var _ocrEngine: IOcrEngine? = null
    private var _erasureEngine: IErasureEngine? = null
    private var _imageEnhanceEngine: IImageEnhanceEngine? = null

    private fun ocrEngineOrNull(): IOcrEngine? {
        if (_ocrEngine == null) _ocrEngine = FeatureAiLoader.createOcrEngine(context, modelManager)
        return _ocrEngine
    }

    private fun erasureEngineOrNull(): IErasureEngine? {
        if (_erasureEngine == null) _erasureEngine = FeatureAiLoader.createErasureEngine(context, modelManager)
        return _erasureEngine
    }

    private fun imageEnhanceEngineOrNull(): IImageEnhanceEngine? {
        if (_imageEnhanceEngine == null) _imageEnhanceEngine = FeatureAiLoader.createImageEnhanceEngine(context, modelManager)
        return _imageEnhanceEngine
    }

    private val db = AppDatabase.getInstance(context)
    // نظام أخطاء موحّد (Central Error Handling): كل نقطة catch رئيسية تمرّ من هنا بدل
    // كتابة رسالة/تسجيل خاص بها — تصنيف موحّد (OCR/Translation/AI Models/CBZ/Files/
    // Network) + رسالة عربية آمنة للمستخدم + سجل داخلي دوّار يمكن تصديره لاحقاً.
    // 🔍 (2026-08-15) عبر singleton مشترك (AppErrorLog) بدل نسخة خاصة — عشان OCREngine
    // بموديول feature_ai يقدر يستخدم نفس نسخة السجل هذه بالضبط ويظهر بنفس شاشة "السجل"
    // بالواجهة. راجع تعليق AppErrorLog الطويل بـErrorManager.kt لتفاصيل سبب هذا التغيير.
    private val errorManager = com.comictrans.error.AppErrorLog.get(context)

    // ================= إدارة نماذج AI Lite / AI Pro =================

    // ملفات PaddleOCR Lite (det.nb/rec.nb/cls.nb/ppocr_keys_v1.txt) قد تكون فعلياً "مضمّنة"
    // في assets/paddle (لو أُضيفت وقت البناء عبر CI) بدل مُنزَّلة عبر ModelManager. سابقاً
    // كانت واجهة JS تفترض أنها مضمّنة دائماً بدون تحقق فعلي (hardcoded) — نتحقق هنا فعلياً
    // ونرسل الحالة الحقيقية بدل الافتراض.
    private fun isPaddleActuallyBundledInAssets(): Boolean = try {
        val listed = context.assets.list("paddle")?.toSet() ?: emptySet()
        setOf("det.nb", "rec.nb", "cls.nb", "ppocr_keys_v1.txt").all { it in listed }
    } catch (e: Exception) {
        false
    }

    // ================= بند "النسخ الاحتياطي/الاستعادة" للنماذج المحمّلة (2026-08-20) =================
    // راجع التعليق الطويل أعلى ModelManager.exportModelsZip لسبب الحاجة الفعلية لهذا (حذف
    // مساحة التطبيق الخاصة عند إلغاء التثبيت — سلوك نظام تشغيل، لا خطأ بالتطبيق). التدفق:
    // 1) JS يستدعي backupModels()/restoreModels() (زرّان جديدان بقائمة ⚙️ الإعدادات).
    // 2) هنا نُحوِّل الطلب فوراً لـMainActivity.launchModelsBackup/Restore على الخيط الرئيسي
    //    (منتقي ملفات SAF يشترط تشغيله من Activity، لا يعمل من AppInterface مباشرة).
    // 3) بعد اختيار المستخدم فعلياً (ActivityResultLauncher بـMainActivity)، تُستدعى
    //    performModelsBackup/performModelsRestore هنا بالـUri النهائي لتنفيذ القراءة/الكتابة
    //    الفعلية على IO thread (قد تستغرق ثوانٍ لعشرات الملفات — لا يجوز حجب الخيط الرئيسي).
    @JavascriptInterface
    fun backupModels() {
        (context as MainActivity).runOnUiThread { context.launchModelsBackup() }
    }

    @JavascriptInterface
    fun restoreModels() {
        (context as MainActivity).runOnUiThread { context.launchModelsRestore() }
    }

    /** تُستدعى من MainActivity.backupModelsLauncher بعد اختيار المستخدم مكان الحفظ فعلياً. */
    fun performModelsBackup(uri: Uri) {
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            try {
                val count = context.contentResolver.openOutputStream(uri)?.use { out ->
                    modelManager.exportModelsZip(out) { name ->
                        sendToWebView("onModelsBackupProgress", JSONObject().apply { put("file", name) }.toString())
                    }
                } ?: throw java.io.IOException("تعذر فتح الملف الوجهة للكتابة")
                sendToWebView("onModelsBackupDone", JSONObject().apply {
                    put("success", true); put("count", count)
                }.toString())
            } catch (e: Exception) {
                errorManager.handle(e, com.comictrans.error.ErrorCategory.FILE, "فشل النسخ الاحتياطي للنماذج")
                sendToWebView("onModelsBackupDone", JSONObject().apply {
                    put("success", false); put("error", e.message ?: "خطأ غير معروف")
                }.toString())
            }
        }
    }

    /** تُستدعى من MainActivity.restoreModelsLauncher بعد اختيار المستخدم ملف النسخة الاحتياطية. */
    fun performModelsRestore(uri: Uri) {
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            try {
                val result = context.contentResolver.openInputStream(uri)?.use { input ->
                    modelManager.importModelsZip(input) { name ->
                        sendToWebView("onModelsRestoreProgress", JSONObject().apply { put("file", name) }.toString())
                    }
                } ?: throw java.io.IOException("تعذر فتح الملف المصدر للقراءة")
                sendToWebView("onModelsRestoreDone", JSONObject().apply {
                    put("success", true)
                    put("restoredFiles", result.restoredFiles)
                    put("verifiedModels", result.verifiedModels)
                    put("failedModels", JSONArray(result.failedModels))
                }.toString())
                listModels() // تحديث فوري لقائمة "محمّل/غير محمّل" بالواجهة بعد الاستعادة
            } catch (e: Exception) {
                errorManager.handle(e, com.comictrans.error.ErrorCategory.FILE, "فشل استعادة النماذج من النسخة الاحتياطية")
                sendToWebView("onModelsRestoreDone", JSONObject().apply {
                    put("success", false); put("error", e.message ?: "خطأ غير معروف")
                }.toString())
            }
        }
    }

    // ================= بند "حذف النماذج اليتيمة" (2026-08-20) =================
    // راجع التعليق الطويل أعلى ModelManager.findOrphanedFiles للسياق الكامل. زر منفصل بقائمة
    // "⚙️ إدارة النماذج" يفحص أولاً (findOrphanedModelFiles → يعرض القائمة والحجم للمستخدم)
    // ثم يحذف فقط بعد تأكيد صريح (deleteOrphanedModelFiles) — لا حذف تلقائي بصمت بأي حال.
    @JavascriptInterface
    fun findOrphanedModelFiles() {
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            try {
                val orphans = modelManager.findOrphanedFiles()
                val arr = JSONArray()
                var totalBytes = 0L
                orphans.forEach { o ->
                    arr.put(JSONObject().apply { put("path", o.relativePath); put("sizeBytes", o.sizeBytes) })
                    totalBytes += o.sizeBytes
                }
                sendToWebView("onOrphanedModelFiles", JSONObject().apply {
                    put("files", arr); put("totalBytes", totalBytes)
                }.toString())
            } catch (e: Exception) {
                errorManager.handle(e, com.comictrans.error.ErrorCategory.FILE, "فشل فحص الملفات اليتيمة")
            }
        }
    }

    @JavascriptInterface
    fun deleteOrphanedModelFiles() {
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            try {
                val (count, freed) = modelManager.deleteOrphanedFiles()
                sendToWebView("onOrphanedModelFilesDeleted", JSONObject().apply {
                    put("count", count); put("freedBytes", freed)
                }.toString())
            } catch (e: Exception) {
                errorManager.handle(e, com.comictrans.error.ErrorCategory.FILE, "فشل حذف الملفات اليتيمة")
            }
        }
    }

    @JavascriptInterface
    fun listModels() {
        val paddleBundled = isPaddleActuallyBundledInAssets()
        // بناء حالة نماذج ML Kit يحتاج استعلاماً فعلياً من Google Play services (Task غير
        // متزامن)، لذلك أصبحت الدالة كاملة تُبنى وتُرسَل داخل coroutine واحدة بدل إرسال
        // مصفوفتين منفصلتين — الواجهة (window.onModelList) أصلاً غير متزامنة وما تفترض
        // استدعاءً فورياً، فهذا لا يغيّر أي سلوك ظاهر بالواجهة.
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            val arr = JSONArray()
            modelManager.availableModels.forEach { m ->
                val isPaddleFile = m.id.startsWith("paddle_")
                arr.put(JSONObject().apply {
                    put("id", m.id)
                    put("displayName", m.displayName)
                    put("approxSizeMB", m.approxSizeMB)
                    put("hasUrl", m.url.isNotBlank())
                    // لو ملفات Paddle مضمّنة فعلياً في assets وقت البناء، فهي "جاهزة" حتى لو لم
                    // تُنزَّل عبر ModelManager؛ غير ذلك نعتمد فقط على وجودها الفعلي على التخزين.
                    put("downloaded", (isPaddleFile && paddleBundled) || modelManager.isDownloaded(m))
                    put("bundled", isPaddleFile && paddleBundled)
                })
            }
            // حزم Google ML Kit (ترجمة EN/AR محلية) — لا تحتاج أي رابط (راجع MlkitModelManager)،
            // فتظهر بنفس شاشة "إدارة نماذج AI" بجانب AI Lite/AI Pro/PaddleOCR، بزر تنزيل مباشر
            // فعلي بدل أي طلب من المستخدم يلصق رابطاً.
            // 🔍 (2026-08-19، V60) إصلاح جذري ثانٍ لعطل "زر ML Kit لا يعمل": حالة كل حزمة
            // كانت تُستعلَم من Google Play services **داخل حلقة بناء القائمة نفسها**، وبدون
            // أي مهلة — فلو تأخّرت/تعلّقت الخدمة (جهاز بلا Google Play، أو Task لا ينتهي)،
            // لا تُرسَل onModelList إطلاقاً، فتبقى modelsState فارغة بالواجهة، وعندها
            // triggerModelDownload يعتبر النموذج "بلا رابط" ويطلب من المستخدم لصق رابط
            // (وهو أمر لا معنى له لـML Kit) بدل بدء التنزيل. الآن: استعلام واحد بمهلة 8 ثوانٍ،
            // وعند الفشل نفترض "غير مُنزَّلة" ونُكمل إرسال القائمة على أي حال.
            val mlkitDownloadedCodes: Set<String> = try {
                kotlinx.coroutines.withTimeoutOrNull(8000) {
                    mlkitModelManager.downloadedLanguageCodes()
                } ?: emptySet()
            } catch (e: Exception) {
                errorManager.handleMessage(
                    "ML Kit: تعذّر قراءة حالة الحزم المحلية (${e.message}) — ستظهر كغير مُنزَّلة",
                    com.comictrans.error.ErrorCategory.NETWORK,
                    com.comictrans.error.ErrorSeverity.WARNING
                )
                emptySet()
            }
            mlkitModelManager.languages.forEach { info ->
                arr.put(JSONObject().apply {
                    put("id", info.code)
                    put("displayName", info.displayName)
                    put("approxSizeMB", 30) // تقديري — نماذج ترجمة ML Kit لكل لغة عادة قرابة هذا الحجم
                    put("hasUrl", true)
                    put("downloaded", info.code in mlkitDownloadedCodes)
                    put("bundled", false)
                    put("mlkit", true)
                })
            }
            sendToWebView("onModelList", arr.toString())
        }
    }

    @JavascriptInterface
    fun downloadModel(modelId: String) {
        val mlkitInfo = mlkitModelManager.languages.find { it.code == modelId }
        if (mlkitInfo != null) {
            // 🔍 (2026-08-19، V60) إصلاح "زر تحميل الترجمة المحلية (ML Kit) لا يعمل":
            //  - لم تكن تُرسَل أي حالة DOWNLOADING إطلاقاً، فصف النموذج بالواجهة يبقى على زر
            //    "⬇️ تنزيل" بلا أي تغيير مرئي — يبدو الزر "ميتاً" رغم أن الطلب انطلق فعلاً.
            //  - ولا يوجد أي منع لتكرار الضغط، فكل ضغطة تُطلق طلب تنزيل جديد بالتوازي.
            if (!mlkitDownloading.add(modelId)) return
            sendModelDownloadState(
                com.comictrans.engine.DownloadStatus(
                    modelId, com.comictrans.engine.DownloadState.DOWNLOADING, 5,
                    "جارٍ التنزيل عبر Google Play services…"
                )
            )
            (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
                val result = mlkitModelManager.download(mlkitInfo)
                mlkitDownloading.remove(modelId)
                result.fold(
                    onSuccess = {
                        sendModelDownloadState(
                            com.comictrans.engine.DownloadStatus(
                                modelId, com.comictrans.engine.DownloadState.COMPLETED, 100,
                                "تم تنزيل ${mlkitInfo.displayName} بنجاح"
                            )
                        ) // COMPLETED/FAILED يُصدران رسالة onModelStatus تلقائياً — لا نكرّرها هنا
                    },
                    onFailure = { err ->
                        sendModelDownloadState(
                            com.comictrans.engine.DownloadStatus(
                                modelId, com.comictrans.engine.DownloadState.FAILED, 0,
                                "فشل تنزيل ${mlkitInfo.displayName}: " +
                                    (err.message ?: "تأكد من الاتصال وتوفّر خدمات Google Play")
                            )
                        )
                    }
                )
            }
            return
        }
        val model = modelManager.availableModels.find { it.id == modelId } ?: run {
            sendModelStatus(modelId, false, "نموذج غير معروف")
            return
        }
        // startDownload() نفسها تكتشف تلقائياً وجود ملف .part من محاولة سابقة (متوقفة أو
        // Paused) وتُكمل منه (Resume)، وتمنع بدء تنزيل ثانٍ لو نفس النموذج قيد التنزيل فعلاً.
        modelManager.startDownload(model) { status -> onModelDownloadUpdate(modelId, model.displayName, status) }
    }

    /** يوقف تنزيل نموذج مؤقتاً — الملف الجزئي يبقى محفوظاً لاستئنافه لاحقاً. */
    @JavascriptInterface
    fun pauseModelDownload(modelId: String) {
        // حزم ML Kit تُنزَّل داخلياً عبر Google Play services — لا يوجد إيقاف مؤقت حقيقي لها،
        // فنكتفي بإيقاف متابعتها بالواجهة بدل استدعاء ModelManager بمعرّف لا يعرفه أصلاً.
        if (mlkitDownloading.remove(modelId)) {
            sendModelDownloadState(com.comictrans.engine.DownloadStatus(modelId, com.comictrans.engine.DownloadState.NONE, message = "أُوقفت متابعة تنزيل حزمة ML Kit"))
            return
        }
        modelManager.pauseDownload(modelId)
        sendModelDownloadState(com.comictrans.engine.DownloadStatus(modelId, com.comictrans.engine.DownloadState.PAUSED, message = "تم إيقاف التنزيل مؤقتاً"))
    }

    /** يستأنف تنزيلاً متوقفاً (Paused) أو غير مكتمل — نفس منطق downloadModel بالضبط. */
    @JavascriptInterface
    fun resumeModelDownload(modelId: String) = downloadModel(modelId)

    /** يلغي التنزيل نهائياً ويحذف أي ملف جزئي — بعكس pauseModelDownload لا يمكن استئنافه بعدها. */
    @JavascriptInterface
    fun cancelModelDownload(modelId: String) {
        if (mlkitDownloading.remove(modelId)) {
            sendModelDownloadState(com.comictrans.engine.DownloadStatus(modelId, com.comictrans.engine.DownloadState.NONE, message = "أُلغيت متابعة التنزيل"))
            return
        }
        modelManager.cancelDownload(modelId)
        sendModelDownloadState(com.comictrans.engine.DownloadStatus(modelId, com.comictrans.engine.DownloadState.NONE, message = "أُلغي التنزيل"))
    }

    private fun onModelDownloadUpdate(modelId: String, displayName: String, status: com.comictrans.engine.DownloadStatus) {
        sendModelDownloadState(status)
        // نحافظ على توافق الأحداث القديمة (onModelProgress/onModelStatus) حتى لا تنكسر أي
        // شاشة تعتمد عليها فقط، بجانب الحدث الجديد onModelDownloadState الأغنى بالحالة.
        when (status.state) {
            com.comictrans.engine.DownloadState.DOWNLOADING, com.comictrans.engine.DownloadState.VERIFYING ->
                sendModelProgress(modelId, status.progressPct)
            com.comictrans.engine.DownloadState.COMPLETED ->
                sendModelStatus(modelId, true, status.message ?: "تم تنزيل $displayName بنجاح")
            com.comictrans.engine.DownloadState.FAILED ->
                sendModelStatus(modelId, false, status.message ?: "فشل التنزيل")
            else -> {}
        }
    }

    private fun sendModelDownloadState(status: com.comictrans.engine.DownloadStatus) {
        val json = JSONObject().apply {
            put("id", status.modelId)
            put("state", status.state.name)
            put("progress", status.progressPct)
            put("message", status.message ?: "")
        }
        sendToWebView("onModelDownloadState", json.toString())
    }

    @JavascriptInterface
    fun deleteModel(modelId: String) {
        val mlkitInfo = mlkitModelManager.languages.find { it.code == modelId }
        if (mlkitInfo != null) {
            (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
                val result = mlkitModelManager.delete(mlkitInfo)
                result.fold(
                    onSuccess = { sendModelStatus(modelId, true, "تم حذف ${mlkitInfo.displayName}") },
                    onFailure = { err -> sendModelStatus(modelId, false, err.message ?: "فشل الحذف") }
                )
            }
            return
        }
        val model = modelManager.availableModels.find { it.id == modelId } ?: return
        modelManager.delete(model)
        sendModelStatus(modelId, true, "تم حذف ${model.displayName}")
    }

    @JavascriptInterface
    fun setModelUrl(modelId: String, url: String) {
        modelManager.setCustomUrl(modelId, url)
        listModels()
    }

    private fun sendModelProgress(modelId: String, pct: Int) {
        val json = JSONObject().apply { put("id", modelId); put("progress", pct) }
        sendToWebView("onModelProgress", json.toString())
    }

    private fun sendModelStatus(modelId: String, success: Boolean, message: String) {
        val json = JSONObject().apply {
            put("id", modelId); put("success", success); put("message", message)
        }
        sendToWebView("onModelStatus", json.toString())
    }

    // Performance architecture: CBZ pages are extracted once by Kotlin and served from
    // the local comic.local URL. startProcessing receives only the page index + settings;
    // the page Bitmap is decoded directly from the native cache.
    @JavascriptInterface
    fun isNativeFileImportEnabled(): Boolean = true

    /** Native CBZ/ZIP reader. JavaScript only renders the pages; it never unpacks the archive. */
    fun loadComicFromUri(uri: Uri, displayName: String) {
        // فتح ملف جديد يُلغي أي فك أرشيف سابق لم ينتهِ + أي معالجة جارية على الملف القديم،
        // قبل حذف مجلد الصفحات — وإلا يكتب المسار القديم في مجلد حُذف/أُعيد إنشاؤه.
        loadJob?.cancel()
        stopProcessing()
        nativePageFiles = emptyList()
        loadJob = (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            try {
                val root = File(context.cacheDir, "comic_pages")
                root.deleteRecursively()
                root.mkdirs()
                processedPageRoot.deleteRecursively()
                processedPageRoot.mkdirs()
                val extracted = ArrayList<Pair<String, File>>()
                var totalBytes = 0L
                context.contentResolver.openInputStream(uri)?.use { input ->
                    ZipInputStream(input.buffered(128 * 1024)).use { zip ->
                        var entry = zip.nextEntry
                        while (entry != null) {
                            if (!entry.isDirectory && isImageEntry(entry.name)) {
                                val safeName = "page_${extracted.size.toString().padStart(6, '0')}_${safeExtension(entry.name)}"
                                val outFile = File(root, safeName)
                                var written = 0L
                                outFile.outputStream().buffered(128 * 1024).use { out ->
                                    val buffer = ByteArray(128 * 1024)
                                    while (true) {
                                        val n = zip.read(buffer)
                                        if (n <= 0) break
                                        written += n
                                        totalBytes += n
                                        if (totalBytes > 512L * 1024L * 1024L) throw IllegalStateException("CBZ كبير جداً (الحد 512MB)")
                                        out.write(buffer, 0, n)
                                    }
                                }
                                if (written > 0) extracted.add(entry.name to outFile)
                            }
                            zip.closeEntry()
                            entry = zip.nextEntry
                        }
                    }
                } ?: throw IllegalStateException("تعذرت قراءة ملف CBZ")

                val sorted = extracted.sortedWith { p1, p2 -> compareByNatural(p1.first, p2.first) }
                nativePageFiles = sorted.map { it.second }
                nativeComicTitle = displayName
                if (nativePageFiles.isEmpty()) throw IllegalStateException("لم يتم العثور على صور داخل CBZ")
                // بصمة خفيفة (اسم الملف + عدد الصفحات + الحجم الكلي) بدل هاش SHA256 كامل
                // للملف — تجنّباً لقراءة كل الـ512MB مرة إضافية فقط للتجزئة، مع بقاء البصمة
                // مميّزة عملياً بما يكفي للتفريق بين كوميكسات مختلفة بنفس الاسم تقريباً.
                nativeComicHash = java.security.MessageDigest.getInstance("SHA-256")
                    .digest("$displayName|${nativePageFiles.size}|$totalBytes".toByteArray())
                    .joinToString("") { "%02x".format(it) }

                val json = JSONObject().apply {
                    put("title", nativeComicTitle)
                    put("count", nativePageFiles.size)
                    put("baseUrl", "https://comic.local/page/")
                }
                sendToWebView("onNativeComicLoaded", json.toString())
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                val err = errorManager.handle(e, com.comictrans.error.ErrorCategory.CBZ, "فشل فتح ملف الكوميك")
                sendError(-1, err.userMessage)
            }
        }
    }

    private fun isImageEntry(name: String): Boolean =
        !name.contains("__MACOSX", ignoreCase = true) &&
            name.substringAfterLast('/').matches(Regex("(?i).+\\.(jpg|jpeg|png|webp|gif|bmp)$"))

    private fun safeExtension(name: String): String {
        val ext = name.substringAfterLast('.', "jpg").lowercase(Locale.ROOT)
        return if (ext in setOf("jpg", "jpeg", "png", "webp", "gif", "bmp")) ext else "jpg"
    }

    private fun compareByNatural(a: String, b: String): Int {
        val pattern = Regex("\\d+")
        val at = pattern.findAll(a).toList()
        val bt = pattern.findAll(b).toList()
        var posA = 0
        var posB = 0
        val parts = maxOf(at.size, bt.size)
        for (i in 0 until parts) {
            val aNum = at.getOrNull(i)?.value?.toLongOrNull()
            val bNum = bt.getOrNull(i)?.value?.toLongOrNull()
            if (aNum != null && bNum != null && aNum != bNum) return aNum.compareTo(bNum)
            val aText = if (i < at.size) a.substring(posA, at[i].range.first) else a.substring(posA)
            val bText = if (i < bt.size) b.substring(posB, bt[i].range.first) else b.substring(posB)
            val textCmp = aText.compareTo(bText, ignoreCase = true)
            if (textCmp != 0) return textCmp
            if (i < at.size) posA = at[i].range.last + 1
            if (i < bt.size) posB = bt[i].range.last + 1
        }
        return a.substring(posA).compareTo(b.substring(posB), ignoreCase = true)
    }

    fun getNativePageFile(index: Int): File? = nativePageFiles.getOrNull(index)

    fun getProcessedPageFile(index: Int): File? {
        val file = File(processedPageRoot, "page_${index}.jpg")
        return file.takeIf { it.exists() && it.isFile && it.length() > 0L }
    }

    @JavascriptInterface
    fun startProcessing(pageIndex: Int, settingsJson: String) {
        if (isProcessing) return
        isProcessing = true
        shouldStop = false
        val settings = gson.fromJson(settingsJson, SettingsData::class.java)
        val file = nativePageFiles.getOrNull(pageIndex)
        processingJob = (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            if (file == null || !file.exists()) {
                sendError(pageIndex, "صورة الصفحة غير متوفرة")
                isProcessing = false
                return@launch
            }
            processPage(pageIndex, file, settings)
        }
    }

    @JavascriptInterface
    fun stopProcessing() {
        shouldStop = true
        isProcessing = false
        processingJob?.cancel()
        processingJob = null
    }

    /**
     * 🔍 (2026-08-19، V60) "إيقاف كل العمليات" — طلب صريح: زر واحد يوقف **كل شيء** فعلياً،
     * لا مجرد الصفحة الحالية:
     *  1) معالجة الصفحة/الترجمة الجارية (إلغاء الـcoroutine نفسها، لا مجرد راية shouldStop).
     *  2) فك أرشيف CBZ لو كان لا يزال جارياً.
     *  3) كل تنزيلات النماذج الجارية (إيقاف مؤقت — الملفات الجزئية تبقى للاستئناف لاحقاً).
     * ثم يُبلِغ الواجهة (onAllStopped) لتصفير أزرارها وحلقة "ترجمة الكل".
     */
    @JavascriptInterface
    fun stopAllOperations() {
        stopProcessing()
        loadJob?.cancel()
        loadJob = null
        var pausedCount = 0
        modelManager.availableModels.forEach { m ->
            if (modelManager.isDownloading(m.id)) {
                modelManager.pauseDownload(m.id)
                pausedCount++
                sendModelDownloadState(
                    com.comictrans.engine.DownloadStatus(
                        m.id, com.comictrans.engine.DownloadState.PAUSED,
                        message = "أُوقف مؤقتاً ضمن إيقاف كل العمليات"
                    )
                )
            }
        }
        mlkitDownloading.toList().forEach { id ->
            mlkitDownloading.remove(id)
            sendModelDownloadState(
                com.comictrans.engine.DownloadStatus(
                    id, com.comictrans.engine.DownloadState.NONE,
                    message = "أُلغيت متابعة تنزيل حزمة ML Kit"
                )
            )
        }
        sendToWebView("onAllStopped", JSONObject().apply {
            put("pausedDownloads", pausedCount)
        }.toString())
    }

    // يُستدعى من MainActivity.onDestroy لتحرير جلسة ONNX/مفسّر TFLite المُخزَّنين مؤقتاً،
    // ولإلغاء أي تنزيل نماذج لا يزال جارياً (بدون حذف ملفاته الجزئية — تُستأنف لاحقاً).
    fun releaseResources() {
        _erasureEngine?.close()
        modelManager.release()
    }

    // 🔍 (2026-08-17) كانت هذه الدالة تكتب لـLogcat فقط (Log.d) رغم أن الجسر (AndroidBridge)
    // موجود ومُسجَّل بالفعل بـMainActivity — لم يكن هناك أي طريقة لرسائل JS تصل لشاشة
    // "📋 السجل" الحقيقية (المُغذّاة من errorManager.recentLogsText()، راجع getRecentLogs
    // أدناه). الآن تُمرَّر أيضاً لـerrorManager — بنفس مستوى WARNING المُستخدَم فعلاً بكل
    // رسائل التشخيص/الخطوات المشابهة بـOCREngine.kt (سواء نجاح أو تراجع)، اتّساقاً مع نفس
    // الاتفاقية المُتَّبَعة أصلاً بالكود، بدل إضافة مستوى جديد (INFO) قد يكسر أي when()
    // مطابقة شاملة (exhaustive) لـErrorSeverity بمكان آخر.
    @JavascriptInterface
    fun logFromJS(message: String) {
        Log.d("ComicJS", message)
        errorManager.handleMessage(message, com.comictrans.error.ErrorCategory.UNKNOWN, com.comictrans.error.ErrorSeverity.WARNING)
    }

    /** آخر أسطر السجل الموحّد (ErrorManager) — يفيد لعرض سجل تشخيصي داخل التطبيق عند الحاجة. */
    @JavascriptInterface
    fun getRecentLogs(): String = errorManager.recentLogsText()

    // 🔍 (2026-08-15) زر "مسح ذاكرة الترجمة" الجديد بالإعدادات (طلب المستخدم صراحة). يحذف:
    // 1) جدول translations كاملاً (ذاكرة الترجمة الذكية — نص→ترجمة سابقة لكل المحركات).
    // 2) جدول page_cache كاملاً (كاش صفحات كاملة مُعالَجة — OCR+ترجمة+طمس معاً) عبر كل
    //    الكوميكسات المفتوحة سابقاً، **و**الصور الدائمة المرتبطة بها (page_cache_images).
    // الرد يصل عبر onMemoryCleared(success:Boolean). 🔍 (2026-08-19) جدول comic_dictionary
    // لم يعد مستخدَماً أصلاً (حُذفت ميزة القاموس من الواجهة بطلب المستخدم) لكنه يُترَك
    // هنا دون مسح — بيانات ميتة غير ضارة، وحذفها لا يغيّر أي سلوك ظاهر.
    // 🔍 (تصحيح لاحق بطلب المستخدم): هذا الزر يمسح **الذاكرة المحفوظة فقط** (قاعدتا
    // البيانات أعلاه) — لا يمس processedPageRoot (كاش الجلسة الحالية) ولا يُرسِل أي أمر
    // للواجهة يُصفّر عرض الصفحات المفتوحة حالياً بالملف الحالي. سابقاً كان يحذف
    // processedPageRoot أيضاً ويُصفّر كل صفحة مفتوحة بالواجهة فوراً (canvas/blocks) —
    // المستخدم وضّح أنه يريد فقط مسح الذاكرة المحفوظة (يؤثر على كوميكسات تُفتَح لاحقاً)،
    // بدون أي أثر فوري على الملف المفتوح الآن في الشاشة.
    @JavascriptInterface
    fun clearAllMemory() {
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            try {
                db.translationDao().deleteAll()
                db.pageCacheDao().deleteAll()
                File(context.filesDir, "page_cache_images").deleteRecursively()
                File(context.filesDir, "page_cache_images").mkdirs()
                // 🔍 (2026-08-18) إصلاح إضافي — طلب المستخدم صراحة "مسح ذاكرة الترجمة
                // بالكامل". الحذف عبر DAO (DELETE FROM ...) يُزيل الصفوف منطقياً فقط —
                // SQLite لا يُقلّص حجم ملف قاعدة البيانات نفسه على القرص تلقائياً (الصفحات
                // المحذوفة تبقى محجوزة بـ"free list" داخلي لإعادة استخدام مستقبلي). هذا لا
                // يُفقِد أي بيانات ولا يظهر كخلل وظيفي، لكنه يعني تقنياً أن "المسح الكامل"
                // لم يكن يُحرِّر مساحة القرص فعلياً رغم أن كل الصفوف اختفت من نتائج
                // الاستعلامات — VACUUM يعيد كتابة الملف فعلياً بأصغر حجم ممكن. آمن الاستدعاء
                // هنا لأنه يأتي بعد اكتمال الحذفين بالأعلى مباشرة (لا معاملة/transaction
                // مفتوحة وقتها — VACUUM يرفض العمل داخل transaction نشطة).
                try {
                    db.openHelper.writableDatabase.execSQL("VACUUM")
                } catch (e: Exception) {
                    Log.w("ComicApp", "تعذّر تنفيذ VACUUM بعد مسح الذاكرة (غير حرج — البيانات محذوفة فعلياً، فقط لم تُحرَّر مساحة القرص فوراً): ${e.message}")
                }
                sendToWebView("onMemoryCleared", JSONObject().apply { put("success", true) }.toString())
            } catch (e: Exception) {
                errorManager.handle(e, com.comictrans.error.ErrorCategory.FILE, "فشل مسح ذاكرة الترجمة")
                sendToWebView("onMemoryCleared", JSONObject().apply { put("success", false) }.toString())
            }
        }
    }

    private suspend fun processPage(pageIndex: Int, imageFile: File, settings: SettingsData) {
        val fingerprint = pageSettingsFingerprint(settings)
        // 🔍 (2026-08-20) إصلاح جذري لبلاغ "التطبيق يعلّق/يتهنّج أثناء أو بعد الترجمة، حتى
        // الجوال بالكامل": السبب الجذري المؤكَّد بمراجعة هذه الدالة كاملة هو **تسريب ذاكرة
        // Bitmap حقيقي** — لا علاقة له بـ"ذاكرة الترجمة" (translationDao/pageCacheDao، تلك
        // كانت مُدقَّقة سابقاً وصحيحة، راجع HANDOFF). كل استدعاء لهذه الدالة (أي أثناء معالجة
        // أو "ترجمة الكل" — يعني عشرات الاستدعاءات المتتالية لصفحات كوميك) يفك ترميز bitmap
        // كامل الصفحة (حتى 3000×3000 بكسل ARGB_8888 ≈ 36MB)، وأحياناً bitmap ثانٍ أكبر بكثير
        // (`ocrBitmap` من محرك تحسين الصورة AI — Real-ESRGAN مثلاً يكبّر الأبعاد فعلياً) —
        // ولم يكن أي من الاثنين يُحرَّر (`.recycle()`) في أي مسار من الدالة **إطلاقاً** بعد
        // الاستخدام (فقط `processedFill`/`finalBitmap`، وهما نسخ منفصلة مُشتقة، كانتا
        // تُحرَّران). الاعتماد كان فقط على GC التلقائي لأندرويد، الذي لا يعمل بالسرعة الكافية
        // مع bitmaps كبيرة متتالية بلا `.recycle()` صريح — النتيجة تراكم ذاكرة فعلي يزداد مع
        // كل صفحة أثناء "ترجمة الكل"، وينتهي إما بـتهنّج/تجمّد ملحوظ (ضغط GC متكرر) أو
        // OutOfMemoryError صريح على الصفحات الأخيرة من كوميك طويل. الإصلاح: `finally` صريح
        // يُحرِّر كلا الـbitmap في **كل** مسار خروج من الدالة (نجاح، فشل، توقف، أو أي عودة
        // مبكرة أخرى) — بدل الاعتماد على GC وحده أو تتبّع كل نقطة خروج يدوياً (كثيرة وسهلة نسيان واحدة منها مستقبلاً).
        var bitmapRef: android.graphics.Bitmap? = null
        var ocrBitmapRef: android.graphics.Bitmap? = null
        try {
            // Cache (بند 5): تفادي إعادة معالجة نفس الصفحة (OCR+ترجمة+طمس) لو سبق معالجتها
            // بنفس الكوميك ونفس رقم الصفحة ونفس بصمة إعدادات المعالجة بالضبط.
            // 🔍 (تصحيح لاحق بطلب المستخدم): مقيَّد الآن بـsettings.useMemory ("استخدم الذاكرة
            // الذكية") — لو المستخدم عطّل الخيار، لازم كل ضغطة ترجمة (صفحة حالية أو الكل)
            // تُعيد كل شيء من الصفر (قراءة OCR + ترجمة + تحسين/طمس) بدون أي اعتماد على كاش
            // سابق، بنفس منطق ذاكرة الترجمة النصية (translationDao) أدناه بدالة
            // translateBlocksWithMemory اللي كانت مقيَّدة بهذا الشرط أصلاً.
            if (settings.useMemory && nativeComicHash.isNotBlank()) {
                val cached = db.pageCacheDao().find(nativeComicHash, pageIndex, fingerprint)
                if (cached != null && serveFromCache(pageIndex, cached, settings)) return
            }

            // 1. OCR
            sendStatus(pageIndex, "ocr", 0)

            // *** إصلاح جذري: "لو الملف كبير لا يترجم" ***
            // كان هنا BitmapFactory.decodeFile(path) بدون أي حد لأبعاد الصورة — يفك الترميز
            // بالحجم الأصلي بالكامل في الذاكرة (عرض×ارتفاع×4 بايت لكل بكسل بصيغة ARGB_8888).
            // صفحة كوميك ممسوحة ضوئياً بدقة عالية (300dpi فأعلى) أو صورة webtoon طويلة جداً
            // يسهل أن تتجاوز 4000×6000 بكسل = ~96MB لنسخة واحدة فقط، قبل أي نسخ إضافية
            // (تعزيز/OCR/طمس OpenCV تنشئ نسخاً موازية). هذا يستنزف حد الذاكرة المسموح للتطبيق
            // (عادة 256-512MB) ويرمي OutOfMemoryError — وأحياناً يقتل نظام أندرويد العملية
            // بالكامل مباشرة (low-memory killer) قبل أن يصل الاستثناء لأي catch، فتبدو النتيجة
            // للمستخدم وكأن التطبيق "لا يترجم" بصمت. الحل: decodeBitmapBounded() تفحص الأبعاد
            // أولاً (inJustDecodeBounds) بدون تحميل أي بيانات فعلية، ثم تفك الترميز بعامل تصغير
            // (inSampleSize) يحصر أطول بعد عند MAX_PAGE_DIMENSION — كافٍ جداً لجودة OCR/طمس
            // ممتازة، ويقي من OOM على أي جهاز عملياً.
            val decodedPage = decodeBitmapBounded(imageFile) ?: run {
                sendError(pageIndex, "تعذر قراءة صورة الصفحة (قد تكون تالفة أو كبيرة جداً على ذاكرة الجهاز)")
                return
            }
            val bitmap = decodedPage.bitmap
            bitmapRef = bitmap
            val decodeScale = decodedPage.decodeScale

            // تعزيز الصورة قبل OCR (اختياري) — يُستخدم فقط لتحسين دقة القراءة، والصورة
            // الأصلية تبقى كما هي لخطوات الطمس والعرض لاحقاً.
            val enhanceResult = if (settings.enhanceImage) {
                val engine = imageEnhanceEngineOrNull()
                if (engine == null) {
                    sendWarning(pageIndex, "موديول الذكاء الاصطناعي (feature_ai) غير متاح — تم تخطي تحسين الصورة")
                    null
                } else {
                    sendStatus(pageIndex, "enhance", 0)
                    val r = engine.enhance(bitmap, settings.enhanceMethod)
                    sendStatus(pageIndex, "enhance", 100)
                    r
                }
            } else null
            val ocrBitmap = enhanceResult?.bitmap ?: bitmap
            if (ocrBitmap !== bitmap) ocrBitmapRef = ocrBitmap
            val enhanceScale = enhanceResult?.scale ?: 1f

            val ocrEngine = ocrEngineOrNull()
            if (ocrEngine == null) {
                sendError(pageIndex, "موديول الذكاء الاصطناعي (feature_ai) غير مثبَّت أو تعذر تحميله — تعذّر تشغيل التعرّف الضوئي على النص")
                isProcessing = false
                return
            }
            // 🔍 (2026-08-21) حُذفت فروع "tesseract"/"easyocr" نهائياً مع حذف Tesseract/
            // EasyOCR/CRAFT Mobile/EAST بالكامل بطلب المستخدم — كل محرك OCR متبقٍّ عنده
            // كاشفه المدمج الخاص فعلياً. إعدادات محفوظة قديمة بهاتين القيمتين تسقط تلقائياً
            // على else (ML Kit) بأمان.
            val rawBlocks = when (settings.ocrEngine) {
                "paddle_lite" -> ocrEngine.recognizePaddleLite(ocrBitmap)
                "mlkit" -> ocrEngine.recognizeMLKit(ocrBitmap)
                "ocr_local_llm" -> ocrEngine.recognizeLocalLlm(ocrBitmap, settings.ocrLocalApiUrl, settings.ocrLocalApiKey, settings.ocrLocalModel)
                "cloud" -> ocrEngine.recognizeCloud(ocrBitmap, settings.cloudApiUrl)
                else -> ocrEngine.recognizeMLKit(ocrBitmap)
            }
            // ✅ (2026-08-20) تحرير مبكر لـocrBitmap فور انتهاء استخدامه الوحيد (OCR) — لا حاجة
            // للانتظار لنهاية الدالة (راجع تعليق bitmapRef/ocrBitmapRef الطويل أعلى بداية هذه
            // الدالة). مهم خصوصاً لو enhanceImage=true مع محرك AI يكبّر الأبعاد فعلياً (Real-
            // ESRGAN) — يُحرَّر أكبر bitmap بالدالة **قبل** خطوة الترجمة (شبكية، قد تستغرق
            // ثوانٍ لكل فقاعة)، بدل إبقائه بالذاكرة بلا فائدة طوال تلك الفترة.
            if (ocrBitmap !== bitmap && !ocrBitmap.isRecycled) {
                ocrBitmap.recycle()
                ocrBitmapRef = null
            }
            // لو التعزيز كبّر أبعاد الصورة (وضع AI)، ولو الصفحة أصلاً صُغِّرت قبل OCR
            // (decodeScale > 1، صفحات كبيرة — راجع تعليق decodeBitmapBounded/DecodedPage
            // أعلاه لسبب هذا الإصلاح)، نرجّع إحداثيات الكتل لمقياس الملف الأصلي على القرص
            // (نفس المقياس اللي تعرضه JS دائماً بدون أي تصغير من عندها).
            // ⚠️ الاتجاه صحيح: totalScale = enhanceScale/decodeScale (لا enhanceScale*decodeScale
            // — جرَّبتها مضروبة أول مرة وطلعت معكوسة تماماً بمثال رقمي: تصغير أصلي 2x بدون
            // تعزيز كان سينتج إحداثيات نصف الصحيح بدل ضعفها). enhanceScale يُكبِّر أبعاد
            // ocrBitmap فوق bitmap (يبعّد عن الأصل، فيحتاج قسمة)، وdecodeScale يُصغِّر bitmap
            // تحت الأصل (يقرِّب من الأصل بمقدار decodeScale، فيحتاج ضرب — أي قسمة على
            // 1/decodeScale — ولذلك القسمة الإجمالية على enhanceScale/decodeScale).
            val totalScale = if (decodeScale > 0f) enhanceScale / decodeScale else enhanceScale
            val blocks = if (totalScale != 1f) {
                rawBlocks.map {
                    it.copy(
                        x = (it.x / totalScale).toInt(),
                        y = (it.y / totalScale).toInt(),
                        width = (it.width / totalScale).toInt(),
                        height = (it.height / totalScale).toInt()
                    )
                }
            } else rawBlocks

            // *** إصلاح إضافي: تسريب isProcessing عند التوقف اليدوي ***
            // نقطتا الخروج المبكر هذي (shouldStop=true) كانتا تنسيان تصفير isProcessing —
            // لو المستخدم ضغط "إيقاف" لحظة وصول الكود لإحدى هاتين النقطتين بالضبط، يبقى
            // isProcessing=true للأبد ويرفض startProcessing() أي صفحة جديدة حتى إعادة
            // تشغيل التطبيق. الآن نصفّره بكل نقاط الخروج المبكر بجانب المسارين الأساسيين
            // (النجاح والخطأ) بالأسفل.
            if (shouldStop) { sendStopped(pageIndex); isProcessing = false; return }
            sendStatus(pageIndex, "ocr", 100)

            // 🔍 (2026-08-19) تبسيط بطلب المستخدم: حُذفت حقول "نوع الكوميكس"/"اسم السلسلة"/
            // "قاموس مصطلحات الكوميكس" من الواجهة بالكامل — الـsystem prompt الآن عام واحد
            // (لغة الهدف فقط) بدل تركيبة من ثلاثة مدخلات. راجع PromptManager.kt.
            val targetLangName = if (settings.targetLang == "ar") "Arabic" else settings.targetLang
            val systemPrompt = com.comictrans.engine.PromptManager.buildSystemPrompt(targetLangName)

            // 2. Translation (بند 6: سياق الصفحة/Batch لمحركات LLM، مع رجوع تلقائي لفقاعة-فقاعة)
            sendStatus(pageIndex, "translate", 0)
            val warnedThisPage = java.util.concurrent.atomic.AtomicBoolean(false)
            val translatedBlocks = translatePageBlocks(pageIndex, blocks, settings, systemPrompt, warnedThisPage)

            if (shouldStop) { sendStopped(pageIndex); isProcessing = false; return }

            // 3. Erasure
            sendStatus(pageIndex, "erasure", 0)
            val erasureData = when (settings.erasureMode) {
                "fill" -> {
                    // ✅ نُقِل هذه الدفعة من JS Canvas إلى Kotlin أصلياً (راجع TextRenderer.kt
                    // — أول تفعيل فعلي لمحرك رسم نص Kotlin بهذا المشروع). كان "fill" سابقاً
                    // "block_coords" فقط (إحداثيات خام، ترسم HTML النص فوقها بمقياس/موضع قد
                    // يختلف عن مقياس OCR الفعلي — هذا بالضبط سبب بلاغ "النص يخرج عن مكانه"
                    // الموثَّق بمحادثة سابقة، رغم أن تلك الدفعة أصلحت جزءاً من المشكلة بمواءمة
                    // الإحداثيات نفسها لا مصدر الرسم). الآن Kotlin يمسح النص القديم بلون حواف
                    // الفقاعة الحقيقي (نفس منطق sampleEdgeColor بـJS منقولاً حرفياً) ويرسم
                    // الترجمة فوقه على نفس bitmap المُستخدَم فعلياً لـOCR — لا احتمال تفاوت
                    // مقياس بين الكشف والرسم إطلاقاً بعد الآن، لأنهما نفس الصورة بالضبط.
                    val processedFill = try {
                        TextRenderer.eraseAndDrawFill(bitmap, translatedBlocks, settings)
                    } catch (e: Throwable) {
                        errorManager.handle(e, com.comictrans.error.ErrorCategory.UNKNOWN, "فشل رسم النص الأصلي (Kotlin) — رجوع لرسم JS الاحتياطي")
                        null
                    }
                    if (processedFill != null) {
                        val processedFile = File(processedPageRoot, "page_${pageIndex}.jpg")
                        processedFile.outputStream().buffered(128 * 1024).use { out ->
                            if (!processedFill.compress(android.graphics.Bitmap.CompressFormat.JPEG, 92, out)) {
                                throw IllegalStateException("تعذر حفظ الصورة المعالجة")
                            }
                        }
                        processedFill.recycle()
                        listOf(JSONObject().apply {
                            put("type", "full_page")
                            put("processedUrl", "https://comic.local/processed/$pageIndex?v=${System.currentTimeMillis()}")
                            put("textBlocks", JSONArray())
                            put("textBaked", true) // ⚠️ يخبر JS ألا يعيد رسم النص فوق الصورة (راجع renderPage بـindex.html)
                            put("mode", settings.erasureMode)
                        })
                    } else {
                        // رجوع احتياطي كامل لمسار JS القديم لو فشل الرسم الأصلي لأي سبب —
                        // الصفحة لا تفشل كاملة أبداً بسبب مشكلة برسم النص وحده.
                        translatedBlocks.map { block ->
                            JSONObject().apply {
                                put("x", block.x); put("y", block.y)
                                put("width", block.width); put("height", block.height)
                                put("translatedText", block.translatedText)
                                put("mode", settings.erasureMode); put("type", "block_coords")
                            }
                        }
                    }
                }
                "blur" -> {
                    // ⚠️ لم يُنقَل هذه الدفعة — يبقى "blur" الوضع الوحيد المرسوم بالكامل عبر
                    // JS Canvas بمتصفح WebView (ctx.filter='blur(8px)'). السبب: لا مكافئ مباشر
                    // بسيط لـCSS blur filter بـandroid.graphics.Canvas بدون RenderScript (مهمل
                    // رسمياً بأندرويد الحديث) أو مكتبة طمس صور خارجية جديدة — تأجيله مقصود لعدم
                    // إضافة اعتمادية جديدة أو خوارزمية طمس مخمَّنة غير مؤكَّدة بصرياً بهذه الجلسة.
                    translatedBlocks.map { block ->
                        JSONObject().apply {
                            put("x", block.x)
                            put("y", block.y)
                            put("width", block.width)
                            put("height", block.height)
                            put("translatedText", block.translatedText)
                            put("mode", settings.erasureMode)
                            put("type", "block_coords")
                        }
                    }
                }
                "opencv", "migan" -> {
                    // Native processing returns a Bitmap. Store it in cache and expose only a
                    // local WebView URL, never a multi-megabyte Base64 string over the JS bridge.
                    val engine = erasureEngineOrNull()
                    if (engine == null) {
                        sendError(pageIndex, "موديول الذكاء الاصطناعي (feature_ai) غير مثبَّت أو تعذر تحميله — تعذّر الطمس")
                        isProcessing = false
                        return
                    }
                    val processed = engine.processBitmap(bitmap, translatedBlocks, settings.erasureMode, settings.bubbleAwareErasure)
                    // ✅ نُقِل هذه الدفعة: النص المترجم يُرسَم الآن أصلياً بـKotlin (TextRenderer)
                    // فوق نفس bitmap المُعالَج مباشرة، بدل تمرير الإحداثيات فقط لـJS لترسمه
                    // لاحقاً على صورة مُحمَّلة من ملف — هذا يزيل خطوة كاملة كانت مصدراً محتملاً
                    // لأي تفاوت مقياس/توقيت مستقبلي، بنفس روح إصلاح "fill" أعلاه بالضبط.
                    var textBaked = false
                    val finalBitmap = if (processed != null) {
                        try {
                            val mutable = if (processed.isMutable) processed else processed.copy(android.graphics.Bitmap.Config.ARGB_8888, true)
                            TextRenderer.drawTranslatedText(mutable, translatedBlocks, settings)
                            textBaked = true
                            mutable
                        } catch (e: Throwable) {
                            errorManager.handle(e, com.comictrans.error.ErrorCategory.UNKNOWN, "فشل رسم النص الأصلي (Kotlin) فوق الصورة المطموسة — رجوع لرسم JS الاحتياطي")
                            processed // نُبقي الصورة المطموسة بلا نص، JS سيرسم النص فوقها كالسابق (textBaked=false)
                        }
                    } else null
                    val processedFile = File(processedPageRoot, "page_${pageIndex}.jpg")
                    if (finalBitmap != null) {
                        processedFile.outputStream().buffered(128 * 1024).use { out ->
                            if (!finalBitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 92, out)) {
                                throw IllegalStateException("تعذر حفظ الصورة المعالجة")
                            }
                        }
                        finalBitmap.recycle()
                    }
                    val textData = translatedBlocks.map { block ->
                        JSONObject().apply {
                            put("x", block.x)
                            put("y", block.y)
                            put("width", block.width)
                            put("height", block.height)
                            put("translatedText", block.translatedText)
                        }
                    }
                    listOf(JSONObject().apply {
                        put("type", "full_page")
                        put("processedUrl", "https://comic.local/processed/$pageIndex?v=${System.currentTimeMillis()}")
                        put("textBlocks", if (textBaked) JSONArray() else JSONArray(textData))
                        put("textBaked", textBaked)
                        put("mode", settings.erasureMode)
                    })
                }
                else -> emptyList()
            }
            sendStatus(pageIndex, "erasure", 100)

            // 4. Send result back to HTML
            val result = JSONObject().apply {
                put("pageIndex", pageIndex)
                put("blocks", JSONArray(translatedBlocks.map { gson.toJson(it) }))
                put("erasureData", JSONArray(erasureData))
                put("settings", gson.toJson(settings))
            }

            sendToWebView("onPageReady", result.toString())
            isProcessing = false

            // كتابة نتيجة هذه الصفحة في الكاش (غير حرجة — فشلها لا يوقف عرض الصفحة، لأننا
            // بالفعل أرسلنا onPageReady فوق قبل هذه الخطوة). 🔍 (تصحيح لاحق) مقيَّدة بـ
            // settings.useMemory أيضاً — لو الخيار معطَّل ما نخزّن شيء أصلاً، اتّساقاً مع
            // منع القراءة منه أعلاه (بدل تخزين نتائج لن تُقرأ أبداً بينما الخيار معطَّل).
            if (settings.useMemory && nativeComicHash.isNotBlank()) {
                try {
                    val persistedImagePath = if (settings.erasureMode in setOf("opencv", "migan")) {
                        val persistDir = File(context.filesDir, "page_cache_images").apply { mkdirs() }
                        val persisted = File(persistDir, "${nativeComicHash}_${pageIndex}_${fingerprint.hashCode()}.jpg")
                        val src = File(processedPageRoot, "page_${pageIndex}.jpg")
                        if (src.exists()) { src.copyTo(persisted, overwrite = true); persisted.absolutePath } else null
                    } else null
                    db.pageCacheDao().insert(
                        com.comictrans.db.PageCacheEntity(
                            comicHash = nativeComicHash,
                            pageNumber = pageIndex,
                            settingsFingerprint = fingerprint,
                            blocksJson = result.getJSONArray("blocks").toString(),
                            erasureDataJson = result.getJSONArray("erasureData").toString(),
                            processedImagePath = persistedImagePath
                        )
                    )
                    db.pageCacheDao().trimOld()
                } catch (e: Exception) {
                    errorManager.handle(e, com.comictrans.error.ErrorCategory.FILE, "فشل حفظ الصفحة في الكاش (غير حرج)")
                }
            }

        } catch (e: Throwable) {
            val err = errorManager.handle(e, com.comictrans.error.ErrorCategory.UNKNOWN, "فشلت معالجة الصفحة")
            sendError(pageIndex, err.userMessage)
            isProcessing = false
        } finally {
            // راجع التعليق الطويل عند تعريف bitmapRef/ocrBitmapRef أعلى بداية هذه الدالة —
            // هذا يضمن التحرير الفعلي بكل مسار خروج (نجاح/فشل/توقف مبكر) بدل الاعتماد فقط
            // على GC التلقائي. isRecycled فحص آمن لتفادي استثناء لو سبق تحريره صراحة بمسار آخر
            // (مثلاً ocrBitmapRef المُحرَّر مبكراً فوق، أو bitmap لو أُعيد استخدام مرجعه بالخطأ مستقبلاً).
            try { ocrBitmapRef?.let { if (!it.isRecycled) it.recycle() } } catch (_: Throwable) {}
            try { bitmapRef?.let { if (!it.isRecycled) it.recycle() } } catch (_: Throwable) {}
        }
    }

    // ================= بند 6: ترجمة الصفحة بسياق واحد (Batch) مع رجوع تلقائي لفقاعة-فقاعة =================
    // محركات LLM (gemini/openai/openrouter/custom) تدعم إرسال كل فقاعات الصفحة المعلّقة
    // بطلب واحد (سياق الحوار الكامل بالصفحة → ترجمة أدق من فقاعة بمعزل عن البقية، وطلب
    // شبكي واحد بدل N). محركات الترجمة التقليدية (mlkit/google/deepl) لا تدعم System
    // Prompt/سياقاً أصلاً فتبقى دائماً على المسار فقاعة-فقاعة. لو فشل الـbatch (استثناء
    // شبكة، أو رد لا يطابق تنسيق JSON المطلوب، أو عدد عناصر مختلف عن عدد النصوص المُرسَلة)
    // نرجع تلقائياً لنفس منطق فقاعة-فقاعة القديم (متوازي عبر Semaphore) بدل فشل الصفحة كاملة.
    private val BATCH_CAPABLE_ENGINES = setOf("gemini", "openai", "openrouter", "custom")

    private suspend fun translatePageBlocks(
        pageIndex: Int,
        blocks: List<BlockData>,
        settings: SettingsData,
        systemPrompt: String,
        warnedThisPage: java.util.concurrent.atomic.AtomicBoolean
    ): List<BlockData> {
        if (blocks.isEmpty()) return blocks

        // 🔍 (2026-08-19) تقسيم الترجمة بين مفتاحي API للسيرفر المحلي (بند بطلب المستخدم):
        // عند تفعيل "تقسيم الترجمة بين المفتاحين" بالإعدادات ووجود مفتاح ثانٍ غير فارغ،
        // تُترجَم الصفحات بالتناوب — الفهرس الزوجي بالمفتاح الأول والفردي بالثاني (نفس
        // الرابط ونفس النموذج، فقط المفتاح يتبدّل) — يوزّع الضغط/الحصص بين مفتاحين.
        val activeCustomApiKey = if (settings.translateEngine == "custom" &&
            settings.customDualKeyEnabled && settings.customApiKey2.isNotBlank() && pageIndex % 2 == 1
        ) settings.customApiKey2 else settings.customApiKey

        data class Pending(val index: Int, val block: BlockData)
        // ذاكرة الترجمة أولاً (بحث تسلسلي — قراءات محلية من Room سريعة جداً، لا تحتاج توازي)
        // — نفس القيد القديم: مقيَّدة بنفس محرك الترجمة الحالي حتى لا تُستخدَم ترجمة قديمة
        // من محرك مختلف بصمت بدل استدعاء المحرك المختار فعلياً الآن.
        val resolved = java.util.concurrent.ConcurrentHashMap<Int, String>()
        val pending = ArrayList<Pending>()
        blocks.forEachIndexed { idx, block ->
            val memoryResult = if (settings.useMemory) {
                db.translationDao().findExact(block.text.trim(), settings.sourceLang, settings.targetLang, settings.translateEngine)
            } else null
            if (memoryResult != null) resolved[idx] = memoryResult.translatedText else pending.add(Pending(idx, block))
        }

        if (pending.isEmpty()) {
            sendStatus(pageIndex, "translate", 100)
            return blocks.mapIndexed { idx, block -> block.copy(translatedText = resolved[idx] ?: block.text) }
        }

        // Batch حقيقي — فقط لمحركات LLM ولو فيه أكثر من فقاعة معلّقة واحدة (batch لفقاعة
        // وحيدة لا فائدة منه، ويكفي المسار الفردي).
        var batchSucceeded = false
        if (settings.translateEngine in BATCH_CAPABLE_ENGINES && pending.size > 1) {
            try {
                sendStatus(pageIndex, "translate", 15)
                val texts = pending.map { it.block.text }
                val results = when (settings.translateEngine) {
                    "gemini" -> translateEngine.translateBatchGemini(texts, settings.targetLang, systemPrompt, settings.geminiKey, settings.geminiModel)
                    "openai" -> translateEngine.translateBatchOpenAIStyle(texts, settings.targetLang, systemPrompt, "https://api.openai.com/v1/chat/completions", settings.openaiKey, settings.openaiModel)
                    "openrouter" -> translateEngine.translateBatchOpenAIStyle(texts, settings.targetLang, systemPrompt, "https://openrouter.ai/api/v1/chat/completions", settings.openrouterKey, settings.openrouterModel, mapOf("X-Title" to "Comic Translator"))
                    "custom" -> {
                        if (settings.customApiUrl.isBlank()) throw IllegalArgumentException("Local LLM: رابط API فارغ")
                        translateEngine.translateBatchOpenAIStyle(texts, settings.targetLang, systemPrompt, settings.customApiUrl, activeCustomApiKey, settings.customModel)
                    }
                    else -> throw IllegalStateException("محرك غير مدعوم لـbatch")
                }
                pending.forEachIndexed { i, p ->
                    resolved[p.index] = results[i]
                    if (settings.useMemory && results[i].isNotBlank()) {
                        db.translationDao().insert(
                            com.comictrans.db.TranslationEntity(
                                sourceText = p.block.text.trim(), translatedText = results[i].trim(),
                                sourceLang = settings.sourceLang, targetLang = settings.targetLang, engine = settings.translateEngine
                            )
                        )
                    }
                }
                batchSucceeded = true
                sendStatus(pageIndex, "translate", 100)
            } catch (e: Throwable) {
                Log.w("ComicApp", "فشل batch الترجمة (${settings.translateEngine}) — رجوع لفقاعة-فقاعة: ${e.message}")
            }
        }

        // المسار الفردي (فقاعة-فقاعة، متوازٍ عبر Semaphore) — إما لأن المحرك أصلاً لا يدعم
        // batch، أو فقاعة معلّقة واحدة فقط، أو الـbatch فشل فعلياً بالأعلى.
        if (!batchSucceeded) {
            val translateSemaphore = Semaphore(5)
            val completedCount = java.util.concurrent.atomic.AtomicInteger(0)
            coroutineScope {
                pending.map { p ->
                    async(Dispatchers.IO) {
                        if (shouldStop) return@async
                        val translated = try {
                            translateSemaphore.withPermit {
                                when (settings.translateEngine) {
                                    "mlkit" -> translateEngine.translateMLKit(p.block.text, settings.sourceLang, settings.targetLang)
                                    "google" -> translateEngine.translateGoogle(p.block.text, settings.sourceLang, settings.targetLang)
                                    "gemini" -> translateEngine.translateGemini(p.block.text, settings.sourceLang, settings.targetLang, settings.geminiKey, settings.geminiModel, systemPrompt)
                                    "openai" -> translateEngine.translateOpenAI(p.block.text, settings.sourceLang, settings.targetLang, settings.openaiKey, settings.openaiModel, systemPrompt)
                                    "openrouter" -> translateEngine.translateOpenRouter(p.block.text, settings.sourceLang, settings.targetLang, settings.openrouterKey, settings.openrouterModel, systemPrompt)
                                    "deepl" -> translateEngine.translateDeepL(p.block.text, settings.sourceLang, settings.targetLang, settings.deeplKey)
                                    "custom" -> translateEngine.translateCustom(p.block.text, settings.sourceLang, settings.targetLang, settings.customApiUrl, activeCustomApiKey, settings.customModel, systemPrompt)
                                    else -> translateEngine.translateGoogle(p.block.text, settings.sourceLang, settings.targetLang)
                                }
                            }
                        } catch (e: Throwable) {
                            Log.e("ComicApp", "فشلت الترجمة (${settings.translateEngine})", e)
                            if (warnedThisPage.compareAndSet(false, true)) {
                                sendWarning(pageIndex, "⚠️ فشلت الترجمة (${settings.translateEngine}): ${e.message ?: "خطأ غير معروف"} — سيُعرض النص الأصلي")
                            }
                            p.block.text // رجوع للنص الأصلي كحل احتياطي بدل إيقاف الصفحة كاملة
                        }

                        if (settings.useMemory && translated.isNotBlank()) {
                            db.translationDao().insert(
                                com.comictrans.db.TranslationEntity(
                                    sourceText = p.block.text.trim(), translatedText = translated.trim(),
                                    sourceLang = settings.sourceLang, targetLang = settings.targetLang, engine = settings.translateEngine
                                )
                            )
                        }

                        resolved[p.index] = translated
                        val done = completedCount.incrementAndGet()
                        sendStatus(pageIndex, "translate", (done * 100 / pending.size.coerceAtLeast(1)))
                    }
                }.forEach { it.await() }
            }
        }

        return blocks.mapIndexed { idx, block -> block.copy(translatedText = resolved[idx] ?: block.text) }
    }

    /** بصمة إعدادات المعالجة — أي فرق فيها يعني أن نتيجة الكاش القديمة لم تعد صالحة لهذه الصفحة. */
    private fun pageSettingsFingerprint(settings: SettingsData): String =
        "${settings.ocrEngine}|${settings.translateEngine}|${settings.erasureMode}|" +
            "${settings.sourceLang}|${settings.targetLang}|${settings.enhanceImage}|${settings.enhanceMethod}|" +
            "${settings.bubbleAwareErasure}|" +
            // ✅ أُضيفت هذه الدفعة: أوضاع fill/opencv/migan تخبز النص المترجم الآن
            // مباشرة داخل صورة الصفحة المخزَّنة بالكاش (TextRenderer.kt الجديد) — بعكس
            // السابق حيث كانت هذه الحقول تخص JS فقط ولا تؤثر على أي بيانات Kotlin مخزَّنة.
            // بدون إضافتها هنا، تغيير الخط/الحجم/اللون بعد أول معالجة لن يُعاد رسمه أبداً
            // لصفحة سبق تخزينها بالكاش — نفس فئة الخطأ الموثَّقة سابقاً لبقية الحقول هنا.
            "${settings.textRendererEngine}|${settings.fontFamily}|${settings.smartFontSize}|" +
            "${settings.fontSizeScale}|${settings.lineSpacingScale}|${settings.textWidthRatio}|" +
            "${settings.textColor}|${settings.textBackground}|${settings.fontSizeStrategy}"

    /**
     * يحاول تلبية طلب صفحة كاملاً من الكاش بدل أي OCR/ترجمة/طمس فعلي. يرجع false (بدون
     * إرسال أي حدث للواجهة) لو الملف المُخزَّن مفقود من القرص — عندها يكمل processPage
     * المسار العادي كأن الكاش غير موجود أصلاً.
     */
    private fun serveFromCache(pageIndex: Int, cached: com.comictrans.db.PageCacheEntity, settings: SettingsData): Boolean {
        return try {
            if (cached.processedImagePath != null) {
                val src = File(cached.processedImagePath)
                if (!src.exists()) return false
                src.copyTo(File(processedPageRoot, "page_${pageIndex}.jpg"), overwrite = true)
            }
            sendStatus(pageIndex, "ocr", 100)
            sendStatus(pageIndex, "translate", 100)
            sendStatus(pageIndex, "erasure", 100)
            val result = JSONObject().apply {
                put("pageIndex", pageIndex)
                put("blocks", JSONArray(cached.blocksJson))
                put("erasureData", JSONArray(cached.erasureDataJson))
                put("settings", gson.toJson(settings))
            }
            sendToWebView("onPageReady", result.toString())
            isProcessing = false
            true
        } catch (e: Exception) {
            errorManager.handle(e, com.comictrans.error.ErrorCategory.FILE, "فشل استرجاع الصفحة من الكاش")
            false
        }
    }

    // أقصى بعد (عرض أو ارتفاع) مسموح لصورة الصفحة بعد فك الترميز. رقم كبير بما يكفي للحفاظ
    // على نص واضح للـOCR والطمس، وصغير بما يكفي لتفادي OutOfMemoryError على أي جهاز.
    private val MAX_PAGE_DIMENSION = 3000

    // *** إصلاح: احترام دوران EXIF قبل تمرير الصورة لـ OCR ***
    // لو الصفحة صورة التُقطت بكاميرا هاتف (بعض تطبيقات المسح الضوئي تحفظ EXIF بدل تدوير
    // البكسلات فعلياً)، BitmapFactory.decodeFile() يتجاهل هذا الوسم تماماً ويرجع البكسلات
    // كما هي بالملف — أي أن الصورة قد تصل لمحرك OCR مقلوبة/مائلة 90/180/270 درجة رغم أنها
    // تظهر معتدلة بصرياً في أي عارض يحترم EXIF (المتصفح/معرض الصور). محرك OCR (نص بزاوية
    // خاطئة) يخطئ بأحرف/كلمات كثيرة بدون أي فشل واضح — بالضبط عرض "بعض الكلمات تُقرأ غلط".
    private fun exifRotationDegrees(file: File): Int {
        return try {
            val exif = androidx.exifinterface.media.ExifInterface(file.absolutePath)
            when (exif.getAttributeInt(
                androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION,
                androidx.exifinterface.media.ExifInterface.ORIENTATION_NORMAL
            )) {
                androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90
                androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180
                androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
        } catch (e: Exception) {
            0 // لا EXIF أو فشل قراءته — الغالبية العظمى من صفحات الكوميك بدون هذا الوسم أصلاً
        }
    }

    // 🔍 (2026-08-18) إصلاح حرج لبلاغ "النصوص لا تعود مكانها، تروح خارج الشاشة، الأحجام غير
    // مناسبة" — يحدث بغض النظر عن "حجم ذكي". السبب الجذري: decodeBitmapBounded (أدناه)
    // تُصغِّر أي صفحة أبعادها > MAX_PAGE_DIMENSION=3000 (شائع جداً بصفحات كوميك/مانجا ممسوحة
    // ضوئياً — بالضبط سبب تكرار البلاغ) قبل تشغيل OCR عليها — فإحداثيات الصناديق (x,y,width,
    // height) القادمة من OCR تكون بمقياس البتمام **المُصغَّر**. لكن JS يعرض الصفحة من الملف
    // **الأصلي غير المُصغَّر مباشرة** (راجع getNativePageFile بـMainActivity — لا تصغير هناك
    // إطلاقاً)، وaحداثيات page.width/height بـJS مبنية على أبعاد الملف الأصلي. النتيجة:
    // كل صندوق نص يُرسَم بموضع/مقاس أصغر بكثير من الصحيح (بنسبة عامل التصغير inSampleSize)،
    // فيظهر بمكان خاطئ (غالباً منزاحاً لأعلى-يسار) وبحجم غير متناسب مع الفقاعة الحقيقية —
    // بالضبط الأعراض الموصوفة. كان يُصحَّح فقط عامل تكبير AI enhance (enhanceScale أدناه)،
    // لا عامل تصغير الذاكرة هذا — فجوة منفصلة تماماً لم تُغطَّ من قبل. الإصلاح: decodeScale
    // (المُرجَع الآن من decodeBitmapBounded) يُدمَج مع enhanceScale بنفس خطوة إعادة القياس.
    private data class DecodedPage(val bitmap: android.graphics.Bitmap, val decodeScale: Float)

    private fun decodeBitmapBounded(file: File): DecodedPage? {
        val boundsOpts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        android.graphics.BitmapFactory.decodeFile(file.absolutePath, boundsOpts)
        val (origW, origH) = boundsOpts.outWidth to boundsOpts.outHeight
        if (origW <= 0 || origH <= 0) return null // ملف تالف أو غير صورة فعلياً

        return try {
            var inSampleSize = 1
            if (origW > MAX_PAGE_DIMENSION || origH > MAX_PAGE_DIMENSION) {
                val halfW = origW / 2
                val halfH = origH / 2
                while ((halfW / inSampleSize) >= MAX_PAGE_DIMENSION || (halfH / inSampleSize) >= MAX_PAGE_DIMENSION) {
                    inSampleSize *= 2
                }
            }

            val decodeOpts = android.graphics.BitmapFactory.Options().apply {
                this.inSampleSize = inSampleSize
                inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
            }
            var decoded = android.graphics.BitmapFactory.decodeFile(file.absolutePath, decodeOpts)
            if (decoded != null && inSampleSize > 1) {
                Log.d("ComicApp", "صفحة كبيرة (${origW}x$origH) — تم تصغيرها لـ ${decoded.width}x${decoded.height} (inSampleSize=$inSampleSize) لتفادي نفاد الذاكرة")
            }
            val rotation = if (decoded != null) exifRotationDegrees(file) else 0
            if (decoded != null && rotation != 0) {
                val matrix = android.graphics.Matrix().apply { postRotate(rotation.toFloat()) }
                val rotated = android.graphics.Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
                if (rotated != decoded) decoded.recycle()
                Log.d("ComicApp", "تم تصحيح دوران EXIF للصفحة ($rotation°)")
                decoded = rotated
            }
            // ⚠️ الدوران 90/270 يبدّل العرض/الارتفاع فعلياً — decodeScale يُحسَب من origW فقط
            // (لا يهم الدوران هنا لأنه نسبة تصغير عددية بحتة، لا اتجاه؛ JS/الملف الأصلي
            // أيضاً بدون تدوير، فكلا الطرفين على نفس الاتجاه المرجعي أصلاً — لا تعارض).
            decoded?.let { DecodedPage(it, origW.toFloat() / it.width.toFloat().coerceAtLeast(1f)) }
        } catch (e: OutOfMemoryError) {
            // احتياط أخير: لو حتى بعد التصغير الأولي حصل OOM (جهاز ضعيف جداً بالذاكرة)،
            // نحاول مرة إضافية بعامل تصغير أكبر بدل الفشل الكامل.
            Log.e("ComicApp", "OOM أثناء فك ترميز الصورة — إعادة محاولة بحجم أصغر", e)
            try {
                val decodeOpts = android.graphics.BitmapFactory.Options().apply {
                    inSampleSize = 8
                    inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
                }
                val fallback = android.graphics.BitmapFactory.decodeFile(file.absolutePath, decodeOpts)
                fallback?.let { DecodedPage(it, origW.toFloat() / it.width.toFloat().coerceAtLeast(1f)) }
            } catch (e2: Throwable) {
                Log.e("ComicApp", "فشلت المحاولة الاحتياطية أيضاً", e2)
                null
            }
        } catch (e: Throwable) {
            errorManager.handle(e, com.comictrans.error.ErrorCategory.FILE, "فشل فك ترميز صورة الصفحة")
            null
        }
    }

    private fun sendStatus(pageIndex: Int, stage: String, progress: Int) {
        val json = JSONObject().apply {
            put("pageIndex", pageIndex)
            put("stage", stage)
            put("progress", progress)
        }
        sendToWebView("onStatusUpdate", json.toString())
    }

    private fun sendError(pageIndex: Int, message: String) {
        val json = JSONObject().apply {
            put("pageIndex", pageIndex)
            put("error", message)
        }
        sendToWebView("onError", json.toString())
    }

    private fun sendWarning(pageIndex: Int, message: String) {
        val json = JSONObject().apply {
            put("pageIndex", pageIndex)
            put("warning", message)
        }
        sendToWebView("onWarning", json.toString())
    }

    private fun sendStopped(pageIndex: Int) {
        val json = JSONObject().apply {
            put("pageIndex", pageIndex)
            put("stopped", true)
        }
        sendToWebView("onStopped", json.toString())
    }

    private fun sendToWebView(functionName: String, data: String) {
        (context as MainActivity).runOnUiThread {
            // JSONObject.quote() ينتج نص JS/JSON آمن (يهرب الاقتباسات والأسطر الجديدة وغيرها)
            // بدل تضمين data مباشرة داخل اقتباس أحادي، لتفادي انكسار الاستدعاء لو النص يحتوي على '
            val safeData = JSONObject.quote(data)
            webView.evaluateJavascript("window.$functionName($safeData)", null)
        }
    }
}
