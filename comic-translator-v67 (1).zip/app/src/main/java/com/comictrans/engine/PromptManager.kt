package com.comictrans.engine

/**
 * نظام إدارة الـPrompts. يبني system prompt واحد يُرسَل مع كل طلب ترجمة لمحركات
 * الـLLM (custom/openai/gemini/openrouter).
 *
 * 🔍 (2026-08-19) تبسيط بطلب المستخدم: حُذفت مدخلات "نوع الكوميكس" (manga/manhwa/western)
 * و"اسم السلسلة" و"قاموس مصطلحات الكوميكس" بالكامل — من الواجهة (index.html) ومن توقيع
 * هذه الدالة معاً. الـprompt الآن عام واحد يعتمد على لغة الهدف فقط، بدل تركيبة من ثلاثة
 * مدخلات كانت تُبنى هنا.
 */
object PromptManager {

    /** يبني system prompt عاماً لترجمة الكوميكس إلى لغة الهدف المطلوبة. */
    fun buildSystemPrompt(targetLangName: String): String =
        "You are a professional comic translator. Translate the comic dialogue into " +
            "$targetLangName naturally and idiomatically — avoid literal word-for-word " +
            "translation, preserve the tone (humorous, dramatic, action) of each line, and " +
            "keep character names and recurring terms consistent across all pages.\n\n" +
            "Return ONLY the translation, with no explanation, no quotes, no notes."
}
