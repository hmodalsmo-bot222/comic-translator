package com.comictrans.engine

import android.content.Context
import com.google.android.gms.tasks.Task
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * يدير تنزيل/حذف حزم Google ML Kit — نماذج الترجمة المحلية (على الجهاز) الخاصة بمحرك
 * "ML Kit" (translateEngine = "mlkit" في index.html)، منفصل تماماً عن ModelManager.
 *
 * الفرق الجوهري عن ModelManager: نماذج ML Kit ليست ملف HTTP نُنزّله نحن يدوياً برابط —
 * Google توفّرها عبر واجهة RemoteModelManager الرسمية (com.google.mlkit:translate، مُضاف
 * أصلاً في build.gradle)، وهي التي تدير موقع/استضافة/نسخة الملف داخلياً بالكامل. هذا هو
 * بالضبط سبب عدم وجود أي "رابط" يُطلب من المستخدم لصقه لهذه النماذج على الإطلاق — الاستدعاء
 * وحده كافٍ لبدء التنزيل الحقيقي عبر Google Play services.
 *
 * التطبيق حالياً يترجم فقط من الإنجليزية (en) للعربية (ar) بشكل ثابت — لا يوجد أي محدد لغة
 * بالواجهة (راجع getSettings() في index.html: sourceLang/targetLang ثابتتان). لذلك نكتفي
 * هنا بإدارة هاتين اللغتين فقط، بدل عرض كل اللغات التي يدعمها ML Kit بلا أي فائدة عملية.
 */
class MlkitModelManager(private val context: Context) {

    data class MlkitLangInfo(
        val code: String,          // معرّف يُستخدم كـ"id" موحّد مع ModelManager في نفس شاشة الإدارة
        val displayName: String,
        val translateLanguage: String // أحد ثوابت TranslateLanguage
    )

    val languages: List<MlkitLangInfo> = listOf(
        MlkitLangInfo("mlkit_en", "📱 حزمة ML Kit — الإنجليزية (English)", TranslateLanguage.ENGLISH),
        MlkitLangInfo("mlkit_ar", "📱 حزمة ML Kit — العربية (Arabic)", TranslateLanguage.ARABIC)
    )

    private val remoteModelManager by lazy { RemoteModelManager.getInstance() }

    private fun remoteModel(translateLanguage: String): TranslateRemoteModel =
        TranslateRemoteModel.Builder(translateLanguage).build()

    // مكتبة ML Kit (Google Play services) تستخدم Task<T> وليس suspend function مباشرة —
    // هذه دالة مساعدة صغيرة تحوّلها لـsuspend عادية بدون إضافة أي تبعية جديدة لملف
    // build.gradle (play-services-tasks متوفرة أصلاً كتبعية غير مباشرة عبر ML Kit نفسه).
    private suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { cont ->
        addOnSuccessListener { if (cont.isActive) cont.resume(it) }
        addOnFailureListener { e -> if (cont.isActive) cont.resumeWithException(e) }
        // 🔍 (2026-08-19، V60) كان ناقصاً: Task قد تُلغى (خدمات Google Play تُعاد تهيئتها،
        // أو انقطاع)، وحينها لا يُستدعى success ولا failure إطلاقاً — فتبقى الـcoroutine
        // معلّقة للأبد. عملياً هذا كان يجمّد listModels() (لا تصل قائمة النماذج للواجهة أبداً)
        // ويجعل زر تنزيل حزمة ML Kit يبدو بلا أي استجابة.
        addOnCanceledListener {
            if (cont.isActive) cont.resumeWithException(IllegalStateException("أُلغيت العملية من Google Play services"))
        }
    }

    /** كل رموز اللغات المُنزَّلة فعلاً — استعلام واحد بدل استعلام منفصل لكل لغة. */
    suspend fun downloadedLanguageCodes(): Set<String> = withContext(Dispatchers.IO) {
        val downloaded = remoteModelManager.getDownloadedModels(TranslateRemoteModel::class.java).await()
        languages.filter { info -> downloaded.any { it.language == info.translateLanguage } }
            .map { it.code }
            .toSet()
    }

    suspend fun isDownloaded(info: MlkitLangInfo): Boolean = withContext(Dispatchers.IO) {
        try {
            val downloaded = remoteModelManager.getDownloadedModels(TranslateRemoteModel::class.java).await()
            downloaded.any { it.language == info.translateLanguage }
        } catch (e: Exception) {
            false
        }
    }

    suspend fun download(info: MlkitLangInfo): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            // requireWifi غير مفعَّل عمداً — بنفس سلوك بقية نماذج التطبيق (AI Lite/Pro)، حتى
            // يعمل التنزيل ولو المستخدم على بيانات الجوال فقط.
            val conditions = DownloadConditions.Builder().build()
            remoteModelManager.download(remoteModel(info.translateLanguage), conditions).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun delete(info: MlkitLangInfo): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            remoteModelManager.deleteDownloadedModel(remoteModel(info.translateLanguage)).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
