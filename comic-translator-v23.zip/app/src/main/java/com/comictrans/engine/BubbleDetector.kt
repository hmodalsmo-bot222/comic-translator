package com.comictrans.engine

import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Log
import com.comictrans.model.BlockData
import org.opencv.android.Utils
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfInt
import org.opencv.core.MatOfPoint
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc

/**
 * كشف فقاعات الكلام (بند 3) — يحدد الشكل الفعلي (غير المستطيل) لفقاعة الكلام حول كل قطعة
 * نص، بدل الاكتفاء بصندوق OCR المستطيل الخام. يُستخدَم حالياً لتحسين قناع الطمس في
 * ErasureEngine.inpaintOpenCV فقط (راجع الشرح هناك) — أوضاع AI Lite/AI Pro ما زالت تستخدم
 * صندوق مستطيل بهامش (paddedCropRect) لأن بنية الاستدلال فيها per-block crop بمقاس ثابت،
 * ودمج قناع بشكل حر داخل تلك القصاصات المصغّرة يحتاج تعديلاً إضافياً منفصلاً لاحقاً.
 *
 * ⚠️ **العتبات أدناه (companion object) لم تُختبَر على صور كوميكس حقيقية بعد** — هذا أصعب
 * جزء تقنياً بالخطة (راجع HANDOFF_NEXT_ASSISTANT.md، خطوة 3). القيم الحالية اجتهاد أولي
 * مبني على خصائص عامة لفقاعات الكلام (شكل محدّب نسبياً، امتلاء فاتح أو تعبئة لونية موحّدة
 * تقريباً)، ويُتوقَّع تحتاج تعديلاً فعلياً بعد تجربة صور حقيقية (مانجا/مانهوا/كوميكس غربي
 * تختلف كثيراً بأسلوب الرسم). لو الكشف طلّع نتائج ضعيفة (فقاعات مفقودة أو مناطق رسم خُطئاً
 * كفقاعات)، ابدأ بتعديل MIN_AREA_RATIO/MAX_AREA_RATIO/MIN_SOLIDITY/MIN_EXTENT هنا أولاً.
 *
 * منهجية الكشف: مساران مستقلان يُدمَج ناتجهما (راجع detectBubbles):
 *  1) findByWhiteFill: يعزل المناطق الفاتحة (Otsu أو عتبة يدوية fallback) ثم إغلاق مورفولوجي
 *     يسد الفجوات الصغيرة بحد الفقاعة — يغطي أغلب فقاعات المانجا/الكوميكس الغربي التقليدية
 *     ذات التعبئة البيضاء.
 *  2) findByEdges: Canny + إغلاق مورفولوجي على الحواف مباشرة (بدون افتراض تعبئة بيضاء) —
 *     يفيد الحالات ذات تعبئة لونية (شائع بالمانهوا) حيث لا يوجد امتلاء أبيض واضح لعزله.
 * كل مسار يُصفّى بثلاثة معايير هندسية (مساحة نسبية، امتلاء extent، تحدّب solidity) لاستبعاد
 * أي كنتور لا يشبه فقاعة كلام فعلياً (لوحات/إطارات صفحة/خطوط رسم عشوائية).
 */
class BubbleDetector {

    private val TAG = "BubbleDetector"

    /** [rect]: الصندوق المحيط بشكل الفقاعة الفعلي (بمقياس بكسلات الصورة الأصلية).
     *  [contour]: نقاط حدود الفقاعة الفعلية (غير مستطيلة) — تُستخدَم لرسم قناع بالشكل الحقيقي. */
    data class Bubble(val rect: Rect, val contour: MatOfPoint)

    companion object {
        // نسبة أصغر/أكبر مساحة مقبولة لكنتور كي يُعتبَر فقاعة كلام محتملة، من مساحة الصفحة كاملة.
        private const val MIN_AREA_RATIO = 0.0006
        private const val MAX_AREA_RATIO = 0.35
        // مساحة الكنتور / مساحة الغلاف المحدب (Convex Hull) — الفقاعات مستديرة/بيضاوية
        // غالباً فتكون قريبة من شكلها المحدّب؛ يستبعد أشكالاً متعرّجة (خطوط رسم، حواف لوحة).
        private const val MIN_SOLIDITY = 0.75
        // مساحة الكنتور / مساحة صندوقه المحيط — يستبعد أشكالاً رفيعة جداً بالنسبة لصندوقها
        // (خط مستقيم طويل مثلاً يعطي extent منخفض جداً رغم احتمال solidity مرتفع).
        private const val MIN_EXTENT = 0.35
        // عتبة IoU لاعتبار كنتورين (من المسارين) نفس الفقاعة عند الدمج.
        private const val DEDUPE_IOU = 0.55
    }

    /** يكشف كل فقاعات الكلام المحتملة بالصفحة كاملة (مستقل عن نتائج OCR). */
    fun detectBubbles(bitmap: Bitmap): List<Bubble> {
        if (!OpenCVStatus.isAvailable) {
            Log.w(TAG, "OpenCV غير محمّلة — تخطي كشف الفقاعات (رجوع لمستطيلات OCR فقط)")
            return emptyList()
        }
        val src = Mat()
        val gray = Mat()
        return try {
            Utils.bitmapToMat(bitmap, src)
            Imgproc.cvtColor(src, gray, Imgproc.COLOR_RGBA2GRAY)

            val pageArea = bitmap.width.toDouble() * bitmap.height.toDouble()
            val fromWhite = findByWhiteFill(gray, pageArea)
            val fromEdges = findByEdges(gray, pageArea)

            mergeCandidates(fromWhite, fromEdges)
        } catch (e: Throwable) {
            Log.e(TAG, "فشل كشف الفقاعات — الاستمرار بدون تحسين الشكل (مستطيلات OCR فقط)", e)
            emptyList()
        } finally {
            src.release()
            gray.release()
        }
    }

    /**
     * يبني قناع الطمس (CV_8UC1، 255=امسح هذه المنطقة) لقائمة فقاعات النص المُترجَمة:
     * لكل قطعة نص، لو وُجدت فقاعة مطابقة (matchBlockToBubble) يُرسَم شكلها الفعلي (contour)
     * معبّأً بدل مستطيل خام — وإلا رجوع آمن لمستطيل النص القديم بالضبط (نفس السلوك السابق،
     * فلا احتمال تدهور عن ما كان موجوداً). الاستدعاء آمن دائماً حتى لو OpenCV غير محمّلة أو
     * detectBubbles رجع قائمة فارغة (يرجع عندها لمستطيلات فقط تلقائياً).
     */
    fun buildErasureMask(
        bitmap: Bitmap,
        blocks: List<BlockData>,
        bubbles: List<Bubble> = detectBubbles(bitmap)
    ): Mat {
        val mask = Mat.zeros(Size(bitmap.width.toDouble(), bitmap.height.toDouble()), CvType.CV_8UC1)
        for (block in blocks) {
            val bubble = matchBlockToBubble(block, bubbles)
            if (bubble != null) {
                Imgproc.drawContours(mask, listOf(bubble.contour), -1, Scalar(255.0), -1)
            } else {
                val x1 = block.x.coerceIn(0, bitmap.width - 1)
                val y1 = block.y.coerceIn(0, bitmap.height - 1)
                val x2 = (block.x + block.width).coerceIn(0, bitmap.width)
                val y2 = (block.y + block.height).coerceIn(0, bitmap.height)
                Imgproc.rectangle(
                    mask,
                    Point(x1.toDouble(), y1.toDouble()),
                    Point(x2.toDouble(), y2.toDouble()),
                    Scalar(255.0),
                    -1
                )
            }
        }
        return mask
    }

    /**
     * يختار الفقاعة الأنسب لقطعة نص: يجب أن تكون أغلب مساحة صندوق النص داخل صندوق الفقاعة
     * (لا مجرد تقاطع بسيط — يمنع مطابقة فقاعة مجاورة خطأً)، ولو تطابقت أكثر من فقاعة، تُختار
     * الأصغر مساحة (الأكثر تحديداً، تفادياً لاختيار كنتور كبير كاذب يحتوي عدة فقاعات صغيرة).
     */
    private fun matchBlockToBubble(block: BlockData, bubbles: List<Bubble>): Bubble? {
        if (bubbles.isEmpty()) return null
        val blockRect = Rect(block.x, block.y, block.x + block.width, block.y + block.height)
        val blockArea = (blockRect.width().toLong() * blockRect.height().toLong()).coerceAtLeast(1)

        var best: Bubble? = null
        var bestBubbleArea = Long.MAX_VALUE
        for (bubble in bubbles) {
            val inter = Rect(blockRect)
            if (!inter.intersect(bubble.rect)) continue
            val interArea = inter.width().toLong() * inter.height().toLong()
            val overlapRatio = interArea.toDouble() / blockArea
            if (overlapRatio < 0.55) continue

            val bubbleArea = bubble.rect.width().toLong() * bubble.rect.height().toLong()
            if (bubbleArea < bestBubbleArea) {
                bestBubbleArea = bubbleArea
                best = bubble
            }
        }
        return best
    }

    private fun findByWhiteFill(gray: Mat, pageArea: Double): List<Bubble> {
        val binary = Mat()
        val closed = Mat()
        val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(7.0, 7.0))
        return try {
            // Otsu تعطي نتائج جيدة لعزل التعبئة الفاتحة عن الخلفية بأغلب صفحات الكوميك، لكنها
            // قد تفشل بصفحات معقدة التباين — عتبة يدوية (200) fallback لو النتيجة غير منطقية
            // (قريبة جداً من 0 أو 255، دليل فشل Otsu بصفحة غير نمطية).
            val otsuThresh = Imgproc.threshold(gray, binary, 0.0, 255.0, Imgproc.THRESH_BINARY + Imgproc.THRESH_OTSU)
            if (otsuThresh < 120.0 || otsuThresh > 250.0) {
                Imgproc.threshold(gray, binary, 200.0, 255.0, Imgproc.THRESH_BINARY)
            }
            Imgproc.morphologyEx(binary, closed, Imgproc.MORPH_CLOSE, kernel)
            extractBubbleContours(closed, pageArea)
        } finally {
            binary.release()
            closed.release()
            kernel.release()
        }
    }

    private fun findByEdges(gray: Mat, pageArea: Double): List<Bubble> {
        val blurred = Mat()
        val edges = Mat()
        val closed = Mat()
        val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(5.0, 5.0))
        return try {
            Imgproc.GaussianBlur(gray, blurred, Size(3.0, 3.0), 0.0)
            Imgproc.Canny(blurred, edges, 50.0, 150.0)
            Imgproc.morphologyEx(edges, closed, Imgproc.MORPH_CLOSE, kernel, Point(-1.0, -1.0), 2)
            extractBubbleContours(closed, pageArea)
        } finally {
            blurred.release()
            edges.release()
            closed.release()
            kernel.release()
        }
    }

    private fun extractBubbleContours(binary: Mat, pageArea: Double): List<Bubble> {
        val contours = mutableListOf<MatOfPoint>()
        val hierarchy = Mat()
        Imgproc.findContours(binary, contours, hierarchy, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
        hierarchy.release()

        val minArea = pageArea * MIN_AREA_RATIO
        val maxArea = pageArea * MAX_AREA_RATIO
        val result = mutableListOf<Bubble>()
        for (contour in contours) {
            val area = Imgproc.contourArea(contour)
            if (area < minArea || area > maxArea) {
                contour.release()
                continue
            }
            val boundingRect = Imgproc.boundingRect(contour)
            val boxArea = (boundingRect.width.toDouble() * boundingRect.height.toDouble()).coerceAtLeast(1.0)
            val extent = area / boxArea
            if (extent < MIN_EXTENT) {
                contour.release()
                continue
            }
            val solidity = solidityOf(contour, area)
            if (solidity < MIN_SOLIDITY) {
                contour.release()
                continue
            }
            result.add(
                Bubble(
                    rect = Rect(
                        boundingRect.x, boundingRect.y,
                        boundingRect.x + boundingRect.width, boundingRect.y + boundingRect.height
                    ),
                    contour = contour
                )
            )
        }
        return result
    }

    private fun solidityOf(contour: MatOfPoint, contourArea: Double): Double {
        val hullIndices = MatOfInt()
        val hullMat = MatOfPoint()
        return try {
            Imgproc.convexHull(contour, hullIndices)
            val points = contour.toArray()
            val hullPoints = hullIndices.toArray().mapNotNull { idx -> points.getOrNull(idx) }
            if (hullPoints.size < 3) return 0.0
            hullMat.fromList(hullPoints)
            val hullArea = Imgproc.contourArea(hullMat)
            if (hullArea <= 0.0) 0.0 else (contourArea / hullArea).coerceIn(0.0, 1.0)
        } catch (e: Exception) {
            0.0
        } finally {
            hullIndices.release()
            hullMat.release()
        }
    }

    /**
     * يدمج نتائج المسارين (تعبئة بيضاء + حواف)، ويستبعد التكرار (كنتوران يغطيان نفس المنطقة
     * تقريباً باكتشاف مسارين مختلفين) عبر IoU على الصناديق المحيطة — كافٍ هنا لأن الهدف تفادي
     * رسم/مطابقة نفس المنطقة مرتين، مو دقة هندسية عالية. عند التكرار، تُفضَّل الفقاعة الأكبر
     * (غالباً الأكثر اكتمالاً لحدود الشكل الفعلي).
     */
    private fun mergeCandidates(a: List<Bubble>, b: List<Bubble>): List<Bubble> {
        val all = (a + b).sortedByDescending { it.rect.width().toLong() * it.rect.height().toLong() }
        val kept = mutableListOf<Bubble>()
        for (candidate in all) {
            val duplicate = kept.any { iou(it.rect, candidate.rect) > DEDUPE_IOU }
            if (duplicate) {
                candidate.contour.release()
            } else {
                kept.add(candidate)
            }
        }
        return kept
    }

    private fun iou(a: Rect, b: Rect): Double {
        val inter = Rect(a)
        if (!inter.intersect(b)) return 0.0
        val interArea = inter.width().toLong() * inter.height().toLong()
        val unionArea = a.width().toLong() * a.height().toLong() + b.width().toLong() * b.height().toLong() - interArea
        return if (unionArea <= 0) 0.0 else interArea.toDouble() / unionArea
    }
}
