package com.comictrans.model

data class SettingsData(
    val ocrEngine: String = "mlkit",
    val erasureMode: String = "fill",
    val translateEngine: String = "google",
    val sourceLang: String = "en",
    val targetLang: String = "ar",
    val useMemory: Boolean = true,
    val enhanceImage: Boolean = true, // افتراضي مفعّل الآن — يحسّن دقة قراءة OCR لخطوط الكوميك بدون أي نموذج إضافي (راجع الشرح في index.html)
    val enhanceMethod: String = "opencv",
    val ocrSpaceKey: String = "",
    val cloudApiUrl: String = "",
    val geminiKey: String = "",
    val geminiModel: String = "gemini-2.0-flash",
    val openaiKey: String = "",
    val openaiModel: String = "gpt-4o-mini",
    val openrouterKey: String = "",
    val openrouterModel: String = "openai/gpt-4o-mini",
    val deeplKey: String = "",
    // بند 8: Local LLM (Ollama / LM Studio / أي سيرفر متوافق مع OpenAI API). translateEngine
    // = "custom" يستخدم هذه الحقول. مثال customApiUrl لـOllama محلي:
    // "http://127.0.0.1:11434/v1/chat/completions" — والـcustomApiKey يُترَك فارغاً غالباً
    // (Ollama/LM Studio لا يتطلبان مفتاحاً افتراضياً).
    val customApiUrl: String = "",
    val customApiKey: String = "",
    val customModel: String = "",
    // بند 7: نظام Prompts حسب نوع الكوميكس + سياق السلسلة — يُستخدَمان في PromptManager
    // لبناء system prompt مناسب (نبرة/أسلوب حوار يختلف بين مانجا يابانية ومانهوا كورية
    // وكوميكس غربي)، ويُمرَّران فقط للمحركات القائمة على LLM (custom/openai/gemini/openrouter).
    val comicType: String = "manga", // "manga" | "manhwa" | "western"
    val seriesName: String = ""
)
