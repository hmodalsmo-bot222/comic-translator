package com.comictrans.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.util.Log
import com.comictrans.model.BlockData
import org.json.JSONObject
import org.opencv.android.Utils
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo
import org.tensorflow.lite.Interpreter
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

class ErasureEngine(private val context: Context) {

    private val TAG = "ErasureEngine"

    // OpenCV Inpaint — works now if OpenCV is loaded
    fun inpaintOpenCV(bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        return try {
            // Convert Bitmap to Mat
            val srcMat = Mat()
            Utils.bitmapToMat(bitmap, srcMat)

            // Create mask (black image, white where text is)
            val maskMat = Mat.zeros(srcMat.size(), CvType.CV_8UC1)
            for (block in blocks) {
                val x1 = block.x.coerceIn(0, bitmap.width - 1)
                val y1 = block.y.coerceIn(0, bitmap.height - 1)
                val x2 = (block.x + block.width).coerceIn(0, bitmap.width)
                val y2 = (block.y + block.height).coerceIn(0, bitmap.height)
                Imgproc.rectangle(
                    maskMat,
                    Point(x1.toDouble(), y1.toDouble()),
                    Point(x2.toDouble(), y2.toDouble()),
                    Scalar(255.0), // White = inpaint this area
                    -1 // Filled
                )
            }

            // Inpaint using Telea algorithm
            val resultMat = Mat()
            Photo.inpaint(srcMat, maskMat, resultMat, 3.0, Photo.INPAINT_TELEA)

            // Convert back to Bitmap
            val resultBitmap = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(resultMat, resultBitmap)

            // Release mats
            srcMat.release()
            maskMat.release()
            resultMat.release()

            resultBitmap
        } catch (e: Exception) {
            Log.e(TAG, "OpenCV inpaint failed", e)
            // Fallback: return original with white boxes
            fallbackErase(bitmap, blocks)
        }
    }

    // AI Lite (TFLite) — stub, needs .tflite model file
    fun inpaintTFLite(bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        return try {
            val modelPath = context.getExternalFilesDir(null)?.absolutePath + "/models/lama-lite.tflite"
            val tfliteModel = loadModelFile(modelPath)
            val interpreter = Interpreter(tfliteModel)

            // TODO: Implement proper preprocessing
            // 1. Resize image to model input size (e.g., 512x512)
            // 2. Create mask from blocks
            // 3. Normalize to [-1, 1] or [0, 1]
            // 4. Run inference
            // 5. Post-process and resize back

            Log.w(TAG, "TFLite inpaint not fully implemented - using OpenCV fallback")
            inpaintOpenCV(bitmap, blocks)
        } catch (e: Exception) {
            Log.e(TAG, "TFLite inpaint failed", e)
            inpaintOpenCV(bitmap, blocks)
        }
    }

    // AI Pro (ONNX) — stub, needs .onnx model file
    fun inpaintONNX(bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        return try {
            val modelPath = context.getExternalFilesDir(null)?.absolutePath + "/models/lama-pro.onnx"
            val env = OrtEnvironment.getEnvironment()
            val session = env.createSession(modelPath, OrtSession.SessionOptions())

            // TODO: Implement proper preprocessing
            // 1. Resize image to model input size
            // 2. Create mask
            // 3. Convert to float tensor
            // 4. Run session
            // 5. Post-process

            session.close()
            env.close()

            Log.w(TAG, "ONNX inpaint not fully implemented - using OpenCV fallback")
            inpaintOpenCV(bitmap, blocks)
        } catch (e: Exception) {
            Log.e(TAG, "ONNX inpaint failed", e)
            inpaintOpenCV(bitmap, blocks)
        }
    }

    // Main entry point called from AppInterface
    fun processBlocks(bitmap: Bitmap, blocks: List<BlockData>, mode: String): List<JSONObject> {
        return when (mode) {
            "opencv" -> {
                val resultBitmap = inpaintOpenCV(bitmap, blocks)
                // Return single result for the whole page
                listOf(JSONObject().apply {
                    put("mode", "opencv")
                    put("type", "full_page")
                    put("imageBase64", bitmapToBase64(resultBitmap))
                })
            }
            "ai_lite" -> {
                val resultBitmap = inpaintTFLite(bitmap, blocks)
                listOf(JSONObject().apply {
                    put("mode", "ai_lite")
                    put("type", "full_page")
                    put("imageBase64", bitmapToBase64(resultBitmap))
                })
            }
            "ai_pro" -> {
                val resultBitmap = inpaintONNX(bitmap, blocks)
                listOf(JSONObject().apply {
                    put("mode", "ai_pro")
                    put("type", "full_page")
                    put("imageBase64", bitmapToBase64(resultBitmap))
                })
            }
            else -> {
                // For fill/blur - return block coordinates for HTML to handle
                blocks.map { block ->
                    JSONObject().apply {
                        put("x", block.x)
                        put("y", block.y)
                        put("width", block.width)
                        put("height", block.height)
                        put("mode", mode)
                        put("type", "block_coords")
                    }
                }
            }
        }
    }

    private fun fallbackErase(bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val result = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)
        val paint = Paint().apply { color = Color.WHITE }
        for (block in blocks) {
            canvas.drawRect(
                Rect(block.x, block.y, block.x + block.width, block.y + block.height),
                paint
            )
        }
        return result
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val stream = java.io.ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream)
        val bytes = stream.toByteArray()
        return "data:image/jpeg;base64," + android.util.Base64.encodeToString(bytes, android.util.Base64.DEFAULT)
    }

    private fun loadModelFile(path: String): MappedByteBuffer {
        val file = java.io.File(path)
        val stream = FileInputStream(file)
        val channel = stream.channel
        return channel.map(FileChannel.MapMode.READ_ONLY, 0, file.length())
    }
}
