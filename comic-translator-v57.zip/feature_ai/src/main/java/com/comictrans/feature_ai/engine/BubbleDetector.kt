package com.comictrans.feature_ai.engine

import android.graphics.Bitmap
import android.util.Log
import com.comictrans.engine.OpenCVStatus
import com.comictrans.model.BlockData
import org.opencv.android.Utils
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc

/**
 * بند 3: كشف فقاعات الكلام (Speech Bubble Detection).
 *
 * فقاعات الكلام في الكوميكس/المانجا عادة مناطق فاتحة جداً (أبيض تقريباً) محاطة بخط حدّي
 * غامق (outline)، بيضاوية أو مستطيلة الزوايا أو غيمية الشكل (فقاعات الأفكار). الهدف هنا:
 * بدل الاعتماد فقط على المستطيل الخام اللي يرجعه محرك OCR لكل بلوك نص (يتضمن أحياناً هوامش
 * بيضاء زائدة، أو لا يغطي الفقاعة كاملة لو النص لا يملأها) — نحاول إيجاد **حدود الفقاعة
 * الفعلية** حول كل بلوك عبر Imgproc.findContours، لاستخدامها كقناع طمس (Photo.inpaint mask)
 * أدق من مستطيل خام قد يقصّ جزءاً من الفقاعة أو يطمس رسماً حولها بلا داعٍ.
 *
 * ⚠️ ملاحظة صريحة لمن يبني ويختبر: هذا أصعب بنود الخطة الأصلية تقنياً — كل القيم الثابتة
 * تحت ([LIGHT_THRESHOLD]، [MIN_AREA_RATIO]/[MAX_AREA_RATIO]، هامش منطقة البحث) قيم بداية
 * معقولة نظرياً فقط، **لم تُختبَر على أي صورة كوميكس حقيقية إطلاقاً** (بيئة الكتابة بدون
 * قدرة عرض/معالجة صور فعلية — لا Android SDK ولا إنترنت). توقّع حاجة حقيقية لضبط هذه القيم
 * بعد أول تجربة فعلية، وربما قيماً مختلفة لأنماط فن مختلفة (مانجا أبيض/أسود مقابل مانهوا/
 * كوميكس غربي ملوّن قد تحتاج عتبات إضاءة مختلفة تماماً).
 *
 * هذا الملف **غير مربوط تلقائياً بأي مسار طمس افتراضي حالياً** — الدمج الآمن الوحيد المُفعَّل
 * هو عبر `ErasureEngine.processBitmap(..., bubbleAware = true)` (افتراضي false، راجع
 * ErasureEngine.kt وAppInterface.kt)، عمداً حتى لا يتغيّر سلوك وضع "opencv" الافتراضي
 * الموجود مسبقاً (والمُختبَر تاريخياً) بدون علم صريح من المستخدم أو اختبار فعلي لهذا الملف.
 */
object BubbleDetector {

    private const val TAG = "BubbleDetector"

    // فقاعة الكلام النموذجية فاتحة جداً (أبيض تقريباً) — نفصل الفاتح عن الغامق بعتبة ثابتة
    // بدل Otsu التكيفية، لأن Otsu قد "يقرر" عتبة سيئة على صفحة يغلب عليها رسم غامق (مشهد
    // ليلي مثلاً) فتفشل في عزل فقاعة فاتحة صغيرة وسط صفحة غامقة أغلبها. عتبة ثابتة عالية
    // (200/255) تفترض أن الفقاعة فعلاً فاتحة جداً مقارنة بمعظم فن الكوميكس المحيط — افتراض
    // معقول شائع لكنه سيفشل عمداً (يرجع null) مع أنماط فن غير تقليدية (فقاعات ملوّنة غامقة)
    // بدل تخمين خاطئ صامت.
    private const val LIGHT_THRESHOLD = 200.0

    // نطاق نسبة (مساحة الكونتور ÷ مساحة منطقة البحث المُوسَّعة) المقبول لاعتباره "فقاعة"
    // منطقية — كونتور أصغر من هذا غالباً ضوضاء/جزء حرف منفصل، وأكبر منه غالباً التقط خلفية
    // الصفحة كلها بالخطأ (فشل الفصل بين الفقاعة والمحيط).
    private const val MIN_AREA_RATIO = 0.05
    private const val MAX_AREA_RATIO = 0.92

    /**
     * يحاول إيجاد كونتور فقاعة الكلام المحيطة بمستطيل نص [block] داخل [bitmap]. يبحث في
     * منطقة مُوسَّعة حول المستطيل (padding نسبي لحجم النص) لأن حدود الفقاعة الفعلية عادة
     * أكبر من مستطيل النص الخام. يرجع null لو لم يُعثر على كونتور معقول يحتوي مركز النص —
     * عندها يجب على المتصل الرجوع للمستطيل الخام (لا يوجد افتراض بديل هنا، تعمّداً).
     * الإحداثيات المُرجَعة بمقياس [bitmap] الأصلي كاملاً (وليس منطقة البحث المقصوصة).
     */
    fun detectBubbleContour(bitmap: Bitmap, block: BlockData): MatOfPoint? {
        if (!OpenCVStatus.isAvailable) return null
        if (block.width <= 0 || block.height <= 0) return null

        // هامش بحث حول مستطيل النص — فقاعة الكلام النموذجية أكبر من نصّها بوضوح على كل
        // جهة (~60% من أبعاد النص كحد أدنى للهامش، بحد أدنى 20 بكسل حتى لا يضيق البحث جداً
        // لنص صغير الخط).
        val padX = maxOf((block.width * 0.6).toInt(), 20)
        val padY = maxOf((block.height * 0.6).toInt(), 20)
        val rx1 = (block.x - padX).coerceIn(0, bitmap.width - 1)
        val ry1 = (block.y - padY).coerceIn(0, bitmap.height - 1)
        val rx2 = (block.x + block.width + padX).coerceIn(rx1 + 1, bitmap.width)
        val ry2 = (block.y + block.height + padY).coerceIn(ry1 + 1, bitmap.height)
        val regionW = rx2 - rx1
        val regionH = ry2 - ry1
        if (regionW <= 4 || regionH <= 4) return null

        var mat: Mat? = null
        var gray: Mat? = null
        var binary: Mat? = null
        var kernel: Mat? = null
        var hierarchy: Mat? = null
        var cropped: Bitmap? = null
        return try {
            cropped = Bitmap.createBitmap(bitmap, rx1, ry1, regionW, regionH)
            mat = Mat()
            Utils.bitmapToMat(cropped, mat)
            gray = Mat()
            Imgproc.cvtColor(mat, gray, Imgproc.COLOR_RGBA2GRAY)

            binary = Mat()
            Imgproc.threshold(gray, binary, LIGHT_THRESHOLD, 255.0, Imgproc.THRESH_BINARY)

            // إغلاق فتحات صغيرة بخط الحدّ (outline) قد تنقطع بسبب ضغط JPEG/تعرّج المسح
            // الضوئي — closing يعيد وصلها حتى لا تنقسم الفقاعة الواحدة لعدة كونتورات صغيرة
            // منفصلة بدل كونتور واحد متكامل.
            kernel = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(5.0, 5.0))
            Imgproc.morphologyEx(binary, binary, Imgproc.MORPH_CLOSE, kernel)

            val contours = ArrayList<MatOfPoint>()
            hierarchy = Mat()
            Imgproc.findContours(binary, contours, hierarchy, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)

            val regionArea = (regionW * regionH).toDouble()
            val blockCenterX = (block.x - rx1 + block.width / 2).toDouble()
            val blockCenterY = (block.y - ry1 + block.height / 2).toDouble()

            // من بين كل الكونتورات المُكتشَفة، نختار الأقرب منطقياً لفقاعة كلام حقيقية:
            // مساحة ضمن النطاق المقبول، **ويحتوي مركز مستطيل النص فعلياً** (يمنع التقاط
            // فقاعة مجاورة تقع جزئياً داخل منطقة البحث المُوسَّعة بالخطأ).
            var best: MatOfPoint? = null
            var bestArea = -1.0
            for (c in contours) {
                val area = Imgproc.contourArea(c)
                val ratio = area / regionArea
                if (ratio < MIN_AREA_RATIO || ratio > MAX_AREA_RATIO) { c.release(); continue }
                val rect = Imgproc.boundingRect(c)
                val containsCenter = blockCenterX >= rect.x && blockCenterX <= rect.x + rect.width &&
                    blockCenterY >= rect.y && blockCenterY <= rect.y + rect.height
                if (!containsCenter) { c.release(); continue }
                if (area > bestArea) {
                    best?.release()
                    bestArea = area
                    best = c
                } else {
                    c.release()
                }
            }

            // نترجم إحداثيات الكونتور الفائز من مقياس منطقة البحث المقصوصة لمقياس الصورة
            // الأصلية كاملة (نضيف إزاحة rx1/ry1) قبل إرجاعه للمتصل.
            best?.let { winner ->
                val points = winner.toArray().map { p -> Point(p.x + rx1, p.y + ry1) }
                winner.release()
                MatOfPoint(*points.toTypedArray())
            }
        } catch (e: Throwable) {
            Log.w(TAG, "فشل كشف فقاعة الكلام لبلوك نص — رجوع متوقَّع لمستطيل خام من المتصل", e)
            null
        } finally {
            mat?.release(); gray?.release(); binary?.release(); kernel?.release(); hierarchy?.release()
            cropped?.recycle()
        }
    }

    /**
     * يبني قناع (Mat بمقاس [bitmap]، CV_8UC1، 255=أبيض داخل منطقة الطمس) لكل [blocks] —
     * يُستخدَم مباشرة كقناع لـPhoto.inpaint() بدل قناع المستطيلات الخام. أي بلوك لم يُعثر
     * لفقاعته على كونتور معقول يُرسَم كمستطيل خام (نفس السلوك القديم قبل هذا البند) بدل
     * تركه بدون طمس إطلاقاً — سلوك احتياطي متعمَّد لكل بلوك على حدة، لا للصفحة كاملة.
     * المتصل مسؤول عن استدعاء `mask.release()` بعد الاستخدام.
     */
    fun buildBubbleMask(bitmap: Bitmap, blocks: List<BlockData>): Mat {
        val mask = Mat.zeros(Size(bitmap.width.toDouble(), bitmap.height.toDouble()), CvType.CV_8UC1)
        for (block in blocks) {
            val contour = detectBubbleContour(bitmap, block)
            if (contour != null) {
                Imgproc.fillPoly(mask, listOf(contour), Scalar(255.0))
                contour.release()
            } else {
                val x1 = block.x.coerceIn(0, bitmap.width - 1)
                val y1 = block.y.coerceIn(0, bitmap.height - 1)
                val x2 = (block.x + block.width).coerceIn(0, bitmap.width)
                val y2 = (block.y + block.height).coerceIn(0, bitmap.height)
                Imgproc.rectangle(
                    mask,
                    Point(x1.toDouble(), y1.toDouble()),
                    Point(x2.toDouble(), y2.toDouble()),
                    Scalar(255.0),
                    -1
                )
            }
        }
        return mask
    }
}
