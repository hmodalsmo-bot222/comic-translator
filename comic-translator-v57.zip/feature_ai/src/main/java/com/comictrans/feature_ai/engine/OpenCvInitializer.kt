package com.comictrans.feature_ai.engine

import com.comictrans.engine.OpenCVStatus
import com.comictrans.engine.contracts.IOpenCvInitializer

/**
 * بند 11 — تهيئة مكتبة OpenCV الأصلية. انتقلت هنا لأن اعتمادية org.opencv:opencv
 * (وملفات .so الثقيلة المرافقة لها) انتقلت من app/build.gradle إلى feature_ai/build.gradle.
 * يُستدعى عبر Reflection من MainActivity.onCreate (راجع FeatureAiLoader.initializeOpenCV()
 * بموديول app). constructor بلا بارامترات لنفس سبب EngineFactories.kt المجاور.
 */
class OpenCvInitializer : IOpenCvInitializer {
    override fun initialize(): Boolean {
        val ok = org.opencv.android.OpenCVLoader.initLocal()
        OpenCVStatus.isAvailable = ok
        return ok
    }
}
