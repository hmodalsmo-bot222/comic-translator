package com.comictrans.feature_ai.engine

import android.content.Context
import com.comictrans.engine.ModelManager
import com.comictrans.engine.contracts.IErasureEngine
import com.comictrans.engine.contracts.IErasureEngineFactory
import com.comictrans.engine.contracts.IImageEnhanceEngine
import com.comictrans.engine.contracts.IImageEnhanceEngineFactory
import com.comictrans.engine.contracts.IOcrEngine
import com.comictrans.engine.contracts.IOcrEngineFactory

/**
 * بند 11 — نقاط الدخول اللي يحمّلها FeatureAiLoader (بموديول app) عبر Reflection.
 * كل كلاس هنا يحتاج constructor بلا بارامترات (no-arg) عشان
 * `Class.forName(...).getDeclaredConstructor().newInstance()` يشتغل صح — لذلك الإنشاء
 * الفعلي للمحرك (اللي يحتاج context/modelManager) موجود بدالة create() نفسها، لا بالـ
 * constructor. الأسماء الكاملة لهذه الكلاسات (الحزمة + اسم الكلاس) لازم تطابق بالضبط
 * الثوابت المستخدمة بـ FeatureAiLoader.kt (موديول app) — أي تغيير هنا يتطلب تعديلاً
 * يدوياً مطابقاً هناك.
 */

class OcrEngineFactory : IOcrEngineFactory {
    override fun create(context: Context, modelManager: ModelManager): IOcrEngine =
        OCREngine(context, modelManager)
}

class ErasureEngineFactory : IErasureEngineFactory {
    override fun create(context: Context, modelManager: ModelManager): IErasureEngine =
        ErasureEngine(context, modelManager)
}

class ImageEnhanceEngineFactory : IImageEnhanceEngineFactory {
    override fun create(context: Context, modelManager: ModelManager): IImageEnhanceEngine =
        ImageEnhanceEngine(context, modelManager)
}
