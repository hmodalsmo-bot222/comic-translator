package com.comictrans.feature_ai.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.util.Log
import com.comictrans.engine.ModelManager
import com.comictrans.engine.OpenCVStatus
import com.comictrans.engine.contracts.IErasureEngine
import com.comictrans.model.BlockData
import org.json.JSONObject
import org.opencv.android.Utils
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo
import org.tensorflow.lite.Interpreter
import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

// حجم مُدخل نموذج LaMa (ONNX من Carve/LaMa-ONNX، ونفترض نفس المقاس لـ TFLite ما لم
// يوفّر المستخدم نموذجاً بمقاس مختلف — راجع ModelManager.kt لتفاصيل مصدر النموذج).
private const val MODEL_INPUT_SIZE = 512

class ErasureEngine(
    private val context: Context,
    private val modelManager: ModelManager
) : IErasureEngine {

    private val TAG = "ErasureEngine"

    // تحميل نموذج AI Pro (ONNX)/AI Lite (TFLite) من الملف وتحسين الرسم البياني (graph
    // optimization) عملية مكلفة تاخذ وقتاً حقيقياً — كان الكود قبلاً يعيد هذا التحميل من
    // جديد مع كل صفحة (حتى لو نفس الملف)، وهذا كان السبب الأساسي لبطء وضع AI Pro. نحتفظ
    // هنا بجلسة/مفسّر واحد مُحمَّل مسبقاً، ونعيد استخدامه طالما مسار ملف النموذج نفسه لم
    // يتغيّر (يتغيّر فقط لو المستخدم حمّل نسخة نموذج مختلفة).
    private var cachedOnnxEnv: OrtEnvironment? = null
    private var cachedOnnxSession: OrtSession? = null
    private var cachedOnnxModelPath: String? = null

    private var cachedTfliteInterpreter: Interpreter? = null
    private var cachedTfliteModelPath: String? = null

    private fun getOrCreateOnnxSession(modelPath: String): Pair<OrtEnvironment, OrtSession> {
        if (cachedOnnxSession != null && cachedOnnxModelPath == modelPath) {
            return cachedOnnxEnv!! to cachedOnnxSession!!
        }
        try { cachedOnnxSession?.close() } catch (_: Exception) {}
        val env = cachedOnnxEnv ?: OrtEnvironment.getEnvironment().also { cachedOnnxEnv = it }
        val options = OrtSession.SessionOptions().apply {
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceAtLeast(1))
            // نموذج LaMa (~208MB) يحتوي طبقات Fourier ثقيلة الحساب، وتشغيله على CPU فقط لكل
            // فقاعة نص على حدة (512×512 لكل استدعاء) هو السبب الحقيقي لبطء "AI Pro" — وليس
            // خطأً في التخزين المؤقت (كان مُصلَحاً مسبقاً، انظر التعليق أعلى الكلاس). نحاول
            // تفعيل NNAPI (تسريع عتادي عبر DSP/GPU/NPU متى توفّر على الجهاز) وإلا نستمر على
            // CPU بصمت — بعض العمليات (خصوصاً FFT/irfft المستخدمة في LaMa) قد لا يدعمها
            // NNAPI فيرجع ONNX Runtime تلقائياً لـ CPU لتلك العقد فقط دون فشل كامل.
            try {
                addNnapi()
                Log.d(TAG, "AI Pro: تم تفعيل تسريع NNAPI (لو الجهاز يدعمه)")
            } catch (e: Throwable) {
                Log.w(TAG, "AI Pro: NNAPI غير متاح على هذا الجهاز — استمرار على CPU فقط", e)
            }
        }
        val session = env.createSession(modelPath, options)
        cachedOnnxSession = session
        cachedOnnxModelPath = modelPath
        return env to session
    }

    private fun getOrCreateTfliteInterpreter(file: File): Interpreter {
        if (cachedTfliteInterpreter != null && cachedTfliteModelPath == file.absolutePath) {
            return cachedTfliteInterpreter!!
        }
        try { cachedTfliteInterpreter?.close() } catch (_: Exception) {}
        val buffer = loadModelFile(file)
        val threads = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        // 🔍 (2026-08-18) إصلاح بلاغ فعلي من المستخدم: AOT-GAN Mobile "ينتظر إلى ما لا
        // نهاية" على جهازه. السبب الأرجح: إنشاء GPU Delegate (السطر أدناه) هو استدعاء
        // أصلي (native) قد يعلَّق فعلياً على بعض تشكيلات GPU/تعريفات السائق (driver) —
        // معروف كمشكلة موثَّقة لبعض نماذج TFLite على بعض الأجهزة (تجميع Shader يتعطَّل بدل
        // أن يفشل بخطأ واضح). بدون جهاز حقيقي هنا لا يمكن التأكد أي جهاز بالضبط يتأثر، لكن
        // بما إن هذا استدعاء أصلي غير قابل للإلغاء التعاوني من Kotlin (لا يفحص cancellation
        // إطلاقاً)، withTimeout العادية لن توقفه فعلياً. الحل العملي: ننفّذه على Thread
        // منفصل ونحدّ الانتظار بمهلة — لو انتهت المهلة، نتخلّى عنه (يُترَك يكمل بالخلفية
        // بمفرده، قد يُسرَّب لكنه غير خطير) ونكمل مباشرة بمحاولة NNAPI ثم CPU بدل تعليق
        // الصفحة كاملة للمستخدم للأبد.
        fun createWithTimeout(build: () -> Interpreter, timeoutMs: Long): Interpreter {
            val executor = java.util.concurrent.Executors.newSingleThreadExecutor()
            return try {
                executor.submit(java.util.concurrent.Callable { build() })
                    .get(timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS)
            } finally {
                executor.shutdown() // لا نستدعي shutdownNow — لو المهمة عالقة فعلياً، نتركها
                                     // تنتهي بمفردها بالخلفية بدل مقاطعة أصلية خطيرة (قد
                                     // تترك حالة native فاسدة داخل مكتبة TFLite نفسها).
            }
        }
        val interpreter = try {
            createWithTimeout({
                val gpuDelegate = org.tensorflow.lite.gpu.GpuDelegate()
                val opts = Interpreter.Options().apply { addDelegate(gpuDelegate); setNumThreads(threads) }
                Interpreter(buffer, opts).also { Log.d(TAG, "AI Lite: تم تفعيل GPU Delegate") }
            }, 8000L)
        } catch (e: Throwable) {
            Log.w(TAG, "AI Lite: فشل تفعيل GPU Delegate (أو تجاوز 8 ثوانٍ) — محاولة NNAPI", e)
            try {
                createWithTimeout({
                    val opts = Interpreter.Options().apply { setUseNNAPI(true); setNumThreads(threads) }
                    Interpreter(buffer, opts).also { Log.d(TAG, "AI Lite: تم تفعيل NNAPI") }
                }, 8000L)
            } catch (e2: Throwable) {
                Log.w(TAG, "AI Lite: فشل تفعيل NNAPI أيضاً (أو تجاوز 8 ثوانٍ) — استمرار على CPU متعدد الخيوط فقط", e2)
                val opts = Interpreter.Options().apply { setNumThreads(threads) }
                Interpreter(buffer, opts)
            }
        }
        cachedTfliteInterpreter = interpreter
        cachedTfliteModelPath = file.absolutePath
        return interpreter
    }

    // يُستدعى عند إغلاق التطبيق لتحرير الجلسة/المفسّر المُخزَّنين مؤقتاً (native resources).
    override fun close() {
        try { cachedOnnxSession?.close() } catch (_: Exception) {}
        try { cachedTfliteInterpreter?.close() } catch (_: Exception) {}
        cachedOnnxSession = null
        cachedTfliteInterpreter = null
    }

    // OpenCV Inpaint — works now if OpenCV is loaded
    // بند 3 (كشف فقاعات الكلام): بارامتر [bubbleAware] جديد، افتراضي false — لا يغيّر أي
    // سلوك قديم إطلاقاً ما لم يُفعَّله المتصل صراحة (راجع AppInterface/SettingsData
    // bubbleAwareErasure). لو true، نحاول قناع طمس أدق عبر BubbleDetector.buildBubbleMask()
    // بدل مستطيلات النص الخام؛ أي بلوك يفشل كشف فقاعته فردياً يرجع لمستطيل خام تلقائياً
    // (راجع BubbleDetector.buildBubbleMask نفسها)، فلا يمكن لهذا الخيار أن "يفشل" الصفحة
    // كاملة — أسوأ حالة هي نفس نتيجة false تماماً بلوك ببلوك.
    fun inpaintOpenCV(bitmap: Bitmap, blocks: List<BlockData>, bubbleAware: Boolean = false): Bitmap {
        if (!OpenCVStatus.isAvailable) {
            Log.w(TAG, "OpenCV غير محمّلة على هذا الجهاز — رجوع لطمس بسيط (مربع أبيض)")
            return fallbackErase(bitmap, blocks)
        }
        return try {
            // Convert Bitmap to Mat — Utils.bitmapToMat() على بتمابات ARGB_8888 ينتج دائماً
            // Mat بـ4 قنوات (CV_8UC4 / RGBA)، بما فيها قناة الشفافية.
            val srcRgba = Mat()
            Utils.bitmapToMat(bitmap, srcRgba)

            // *** الإصلاح الجذري لتعليق/انهيار "OpenCV Inpaint" ***
            // Photo.inpaint() في OpenCV يقبل فقط CV_8UC1 (رمادي) أو CV_8UC3 (RGB/BGR) —
            // وهذا موثّق صراحة في مصدر OpenCV (modules/photo/src/inpaint.cpp:
            // CV_Assert(src.type() == CV_8UC1 || src.type() == CV_8UC3)). كان الكود هنا يمرر
            // srcMat بـ4 قنوات مباشرة (ناتج Utils.bitmapToMat) بدون تحويل. فشل CV_Assert هذا
            // يحصل داخل الكود الأصلي (native) عبر JNI، وفي حزمة OpenCV الرسمية لأندرويد لا
            // يتحول دائماً لاستثناء Kotlin قابل للالتقاط بـ try/catch — غالباً يظهر كتجمّد
            // مؤقت (native abort) ثم إنهاء كامل للعملية (crash) بدل استثناء عادي. هذا هو
          // السبب الحقيقي وراء "OpenCV Inpaint يعلق ويخرج التطبيق"، وهو نفس السبب اللي كان
            // يفشّل أوضاع AI Lite/AI Pro أيضاً (يرجعان لـ inpaintOpenCV عند أي خطأ). ملاحظة:
            // ImageEnhanceEngine.kt كان يحوّل RGBA→RGB بشكل صحيح قبل معالجات OpenCV الأخرى —
            // هذا التحويل كان ناقصاً هنا تحديداً في مسار الطمس (inpaint).
            val srcRgb = Mat()
            Imgproc.cvtColor(srcRgba, srcRgb, Imgproc.COLOR_RGBA2RGB)

            // Create mask (black image, white where text is) — بنفس مقاس الصورة بـ3 قنوات.
            // بند 3: لو bubbleAware=true نحاول قناع دقيق بحدود الفقاعة الفعلية، وإلا (أو لو
            // فشل الكشف بالكامل بشكل غير متوقَّع) نرجع لمنطق المستطيلات الخام القديم بالضبط.
            val maskMat = if (bubbleAware) {
                try {
                    BubbleDetector.buildBubbleMask(bitmap, blocks)
                } catch (e: Throwable) {
                    Log.w(TAG, "فشل بناء قناع فقاعات الكلام — رجوع لقناع المستطيلات الخام", e)
                    buildRectMask(srcRgb, bitmap, blocks)
                }
            } else {
                buildRectMask(srcRgb, bitmap, blocks)
            }

            // Inpaint using Telea algorithm (يتطلب الآن CV_8UC3 فقط — تم التأكد أعلاه)
            val resultRgb = Mat()
            Photo.inpaint(srcRgb, maskMat, resultRgb, 3.0, Photo.INPAINT_TELEA)

            // نعيد قناة الشفافية قبل التحويل النهائي لـ Bitmap (ARGB_8888)
            val resultRgba = Mat()
            Imgproc.cvtColor(resultRgb, resultRgba, Imgproc.COLOR_RGB2RGBA)

            // Convert back to Bitmap
            val resultBitmap = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(resultRgba, resultBitmap)

            // Release mats
            srcRgba.release()
            srcRgb.release()
            maskMat.release()
            resultRgb.release()
            resultRgba.release()

            resultBitmap
        } catch (e: Throwable) {
            Log.e(TAG, "OpenCV inpaint failed", e)
            // Fallback: return original with white boxes
            fallbackErase(bitmap, blocks)
        }
    }

    /** قناع المستطيلات الخام القديم (السلوك الافتراضي قبل بند 3، ولا يزال الافتراضي الآن). */
    private fun buildRectMask(srcRgb: Mat, bitmap: Bitmap, blocks: List<BlockData>): Mat {
        val maskMat = Mat.zeros(srcRgb.size(), CvType.CV_8UC1)
        for (block in blocks) {
            val x1 = block.x.coerceIn(0, bitmap.width - 1)
            val y1 = block.y.coerceIn(0, bitmap.height - 1)
            val x2 = (block.x + block.width).coerceIn(0, bitmap.width)
            val y2 = (block.y + block.height).coerceIn(0, bitmap.height)
            Imgproc.rectangle(
                maskMat,
                Point(x1.toDouble(), y1.toDouble()),
                Point(x2.toDouble(), y2.toDouble()),
                Scalar(255.0), // White = inpaint this area
                -1 // Filled
            )
        }
        return maskMat
    }

    // AOT-GAN Mobile (TFLite) — يتطلب نموذج .tflite محمّل مسبقاً (qualcomm/AOT-GAN، راجع
    // ModelManager.kt للمصدر الكامل والتحذيرات). 🔍 (2026-08-16) استبدل هذا "AI Lite" —
    // مُدخلاته NHWC (float[1,512,512,3] صورة + float[1,512,512,1] قناع) بعكس LaMa (NCHW)،
    // لذلك نستخدم cropToNHWCFloatArray بدل cropToNCHWFloatArray. قناع البلوك [size*size] نفسه
    // يعمل بلا تعديل لأنه أحادي القناة (لا فرق NCHW/NHWC مع C=1). ⚠️ لم يُختبَر فعلياً على
    // جهاز — راجع التحذير بـModelManager عن مشاكل مخرجات محتملة (نقاش Qualcomm الرسمي).
    fun inpaintAotGan(bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val model = modelManager.availableModels.find { it.id == "aot_gan" }
        if (model == null || !modelManager.isDownloaded(model)) {
            Log.w(TAG, "AOT-GAN model not downloaded — falling back to OpenCV")
            return inpaintOpenCV(bitmap, blocks)
        }
        return try {
            val interpreter = getOrCreateTfliteInterpreter(modelManager.modelFile(model))
            inpaintPerBlockAotGan(interpreter, bitmap, blocks)
        } catch (e: Throwable) {
            Log.e(TAG, "AOT-GAN inpaint failed — falling back to OpenCV", e)
            inpaintOpenCV(bitmap, blocks)
        }
    }

    // MI-GAN Mobile (ONNX) — يتطلب نموذج .onnx محمّل مسبقاً (andraniksargsyan/migan pipeline،
    // راجع ModelManager.kt). 🔍 (2026-08-16) استبدل هذا "AI Pro" (LaMa) بعد تأكّد عدم وجود
    // نموذج RETHINED منشور للتحميل — راجع تعليق ModelManager الطويل للتفاصيل الكاملة. بعكس
    // LaMa، الـpipeline كاملة (قص/تصغير/تطبيع/دمج) مدمجة داخل ملف الـONNX نفسه، فلا حاجة هنا
    // لـpaddedCropRect بمقاس ثابت 512 أو لمنطق التطبيع اليدوي — نمرر القصاصة بمقاسها الأصلي
    // مباشرة كـuint8، والنموذج يرجع نتيجة مدموجة جاهزة بنفس مقاس القصاصة. مُدخلات uint8:
    // "image" RGB [H,W,3]، "mask" رمادي [H,W] حيث 255=أبقِ الأصلي و0=امسح (عكس LaMa/AOT-GAN
    // تماماً — انتبه، هذا مصدر خطأ شائع لو نُسِخ منطق من الوضعين الآخرين بالغلط).
    fun inpaintMiGan(bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val model = modelManager.availableModels.find { it.id == "migan" }
        if (model == null || !modelManager.isDownloaded(model)) {
            Log.w(TAG, "MI-GAN model not downloaded — falling back to OpenCV")
            return inpaintOpenCV(bitmap, blocks)
        }
        return try {
            val (env, session) = getOrCreateOnnxSession(modelManager.modelFile(model).absolutePath)
            inpaintPerBlockMiGan(env, session, bitmap, blocks)
        } catch (e: Throwable) {
            Log.e(TAG, "MI-GAN inpaint failed — falling back to OpenCV", e)
            inpaintOpenCV(bitmap, blocks)
        }
    }

    private fun inpaintPerBlockMiGan(env: OrtEnvironment, session: OrtSession, bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val result = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)
        // 🔍 أسماء المُدخلات المتوقَّعة "image"/"mask" موثّقة بـREADME الرسمي لـMI-GAN — لم
        // تُتحقَّق بفتح ملف الـONNX فعلياً بهذه البيئة (بدون أدوات فحص هنا)، فنطابق بالاسم أولاً
        // ونرجع لترتيب مُدخلات الجلسة (0=صورة، 1=قناع) كخطة احتياطية بدل الفشل الكامل.
        val inputNames = try { session.inputNames.toList() } catch (e: Throwable) { emptyList() }
        val imgName = inputNames.firstOrNull { it.contains("image", true) || it.contains("img", true) }
            ?: inputNames.getOrNull(0) ?: "image"
        val maskName = inputNames.firstOrNull { it.contains("mask", true) }
            ?: inputNames.getOrNull(1) ?: "mask"

        for (block in blocks) {
            var cropped: Bitmap? = null
            try {
                val crop = paddedCropRect(block, bitmap.width, bitmap.height)
                val cropW = crop.width(); val cropH = crop.height()
                cropped = Bitmap.createBitmap(bitmap, crop.left, crop.top, cropW, cropH)
                val pixels = IntArray(cropW * cropH)
                cropped.getPixels(pixels, 0, cropW, 0, 0, cropW, cropH)

                val imgBuf = ByteBuffer.allocateDirect(cropW * cropH * 3).order(ByteOrder.nativeOrder())
                val maskBuf = ByteBuffer.allocateDirect(cropW * cropH).order(ByteOrder.nativeOrder())
                val mx1 = (block.x - crop.left).coerceIn(0, cropW)
                val my1 = (block.y - crop.top).coerceIn(0, cropH)
                val mx2 = (block.x + block.width - crop.left).coerceIn(0, cropW)
                val my2 = (block.y + block.height - crop.top).coerceIn(0, cropH)
                for (y in 0 until cropH) {
                    for (x in 0 until cropW) {
                        val p = pixels[y * cropW + x]
                        imgBuf.put(((p shr 16) and 0xFF).toByte())
                        imgBuf.put(((p shr 8) and 0xFF).toByte())
                        imgBuf.put((p and 0xFF).toByte())
                        val erase = x in mx1 until mx2 && y in my1 until my2
                        maskBuf.put(if (erase) 0.toByte() else 255.toByte()) // 255=أبقِ، 0=امسح
                    }
                }
                imgBuf.rewind(); maskBuf.rewind()

                val imgTensor = OnnxTensor.createTensor(env, imgBuf, longArrayOf(cropH.toLong(), cropW.toLong(), 3), OnnxJavaType.UINT8)
                val maskTensor = OnnxTensor.createTensor(env, maskBuf, longArrayOf(cropH.toLong(), cropW.toLong(), 1), OnnxJavaType.UINT8)
                try {
                    session.run(mapOf(imgName to imgTensor, maskName to maskTensor)).use { results ->
                        val outValue = results.iterator().next().value
                        val outBmp = miGanOutputToBitmap(outValue.value, cropW, cropH)
                        if (outBmp != null) {
                            canvas.drawBitmap(outBmp, crop.left.toFloat(), crop.top.toFloat(), null)
                            outBmp.recycle()
                        } else {
                            throw IllegalStateException("شكل مخرج MI-GAN غير متوقَّع")
                        }
                    }
                } finally { imgTensor.close(); maskTensor.close() }
            } catch (e: Throwable) {
                Log.e(TAG, "MI-GAN block inference failed, using border-color fallback", e)
                val paint = Paint().apply { color = averageBorderColor(bitmap, block) }
                canvas.drawRect(Rect(block.x, block.y, block.x + block.width, block.y + block.height), paint)
            } finally {
                cropped?.recycle()
            }
        }
        return result
    }

    // مخرج MI-GAN المتوقَّع: مصفوفة متداخلة uint8/byte بشكل [H,W,3] (RGB، بدون محور دفعة —
    // القص لكل بلوك يُمرَّر منفرداً). ⚠️ الشكل الدقيق لم يُتحقَّق فعلياً (راجع التعليق أعلى
    // inpaintPerBlockMiGan) — لو اختلف عملياً، هذه الدالة ترجع null فتُستخدم خطة fallback
    // (لون حدود متوسط) بدل الانهيار.
    @Suppress("UNCHECKED_CAST")
    private fun miGanOutputToBitmap(raw: Any?, w: Int, h: Int): Bitmap? {
        return try {
            val outer = raw as Array<*> // [H]
            val pixels = IntArray(w * h)
            for (y in 0 until h) {
                val row = outer[y] as Array<*> // [W]
                for (x in 0 until w) {
                    val px = row[x] as Array<*> // [3]
                    fun chan(v: Any?): Int = when (v) {
                        is Byte -> v.toInt() and 0xFF
                        is Number -> v.toInt().coerceIn(0, 255)
                        else -> 0
                    }
                    pixels[y * w + x] = Color.rgb(chan(px[0]), chan(px[1]), chan(px[2]))
                }
            }
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.setPixels(pixels, 0, w, 0, 0, w, h)
            bmp
        } catch (e: Throwable) {
            Log.e(TAG, "تعذّر تفسير شكل مخرج MI-GAN", e)
            null
        }
    }

    // ============ منطق مشترك: نقصّ حول كل فقاعة نص (مع هامش سياق)، نصغّر القصاصة
    // لمقاس مُدخل النموذج، نشغّل الاستدلال، ثم نعيد النتيجة لمقاسها الأصلي ونلصقها
    // في مكانها بالصورة الكاملة — بدل تصغير الصفحة كاملة لـ 512×512 (جودة أفضل بكثير
    // لصفحة كومك كاملة الدقة، وأقرب لكيفية عمل تطبيقات الترجمة الاحترافية) ============

    private fun paddedCropRect(block: BlockData, bmpW: Int, bmpH: Int): Rect {
        val padX = (block.width * 0.4f).toInt().coerceAtLeast(16)
        val padY = (block.height * 0.4f).toInt().coerceAtLeast(16)
        val x1 = (block.x - padX).coerceIn(0, bmpW - 1)
        val y1 = (block.y - padY).coerceIn(0, bmpH - 1)
        val x2 = (block.x + block.width + padX).coerceIn(x1 + 1, bmpW)
        val y2 = (block.y + block.height + padY).coerceIn(y1 + 1, bmpH)
        return Rect(x1, y1, x2, y2)
    }

    // مصفوفة float NHWC [1,S,S,3] RGB/255 من قصاصة مُصغّرة لمقاس النموذج — ترتيب مُتداخل
    // (R,G,B لكل بكسل تباعاً) بعكس NCHW القديم (كان مستخدَماً لـLaMa، مُستبدَل الآن بـAOT-GAN
    // الذي مُدخلاته NHWC — راجع تعليق inpaintAotGan وModelManager.kt).
    private fun cropToNHWCFloatArray(bitmap: Bitmap, crop: Rect, size: Int): FloatArray {
        val cropped = Bitmap.createBitmap(bitmap, crop.left, crop.top, crop.width(), crop.height())
        val resized = Bitmap.createScaledBitmap(cropped, size, size, true)
        val pixels = IntArray(size * size)
        resized.getPixels(pixels, 0, size, 0, 0, size, size)
        val out = FloatArray(3 * size * size)
        for (i in 0 until size * size) {
            val p = pixels[i]
            out[i * 3] = ((p shr 16) and 0xFF) / 255f        // R
            out[i * 3 + 1] = ((p shr 8) and 0xFF) / 255f      // G
            out[i * 3 + 2] = (p and 0xFF) / 255f              // B
        }
        if (cropped !== bitmap) cropped.recycle()
        resized.recycle()
        return out
    }

    // قناع [1,1,S,S]: 1.0 داخل مستطيل الفقاعة الأصلي (بعد تحويله لمقاس القصاصة المُصغّرة)، 0 خارجه
    private fun blockMaskFloatArray(block: BlockData, crop: Rect, size: Int): FloatArray {
        val mask = FloatArray(size * size)
        val sx = size.toFloat() / crop.width()
        val sy = size.toFloat() / crop.height()
        val mx1 = (((block.x - crop.left) * sx).toInt()).coerceIn(0, size)
        val my1 = (((block.y - crop.top) * sy).toInt()).coerceIn(0, size)
        val mx2 = (((block.x + block.width - crop.left) * sx).toInt()).coerceIn(0, size)
        val my2 = (((block.y + block.height - crop.top) * sy).toInt()).coerceIn(0, size)
        for (y in my1 until my2) {
            for (x in mx1 until mx2) mask[y * size + x] = 1f
        }
        return mask
    }

    // مُخرَج NHWC مُتداخل [S,S,3] → Bitmap (بعكس outputArrayToBitmap القديمة التي كانت تفترض
    // NCHW مستوٍ لـLaMa).
    private fun outputArrayToBitmapNHWC(output: FloatArray, size: Int): Bitmap {
        val pixels = IntArray(size * size)
        for (i in 0 until size * size) {
            val r = output[i * 3].toInt().coerceIn(0, 255)
            val g = output[i * 3 + 1].toInt().coerceIn(0, 255)
            val b = output[i * 3 + 2].toInt().coerceIn(0, 255)
            pixels[i] = Color.rgb(r, g, b)
        }
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        bmp.setPixels(pixels, 0, size, 0, 0, size, size)
        return bmp
    }

    private fun inpaintPerBlockAotGan(interpreter: Interpreter, bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val result = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)
        val size = MODEL_INPUT_SIZE
        for (block in blocks) {
            try {
                val crop = paddedCropRect(block, bitmap.width, bitmap.height)
                val imgArr = cropToNHWCFloatArray(bitmap, crop, size)
                val maskArr = blockMaskFloatArray(block, crop, size)

                val imgBuf = ByteBuffer.allocateDirect(imgArr.size * 4).order(ByteOrder.nativeOrder())
                imgArr.forEach { imgBuf.putFloat(it) }
                imgBuf.rewind()
                val maskBuf = ByteBuffer.allocateDirect(maskArr.size * 4).order(ByteOrder.nativeOrder())
                maskArr.forEach { maskBuf.putFloat(it) }
                maskBuf.rewind()

                val outputBuf = ByteBuffer.allocateDirect(3 * size * size * 4).order(ByteOrder.nativeOrder())
                // 🔍 (2026-08-18) بلاغ فعلي: AOT-GAN يعلَّق للأبد على جهاز المستخدم. غلاف
                // مهلة إضافي هنا (بجانب مهلة إنشاء المفسِّر بـgetOrCreateTfliteInterpreter)
                // يغطي احتمال أن التعليق الفعلي يصير بالاستدلال نفسه لا بإنشاء المفسِّر —
                // لو عمليات AOT-GAN غير مدعومة كلياً بمفوَّض GPU الجزئي على هذا الجهاز، قد
                // يعلَّق run() نفسه بدل مجرد الفشل بخطأ واضح. 12 ثانية للبلوك الواحد سخية
                // بما يكفي لأي جهاز حتى بدون تسريع (نموذج متوسط الحجم 61MB)، بينما تمنع
                // تعليق الصفحة كاملة للأبد لو صار تعليق فعلي.
                val inferenceExecutor = java.util.concurrent.Executors.newSingleThreadExecutor()
                try {
                    inferenceExecutor.submit(java.util.concurrent.Callable {
                        interpreter.runForMultipleInputsOutputs(arrayOf(imgBuf, maskBuf), mapOf(0 to outputBuf))
                    }).get(12000L, java.util.concurrent.TimeUnit.MILLISECONDS)
                } finally {
                    inferenceExecutor.shutdown()
                }

                outputBuf.rewind()
                val plane = size * size
                val rawOut = FloatArray(3 * plane)
                for (i in rawOut.indices) rawOut[i] = outputBuf.float

                // 🔍 (2026-08-15، محفوظ من AI Lite القديم) إصلاح خلل تطبيع محتمل بنفس الفكرة —
                // بدل افتراض ثابت أعمى لمقياس مخرج النموذج ([0,1] أو [-1,1] أو [0,255])، نكتشف
                // المدى فعلياً من القيم الحقيقية وقت التشغيل:
                val minV = rawOut.min(); val maxV = rawOut.max()
                val flatOut = when {
                    // مخرج بمقياس [0,1] تقريباً → تحويل لـ[0,255]
                    minV >= -0.05f && maxV <= 1.05f -> FloatArray(rawOut.size) { rawOut[it] * 255f }
                    // مخرج بمقياس [-1,1] تقريباً (شائع بنماذج GAN/inpainting بعد Tanh) → [0,255]
                    minV >= -1.05f && maxV <= 1.05f -> FloatArray(rawOut.size) { (rawOut[it] + 1f) * 127.5f }
                    // غير ذلك: القيم أصلاً تتجاوز [-1,1] بوضوح — الأرجح أن المخرج بمقياس
                    // [0,255] (أو قريب منه) أصلاً ولا حاجة لأي تحويل إضافي.
                    else -> rawOut
                }
                val outBmp = outputArrayToBitmapNHWC(flatOut, size)
                val scaledBack = Bitmap.createScaledBitmap(outBmp, crop.width(), crop.height(), true)
                canvas.drawBitmap(scaledBack, crop.left.toFloat(), crop.top.toFloat(), null)
                outBmp.recycle(); scaledBack.recycle()
            } catch (e: Throwable) {
                Log.e(TAG, "AOT-GAN block inference failed for block, using border-color fallback", e)
                val paint = Paint().apply { color = averageBorderColor(bitmap, block) }
                canvas.drawRect(Rect(block.x, block.y, block.x + block.width, block.y + block.height), paint)
            }
        }
        return result
    }

    // Main entry point called from AppInterface
    /**
     * Native erasure entry point. Returns the processed page Bitmap directly.
     * The caller stores it in the local cache and serves it to WebView by URL;
     * no Base64 payload is created for the WebView bridge.
     *
     * بند 3: [bubbleAware] (افتراضي false) يُمرَّر فقط لوضع "opencv" حالياً — أوضاع
     * aot_gan/migan (سابقاً ai_lite/ai_pro، استُبدلا 2026-08-16) تعتمد أصلاً على قصّ مُوسَّع
     * حول كل بلوك (paddedCropRect) وليس قناع مستطيل/فقاعة، فلا ينطبق عليها هذا الخيار بنفس
     * الطريقة.
     */
    override fun processBitmap(bitmap: Bitmap, blocks: List<BlockData>, mode: String, bubbleAware: Boolean): Bitmap? {
        return when (mode) {
            "opencv" -> inpaintOpenCV(bitmap, blocks, bubbleAware)
            "aot_gan" -> inpaintAotGan(bitmap, blocks)
            "migan" -> inpaintMiGan(bitmap, blocks)
            else -> null
        }
    }

    private fun fallbackErase(bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val result = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)
        for (block in blocks) {
            val paint = Paint().apply { color = averageBorderColor(bitmap, block) }
            canvas.drawRect(
                Rect(block.x, block.y, block.x + block.width, block.y + block.height),
                paint
            )
        }
        return result
    }

    /**
     * بند 4: بدل تعبئة أبيض ثابت في كل مسارات الطمس الاحتياطية (fallback — سواء فشل الصفحة
     * كاملة أو بلوك واحد فقط داخل AI Lite/AI Pro)، نأخذ متوسط لون البكسلات على حلقة حدودية
     * حول منطقة النص (خارجها مباشرة، لا داخلها) ونملأ بذلك اللون. هذا أقرب بصرياً لخلفية
     * الفقاعة الفعلية (أبيض/كريمي/رمادي فاتح حسب أسلوب الرسم) من أبيض ثابت يبرز بوضوح فوق
     * أي خلفية ليست بيضاء تماماً. نعيّن الحلقة الحدودية تحديداً (لا منطقة عشوائية من الصفحة)
     * لأنها الأقرب فعلياً للون خلفية الفقاعة المباشر حول النص المطموس.
     */
    private fun averageBorderColor(bitmap: Bitmap, block: BlockData): Int {
        val ringWidth = maxOf((minOf(block.width, block.height) * 0.15f).toInt(), 4)
        val ox1 = (block.x - ringWidth).coerceIn(0, bitmap.width - 1)
        val oy1 = (block.y - ringWidth).coerceIn(0, bitmap.height - 1)
        val ox2 = (block.x + block.width + ringWidth).coerceIn(ox1 + 1, bitmap.width)
        val oy2 = (block.y + block.height + ringWidth).coerceIn(oy1 + 1, bitmap.height)
        val ix1 = block.x.coerceIn(ox1, ox2)
        val iy1 = block.y.coerceIn(oy1, oy2)
        val ix2 = (block.x + block.width).coerceIn(ix1, ox2)
        val iy2 = (block.y + block.height).coerceIn(iy1, oy2)

        var sumR = 0L; var sumG = 0L; var sumB = 0L; var count = 0L
        // نمسح كل بكسلات المستطيل الخارجي (ox1..ox2 × oy1..oy2) ونستبعد المستطيل الداخلي
        // (منطقة النص نفسها ix1..ix2 × iy1..iy2) — يعطينا هذا فقط "الحلقة" المحيطة بالنص.
        val step = 2 // نقفز كل بكسلين لتسريع الحساب بدون خسارة دقة ملموسة على منطقة صغيرة
        var y = oy1
        while (y < oy2) {
            val insideRow = y in iy1 until iy2
            var x = ox1
            while (x < ox2) {
                if (!(insideRow && x in ix1 until ix2)) {
                    val p = bitmap.getPixel(x, y)
                    sumR += (p shr 16) and 0xFF
                    sumG += (p shr 8) and 0xFF
                    sumB += p and 0xFF
                    count++
                }
                x += step
            }
            y += step
        }
        if (count == 0L) return Color.WHITE // حلقة فارغة (بلوك يملأ الصفحة تقريباً) — أبيض كحل أخير معقول
        return Color.rgb((sumR / count).toInt(), (sumG / count).toInt(), (sumB / count).toInt())
    }

    private fun loadModelFile(file: File): MappedByteBuffer {
        val stream = FileInputStream(file)
        val channel = stream.channel
        return channel.map(FileChannel.MapMode.READ_ONLY, 0, file.length())
    }

}
