# تقرير المراجعة الفنية — Comic Translator v12

## أخطر المشاكل التي وجدتها في النسخة الأصلية

1. **cbz-unzip.js / DEFLATE**
   - خوارزمية Huffman كانت تبني الأكواد بالترتيب الكانوني الطبيعي، بينما DEFLATE يرسل البتات LSB-first.
   - النتيجة: ملفات CBZ/ZIP المضغوطة بـ DEFLATE قد تفشل أو تنتج `bad huffman code`.
   - تم إصلاح عكس البتات + إضافة فحوص حدود وكتلة stored والتحقق من المسافة.

2. **OCR كان يرجع أسطر ML Kit منفصلة**
   - هذا يؤدي إلى إرسال عدة طلبات ترجمة لنفس فقاعة الكلام.
   - تم إضافة تجميع هندسي لأسطر OCR المتقاربة إلى كتلة واحدة قبل الترجمة.

3. **لا يوجد PaddleOCR فعلي في المشروع الأصلي**
   - الواجهة كانت تحتوي ML Kit/Tesseract/Cloud فقط.
   - تم إضافة PaddleOCR4Android كخيار محلي، مع Paddle-Lite runtime داخل المكتبة، واستخدام DET+CLS+REC.
   - عند عدم وجود ملفات `.nb` المتوافقة، يتم الرجوع تلقائياً إلى ML Kit بدلاً من انهيار التطبيق.

4. **مشاكل تجهيز Paddle-Lite اليدوي**
   - المشروع الأصلي كان يعتمد على ملفات runtime خارج الشجرة، وهو سبب مباشر لنوع الخطأ السابق الخاص بـ `paddle_api.h` و`libpaddle_light_api_shared.so`.
   - النسخة الجديدة لا تحتوي خطوة `preparePaddleLite` يدوية ولا تفترض وجود هذه الملفات.

5. **GitHub Actions**
   - workflow الأصلي كان يحاول تشغيل `gradle wrapper` ثم `./gradlew` بدون wrapper محفوظ في المشروع.
   - تم تحويله إلى `gradle/actions/setup-gradle@v6` مع Gradle 8.4 وتشغيل `gradle :app:assembleDebug` مباشرة.

6. **Android storage**
   - تم حذف READ/WRITE_EXTERNAL_STORAGE القديمة لأن منتقي الملفات الحديث لا يحتاجها لهذا الاستخدام.

7. **WebView**
   - تم تعطيل cleartext HTTP افتراضياً، وتعطيل الوصول الشامل من file URLs، وإضافة تنظيف WebView عند تدمير Activity.

8. **Reader zoom**
   - تم تثبيت touch behavior للقارئ مع إبقاء التكبير المخصص في JavaScript وعدم إعادة تمكين zoom الأصلي للـ WebView.
   - تم تحسين اختيار الصفحة الحالية.

## ملفات مهمة في النسخة المعدلة

- `app/src/main/java/com/comictrans/engine/OCREngine.kt`
- `app/src/main/java/com/comictrans/AppInterface.kt`
- `app/src/main/assets/index.html`
- `app/src/main/assets/js/cbz-unzip.js`
- `app/src/main/AndroidManifest.xml`
- `app/build.gradle`
- `settings.gradle`
- `.github/workflows/build.yml`
- `app/src/main/assets/paddle/en_dict.txt`

## بخصوص نماذج PaddleOCR

وضعت قاموس English من 95 رمزاً ASCII في `assets/paddle/en_dict.txt`، لكن **لم أضع ملفات det/rec/cls مزيفة أو ناقصة**. يجب أن تكون ملفات `.nb` متوافقة مع runtime والموديل. إذا لم تكن موجودة، التطبيق يستخدم ML Kit تلقائياً.

## حالة التحقق المحلي

- XML files: تم التحقق من سلامة XML.
- `cbz-unzip.js`: اجتاز `node --check`.
- لا أستطيع تنفيذ Android/Gradle build فعلياً داخل هذه البيئة لأن Gradle/Android SDK غير متاحين هنا؛ لذلك لن أدّعي أن APK تم بناؤه محلياً. workflow الجديد مهيأ ليبني المشروع على GitHub Actions.
