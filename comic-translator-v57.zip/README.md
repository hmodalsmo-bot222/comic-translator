# قارئ الكوميكس المترجم — Comic Translator

مشروع Android كامل (Kotlin + HTML5) لترجمة الكوميكس من الإنجليزية للعربية.

## المعمارية

```
Android Native (Kotlin) ← المنصّق
├─ ML Kit OCR (يعمل فوراً)
├─ ML Kit Translation EN→AR (يعمل فوراً)
├─ Google Translate (يعمل فوراً)
├─ SQLite ذاكرة ذكية (تعمل فوراً)
├─ JavaScript Interface (يعمل فوراً)
├─ OkHttp للترجمة السحابية (يعمل فوراً)
├─ OpenCV Inpaint (يعمل عبر Maven Central + OpenCVLoader.initLocal())
├─ TFLite AI Inpainting (stub — يحتاج تطبيقاً حقيقياً + نموذج .tflite)
└─ ONNX AI Inpainting (stub — يحتاج تطبيقاً حقيقياً + نموذج .onnx)

HTML5 (WebView) ← الواجهة
├─ عرض صفحات CBZ (يعمل — STORE method)
├─ Canvas Overlay (يعمل)
├─ قوائم الإعدادات (تعمل)
└─ JavaScript Bridge (يعمل)
```

---

## ما يعمل فوراً (بدون ملفات إضافية)

| الميزة | الحالة | ملاحظة |
|--------|--------|--------|
| ML Kit OCR | ✅ | يعمل offline بعد تحميل النموذج |
| ML Kit Translation EN→AR | ✅ | يعمل offline بعد تحميل النموذج |
| Google Translate (gtx) | ✅ | يحتاج إنترنت |
| Gemini / OpenAI / DeepL | ✅ | يحتاج مفتاح API |
| SQLite ذاكرة ذكية | ✅ | محلي تماماً |
| OCR.space | ✅ | يحتاج مفتاح API |
| Cloud API | ✅ | رابط مخصص |
| ملء لوني (يسحب لون الفقاعة) / تمويه | ✅ | في HTML Canvas |
| خلفية النص (حر / مربع أبيض) | ✅ | إعداد مستقل عن مسح النص القديم |
| OpenCV Inpaint | ✅ | عبر Maven Central، بدون ملفات يدوية |
| CBZ unzip (STORE) | ✅ | الملفات غير المضغوطة |

---

## ما يحتاج ملفات ثنائية إضافية

> **ملاحظة:** OpenCV لم يعد يحتاج نسخ ملفات `.so` يدوياً — يُحمَّل تلقائياً عبر
> حزمة Maven Central الرسمية (`org.opencv:opencv:4.9.0`) المُعرَّفة في `build.gradle`،
> ويُهيَّأ بشكل صحيح الآن عبر `OpenCVLoader.initLocal()`.

### ١. AI Lite (TFLite Inpainting)

**الملفات المطلوبة:**
```
/storage/emulated/0/Android/data/com.comictrans/files/models/lama-lite.tflite
```

**كيفية الحصول:**
1. تحميل نموذج LaMa أو MAT (PyTorch)
2. تحويله إلى TFLite عبر:
   ```python
   import tensorflow as tf
   converter = tf.lite.TFLiteConverter.from_saved_model('lama_model')
   converter.optimizations = [tf.lite.Optimize.DEFAULT]
   tflite_model = converter.convert()
   with open('lama-lite.tflite', 'wb') as f:
       f.write(tflite_model)
   ```
3. ضع الملف في مجلد models على الهاتف

**التحدي:**
- نماذج Inpainting ثقيلة (20-50MB)
- تحويلها يحتاج Python + TensorFlow
- يجب أن تدعم مدخلات: صورة + قناع (mask)

---

### ٢. AI Pro (ONNX Inpainting)

**الملفات المطلوبة:**
```
/storage/emulated/0/Android/data/com.comictrans/files/models/lama-pro.onnx
```

**كيفية الحصول:**
1. تحميل نموذج LaMa (PyTorch)
2. تحويله إلى ONNX:
   ```python
   import torch
   import torch.onnx
   torch.onnx.export(model, dummy_input, "lama-pro.onnx", opset_version=11)
   ```
3. ضع الملف في مجلد models على الهاتف

---

### ٣. fflate.js (للـ CBZ المضغوط DEFLATE)

**الملف المطلوب:**
```
app/src/main/assets/js/fflate.min.js
```

**كيفية الحصول:**
1. `npm install fflate`
2. أو تحميل من CDN: https://cdn.jsdelivr.net/npm/fflate@0.8.2/umd/index.min.js
3. ضعه في المجلد أعلاه
4. عدّل `index.html` ليستخدم fflate بدلاً من `cbz-unzip.js`

**البديل:**
الكود الحالي `cbz-unzip.js` يدعم STORE (غير مضغوط) فقط. معظم CBZ تستخدم DEFLATE.

---

## كيفية البناء

### عبر GitHub Actions (تلقائي — الأسهل)

المشروع يحتوي على `.github/workflows/build.yml` يبني الـ APK تلقائياً عند كل push، ويولّد ملفات gradle wrapper بنفسه (لأنها غير مرفقة بالمشروع).

1. ارفع المشروع لمستودع GitHub جديد (أو موجود).
2. من تبويب **Actions** بالمستودع، شغّل الـ workflow يدوياً (`workflow_dispatch`) أو انتظر أول push.
3. بعد اكتمال التشغيل بنجاح، افتح تفاصيل الـ run وحمّل الـ APK من قسم **Artifacts** باسم `comic-translator-debug-apk`.

### في Codespaces (GitHub)

```bash
# ١. ادخل لمجلد المشروع
cd comic-translator

# ٢. ولّد ملفات gradle wrapper (غير مرفقة بالمشروع)
gradle wrapper --gradle-version 8.4
chmod +x gradlew

# ٣. بناء APK
./gradlew assembleDebug

# ٤. APK الناتج
app/build/outputs/apk/debug/app-debug.apk
```

### في Android Studio

1. افتح المجلد `comic-translator`.
2. انتظر Gradle Sync (يولّد الـ wrapper تلقائياً إن لزم).
3. اضغط Run (▶️) أو Build → Build APK.

---

## الملفات الرئيسية

| الملف | الغرض |
|-------|-------|
| `MainActivity.kt` | WebView + OpenCV init |
| `AppInterface.kt` | JavaScript Interface + Coordinator |
| `OCREngine.kt` | ML Kit + OCR.space + Cloud |
| `TranslationEngine.kt` | ML Kit + Google + Gemini + OpenAI + DeepL |
| `ErasureEngine.kt` | OpenCV + TFLite (stub) + ONNX (stub) |
| `TranslationEntity.kt` | جدول SQLite |
| `index.html` | الواجهة الكاملة |
| `cbz-unzip.js` | فك CBZ (STORE) |

---

## آخر التغييرات (v8)

- **قوائم اختيار جديدة بنفس هوية التطبيق**: كل قوائم `<select>` بالإعدادات (محرك OCR، وضع الطمس، الترجمة، تعزيز الصورة، خلفية المجتمع...) أصبحت تفتح كقائمة منبثقة بأزرار راديو دائرية بدل شكل `<select>` الافتراضي بالمتصفح.
- **🧠 حجم خط ذكي**: خيار جديد بقسم «تنسيق الخط» — يحسب أكبر حجم خط ممكن يخلي النص المترجم كامل (بعد التفاف الأسطر) يتلائم داخل حدود الفقاعة عرضاً وارتفاعاً، بدل نسبة ثابتة من أبعاد الصندوق. مفعّل افتراضياً، ويمكن تعطيله للرجوع للسلايدر اليدوي القديم.
- **☁️ خلفية المجتمع (مزامنة الذاكرة الذكية)**: قسم إعدادات جديد لمزامنة ذاكرة الترجمة بين الأجهزة عبر: Firebase Realtime Database، Supabase، GitHub Gist، أو Local Sync (تصدير/استيراد ملف JSON بدون إنترنت). كل خلفية سحابية تحتاج مشروعك الخاص (لا توجد مفاتيح مضمّنة بالتطبيق) — التفاصيل بقسم «خلفية المجتمع» أدناه.

## آخر التغييرات (v4)

- **حذف PaddleOCR نهائياً**: كان موجوداً بالوثائق فقط (لم يكن مفعّلاً فعلياً بالكود أصلاً)، أُزيلت كل إشاراته.
- **إصلاح جذري لخلفية النص البيضاء الدائمة**: خيار "◯ لا شيء (Overlay)" كان اسمه مضلِّلاً — الكود كان يرسم خلفية بيضاء شبه معتمة خلفه بأي حال، فكانت تظهر دائماً بغض النظر عن الاختيار. أُلغي هذا الخيار المكرر/الخاطئ، وأُضيف بدلاً منه إعداد **مستقل بالكامل** «خلفية النص المترجم»: حر (بدون خلفية) / مربع أبيض — لا يتدخل إطلاقاً بإعدادات مسح النص القديم (fill/blur/opencv...).
- **ملء لوني (Color Fill) أصبح فعلياً "لونياً"**: بدل الأبيض الثابت، يسحب الآن متوسط لون حواف الفقاعة من الصورة الأصلية تلقائياً (`sampleEdgeColor`)، فيتماشى مع لون الفقاعة الحقيقي بدل مربع أبيض دايم.
- **إصلاح OpenCV Inpaint**: كان يفشل بصمت لأن `MainActivity.kt` يحمّل المكتبة بطريقة `System.loadLibrary("opencv_java4")` القديمة غير المتوافقة مع حزمة Maven Central (4.9.0) المستخدمة فعلياً في `build.gradle`؛ استُبدلت بـ `OpenCVLoader.initLocal()` الصحيحة. هذا كان سبب رجوع OpenCV/AI Lite/AI Pro التلقائي لمربع أبيض بدل الطمس الحقيقي.
- **تكبير جديد على مستوى القارئ كامل** (إحساس تطبيقات المانجا): بدل تكبير كل صفحة لحالها بسقف 5x، التكبير الآن مستمر على كل الصفحات مع بعض، بدون سقف أقصى صارم، وبدون أي رجوع تلقائي (فقط نقرة مزدوجة مقصودة تصفّر التكبير)، مع سحب بإصبع واحدة أثناء التكبير عبر القارئ بالكامل.

## آخر التغييرات (v3)

- **إصلاح جذري**: أوضاع OpenCV/AI Lite/AI Pro كانت تعالج الصورة بالأندرويد ثم النتيجة تُرمى ولا تظهر أبداً — لأن `index.html` كان يقرأ حقل `blocks` فقط ويتجاهل `erasureData` القادم من Kotlin. تم التوحيد بينهما وأصبحت كل أوضاع الطمس تعمل فعلياً.
- زر «💾 حفظ وتطبيق الإعدادات» (يحفظ محلياً عبر localStorage ويعيد رسم الصفحات المترجمة فوراً بالتنسيق الجديد).
- قسم «🔤 تنسيق الخط»: نوع الخط (مع فحص فعلي لتوفره على الجهاز)، حجم الخط، تباعد الأسطر، عرض النص داخل الفقاعة، لون الخط.
- رسم الكانفاس بدقة `devicePixelRatio` لخط أوضح عند التكبير.
- حقلا اسم نموذج Gemini/OpenAI قابلان للتعديل بدل ما كانا مثبتين بالكود.
- تكبير/تصغير وتحريك بإصبعين (Pinch-zoom + Pan) على كل صفحة، وتصغير سريع بالنقر المزدوج.
- الشريط العائم صار شبه شفاف وقابل للسحب يمين/يسار، وأضيف زر ثالث «🔄 صفحة جديدة» يمسح ترجمة الصفحة الحالية فقط ويرجعها للأصل لإعادة القراءة والترجمة.
- سجل أحداث أوضح: نجاح كل مرحلة (OCR/ترجمة/طمس)، كل تبديل محرك، الحفظ، الاستعادة.

## ☁️ خلفية المجتمع (مزامنة الذاكرة الذكية)

قسم بالإعدادات لمزامنة ذاكرة الترجمة (SQLite) بين أجهزتك أو مع فريق. كل خيار (عدا Local Sync) يحتاج مشروعك السحابي الخاص — التطبيق لا يحمل أي مفاتيح مضمّنة.

| الخيار | صيغة حقل «مفتاح/رابط الخدمة» | ملاحظة |
|--------|-------------------------------|--------|
| ❌ معطل | — | لا مزامنة، الذاكرة محلية فقط |
| 🔥 Firebase | `رابط_قاعدة_البيانات\|السر` | Realtime Database REST، مثال: `https://xxx.firebaseio.com\|SECRET` |
| ⚡ Supabase | `رابط_المشروع\|apikey` | يحتاج جدول `comictrans_sync` بأعمدة `id`/`data`/`updated_at` تنشئه بنفسك من Table editor |
| 🐙 GitHub Gist | `token` ثم `token\|gistId` بعد أول رفعة | Token يحتاج صلاحية `gist` |
| 💾 Local Sync | — | تصدير/استيراد ملف JSON يدوياً، بدون إنترنت |

## الترخيص

MIT — استخدمه كما تشاء.


## V14 final architecture

- CBZ/ZIP is opened and extracted by Android/Kotlin with `ZipInputStream`; the JavaScript unzip path is removed from the Android app.
- WebView receives only local URLs (`https://comic.local/page/...` and `https://comic.local/processed/...`), not page-image Base64.
- Native OpenCV/AI erasure writes processed pages to the app cache and returns a URL.
- PaddleOCR uses the actual Paddle-Lite Android artifact `paddleocr4android:v1.2.0` and official `.nb` mobile models prepared by GitHub Actions.
- OpenRouter is available as a translation engine with API-key and model fields.


## Build fix (V15)
- Updated PaddleOCR4Android Paddle-Lite dependency from v1.2.0 to v1.3.0. The upstream v1.3.0 tag contains a JitPack build fix; v1.2.0 could not be resolved by GitHub Actions.
