# V18 — المرحلة 1: نظام الأخطاء الموحّد + Model Manager (Resume/Pause/تحقق)

⚠️ **تنبيه صريح**: تم كتابة هذه التعديلات في بيئة بدون Android SDK وبدون اتصال إنترنت —
لم يُبنَ (build) المشروع ولم يُختبر فعلياً على جهاز/محاكي. راجع الكود وابنِه واختبره قبل
الاعتماد عليه، خصوصاً منطق Resume/Pause في ModelManager (يحتاج اختباراً فعلياً مع خادم
حقيقي يدعم/لا يدعم HTTP Range).

## الملفات الجديدة

### `app/src/main/java/com/comictrans/error/AppError.kt`
تمثيل موحّد لأي خطأ: `ErrorCategory` (OCR / TRANSLATION / AI_MODEL / CBZ / FILE /
NETWORK / UNKNOWN)، `ErrorSeverity` (WARNING/ERROR/FATAL)، و`AppError` نفسها (رسالة عربية
آمنة للمستخدم `userMessage` + تفاصيل تقنية `technicalDetail` للسجلات فقط).

### `app/src/main/java/com/comictrans/error/ErrorManager.kt`
النقطة الموحّدة لمعالجة كل الأخطاء:
- `handle(throwable, category, contextMessage)` يحوّل أي `Throwable` إلى `AppError` برسالة
  عربية مناسبة حسب نوع الاستثناء (انقطاع إنترنت / انتهاء مهلة / OOM / صلاحيات / IO عام)،
  ويسجّله، **ولا يرمي أبداً** — حتى لو فشل التسجيل نفسه.
- سجل داخلي دوّار (آخر 300 سطر بالذاكرة) + ملف سجل بحد أقصى ~1MB يُعاد تدويره تلقائياً
  (`getRecentLogs()` مكشوفة الآن لـJS عبر `AppInterface`).
- **لا يمنع Crash فعلياً بحد ذاته** — هو أداة توحيد وتسجيل. منع الانهيار يعتمد على وجود
  `try/catch` أصلاً حول العملية (موجود في أغلب نقاط الكود الحالي) يستدعي `errorManager.handle()`
  بدل معالجة يدوية متفرقة.

## الملفات المعدَّلة

### `app/src/main/java/com/comictrans/engine/ModelManager.kt` (إعادة كتابة كاملة)
- **Resume Download**: عند استئناف تنزيل متوقف، يُرسَل `Range: bytes=<offset>-` من حيث
  توقف ملف `.part`. لو رجع الخادم `206 Partial Content` يُلحَق الجديد بالملف؛ لو رجع `200`
  كاملاً (لا يدعم Range) يُعاد الكتابة من الصفر تلقائياً بدل ملف تالف.
- **Download State Management**: `enum DownloadState { NONE, DOWNLOADING, PAUSED,
  VERIFYING, COMPLETED, FAILED }` + `data class DownloadStatus` تُبلَّغ لحظياً عبر
  `startDownload(model, onUpdate)`.
- **منع التنزيل المكرر**: `activeJobs: ConcurrentHashMap<String, Job>` — استدعاء
  `startDownload()` لنموذج قيد التنزيل فعلاً يُتجاهَل بصمت (الحالة أصلاً DOWNLOADING)، بجانب
  `Mutex` مستقل لكل معرّف نموذج كطبقة حماية إضافية من السباقات.
- **Pause/Cancel حقيقيان**: `pauseDownload(id)` يلغي التنزيل تعاونياً مع الحفاظ على `.part`
  (للاستئناف لاحقاً)؛ `cancelDownload(id)` يلغي وينتظر توقف الكتابة فعلياً (`cancelAndJoin`)
  ثم يحذف `.part` نهائياً.
- **التحقق من الملفات**: بعد اكتمال الكتابة الكاملة (وليس تدريجياً أثناء التنزيل — مهم
  للتوافق مع الاستئناف الجزئي): فحص الحجم الأدنى، ثم SHA256 إن كان معروفاً.
- `release()` جديدة تُلغي كل التنزيلات الجارية دون حذف ملفاتها الجزئية — تُستدعى من
  `AppInterface.releaseResources()` (تُستدعى بدورها من `MainActivity.onDestroy`).

### `app/src/main/java/com/comictrans/AppInterface.kt`
- إنشاء `errorManager` واستخدامه في: خطأ فتح CBZ، الخطأ العام لمعالجة الصفحة، فشل فك ترميز
  صورة الصفحة، وفشل مزامنة الذاكرة (سحابية) — بدل `Log.e` + رسالة يدوية متفرقة في كل موقع.
- `downloadModel()` الآن يستخدم `ModelManager.startDownload()` الجديدة (تكتشف تلقائياً
  ملف `.part` وتستأنف منه).
- ثلاث دوال JS جديدة: `pauseModelDownload(id)`، `resumeModelDownload(id)` (نفس
  `downloadModel` — يكتشف الاستئناف تلقائياً)، `cancelModelDownload(id)`.
- حدث جديد للواجهة: `onModelDownloadState({id, state, progress, message})` — بجانب
  `onModelProgress`/`onModelStatus` القديمين (أُبقيا للتوافق الخلفي، فما ينكسر شيء موجود).
- `getRecentLogs()` جديدة (اختيارية) تكشف آخر سجل الأخطاء لـJS عند الحاجة.
- `releaseResources()` تستدعي الآن `modelManager.release()` أيضاً.

### `app/src/main/assets/index.html`
- كل صف نموذج غير محمّل الآن يحوي `<div class="model-controls">` تُملأ ديناميكياً حسب
  الحالة الواردة من `onModelDownloadState`: زر ⏸️ أثناء التنزيل، ▶️ استكمال + ✖️ إلغاء أثناء
  الإيقاف المؤقت، ⬇️ تنزيل عند الفشل/عدم البدء.
- `window.onModelDownloadState` جديدة تربط الحدث بـ`updateModelRowControls()`.

## ما لم يُلمَس عمداً
- `MlkitModelManager` (تنزيل حزم ترجمة Google ML Kit) — يعتمد على Google Play Services
  الذي يدير الاستئناف/الموثوقية داخلياً أصلاً، فلا حاجة لإعادة تطبيق نفس المنطق عليه.
- باقي محركات OCR/الترجمة/الطمس/CBZ لم تُعدَّل في هذه المرحلة (مقرَّرة للمراحل القادمة
  حسب الأولوية اللي تحددها).

## للاختبار بعد البناء
1. ابدأ تنزيل نموذج كبير (AI Pro ‎~208MB)، اضغط ⏸️ في المنتصف، تأكد أن `.part` باقٍ في
   `Android/data/com.comictrans/files/models/`.
2. اضغط ▶️ استكمال، وتأكد (عبر Logcat أو نسبة التقدّم القافزة فوق 0%) أنه أكمل من نفس
   النقطة لا من الصفر.
3. أغلق التطبيق كاملاً أثناء التنزيل (بدون ضغط إيقاف)، أعد فتحه، اضغط تنزيل لنفس النموذج
   — يجب أن يكتشف `.part` الموجود ويستأنف تلقائياً.
4. اضغط تنزيل مرتين بسرعة على نفس النموذج — يجب أن يبدأ تنزيلاً واحداً فقط لا اثنين.
5. اقطع الإنترنت منتصف تنزيل CBZ كبير أو أثناء ترجمة صفحة — تأكد أن رسالة الخطأ عربية
   واضحة (وليست انهياراً) وأن `getRecentLogs()` (عبر Logcat tag `ComicApp`) يحوي سطراً
   مصنَّفاً بالفئة الصحيحة.
