#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
convert_models_to_tflite.py
============================
يحوّل نموذجين لصيغة .tflite بنفس المواصفات الدقيقة اللي كود التطبيق (Kotlin) يتوقعها
بالضبط — بدل المخاطرة بلصق رابط جاهز قد يكون بمقياس/شكل مختلف يسبب كراش أو صورة تالفة:

  1) enhance_ai  → Real-ESRGAN x2   (يُستخدم في ImageEnhanceEngine.kt)
     - مدخل واحد:  NHWC float32 [1, H, W, 3]  بمدى 0-255، H/W ديناميكيان (أي مقاس)
     - مخرج واحد:  NHWC float32 [1, 2H, 2W, 3] بمدى تقريبي 0-255

  2) ai_lite     → LaMa inpainting  (يُستخدم في ErasureEngine.kt، وضع "AI Lite")
     - مدخلان:    image NCHW float32 [1, 3, 512, 512] بمدى 0-1
                   mask  NCHW float32 [1, 1, 512, 512] (1 = امسح، 0 = أبقِ)
     - مخرج واحد: NCHW float32 [1, 3, 512, 512] بمدى 0-1

طريقة الاستخدام
----------------
    pip install torch onnx onnxruntime tensorflow onnx2tf --break-system-packages

    # 1) تحويل Real-ESRGAN x2 (تحتاج ملف أوزان .pth حقيقي — لينك تحميل أدناه)
    python convert_models_to_tflite.py esrgan --weights RealESRGAN_x2.pth --out realesrgan-x2.tflite

    # 2) تحويل LaMa (تحتاج نفس ملف lama_fp32.onnx اللي يستخدمه AI Pro أصلاً)
    python convert_models_to_tflite.py lama --onnx lama_fp32.onnx --out lama-lite.tflite

بعد التحويل، الصق الملف الناتج داخل مجلد نماذج التطبيق (نفس مسار "إدارة نماذج AI ⚙️" على
الجهاز)، أو استخدم زر "لصق رابط مخصّص" في التطبيق بعد ما ترفع الملف لأي استضافة (Hugging
Face / GitHub Releases) وتحصل على رابط تحميل مباشر له.

من أين أجيب الأوزان الأصلية؟
------------------------------
- Real-ESRGAN x2 (.pth): https://huggingface.co/ai-forever/Real-ESRGAN/blob/main/RealESRGAN_x2.pth
  (هذا ملف PyTorch checkpoint حقيقي وموثوق — لكنه x2 عادي (RRDBNet) وليس مضموناً 100%
  مطابقاً بصرياً لنسخة NVIDIA/xinntao الأصلية؛ يكفي جيداً لتحسين حروف الكوميك قبل OCR).
- LaMa ONNX: نفس الرابط المستخدم فعلاً في ModelManager.kt لـ AI Pro
  (huggingface.co/Carve/LaMa-ONNX) — استخدمه كمدخل هنا مباشرة لإنتاج نسخة TFLite أخف
  (AI Lite) من نفس النموذج بالضبط.

ملاحظة صريحة: هذا السكربت ما تم تشغيله فعلياً هنا (بيئة العمل الحالية بدون إنترنت ولا GPU)
— لكن كل شكل/ترتيب المدخلات والمخرجات مأخوذ حرفياً من كود Kotlin نفسه (ImageEnhanceEngine.kt
و ErasureEngine.kt)، وآخر خطوة بالسكربت (self_test) تتحقق تلقائياً من تطابق الشكل النهائي
قبل ما تعتمد على الملف. شغّله على جهازك وابعتلي أي خطأ يطلع لو صار.
"""

import argparse
import sys


# ============================================================================
# 1) Real-ESRGAN x2 → TFLite (NHWC float32 0-255، مقاس ديناميكي، مطابق لـ
#    ImageEnhanceEngine.kt::tryAIEnhance بالضبط)
# ============================================================================

# تعريف مبسّط لبنية RRDBNet (نفس بنية Real-ESRGAN الرسمية) — مضمّن هنا بدل الاعتماد على
# استنساخ مستودع basicsr/Real-ESRGAN كامل، فقط عشان تحميل ملف .pth وتشغيله للتصدير.
_RRDBNET_DEF = '''
import torch
import torch.nn as nn
import torch.nn.functional as F


def make_layer(block, n_layers, **kwargs):
    return nn.Sequential(*[block(**kwargs) for _ in range(n_layers)])


class ResidualDenseBlock(nn.Module):
    def __init__(self, nf=64, gc=32):
        super().__init__()
        self.conv1 = nn.Conv2d(nf, gc, 3, 1, 1)
        self.conv2 = nn.Conv2d(nf + gc, gc, 3, 1, 1)
        self.conv3 = nn.Conv2d(nf + 2 * gc, gc, 3, 1, 1)
        self.conv4 = nn.Conv2d(nf + 3 * gc, gc, 3, 1, 1)
        self.conv5 = nn.Conv2d(nf + 4 * gc, nf, 3, 1, 1)
        self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)

    def forward(self, x):
        x1 = self.lrelu(self.conv1(x))
        x2 = self.lrelu(self.conv2(torch.cat((x, x1), 1)))
        x3 = self.lrelu(self.conv3(torch.cat((x, x1, x2), 1)))
        x4 = self.lrelu(self.conv4(torch.cat((x, x1, x2, x3), 1)))
        x5 = self.conv5(torch.cat((x, x1, x2, x3, x4), 1))
        return x5 * 0.2 + x


class RRDB(nn.Module):
    def __init__(self, nf, gc=32):
        super().__init__()
        self.RDB1 = ResidualDenseBlock(nf, gc)
        self.RDB2 = ResidualDenseBlock(nf, gc)
        self.RDB3 = ResidualDenseBlock(nf, gc)

    def forward(self, x):
        out = self.RDB1(x)
        out = self.RDB2(out)
        out = self.RDB3(out)
        return out * 0.2 + x


class RRDBNet(nn.Module):
    """RRDBNet بمقياس x2 — نفس بنية ai-forever/Real-ESRGAN RealESRGAN_x2.pth."""

    def __init__(self, in_nc=3, out_nc=3, nf=64, nb=23, gc=32, scale=2):
        super().__init__()
        self.scale = scale
        self.conv_first = nn.Conv2d(in_nc, nf, 3, 1, 1)
        self.RRDB_trunk = make_layer(RRDB, nb, nf=nf, gc=gc)
        self.trunk_conv = nn.Conv2d(nf, nf, 3, 1, 1)
        self.upconv1 = nn.Conv2d(nf, nf, 3, 1, 1)
        if scale == 4:
            self.upconv2 = nn.Conv2d(nf, nf, 3, 1, 1)
        self.HRconv = nn.Conv2d(nf, nf, 3, 1, 1)
        self.conv_last = nn.Conv2d(nf, out_nc, 3, 1, 1)
        self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)

    def forward(self, x):
        fea = self.conv_first(x)
        trunk = self.trunk_conv(self.RRDB_trunk(fea))
        fea = fea + trunk
        fea = self.lrelu(self.upconv1(F.interpolate(fea, scale_factor=2, mode="nearest")))
        if self.scale == 4:
            fea = self.lrelu(self.upconv2(F.interpolate(fea, scale_factor=2, mode="nearest")))
        out = self.conv_last(self.lrelu(self.HRconv(fea)))
        return out
'''


def convert_esrgan(weights_path: str, out_path: str, opset: int = 13):
    """يحمّل RealESRGAN_x2.pth، يلف forward بتطبيع 0-255↔0-1 داخل الغراف نفسه (حتى
    المدخل/المخرج النهائيين في TFLite يبقيان 0-255 زي ما ImageEnhanceEngine.kt يفترض
    بالضبط)، ثم يصدّر ONNX بمحاور ديناميكية H/W، وأخيراً يحوّله لـ TFLite عبر onnx2tf."""
    import io
    import torch

    ns: dict = {}
    exec(compile(_RRDBNET_DEF, "<rrdbnet>", "exec"), ns)
    RRDBNet = ns["RRDBNet"]

    print(f"[1/4] تحميل الأوزان من {weights_path} ...")
    state = torch.load(weights_path, map_location="cpu")
    # ملفات ai-forever/Real-ESRGAN تحفظ الأوزان تحت مفتاح "params" أو "params_ema"
    if isinstance(state, dict) and ("params" in state or "params_ema" in state):
        state = state.get("params_ema") or state["params"]

    model = RRDBNet(scale=2)
    model.load_state_dict(state, strict=True)
    model.eval()

    class Wrapped(torch.nn.Module):
        """يغلّف النموذج بحيث يستقبل 0-255 ويُرجع 0-255 مباشرة — هذا بالضبط ما يفعله
        ImageEnhanceEngine.kt (يقرأ بكسلات 0-255 ويكتب النتيجة كما هي بدون أي تطبيع
        إضافي في كود Kotlin)."""

        def __init__(self, m):
            super().__init__()
            self.m = m

        def forward(self, x):  # x: NHWC 0-255 float32
            x = x.permute(0, 3, 1, 2) / 255.0  # → NCHW 0-1 (شكل RRDBNet الأصلي)
            y = self.m(x)
            y = y.clamp(0.0, 1.0) * 255.0
            return y.permute(0, 2, 3, 1)  # → NHWC 0-255

    wrapped = Wrapped(model)

    print("[2/4] تصدير ONNX بمحاور ديناميكية (أي مقاس صورة) ...")
    dummy = torch.zeros(1, 64, 64, 3, dtype=torch.float32)  # NHWC — شكل وهمي فقط للتتبع
    onnx_bytes = io.BytesIO()
    torch.onnx.export(
        wrapped,
        dummy,
        onnx_bytes,
        input_names=["input"],
        output_names=["output"],
        opset_version=opset,
        dynamic_axes={
            "input": {1: "height", 2: "width"},
            "output": {1: "height2", 2: "width2"},
        },
    )
    onnx_path = out_path.replace(".tflite", ".onnx")
    with open(onnx_path, "wb") as f:
        f.write(onnx_bytes.getvalue())
    print(f"      → {onnx_path}")

    _onnx_to_tflite(onnx_path, out_path, keep_nhwc=True)
    _self_test_esrgan(out_path)


# ============================================================================
# 2) LaMa (ai_lite) → TFLite (NCHW float32، مدخلين، 512×512 ثابت، مطابق لـ
#    ErasureEngine.kt::inpaintPerBlockTFLite بالضبط)
# ============================================================================

def convert_lama(onnx_path: str, out_path: str):
    """يأخذ نفس ملف lama_fp32.onnx المُستخدَم فعلياً لـ AI Pro، ويحوّله لـ TFLite بنفس
    ترتيب/شكل المدخلات والمخرجات (NCHW، 512×512 ثابت) — بدون أي تبديل تخطيط (layout)،
    لأن كود Kotlin يكتب/يقرأ البايتات مباشرة بترتيب NCHW الخام."""
    _onnx_to_tflite(onnx_path, out_path, keep_nhwc=False, fixed_shapes={
        "image": [1, 3, 512, 512],
        "mask": [1, 1, 512, 512],
    })
    _self_test_lama(out_path)


# ============================================================================
# أدوات مشتركة: تحويل ONNX → TFLite عبر onnx2tf
# ============================================================================

def _onnx_to_tflite(onnx_path: str, out_path: str, keep_nhwc: bool, fixed_shapes: dict | None = None):
    """
    keep_nhwc=True  (ESRGAN): نسيب onnx2tf يحوّل NCHW→NHWC تلقائياً (سلوكه الافتراضي، وهو
        بالضبط الشكل اللي نبيه لهذا النموذج) مع محاور ديناميكية.
    keep_nhwc=False (LaMa):   نمنع onnx2tf من قلب التخطيط (--keep_ncw_or_nchw_or_ncdhw_input_names)
        حتى تبقى المدخلات/المخرجات NCHW 512×512 تماماً كما يكتبها Kotlin.
    """
    import subprocess

    print(f"[3/4] تحويل {onnx_path} → TFLite عبر onnx2tf ...")
    cmd = ["onnx2tf", "-i", onnx_path, "-o", "tflite_out", "-osd"]
    if not keep_nhwc:
        cmd += ["-kat"] + list((fixed_shapes or {}).keys())  # keep_nchw_input_names أو مكافئها
    subprocess.run(cmd, check=True)

    import glob
    import shutil

    candidates = glob.glob("tflite_out/*float32.tflite") or glob.glob("tflite_out/*.tflite")
    if not candidates:
        print("تحذير: onnx2tf ما أنتج ملف .tflite واضح — راجع مخرجات الأمر أعلاه يدوياً "
              "داخل مجلد tflite_out/ واختر النسخة float32 المناسبة يدوياً.", file=sys.stderr)
        return
    shutil.copy(candidates[0], out_path)
    print(f"[4/4] تم: {out_path}")


# ============================================================================
# self-test: يتحقق فعلياً من شكل/نوع المدخلات والمخرجات النهائية قبل ما تعتمد على الملف
# ============================================================================

def _self_test_esrgan(tflite_path: str):
    import tensorflow as tf

    interp = tf.lite.Interpreter(model_path=tflite_path)
    interp.resize_tensor_input(0, [1, 64, 64, 3])
    interp.allocate_tensors()
    inp = interp.get_input_details()[0]
    out = interp.get_output_details()[0]
    print("\n--- فحص Real-ESRGAN x2 التلقائي ---")
    print(f"  مدخل:  shape={inp['shape']}  dtype={inp['dtype']}")
    print(f"  مخرج:  shape={out['shape']}  dtype={out['dtype']}")
    ok = (inp["dtype"].__name__ == "float32" and out["dtype"].__name__ == "float32"
          and list(inp["shape"][-1:]) == [3])
    print("  ✅ الشكل يطابق ما يتوقعه ImageEnhanceEngine.kt" if ok else
          "  ⚠️ الشكل غير مطابق — راجع السكربت قبل الاستخدام في التطبيق")


def _self_test_lama(tflite_path: str):
    import tensorflow as tf

    interp = tf.lite.Interpreter(model_path=tflite_path)
    interp.allocate_tensors()
    print("\n--- فحص LaMa (ai_lite) التلقائي ---")
    for d in interp.get_input_details():
        print(f"  مدخل '{d['name']}':  shape={d['shape']}  dtype={d['dtype']}")
    for d in interp.get_output_details():
        print(f"  مخرج '{d['name']}':  shape={d['shape']}  dtype={d['dtype']}")
    shapes = sorted(tuple(d["shape"]) for d in interp.get_input_details())
    expected = sorted([(1, 3, 512, 512), (1, 1, 512, 512)])
    ok = shapes == expected
    print("  ✅ الشكل يطابق ما يتوقعه ErasureEngine.kt (صورة 1×3×512×512 + قناع 1×1×512×512)"
          if ok else "  ⚠️ الشكل غير مطابق — راجع السكربت قبل الاستخدام في التطبيق")


# ============================================================================
if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    pe = sub.add_parser("esrgan", help="تحويل Real-ESRGAN x2 (.pth) → enhance_ai .tflite")
    pe.add_argument("--weights", required=True, help="مسار RealESRGAN_x2.pth")
    pe.add_argument("--out", default="realesrgan-x2.tflite")

    pl = sub.add_parser("lama", help="تحويل LaMa (.onnx) → ai_lite .tflite")
    pl.add_argument("--onnx", required=True, help="مسار lama_fp32.onnx (نفس ملف AI Pro)")
    pl.add_argument("--out", default="lama-lite.tflite")

    args = p.parse_args()
    if args.cmd == "esrgan":
        convert_esrgan(args.weights, args.out)
    elif args.cmd == "lama":
        convert_lama(args.onnx, args.out)
