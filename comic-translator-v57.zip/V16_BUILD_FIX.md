# V16 ARM64 build fix

- Kept `abiFilters "arm64-v8a"` so the APK targets ARM64 only.
- Added `packaging.jniLibs.pickFirsts` for `lib/arm64-v8a/libc++_shared.so`.
  PaddleOCR4Android and OpenCV both package this shared C++ runtime; Android Gradle
  Plugin otherwise fails at `mergeDebugNativeLibs` with DuplicateRelativeFileException.
- Removed the deprecated `package="com.comictrans"` from the app manifest.
- Updated versionCode to 16 / versionName 1.6.0.
- Updated workflow to verify the two critical build settings after ZIP extraction.
