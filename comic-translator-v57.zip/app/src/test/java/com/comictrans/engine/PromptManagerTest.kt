package com.comictrans.engine

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * بند 12: أول دفعة اختبارات وحدة حقيقية للمشروع — PromptManager مُختار كأول هدف عمداً لأنه
 * منطق Kotlin صرف (لا استيراد android.* إطلاقاً)، فيعمل تحت JUnit عادي (`./gradlew test`)
 * بدون جهاز/محاكي/Robolectric — أسرع حلقة تغذية راجعة ممكنة لأي تعديل مستقبلي على نصوص
 * الـsystem prompt (بند 7).
 *
 * ⚠️ هذه الاختبارات **لم تُشغَّل فعلياً** (بيئة الكتابة بلا Android SDK/Gradle) — تحقّقت من
 * صحتها منطقياً فقط بقراءة PromptManager.kt سطراً بسطر ومطابقة كل توقّع هنا مع السلوك
 * الفعلي المكتوب هناك. أول تشغيل فعلي لـ`./gradlew test` سيؤكد ذلك (أو يكشف خطأً بسيطاً).
 */
class PromptManagerTest {

    @Test
    fun `manga type keeps honorifics instruction`() {
        val prompt = PromptManager.buildSystemPrompt("manga", "", emptyMap(), "Arabic")
        assertTrue(prompt.contains("-san"))
        assertTrue(prompt.contains("Japanese manga"))
    }

    @Test
    fun `manhwa type mentions speech-level formality`() {
        val prompt = PromptManager.buildSystemPrompt("manhwa", "", emptyMap(), "Arabic")
        assertTrue(prompt.contains("Korean manhwa"))
        assertTrue(prompt.contains("formality"))
    }

    @Test
    fun `western type mentions idiomatic phrasing`() {
        val prompt = PromptManager.buildSystemPrompt("western", "", emptyMap(), "Arabic")
        assertTrue(prompt.contains("Western comic"))
        assertTrue(prompt.contains("idiomatic"))
    }

    @Test
    fun `unknown comic type falls back to generic instruction`() {
        val prompt = PromptManager.buildSystemPrompt("unknown_type_xyz", "", emptyMap(), "Arabic")
        assertTrue(prompt.contains("Translate naturally and preserve tone"))
    }

    @Test
    fun `blank series name omits series context entirely`() {
        val prompt = PromptManager.buildSystemPrompt("manga", "", emptyMap(), "Arabic")
        assertFalse(prompt.contains("Series:"))
    }

    @Test
    fun `non-blank series name is embedded with consistency instruction`() {
        val prompt = PromptManager.buildSystemPrompt("manga", "One Piece", emptyMap(), "Arabic")
        assertTrue(prompt.contains("Series: \"One Piece\""))
        assertTrue(prompt.contains("consistent with this series"))
    }

    @Test
    fun `empty dictionary omits term dictionary section`() {
        val prompt = PromptManager.buildSystemPrompt("manga", "", emptyMap(), "Arabic")
        assertFalse(prompt.contains("Term dictionary"))
    }

    @Test
    fun `non-empty dictionary lists every term-translation pair`() {
        val dict = mapOf("Luffy" to "لوفي", "Zoro" to "زورو")
        val prompt = PromptManager.buildSystemPrompt("manga", "", dict, "Arabic")
        assertTrue(prompt.contains("Term dictionary"))
        assertTrue(prompt.contains("Luffy => لوفي"))
        assertTrue(prompt.contains("Zoro => زورو"))
    }

    @Test
    fun `always ends with translation-only instruction regardless of inputs`() {
        val withDict = PromptManager.buildSystemPrompt("western", "Batman", mapOf("Bat" to "بات"), "Arabic")
        val withoutDict = PromptManager.buildSystemPrompt("manhwa", "", emptyMap(), "Arabic")
        val tail = "Return ONLY the translation, with no explanation, no quotes, no notes."
        assertTrue(withDict.endsWith(tail))
        assertTrue(withoutDict.endsWith(tail))
    }

    @Test
    fun `target language name is interpolated into the style guide`() {
        val prompt = PromptManager.buildSystemPrompt("manga", "", emptyMap(), "French")
        assertTrue(prompt.contains("into French"))
    }
}
