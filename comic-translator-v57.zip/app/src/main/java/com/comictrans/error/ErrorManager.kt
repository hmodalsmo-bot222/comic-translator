package com.comictrans.error

import android.content.Context
import android.util.Log
import java.io.File
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedDeque

/**
 * نقطة موحّدة لمعالجة كل الأخطاء المتوقعة في التطبيق (OCR/Translation/AI Models/CBZ/
 * Files/Network) بدل كل موقع يكتب try/catch ورسالته الخاصة بشكل متفرّق.
 *
 * الهدف الأساسي: **منع Crash بسبب أخطاء متوقعة**. كل دالة هنا تلتقط Throwable وتحوّله
 * لـ [AppError] برسالة عربية واضحة للمستخدم، وتسجّله (Logcat + سجل داخلي دوّار)، ولا تعيد
 * رمي أي استثناء أبداً — استدعاء handle() آمن دائماً ولا يُسقط التطبيق مهما كان الخطأ.
 *
 * الاستخدام المعتاد في نقاط catch الموجودة فعلياً بالتطبيق:
 * ```
 * } catch (e: Exception) {
 *     val err = errorManager.handle(e, ErrorCategory.CBZ, "فشل فتح الملف")
 *     sendError(pageIndex, err.userMessage)
 * }
 * ```
 */
class ErrorManager(context: Context) {

    companion object {
        private const val TAG = "ComicApp"
        private const val MAX_MEMORY_LOG = 300
        private const val MAX_LOG_FILE_BYTES = 1_000_000L
    }

    private val appContext = context.applicationContext
    private val recentLogs = ConcurrentLinkedDeque<String>()
    private val dateFmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    private val logFile: File by lazy {
        val dir = File(appContext.cacheDir, "logs").apply { mkdirs() }
        File(dir, "app_log.txt")
    }

    /** يحوّل استثناءً حقيقياً (من catch) إلى AppError موحّد، ويسجّله، ولا يرمي أبداً. */
    fun handle(
        throwable: Throwable,
        category: ErrorCategory,
        contextMessage: String = "",
        severity: ErrorSeverity = ErrorSeverity.ERROR
    ): AppError {
        return try {
            val userMessage = friendlyMessage(throwable, category, contextMessage)
            val technical = "${throwable.javaClass.simpleName}: ${throwable.message}"
            val error = AppError(category, severity, userMessage, technical, throwable)
            log(error)
            error
        } catch (loggingFailure: Throwable) {
            // حتى لو فشل نظام التسجيل نفسه (تخزين ممتلئ، إلخ)، لا يجوز أن يُسقط هذا
            // التطبيق أثناء معالجته لخطأ آخر أصلاً — نرجع خطأ عام بأمان.
            AppError(category, severity, "حدث خطأ غير متوقع", throwable.message ?: "unknown", throwable)
        }
    }

    /** لحالات الفشل المنطقي بدون Throwable فعلي (مثال: تحقق فشل، نتيجة فارغة). */
    fun handleMessage(
        message: String,
        category: ErrorCategory,
        severity: ErrorSeverity = ErrorSeverity.ERROR
    ): AppError {
        val error = AppError(category, severity, message, message)
        log(error)
        return error
    }

    private fun friendlyMessage(t: Throwable, category: ErrorCategory, ctx: String): String {
        val base = when (t) {
            is UnknownHostException -> "تعذر الاتصال بالإنترنت — تحقق من الشبكة"
            is SocketTimeoutException -> "انتهت مهلة الاتصال بالخادم — حاول مرة أخرى"
            is OutOfMemoryError -> "الصورة أو الملف كبير جداً على ذاكرة الجهاز المتاحة"
            is SecurityException -> "تم رفض إذن الوصول للملف أو الجهاز"
            is IOException -> when (category) {
                ErrorCategory.FILE, ErrorCategory.CBZ -> "خطأ أثناء قراءة أو كتابة الملف"
                ErrorCategory.NETWORK, ErrorCategory.AI_MODEL, ErrorCategory.TRANSLATION -> "خطأ في الاتصال بالشبكة"
                else -> "خطأ غير متوقع (${category.displayNameAr})"
            }
            else -> t.message?.takeIf { it.isNotBlank() } ?: "خطأ غير متوقع في ${category.displayNameAr}"
        }
        return if (ctx.isNotBlank()) "$ctx: $base" else base
    }

    private fun log(error: AppError) {
        val line = "${dateFmt.format(Date())} [${error.severity}] ${error.logLine}"
        when (error.severity) {
            ErrorSeverity.WARNING -> Log.w(TAG, line, error.cause)
            ErrorSeverity.ERROR -> Log.e(TAG, line, error.cause)
            ErrorSeverity.FATAL -> Log.e(TAG, "FATAL: $line", error.cause)
        }
        recentLogs.addLast(line)
        while (recentLogs.size > MAX_MEMORY_LOG) recentLogs.pollFirst()
        try {
            logFile.appendText(line + "\n")
            if (logFile.length() > MAX_LOG_FILE_BYTES) {
                // إعادة تدوير الملف بدل تركه ينمو للأبد — نبقي فقط آخر الأسطر من الذاكرة.
                logFile.writeText(recentLogs.toList().takeLast(150).joinToString("\n") + "\n")
            }
        } catch (_: Exception) {
            // فشل كتابة ملف السجل نفسه (تخزين ممتلئ/صلاحيات) يجب ألا يُسقط أي شيء —
            // السجل في الذاكرة (recentLogs) يبقى متاحاً بغض النظر عن نجاح الكتابة للملف.
        }
    }

    /** آخر الأسطر المسجَّلة (بالذاكرة) — مفيد لعرض سجل تشخيصي داخل التطبيق دون قراءة ملف. */
    fun recentLogsText(): String = recentLogs.toList().joinToString("\n")

    /** ملف السجل الكامل (دوّار، بحد أقصى ~1MB) — يصلح للتصدير أو الإرفاق بتقرير مشكلة. */
    fun logFileOrNull(): File? = logFile.takeIf { it.exists() }
}

/**
 * 🔍 (أُضيف 2026-08-15، جلسة سابعة) — الوحيد الحقيقي بالتطبيق لسجل "السجل" الظاهر
 * بالواجهة (📋 أيقونة، شاشة "السجل" — نفس اللي ظهر بلقطة شاشة المستخدم بـHTTP 404 سابقاً).
 * قبل هذه الدفعة: OCREngine (بموديول feature_ai) كان يستخدم `android.util.Log.w/e` مباشرة
 * فقط — هذه رسائل تظهر بـLogcat (يحتاج Android Studio/adb، غير متاح للمستخدم فعلياً حسب
 * سير عمله: بناء عبر GitHub Actions، لا جهاز بيئة تطوير) **ولا تظهر إطلاقاً بشاشة "السجل"
 * داخل التطبيق نفسه** — لأن تلك الشاشة تعرض `errorManager.recentLogsText()` من نسخة
 * ErrorManager محدَّدة (المُنشَأة بـAppInterface.kt)، وErrorManager يحتفظ بسجله بالذاكرة
 * (ConcurrentLinkedDeque) **لكل نسخة (instance) على حدة** — نسخة جديدة منفصلة (لو أُنشِئت
 * بموديول feature_ai مثلاً) لن تشارك نفس السجل المرئي بالواجهة إطلاقاً.
 * الحل: singleton بسيط مقيَّد بـapplicationContext (نسخة واحدة فعلية بكل عملية التطبيق)،
 * تستخدمه AppInterface (الموديول الأساسي) **وOCREngine بموديول feature_ai معاً** — الآن
 * أي `errorManager.handleMessage(...)` من أي مكان بالتطبيق (بما فيه الموديول الديناميكي)
 * يظهر فعلياً بشاشة "السجل" اللي يستخدمها المستخدم فعلياً، لا فقط بـLogcat غير المرئي له.
 */
object AppErrorLog {
    @Volatile private var instance: ErrorManager? = null
    fun get(context: android.content.Context): ErrorManager =
        instance ?: synchronized(this) {
            instance ?: ErrorManager(context.applicationContext).also { instance = it }
        }
}
