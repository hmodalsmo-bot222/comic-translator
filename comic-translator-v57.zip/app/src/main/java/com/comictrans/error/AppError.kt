package com.comictrans.error

/**
 * تصنيف الأخطاء عبر التطبيق كاملاً — نفس التصنيفات المطلوبة في مواصفة "نظام أخطاء موحّد":
 * OCR / Translation / AI Models / CBZ / Files / Network، مع UNKNOWN كحل احتياطي لأي حالة
 * لا تقع ضمن هذه الفئات (بدل تجاهلها أو تصنيفها خطأً).
 */
enum class ErrorCategory(val displayNameAr: String) {
    OCR("التعرف الضوئي على النص"),
    TRANSLATION("الترجمة"),
    AI_MODEL("نماذج الذكاء الاصطناعي"),
    CBZ("ملف الكوميك (CBZ)"),
    FILE("الملفات"),
    NETWORK("الشبكة"),
    UNKNOWN("غير معروف")
}

enum class ErrorSeverity { WARNING, ERROR, FATAL }

/**
 * تمثيل موحّد لأي خطأ داخل التطبيق. `userMessage` نص عربي آمن للعرض مباشرة للمستخدم،
 * و`technicalDetail` مخصّص للسجلات/التصدير فقط (لا يُعرض للمستخدم افتراضياً).
 */
data class AppError(
    val category: ErrorCategory,
    val severity: ErrorSeverity,
    val userMessage: String,
    val technicalDetail: String,
    val cause: Throwable? = null
) {
    val logLine: String
        get() = "[${category.name}] $userMessage :: $technicalDetail"
}
