package com.comictrans.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [TranslationEntity::class, PageCacheEntity::class, DictionaryEntity::class], version = 4, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun translationDao(): TranslationDao
    abstract fun pageCacheDao(): PageCacheDao
    abstract fun dictionaryDao(): DictionaryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        // v1 → v2: إضافة عمود engine (راجع شرح السبب في TranslationEntity.kt) + إعادة بناء
        // الفهرس الفريد ليشمله، بدل فقدان "الذاكرة الذكية" القديمة بالكامل عبر
        // fallbackToDestructiveMigration. الصفوف القديمة (بدون معرفة أي محرك أنتجها) تُعطى
        // القيمة الافتراضية "unknown" — تبقى محفوظة لكنها لن تتصادم صامتة مع أي محرك حقيقي.
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE translations ADD COLUMN engine TEXT NOT NULL DEFAULT 'unknown'")
                db.execSQL("DROP INDEX IF EXISTS index_translations_sourceText_sourceLang_targetLang")
                db.execSQL(
                    "CREATE UNIQUE INDEX IF NOT EXISTS " +
                        "index_translations_sourceText_sourceLang_targetLang_engine " +
                        "ON translations (sourceText, sourceLang, targetLang, engine)"
                )
            }
        }

        // v2 → v3: إضافة جدول page_cache (كاش معالجة الصفحات الكاملة — بند 5 من مواصفة
        // التطوير: OCR + ترجمة + طمس مُخزَّنة معاً لتفادي إعادة معالجة نفس الصفحة).
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS page_cache (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "comicHash TEXT NOT NULL, " +
                        "pageNumber INTEGER NOT NULL, " +
                        "settingsFingerprint TEXT NOT NULL, " +
                        "blocksJson TEXT NOT NULL, " +
                        "erasureDataJson TEXT NOT NULL, " +
                        "processedImagePath TEXT, " +
                        "processingDate INTEGER NOT NULL)"
                )
                db.execSQL(
                    "CREATE UNIQUE INDEX IF NOT EXISTS " +
                        "index_page_cache_comicHash_pageNumber_settingsFingerprint " +
                        "ON page_cache (comicHash, pageNumber, settingsFingerprint)"
                )
            }
        }

        // v3 → v4: إضافة جدول comic_dictionary (بند 7: Comic Dictionary — قاموس مصطلحات
        // ثابت لكل كوميكس، يُرسَل مع كل طلب ترجمة عبر PromptManager).
        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS comic_dictionary (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "comicHash TEXT NOT NULL, " +
                        "term TEXT NOT NULL, " +
                        "translation TEXT NOT NULL)"
                )
                db.execSQL(
                    "CREATE UNIQUE INDEX IF NOT EXISTS " +
                        "index_comic_dictionary_comicHash_term " +
                        "ON comic_dictionary (comicHash, term)"
                )
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "comic_translator.db"
                ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4).build().also { INSTANCE = it }
            }
        }
    }
}
