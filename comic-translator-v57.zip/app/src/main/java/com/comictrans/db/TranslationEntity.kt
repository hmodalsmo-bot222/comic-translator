package com.comictrans.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

// *** إصلاح جذري: "الترجمة مهما غيّرتها ترجع محلية" ***
// السبب: findExact() كانت تبحث بـ(sourceText) فقط — بدون حتى sourceLang/targetLang، ودون
// أي علاقة بمحرك الترجمة (translateEngine) المُستخدَم. أول مرة تُترجَم فيها عبارة (حتى لو
// بمحرك مؤقت أو افتراضي مثل ML Kit المحلي أو Google المجاني)، تُخزَّن نتيجتها في "الذاكرة
// الذكية". بعدها، أي تكرار لنفس العبارة — حتى لو المستخدم غيّر المحرك لاحقاً إلى Gemini/
// OpenAI/DeepL مدفوع — كان findExact() يعيد نفس الترجمة القديمة المخزَّنة بصمت تام، بدون
// أي استدعاء فعلي للمحرك الجديد المختار. نفس المشكلة تتضاعف مع مزامنة "خلفية المجتمع"
// (pullMemorySync) التي تستورد عبارات ترجمها مستخدمون آخرون (غالباً بمحركات مجانية/محلية)
// وتُطابق نصوصك بنفس الطريقة العمياء. الإصلاح: إضافة عمود engine وجعله جزءاً من مفتاح
// التطابق (الفريد والاستعلام)، بحيث الذاكرة الذكية تبقى مفيدة (توفّر تكرار الطلب لنفس
// المحرك) لكن لا تتجاوز أبداً المحرك الذي اخترته فعلياً الآن.
@Entity(
    tableName = "translations",
    indices = [Index(value = ["sourceText", "sourceLang", "targetLang", "engine"], unique = true)]
)
data class TranslationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sourceText: String,
    val translatedText: String,
    val sourceLang: String,
    val targetLang: String,
    val engine: String = "unknown", // أي محرك ترجمة أنتج هذه النتيجة — راجع الشرح أعلاه
    val frequency: Int = 1,
    val createdAt: Long = System.currentTimeMillis(),
    val lastUsed: Long = System.currentTimeMillis()
)
