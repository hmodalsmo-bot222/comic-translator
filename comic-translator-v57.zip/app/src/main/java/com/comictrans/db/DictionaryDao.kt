package com.comictrans.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface DictionaryDao {

    @Query("SELECT * FROM comic_dictionary WHERE comicHash = :comicHash ORDER BY term ASC")
    suspend fun getAll(comicHash: String): List<DictionaryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: DictionaryEntity)

    @Query("DELETE FROM comic_dictionary WHERE comicHash = :comicHash AND term = :term")
    suspend fun delete(comicHash: String, term: String)
}
