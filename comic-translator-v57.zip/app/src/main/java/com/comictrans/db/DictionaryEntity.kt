package com.comictrans.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * قاموس مصطلحات ثابت لكل كوميكس (بند 7: Comic Dictionary) — أسماء شخصيات/مصطلحات خاصة
 * يحفظها المستخدم يدوياً (أو تُحفَظ تلقائياً لاحقاً) لتبقى ترجمتها ثابتة عبر كل صفحات نفس
 * الكوميكس، بدل أن تُترجَم بشكل مختلف كل مرة. راجع PromptManager.buildSystemPrompt
 * لاستخدامها الفعلي، وAppInterface لدوال الإضافة/الحذف المكشوفة لـJS.
 */
@Entity(
    tableName = "comic_dictionary",
    indices = [Index(value = ["comicHash", "term"], unique = true)]
)
data class DictionaryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val comicHash: String,
    val term: String,          // النص الأصلي (بلغة المصدر)
    val translation: String    // الترجمة الثابتة المطلوبة
)
