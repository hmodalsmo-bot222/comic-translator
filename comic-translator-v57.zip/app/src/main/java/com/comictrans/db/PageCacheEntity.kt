package com.comictrans.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * تخزين نتيجة معالجة صفحة كاملة (OCR + ترجمة + طمس) لتفادي إعادة معالجة نفس الصفحة أكثر
 * من مرة. المفتاح الفريد: (comicHash, pageNumber, settingsFingerprint) — أي تغيير في محرك
 * OCR/الترجمة/وضع الطمس/اللغات/طريقة التعزيز يُنتج fingerprint مختلف فيُبطل الكاش تلقائياً
 * لتلك الصفحة (بدل استخدام نتيجة قديمة بإعدادات مختلفة). راجع AppInterface.processPage
 * لمنطق القراءة (serveFromCache) والكتابة الفعلي.
 */
@Entity(
    tableName = "page_cache",
    indices = [Index(value = ["comicHash", "pageNumber", "settingsFingerprint"], unique = true)]
)
data class PageCacheEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val comicHash: String,
    val pageNumber: Int,
    val settingsFingerprint: String,
    val blocksJson: String,                  // نتيجة OCR+الترجمة مدمجة (List<BlockData> كـJSON، نفس بنية حقل "blocks" المُرسَل لـHTML)
    val erasureDataJson: String,              // نفس بنية حقل "erasureData" المُرسَل لـHTML
    val processedImagePath: String? = null,   // مسار دائم لنسخة من الصورة المُعالَجة (لأوضاع opencv/aot_gan/migan فقط)
    val processingDate: Long = System.currentTimeMillis()
)
