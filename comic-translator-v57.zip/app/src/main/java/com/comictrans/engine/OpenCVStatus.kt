package com.comictrans.engine

// حالة تحميل مكتبة OpenCV الأصلية (native). تُضبط مرة واحدة من MainActivity بعد
// استدعاء OpenCVLoader.initLocal()، وتُقرأ من أي محرك يستخدم OpenCV (ErasureEngine،
// ImageEnhanceEngine) قبل لمس أي صنف منها (Mat/Utils/Imgproc/Photo...). لو التحميل فشل،
// أول استدعاء فعلي لأي صنف من هذول بيرمي UnsatisfiedLinkError (صنف Error، مو Exception)
// وبيكرش التطبيق فوراً بدون ما ينلقط بأي try/catch(Exception) عادي. تفادي الاستخدام
// بالكامل لما تكون false أهم بكثير من محاولة اللقط بعد فوات الأوان.
object OpenCVStatus {
    @Volatile
    var isAvailable: Boolean = false
}
