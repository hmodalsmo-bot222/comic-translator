package com.comictrans.engine.contracts

import android.content.Context
import android.util.Log
import com.comictrans.engine.ModelManager
import com.comictrans.engine.OpenCVStatus

/**
 * بند 11 (Module Split) — يحمّل تنفيذ محركات AI الثقيلة (OCR/طمس/تعزيز الصورة) من موديول
 * feature_ai وقت التشغيل عبر Reflection، لأن app لا يقدر يعتمد على feature_ai وقت
 * الترجمة (راجع شرح مفصّل بأعلى AiEngineContracts.kt).
 *
 * ⚠️⚠️ غير مُختبَر فعلياً وقت التشغيل بعد (لا جهاز ولا محاكي متوفر بالبيئة اللي كُتب فيها
 * هذا الملف) — أول بناء ناجح لا يثبت أن هذا الملف يعمل صح، فقط يثبت أن الكود يترجم.
 * لازم تجربة فعلية على جهاز/محاكي، خصوصاً:
 *   1) هل Class.forName() تلقى الكلاسات فعلاً بوقت التشغيل؟ (اسم الحزمة/الكلاس يطابق
 *      بالضبط الملفات الفعلية بـ feature_ai — أي خطأ إملائي هنا يعني فشل صامت لكل
 *      وظائف OCR/الطمس/التعزيز، مع رسالة خطأ واضحة بدل تعطّل مفاجئ بفضل try/catch هنا).
 *   2) بما إن feature_ai مُعرَّف بـ dist:fusing include="true" وهذا بناء APK عادي عبر
 *      assembleDebug (مو Play Bundle حقيقي)، الكلاسات يُفترض تكون بنفس الـAPK دائماً —
 *      سيناريو "on-demand حقيقي، الموديول غير مُثبَّت بعد" يحتاج فحصاً منفصلاً لاحقاً
 *      عبر Play Console (Internal Testing) قبل أي اعتماد على مسار "الموديول مو مثبت"
 *      بالإنتاج الفعلي.
 */
object FeatureAiLoader {
    private const val TAG = "FeatureAiLoader"
    private const val PKG = "com.comictrans.feature_ai.engine"

    fun createOcrEngine(context: Context, modelManager: ModelManager): IOcrEngine? =
        loadFactory<IOcrEngineFactory>("$PKG.OcrEngineFactory")?.create(context, modelManager)

    fun createErasureEngine(context: Context, modelManager: ModelManager): IErasureEngine? =
        loadFactory<IErasureEngineFactory>("$PKG.ErasureEngineFactory")?.create(context, modelManager)

    fun createImageEnhanceEngine(context: Context, modelManager: ModelManager): IImageEnhanceEngine? =
        loadFactory<IImageEnhanceEngineFactory>("$PKG.ImageEnhanceEngineFactory")?.create(context, modelManager)

    /** يُستدعى من MainActivity.onCreate بدل الاعتماد المباشر على OpenCVLoader (انتقل لـ feature_ai). */
    fun initializeOpenCV(): Boolean {
        val initializer = loadFactory<IOpenCvInitializer>("$PKG.OpenCvInitializer")
        if (initializer == null) {
            OpenCVStatus.isAvailable = false
            return false
        }
        return try {
            initializer.initialize()
        } catch (e: Exception) {
            Log.e(TAG, "فشلت تهيئة OpenCV عبر feature_ai", e)
            OpenCVStatus.isAvailable = false
            false
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun <T> loadFactory(className: String): T? = try {
        Class.forName(className).getDeclaredConstructor().newInstance() as T
    } catch (e: ClassNotFoundException) {
        Log.e(TAG, "موديول feature_ai غير مُثبَّت أو الكلاس $className غير موجود", e)
        null
    } catch (e: Exception) {
        Log.e(TAG, "تعذر تحميل $className من feature_ai", e)
        null
    }
}
