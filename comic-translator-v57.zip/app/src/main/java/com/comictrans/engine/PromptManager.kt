package com.comictrans.engine

/**
 * بند 7: نظام إدارة الـPrompts. يبني system prompt واحد يُرسَل مع كل طلب ترجمة لمحركات
 * الـLLM (custom/openai/gemini/openrouter) بدل نص عام واحد لكل الأنواع. الفكرة: نبرة
 * الحوار وأسلوب الترجمة يختلف فعلياً بين مانجا يابانية ومانهوا كورية وكوميكس غربي (مثال:
 * الألقاب اليابانية -san/-kun غالباً تُبقى أو تُترجَم بحذر، بعكس الكوميكس الغربي).
 */
object PromptManager {

    /**
     * يبني system prompt كامل: تعليمات حسب نوع الكوميكس + اسم السلسلة (سياق) + قاموس
     * المصطلحات الثابتة (Comic Dictionary) — يُرسَل مع **كل** طلب ترجمة لنفس الكوميكس حتى
     * تبقى أسماء الشخصيات/المصطلحات الخاصة ثابتة عبر كل الصفحات، بدل أن تُترجَم كل صفحة
     * بشكل مستقل فيختلف اسم نفس الشخصية من صفحة لأخرى.
     */
    fun buildSystemPrompt(
        comicType: String,
        seriesName: String,
        dictionary: Map<String, String>,
        targetLangName: String
    ): String {
        val styleGuide = when (comicType) {
            "manga" -> "You are translating a Japanese manga into $targetLangName. Keep honorifics " +
                "(-san, -kun, -chan, -sama, senpai) as-is unless a natural equivalent exists. Preserve " +
                "onomatopoeia tone. Keep dialogue casual/formal matching the original register."
            "manhwa" -> "You are translating a Korean manhwa into $targetLangName. Preserve honorifics " +
                "and speech-level formality (respectful vs casual speech) as much as the target language " +
                "allows. Keep character relationship dynamics (senior/junior, formal/informal) clear."
            "western" -> "You are translating a Western comic into $targetLangName. Use natural, idiomatic " +
                "phrasing — avoid literal word-for-word translation. Match the tone (humorous, dramatic, " +
                "action) of each line."
            else -> "You are translating a comic into $targetLangName. Translate naturally and preserve tone."
        }

        val seriesContext = if (seriesName.isNotBlank()) {
            "\nSeries: \"$seriesName\". Keep character names and recurring terms consistent with this series."
        } else ""

        val dictText = if (dictionary.isNotEmpty()) {
            "\n\nTerm dictionary — ALWAYS use these exact translations for these terms, never invent " +
                "alternatives:\n" + dictionary.entries.joinToString("\n") { (term, translation) -> "$term => $translation" }
        } else ""

        return "You are a professional comic translator. $styleGuide$seriesContext$dictText\n\n" +
            "Return ONLY the translation, with no explanation, no quotes, no notes."
    }
}
