package com.comictrans.engine

import android.util.Log
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * محرك مزامنة "خلفية المجتمع" — يرفع/ينزل ذاكرة الترجمة الذكية (SQLite) عبر خلفية سحابية
 * يختارها المستخدم بنفسه. لا توجد أي بيانات اعتماد مضمّنة بالكود — المستخدم يوفر مشروعه
 * الخاص (Firebase / Supabase / GitHub) عبر حقل "مفتاح/رابط الخدمة" بالإعدادات.
 *
 * صيغة config حسب الخلفية:
 *  - firebase: "<databaseURL>|<databaseSecretOrAuthToken>"   مثال: https://xxx.firebaseio.com|SECRET
 *  - supabase: "<projectURL>|<apiKey>"                        مثال: https://xxx.supabase.co|eyJhbGci...
 *  - gist:     "<githubToken>" أو "<githubToken>|<gistId>" (بعد أول رفعة يظهر لك الـ gistId لتستخدمه لاحقاً)
 *  - local:    لا حاجة config — يُعالج بالكامل محلياً عبر MainActivity (تصدير/استيراد ملف)
 */
class SyncEngine {

    private val TAG = "SyncEngine"
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()
    private val JSON = "application/json; charset=utf-8".toMediaType()

    private fun splitConfig(config: String): List<String> =
        config.split("|").map { it.trim() }.filter { it.isNotEmpty() }

    fun push(backend: String, config: String, dataJson: String): Result<String> {
        return try {
            when (backend) {
                "firebase" -> pushFirebase(config, dataJson)
                "supabase" -> pushSupabase(config, dataJson)
                "gist" -> pushGist(config, dataJson)
                else -> Result.failure(Exception("خلفية مزامنة غير مدعومة: $backend"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "push failed", e)
            Result.failure(e)
        }
    }

    fun pull(backend: String, config: String): Result<String> {
        return try {
            when (backend) {
                "firebase" -> pullFirebase(config)
                "supabase" -> pullSupabase(config)
                "gist" -> pullGist(config)
                else -> Result.failure(Exception("خلفية مزامنة غير مدعومة: $backend"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "pull failed", e)
            Result.failure(e)
        }
    }

    // ---------- Firebase Realtime Database ----------
    // يستخدم REST المباشر لـ Realtime Database (وليس Firestore) لأنه يعمل بسهولة بدون SDK/OAuth كامل:
    // PUT/GET على <databaseURL>/<path>.json مع ?auth=<secret أو ID token>
    private fun pushFirebase(config: String, dataJson: String): Result<String> {
        val parts = splitConfig(config)
        val dbUrl = parts.getOrNull(0)?.trimEnd('/')
            ?: return Result.failure(Exception("أدخل رابط Firebase Realtime Database (رابط_قاعدة_البيانات|السر)"))
        val authToken = parts.getOrNull(1).orEmpty()
        val url = "$dbUrl/comictrans_memory.json" + if (authToken.isNotBlank()) "?auth=$authToken" else ""
        val body = dataJson.toRequestBody(JSON)
        val req = Request.Builder().url(url).put(body).build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return Result.failure(Exception("فشل الرفع لـ Firebase (${resp.code}): ${resp.body?.string()?.take(200)}"))
            return Result.success("تم رفع الذاكرة إلى Firebase بنجاح")
        }
    }

    private fun pullFirebase(config: String): Result<String> {
        val parts = splitConfig(config)
        val dbUrl = parts.getOrNull(0)?.trimEnd('/')
            ?: return Result.failure(Exception("أدخل رابط Firebase Realtime Database (رابط_قاعدة_البيانات|السر)"))
        val authToken = parts.getOrNull(1).orEmpty()
        val url = "$dbUrl/comictrans_memory.json" + if (authToken.isNotBlank()) "?auth=$authToken" else ""
        val req = Request.Builder().url(url).get().build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return Result.failure(Exception("فشل التنزيل من Firebase (${resp.code})"))
            val text = resp.body?.string()?.trim().orEmpty()
            if (text.isEmpty() || text == "null") return Result.success("[]")
            return Result.success(text)
        }
    }

    // ---------- Supabase ----------
    // يفترض وجود جدول باسم comictrans_sync بأعمدة: id (text, PK) / data (text أو jsonb) / updated_at (int8)
    // المستخدم ينشئه مرة واحدة بنفسه من لوحة Supabase (Table editor)، ثم يستخدم Project URL + anon/service key.
    private fun pushSupabase(config: String, dataJson: String): Result<String> {
        val parts = splitConfig(config)
        if (parts.size < 2) return Result.failure(Exception("صيغة Supabase المطلوبة: رابط_المشروع|apikey"))
        val baseUrl = parts[0].trimEnd('/')
        val apiKey = parts[1]
        val url = "$baseUrl/rest/v1/comictrans_sync?on_conflict=id"
        val row = JSONObject().apply {
            put("id", "default")
            put("data", dataJson)
            put("updated_at", System.currentTimeMillis())
        }
        val arr = JSONArray().put(row)
        val body = arr.toString().toRequestBody(JSON)
        val req = Request.Builder().url(url)
            .addHeader("apikey", apiKey)
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Prefer", "resolution=merge-duplicates")
            .post(body)
            .build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                return Result.failure(Exception("فشل الرفع لـ Supabase (${resp.code}) — تأكد من وجود جدول comictrans_sync بأعمدة id/data/updated_at: ${resp.body?.string()?.take(200)}"))
            }
            return Result.success("تم رفع الذاكرة إلى Supabase بنجاح")
        }
    }

    private fun pullSupabase(config: String): Result<String> {
        val parts = splitConfig(config)
        if (parts.size < 2) return Result.failure(Exception("صيغة Supabase المطلوبة: رابط_المشروع|apikey"))
        val baseUrl = parts[0].trimEnd('/')
        val apiKey = parts[1]
        val url = "$baseUrl/rest/v1/comictrans_sync?id=eq.default&select=data"
        val req = Request.Builder().url(url)
            .addHeader("apikey", apiKey)
            .addHeader("Authorization", "Bearer $apiKey")
            .get().build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return Result.failure(Exception("فشل التنزيل من Supabase (${resp.code})"))
            val text = resp.body?.string().orEmpty()
            val arr = try { JSONArray(text) } catch (e: Exception) { JSONArray() }
            if (arr.length() == 0) return Result.success("[]")
            return Result.success(arr.getJSONObject(0).optString("data", "[]"))
        }
    }

    // ---------- GitHub Gist ----------
    // token يحتاج صلاحية "gist". أول رفعة تُنشئ Gist جديد سري وتُرجع معرّفه لتستخدمه لاحقاً
    // بصيغة token|gistId حتى يتم التحديث فوق نفس الـ Gist بدل إنشاء واحد جديد كل مرة.
    private fun pushGist(config: String, dataJson: String): Result<String> {
        val parts = splitConfig(config)
        val token = parts.getOrNull(0)
            ?: return Result.failure(Exception("أدخل GitHub Personal Access Token بصلاحية gist"))
        val existingId = parts.getOrNull(1)

        val payload = JSONObject().apply {
            put("description", "ComicTranslator sync data")
            put("public", false)
            put("files", JSONObject().apply {
                put("comictrans_memory.json", JSONObject().apply { put("content", dataJson) })
            })
        }
        val body = payload.toString().toRequestBody(JSON)
        val url = if (existingId.isNullOrBlank()) "https://api.github.com/gists" else "https://api.github.com/gists/$existingId"
        val builder = Request.Builder().url(url)
            .addHeader("Authorization", "token $token")
            .addHeader("Accept", "application/vnd.github+json")
        val req = if (existingId.isNullOrBlank()) builder.post(body).build() else builder.patch(body).build()

        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return Result.failure(Exception("فشل الرفع لـ GitHub Gist (${resp.code})"))
            val respJson = JSONObject(resp.body?.string().orEmpty().ifBlank { "{}" })
            val gistId = respJson.optString("id", existingId.orEmpty())
            return Result.success("تم الرفع بنجاح ✅ — احفظ هذه القيمة بحقل الإعداد لاستخدامها لاحقاً: $token|$gistId")
        }
    }

    private fun pullGist(config: String): Result<String> {
        val parts = splitConfig(config)
        val token = parts.getOrNull(0)
        val gistId = parts.getOrNull(1)
        if (token.isNullOrBlank() || gistId.isNullOrBlank()) {
            return Result.failure(Exception("صيغة GitHub Gist المطلوبة للتنزيل: token|gistId"))
        }
        val req = Request.Builder().url("https://api.github.com/gists/$gistId")
            .addHeader("Authorization", "token $token")
            .addHeader("Accept", "application/vnd.github+json")
            .get().build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return Result.failure(Exception("فشل التنزيل من GitHub Gist (${resp.code})"))
            val respJson = JSONObject(resp.body?.string().orEmpty().ifBlank { "{}" })
            val files = respJson.optJSONObject("files") ?: return Result.success("[]")
            val file = files.optJSONObject("comictrans_memory.json") ?: return Result.success("[]")
            return Result.success(file.optString("content", "[]"))
        }
    }
}
