package com.comictrans.model

data class BlockData(
    val text: String,
    val translatedText: String = "",
    val x: Int,
    val y: Int,
    val width: Int,
    val height: Int,
    val confidence: Float = 0f,
    val angle: Float = 0f
)
