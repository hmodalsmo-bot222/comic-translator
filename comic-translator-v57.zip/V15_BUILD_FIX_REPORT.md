# V15 Build Fix Report

## Root cause
GitHub Actions failed before compilation because Gradle could not resolve:
`com.github.equationl.paddleocr4android:paddleocr4android:v1.2.0`

The runner searched Google Maven, Maven Central and JitPack, but no POM was available for that coordinate.

## Fix
Updated `app/build.gradle` to:
`com.github.equationl.paddleocr4android:paddleocr4android:v1.3.0`

The upstream repository's v1.3.0 tag explicitly contains the commit message `ci: 修复 jitpack 构建错误` (fix JitPack build error).

## Paddle-Lite status
This remains the Paddle-Lite Android implementation. The upstream project documents Paddle-Lite as the smaller package path and supports PPOCRv4 and earlier with `.nb` models.

## Other V14 features retained
- Native Kotlin CBZ/ZIP reader
- No imageBase64 page bridge
- WebViewAssetLoader page/processed-page URLs
- PaddleOCR Lite UI option
- OpenRouter translation engine and API key/model fields

## App version
- `versionCode`: 15
- `versionName`: 1.5.0
