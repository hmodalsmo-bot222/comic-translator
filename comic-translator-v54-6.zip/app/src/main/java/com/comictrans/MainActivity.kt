package com.comictrans

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JsPromptResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.widget.EditText
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.FileInputStream

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var appInterface: AppInterface

    // callback الذي يطلبه WebView لتسليم مسار الملف المُختار للصفحة
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        val results: Array<Uri>? = if (result.resultCode == RESULT_OK && data != null) {
            WebChromeClient.FileChooserParams.parseResult(result.resultCode, data)
        } else {
            null
        }
        fileChooserCallback?.onReceiveValue(results)
        fileChooserCallback = null
        val nativeUri = results?.firstOrNull()
        if (result.resultCode == RESULT_OK && nativeUri != null && ::appInterface.isInitialized) {
            val displayName = nativeUri.lastPathSegment?.substringAfterLast('/') ?: "comic.cbz"
            appInterface.loadComicFromUri(nativeUri, displayName)
        }
    }

    // "خلفية المجتمع" — Local Sync: تصدير/استيراد ذاكرة الترجمة كملف JSON بدون إنترنت،
    // المستخدم يشارك الملف يدوياً بين أجهزته (بلوتوث/تطبيق مشاركة/تخزين سحابي عادي).
    private var pendingExportData: String? = null
    private val exportFileLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        val data = pendingExportData
        pendingExportData = null
        if (uri == null || data == null) {
            appInterface.onLocalSyncResult(false, "تم إلغاء التصدير", null)
            return@registerForActivityResult
        }
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(data.toByteArray(Charsets.UTF_8)) }
            appInterface.onLocalSyncResult(true, "تم تصدير الذاكرة بنجاح إلى الملف المختار", null)
        } catch (e: Exception) {
            appInterface.onLocalSyncResult(false, "فشل الكتابة: ${e.message}", null)
        }
    }

    private val importFileLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) {
            appInterface.onLocalSyncResult(false, "تم إلغاء الاستيراد", null)
            return@registerForActivityResult
        }
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            if (text.isNullOrBlank()) {
                appInterface.onLocalSyncResult(false, "الملف فارغ أو تعذّرت قراءته", null)
            } else {
                appInterface.onLocalSyncResult(true, "تم استيراد الملف بنجاح", text)
            }
        } catch (e: Exception) {
            appInterface.onLocalSyncResult(false, "فشلت القراءة: ${e.message}", null)
        }
    }

    fun exportJsonToFile(data: String, suggestedName: String) {
        pendingExportData = data
        exportFileLauncher.launch(suggestedName)
    }

    fun importJsonFromFile() {
        importFileLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // تهيئة OpenCV — بند 11: مكتبة org.opencv انتقلت لموديول feature_ai (Dynamic Feature)،
        // فـapp ما يقدر يعتمد عليها مباشرة وقت الترجمة بعد الآن. التهيئة الفعلية تصير عبر
        // Reflection (راجع FeatureAiLoader.initializeOpenCV() — التنفيذ الحقيقي بـ
        // feature_ai/.../engine/OpenCvInitializer.kt). OpenCVStatus.isAvailable يُحدَّث
        // داخلياً بنفس الاستدعاء (ضمن FeatureAiLoader/OpenCvInitializer)، فلا حاجة لتعيينه هنا يدوياً.
        if (com.comictrans.engine.contracts.FeatureAiLoader.initializeOpenCV()) {
            android.util.Log.d("OpenCV", "OpenCV loaded successfully")
        } else {
            android.util.Log.e("OpenCV", "OpenCV initialization failed — falling back to simple erase")
        }

        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        setupWebView()

        appInterface = AppInterface(this, webView)
        webView.addJavascriptInterface(appInterface, "AndroidBridge")

        // 🔧 (2026-08-17) إصلاح جذري لتعليق تحميل الصفحات: كانت الصفحة الرئيسية تُحمَّل من
        // file:///android_asset/index.html بينما صور الصفحات تُطلَب من نطاق مختلف تماماً
        // (https://comic.local/...). أي طلب Cross-Origin بـ img.crossOrigin="anonymous"
        // صادر من مستند file:// يُحجَب أحياناً من طبقة أمان WebView نفسها **قبل** ما يوصل
        // لـshouldInterceptRequest إطلاقاً (بصمت، بدون أي استثناء أو تحذير) — وهذا يفسّر
        // ليش إصلاح shouldInterceptRequest وحده ما أثّر: الطلب أصلاً ما كان يوصل له.
        // الحل: تحميل الصفحة نفسها من https://comic.local/index.html بدل file:// حتى تصير
        // كل الموارد (الصفحة + الصور) من نفس الأصل (Same-Origin) ولا يوجد أي قيد Cross-Origin.
        webView.loadUrl("https://comic.local/index.html")
    }

    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            // مُعطَّل عمداً: تكبير WebView المدمج (native pinch-zoom) كان يتصادم مع
            // تكبير القارئ المخصّص في JS (initReaderZoom في index.html). Android WebView
            // كان يعالج لفتتين الأصابع كإيماءة تكبير "بصرية" خاصة به (مستوى الـ compositor)،
            // فيبدو الأمر وكأنه تكبير فعلي أثناء إبقاء الأصابع، لكن فور رفعها كان WebView
            // يعيد ضبط/تخطيط الصفحة لمقاسها الطبيعي (لأن أبعاد المحتوى الفعلية ما تغيّرت)،
            // فيرجع كل شي "زي ما كان" — وهذا بالضبط العطل المُبلّغ عنه. تعطيل التكبير المدمج
            // هنا يسلّم التحكم بالكامل لكود JS (initReaderZoom) اللي يطبّق transform يدوي
            // ثابت لا يُلغى إلا بنقرة مزدوجة أو بتصفير صريح.
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val url = request?.url ?: return super.shouldInterceptRequest(view, request)
                // 🔧 (2026-08-17) إصلاح حرج لبلاغ "يقف على تجهيز 1/N ولا يتحرك": أي مسار كان
                // يرجّع null أو يستدعي super.shouldInterceptRequest() لطلبات comic.local (فهرس
                // غير صالح، ملف غير موجود، أو استثناء) كان يجعل WebView يحاول فعلياً حل
                // "comic.local" عبر الشبكة الحقيقية (null يعني "خلّي WebView يكمّل التحميل
                // العادي" حسب توثيق Android — أي شبكة فعلية أيضاً). هذا Domain وهمي غير موجود
                // فعلياً، فمحاولة الشبكة الحقيقية تتعلّق (خصوصاً مع اتصال ضعيف/طوارئ فقط) بدل
                // أن تفشل بسرعة — فلا onload ولا onerror يُطلَق أبداً في JS، فتتجمّد الحلقة على
                // "تجهيز 1/N" للأبد بدون أي رسالة خطأ. الإصلاح: أي طلب comic.local يُجاب محلياً
                // دائماً — حتى لو 404 — ولا يُترك أبداً يهرب لشبكة حقيقية.
                if (url.scheme == "https" && url.host == "comic.local") {
                    val kind = url.pathSegments.firstOrNull()

                    // يخدم الصفحة الرئيسية نفسها (index.html أو /) من assets تحت نفس النطاق
                    // comic.local، حتى تصير كل موارد التطبيق (الصفحة + الصور) من نفس الأصل.
                    if (kind == null || kind == "index.html") {
                        return try {
                            WebResourceResponse(
                                "text/html", "UTF-8", 200, "OK",
                                mapOf("Access-Control-Allow-Origin" to "*"),
                                this@MainActivity.assets.open("index.html")
                            )
                        } catch (_: Exception) {
                            WebResourceResponse(
                                "text/plain", "UTF-8", 500, "Internal Server Error",
                                mapOf("Access-Control-Allow-Origin" to "*"),
                                java.io.ByteArrayInputStream(ByteArray(0))
                            )
                        }
                    }

                    val index = url.pathSegments.getOrNull(1)?.toIntOrNull()
                    val file = if (index != null && ::appInterface.isInitialized) {
                        when (kind) {
                            "page" -> appInterface.getNativePageFile(index)
                            "processed" -> appInterface.getProcessedPageFile(index)
                            else -> null
                        }
                    } else null
                    if (file != null && file.exists()) {
                        val mime = when (file.extension.lowercase()) {
                            "jpg", "jpeg" -> "image/jpeg"
                            "png" -> "image/png"
                            "webp" -> "image/webp"
                            "gif" -> "image/gif"
                            "bmp" -> "image/bmp"
                            else -> "application/octet-stream"
                        }
                        return try {
                            WebResourceResponse(
                                mime, null, 200, "OK",
                                mapOf("Access-Control-Allow-Origin" to "*"),
                                FileInputStream(file)
                            )
                        } catch (_: Exception) {
                            WebResourceResponse(
                                "text/plain", "UTF-8", 500, "Internal Server Error",
                                mapOf("Access-Control-Allow-Origin" to "*"),
                                java.io.ByteArrayInputStream(ByteArray(0))
                            )
                        }
                    }
                    // الملف غير موجود/فهرس غير صالح: رد 404 محلي فوري بدل الهروب للشبكة الحقيقية —
                    // هذا يجعل img.onerror يُطلَق فوراً في JS بدل التجمّد.
                    return WebResourceResponse(
                        "text/plain", "UTF-8", 404, "Not Found",
                        mapOf("Access-Control-Allow-Origin" to "*"),
                        java.io.ByteArrayInputStream(ByteArray(0))
                    )
                }
                return super.shouldInterceptRequest(view, request)
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback
                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                return try {
                    fileChooserLauncher.launch(intent)
                    true
                } catch (e: Exception) {
                    fileChooserCallback = null
                    false
                }
            }

            // *** إصلاح جذري: window.prompt() في index.html كان لا يعمل إطلاقاً ***
            // بمجرد تعيين WebChromeClient مخصّص (كما هنا لأجل onShowFileChooser)، تتوقف
            // معالجة WebView الافتراضية لحوارات JS (alert/confirm/prompt) — الكلاس الأساس
            // WebChromeClient لا ينفّذ أي حوار فعلي لهذه الدوال ما لم يُطلب صراحة override،
            // فتُستدعى prompt() في JS وترجع null فوراً بدون عرض أي حوار للمستخدم إطلاقاً.
            // هذا بالضبط سبب "أضع الرابط ولا يتم التنزيل" عند تنزيل نموذج AI/Paddle مخصّص:
            // كود JS (index.html) يستدعي `prompt(...)`، يرجع null دائماً، فيتوقف الكود عند
            // `if (!url) return;` قبل أي استدعاء لـ AndroidBridge.setModelUrl/downloadModel.
            override fun onJsPrompt(
                view: WebView?,
                url: String?,
                message: String?,
                defaultValue: String?,
                result: JsPromptResult?
            ): Boolean {
                val ctx = view?.context ?: this@MainActivity
                val input = EditText(ctx).apply {
                    setText(defaultValue ?: "")
                    setSelection(text.length)
                }
                AlertDialog.Builder(ctx)
                    .setTitle(message ?: "")
                    .setView(input)
                    .setCancelable(true)
                    .setPositiveButton("موافق") { _, _ -> result?.confirm(input.text.toString()) }
                    .setNegativeButton("إلغاء") { _, _ -> result?.cancel() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            // نفس المشكلة تنطبق على confirm()/alert() لو استُخدمت لاحقاً في index.html —
            // نضيفها احتياطاً حتى لا يتكرر نفس العطل الصامت مستقبلاً.
            override fun onJsConfirm(
                view: WebView?,
                url: String?,
                message: String?,
                result: android.webkit.JsResult?
            ): Boolean {
                val ctx = view?.context ?: this@MainActivity
                AlertDialog.Builder(ctx)
                    .setMessage(message ?: "")
                    .setCancelable(true)
                    .setPositiveButton("موافق") { _, _ -> result?.confirm() }
                    .setNegativeButton("إلغاء") { _, _ -> result?.cancel() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            override fun onJsAlert(
                view: WebView?,
                url: String?,
                message: String?,
                result: android.webkit.JsResult?
            ): Boolean {
                val ctx = view?.context ?: this@MainActivity
                AlertDialog.Builder(ctx)
                    .setMessage(message ?: "")
                    .setCancelable(true)
                    .setPositiveButton("موافق") { _, _ -> result?.confirm() }
                    .setOnCancelListener { result?.confirm() }
                    .show()
                return true
            }
        }
    }

    fun sendToWebView(functionName: String, data: String) {
        runOnUiThread {
            webView.evaluateJavascript("window.$functionName($data)", null)
        }
    }

    override fun onDestroy() {
        if (::appInterface.isInitialized) {
            appInterface.releaseResources()
        }
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("AndroidBridge")
            webView.stopLoading()
            webView.loadUrl("about:blank")
            webView.destroy()
        }
        super.onDestroy()
    }
}
