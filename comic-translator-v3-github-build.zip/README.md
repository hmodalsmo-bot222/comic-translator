# قارئ الكوميكس المترجم — Comic Translator

مشروع Android كامل (Kotlin + HTML5) لترجمة الكوميكس من الإنجليزية للعربية.

## المعمارية

```
Android Native (Kotlin) ← المنصّق
├─ ML Kit OCR (يعمل فوراً)
├─ ML Kit Translation EN→AR (يعمل فوراً)
├─ Google Translate (يعمل فوراً)
├─ SQLite ذاكرة ذكية (تعمل فوراً)
├─ JavaScript Interface (يعمل فوراً)
├─ OkHttp للترجمة السحابية (يعمل فوراً)
├─ OpenCV Inpaint (يحتاج ملفات .so)
├─ TFLite AI Inpainting (يحتاج نموذج .tflite)
├─ ONNX AI Inpainting (يحتاج نموذج .onnx)
└─ PaddleOCR (يحتاج .so + نماذج .nb)

HTML5 (WebView) ← الواجهة
├─ عرض صفحات CBZ (يعمل — STORE method)
├─ Canvas Overlay (يعمل)
├─ قوائم الإعدادات (تعمل)
└─ JavaScript Bridge (يعمل)
```

---

## ما يعمل فوراً (بدون ملفات إضافية)

| الميزة | الحالة | ملاحظة |
|--------|--------|--------|
| ML Kit OCR | ✅ | يعمل offline بعد تحميل النموذج |
| ML Kit Translation EN→AR | ✅ | يعمل offline بعد تحميل النموذج |
| Google Translate (gtx) | ✅ | يحتاج إنترنت |
| Gemini / OpenAI / DeepL | ✅ | يحتاج مفتاح API |
| SQLite ذاكرة ذكية | ✅ | محلي تماماً |
| OCR.space | ✅ | يحتاج مفتاح API |
| Cloud API | ✅ | رابط مخصص |
| Overlay / Fill / Blur | ✅ | في HTML Canvas |
| CBZ unzip (STORE) | ✅ | الملفات غير المضغوطة |

---

## ما يحتاج ملفات ثنائية إضافية

### ١. OpenCV Inpaint

**الملفات المطلوبة:**
```
app/src/main/jniLibs/arm64-v8a/libopencv_java4.so
```

**كيفية الحصول:**
1. تحميل `opencv-4.9.0-android-sdk.zip` من https://opencv.org/releases/
2. فك الضغط
3. انسخ `sdk/native/libs/arm64-v8a/libopencv_java4.so` إلى المجلد أعلاه

**البديل:**
```gradle
// في build.gradle — يحتاج maven repository خاص
implementation 'org.opencv:opencv-android:4.9.0'
// لكن هذا لا يتضمن ملفات .so دائماً
```

---

### ٢. PaddleOCR Lite

**الملفات المطلوبة:**
```
app/src/main/jniLibs/arm64-v8a/libpaddle_light_api_shared.so
app/src/main/assets/paddle/ch_PP-OCRv4_det.nb
app/src/main/assets/paddle/en_PP-OCRv4_rec.nb
app/src/main/assets/paddle/en_dict.txt
```

**كيفية الحصول:**
1. تحميل `PaddleLite-android` من https://github.com/PaddlePaddle/Paddle-Lite
2. تحميل النماذج من https://github.com/PaddlePaddle/PaddleOCR
   - Detection: `ch_PP-OCRv4_det_infer` → تحويلها إلى `.nb` عبر opt tool
   - Recognition: `en_PP-OCRv4_rec_infer` → تحويلها إلى `.nb`
   - Dictionary: `en_dict.txt`

**ملاحظة:** تحويل النماذج يحتاج أدوات Paddle وقد يكون معقداً. يمكنك استخدام نماذج جاهزة `.nb` من مجتمع Paddle إذا وجدت.

---

### ٣. AI Lite (TFLite Inpainting)

**الملفات المطلوبة:**
```
/storage/emulated/0/Android/data/com.comictrans/files/models/lama-lite.tflite
```

**كيفية الحصول:**
1. تحميل نموذج LaMa أو MAT (PyTorch)
2. تحويله إلى TFLite عبر:
   ```python
   import tensorflow as tf
   converter = tf.lite.TFLiteConverter.from_saved_model('lama_model')
   converter.optimizations = [tf.lite.Optimize.DEFAULT]
   tflite_model = converter.convert()
   with open('lama-lite.tflite', 'wb') as f:
       f.write(tflite_model)
   ```
3. ضع الملف في مجلد models على الهاتف

**التحدي:**
- نماذج Inpainting ثقيلة (20-50MB)
- تحويلها يحتاج Python + TensorFlow
- يجب أن تدعم مدخلات: صورة + قناع (mask)

---

### ٤. AI Pro (ONNX Inpainting)

**الملفات المطلوبة:**
```
/storage/emulated/0/Android/data/com.comictrans/files/models/lama-pro.onnx
```

**كيفية الحصول:**
1. تحميل نموذج LaMa (PyTorch)
2. تحويله إلى ONNX:
   ```python
   import torch
   import torch.onnx
   torch.onnx.export(model, dummy_input, "lama-pro.onnx", opset_version=11)
   ```
3. ضع الملف في مجلد models على الهاتف

---

### ٥. fflate.js (للـ CBZ المضغوط DEFLATE)

**الملف المطلوب:**
```
app/src/main/assets/js/fflate.min.js
```

**كيفية الحصول:**
1. `npm install fflate`
2. أو تحميل من CDN: https://cdn.jsdelivr.net/npm/fflate@0.8.2/umd/index.min.js
3. ضعه في المجلد أعلاه
4. عدّل `index.html` ليستخدم fflate بدلاً من `cbz-unzip.js`

**البديل:**
الكود الحالي `cbz-unzip.js` يدعم STORE (غير مضغوط) فقط. معظم CBZ تستخدم DEFLATE.

---

## كيفية البناء

### عبر GitHub Actions (تلقائي — الأسهل)

المشروع يحتوي على `.github/workflows/build.yml` يبني الـ APK تلقائياً عند كل push، ويولّد ملفات gradle wrapper بنفسه (لأنها غير مرفقة بالمشروع).

1. ارفع المشروع لمستودع GitHub جديد (أو موجود).
2. من تبويب **Actions** بالمستودع، شغّل الـ workflow يدوياً (`workflow_dispatch`) أو انتظر أول push.
3. بعد اكتمال التشغيل بنجاح، افتح تفاصيل الـ run وحمّل الـ APK من قسم **Artifacts** باسم `comic-translator-debug-apk`.

### في Codespaces (GitHub)

```bash
# ١. ادخل لمجلد المشروع
cd comic-translator

# ٢. ولّد ملفات gradle wrapper (غير مرفقة بالمشروع)
gradle wrapper --gradle-version 8.4
chmod +x gradlew

# ٣. بناء APK
./gradlew assembleDebug

# ٤. APK الناتج
app/build/outputs/apk/debug/app-debug.apk
```

### في Android Studio

1. افتح المجلد `comic-translator`.
2. انتظر Gradle Sync (يولّد الـ wrapper تلقائياً إن لزم).
3. اضغط Run (▶️) أو Build → Build APK.

---

## الملفات الرئيسية

| الملف | الغرض |
|-------|-------|
| `MainActivity.kt` | WebView + OpenCV init |
| `AppInterface.kt` | JavaScript Interface + Coordinator |
| `OCREngine.kt` | ML Kit + OCR.space + Cloud + PaddleOCR |
| `TranslationEngine.kt` | ML Kit + Google + Gemini + OpenAI + DeepL |
| `ErasureEngine.kt` | OpenCV + TFLite + ONNX |
| `PaddleOCRNative.kt` | JNI wrapper |
| `PaddleOCREngine.kt` | Model management |
| `TranslationEntity.kt` | جدول SQLite |
| `index.html` | الواجهة الكاملة |
| `cbz-unzip.js` | فك CBZ (STORE) |

---

## آخر التغييرات (v3)

- **إصلاح جذري**: أوضاع OpenCV/AI Lite/AI Pro كانت تعالج الصورة بالأندرويد ثم النتيجة تُرمى ولا تظهر أبداً — لأن `index.html` كان يقرأ حقل `blocks` فقط ويتجاهل `erasureData` القادم من Kotlin. تم التوحيد بينهما وأصبحت كل أوضاع الطمس تعمل فعلياً.
- تنبيه صريح بالسجل عند فشل PaddleOCR Lite ورجوعه التلقائي لـ ML Kit (بدل ما يحدث بصمت).
- زر «💾 حفظ وتطبيق الإعدادات» (يحفظ محلياً عبر localStorage ويعيد رسم الصفحات المترجمة فوراً بالتنسيق الجديد).
- قسم «🔤 تنسيق الخط»: نوع الخط (مع فحص فعلي لتوفره على الجهاز)، حجم الخط، تباعد الأسطر، عرض النص داخل الفقاعة، لون الخط.
- رسم الكانفاس بدقة `devicePixelRatio` لخط أوضح عند التكبير.
- حقلا اسم نموذج Gemini/OpenAI قابلان للتعديل بدل ما كانا مثبتين بالكود.
- تكبير/تصغير وتحريك بإصبعين (Pinch-zoom + Pan) على كل صفحة، وتصغير سريع بالنقر المزدوج.
- الشريط العائم صار شبه شفاف وقابل للسحب يمين/يسار، وأضيف زر ثالث «🔄 صفحة جديدة» يمسح ترجمة الصفحة الحالية فقط ويرجعها للأصل لإعادة القراءة والترجمة.
- سجل أحداث أوضح: نجاح كل مرحلة (OCR/ترجمة/طمس)، كل تبديل محرك، الحفظ، الاستعادة.

## الترخيص

MIT — استخدمه كما تشاء.


## البناء عبر GitHub Actions

هذا المشروع مجهز بملف:
`.github/workflows/build.yml`

بعد رفع المشروع إلى GitHub:
1. افتح تبويب **Actions**.
2. اختر **Build Android APK**.
3. اضغط **Run workflow**.
4. انتظر حتى يصبح التنفيذ أخضر.
5. افتح التنفيذ ثم قسم **Artifacts**.
6. نزّل `comic-translator-debug-apk`.

يتم تجهيز Android SDK/CMake وJDK 17، ثم إنشاء Gradle Wrapper وبناء APK.
ويتم تجهيز Paddle-Lite 2.10 وPP-OCRv2 slim أثناء البناء.
