# PaddleOCR Lite integration

This project now uses the official Paddle-Lite 2.10 Android runtime and official PP-OCRv2 slim `.nb` models.

The first Gradle build automatically downloads and prepares:
- Paddle-Lite arm64 runtime (`libpaddle_light_api_shared.so`)
- PP-OCRv2 slim detector
- PP-OCRv2 slim recognizer
- PaddleOCR dictionary

After the APK is built, OCR inference is fully local/offline; the app does not download OCR models at runtime.

The integration is intentionally arm64-v8a only, matching the existing project ABI choice.
