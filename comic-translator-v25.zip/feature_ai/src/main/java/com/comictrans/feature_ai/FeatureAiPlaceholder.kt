package com.comictrans.feature_ai

/**
 * بند 11 — الخطوة الأولى فقط. لا وظيفة فعلية بعد.
 *
 * هذا الملف موجود فقط عشان module بند 11 يحتوي كود Kotlin حقيقي (بدل موديول فاضٍ تماماً)
 * لنتأكد أن toolchain الـKotlin/Gradle الخاص بـDynamic Feature Module يبني بنجاح فعلياً.
 * بالخطوة التالية (بعد تأكيد نجاح هذا البناء)، هذا الملف يُستبدَل تدريجياً بمحركات AI
 * الحقيقية المنقولة من app/src/main/java/com/comictrans/engine/ (البداية المقترحة:
 * ErasureEngine.kt + OpenCVStatus.kt، لأنهما الأقل ترابطاً مع بقية AppInterface.kt).
 */
object FeatureAiPlaceholder {
    const val MODULE_NAME = "feature_ai"
}
