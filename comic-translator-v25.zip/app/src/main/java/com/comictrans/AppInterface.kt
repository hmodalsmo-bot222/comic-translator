package com.comictrans

import android.content.Context
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.net.Uri
import java.io.File
import java.io.FileInputStream
import java.util.zip.ZipInputStream
import java.util.Locale
import androidx.lifecycle.lifecycleScope
import com.comictrans.engine.OCREngine
import com.comictrans.engine.TranslationEngine
import com.comictrans.engine.ErasureEngine
import com.comictrans.engine.ImageEnhanceEngine
import com.comictrans.engine.SyncEngine
import com.comictrans.db.AppDatabase
import com.comictrans.db.TranslationEntity
import com.comictrans.model.BlockData
import com.comictrans.model.SettingsData
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class AppInterface(
    private val context: Context,
    private val webView: WebView
) {

    private val gson = Gson()
    private var isProcessing = false
    private var shouldStop = false
    private var nativePageFiles: List<File> = emptyList()
    private var nativeComicTitle: String = ""
    // بصمة الكوميك الحالي (بند 5: Cache) — تُستخدم كمفتاح جزئي في page_cache حتى لا تختلط
    // نتائج صفحة من كوميك بنفس رقم صفحة من كوميك آخر. راجع حساب القيمة في loadComicFromUri.
    private var nativeComicHash: String = ""
    private val processedPageRoot: File by lazy { File(context.cacheDir, "processed_pages") }

    private val modelManager = com.comictrans.engine.ModelManager(context)
    private val mlkitModelManager = com.comictrans.engine.MlkitModelManager(context)
    private val ocrEngine = OCREngine(context, modelManager)
    private val translateEngine = TranslationEngine(context)
    private val erasureEngine = ErasureEngine(context, modelManager)
    private val imageEnhanceEngine = ImageEnhanceEngine(context, modelManager)
    private val syncEngine = SyncEngine()
    private val db = AppDatabase.getInstance(context)
    // نظام أخطاء موحّد (Central Error Handling): كل نقطة catch رئيسية تمرّ من هنا بدل
    // كتابة رسالة/تسجيل خاص بها — تصنيف موحّد (OCR/Translation/AI Models/CBZ/Files/
    // Network) + رسالة عربية آمنة للمستخدم + سجل داخلي دوّار يمكن تصديره لاحقاً.
    private val errorManager = com.comictrans.error.ErrorManager(context)

    // ================= إدارة نماذج AI Lite / AI Pro =================

    // ملفات PaddleOCR Lite (det.nb/rec.nb/cls.nb/ppocr_keys_v1.txt) قد تكون فعلياً "مضمّنة"
    // في assets/paddle (لو أُضيفت وقت البناء عبر CI) بدل مُنزَّلة عبر ModelManager. سابقاً
    // كانت واجهة JS تفترض أنها مضمّنة دائماً بدون تحقق فعلي (hardcoded) — نتحقق هنا فعلياً
    // ونرسل الحالة الحقيقية بدل الافتراض.
    private fun isPaddleActuallyBundledInAssets(): Boolean = try {
        val listed = context.assets.list("paddle")?.toSet() ?: emptySet()
        setOf("det.nb", "rec.nb", "cls.nb", "ppocr_keys_v1.txt").all { it in listed }
    } catch (e: Exception) {
        false
    }

    @JavascriptInterface
    fun listModels() {
        val paddleBundled = isPaddleActuallyBundledInAssets()
        // بناء حالة نماذج ML Kit يحتاج استعلاماً فعلياً من Google Play services (Task غير
        // متزامن)، لذلك أصبحت الدالة كاملة تُبنى وتُرسَل داخل coroutine واحدة بدل إرسال
        // مصفوفتين منفصلتين — الواجهة (window.onModelList) أصلاً غير متزامنة وما تفترض
        // استدعاءً فورياً، فهذا لا يغيّر أي سلوك ظاهر بالواجهة.
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            val arr = JSONArray()
            modelManager.availableModels.forEach { m ->
                val isPaddleFile = m.id.startsWith("paddle_")
                arr.put(JSONObject().apply {
                    put("id", m.id)
                    put("displayName", m.displayName)
                    put("approxSizeMB", m.approxSizeMB)
                    put("hasUrl", m.url.isNotBlank())
                    // لو ملفات Paddle مضمّنة فعلياً في assets وقت البناء، فهي "جاهزة" حتى لو لم
                    // تُنزَّل عبر ModelManager؛ غير ذلك نعتمد فقط على وجودها الفعلي على التخزين.
                    put("downloaded", (isPaddleFile && paddleBundled) || modelManager.isDownloaded(m))
                    put("bundled", isPaddleFile && paddleBundled)
                })
            }
            // حزم Google ML Kit (ترجمة EN/AR محلية) — لا تحتاج أي رابط (راجع MlkitModelManager)،
            // فتظهر بنفس شاشة "إدارة نماذج AI" بجانب AI Lite/AI Pro/PaddleOCR، بزر تنزيل مباشر
            // فعلي بدل أي طلب من المستخدم يلصق رابطاً.
            mlkitModelManager.languages.forEach { info ->
                arr.put(JSONObject().apply {
                    put("id", info.code)
                    put("displayName", info.displayName)
                    put("approxSizeMB", 30) // تقديري — نماذج ترجمة ML Kit لكل لغة عادة قرابة هذا الحجم
                    put("hasUrl", true)
                    put("downloaded", mlkitModelManager.isDownloaded(info))
                    put("bundled", false)
                    put("mlkit", true)
                })
            }
            sendToWebView("onModelList", arr.toString())
        }
    }

    @JavascriptInterface
    fun downloadModel(modelId: String) {
        val mlkitInfo = mlkitModelManager.languages.find { it.code == modelId }
        if (mlkitInfo != null) {
            (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
                sendModelProgress(modelId, 1) // إشارة بدء فورية — واجهة Google لا تعطي نسبة تقدّم حقيقية بالبايت
                val result = mlkitModelManager.download(mlkitInfo)
                result.fold(
                    onSuccess = { sendModelStatus(modelId, true, "تم تنزيل ${mlkitInfo.displayName} بنجاح") },
                    onFailure = { err -> sendModelStatus(modelId, false, err.message ?: "فشل تنزيل حزمة ML Kit") }
                )
            }
            return
        }
        val model = modelManager.availableModels.find { it.id == modelId } ?: run {
            sendModelStatus(modelId, false, "نموذج غير معروف")
            return
        }
        // startDownload() نفسها تكتشف تلقائياً وجود ملف .part من محاولة سابقة (متوقفة أو
        // Paused) وتُكمل منه (Resume)، وتمنع بدء تنزيل ثانٍ لو نفس النموذج قيد التنزيل فعلاً.
        modelManager.startDownload(model) { status -> onModelDownloadUpdate(modelId, model.displayName, status) }
    }

    /** يوقف تنزيل نموذج مؤقتاً — الملف الجزئي يبقى محفوظاً لاستئنافه لاحقاً. */
    @JavascriptInterface
    fun pauseModelDownload(modelId: String) {
        modelManager.pauseDownload(modelId)
        sendModelDownloadState(com.comictrans.engine.DownloadStatus(modelId, com.comictrans.engine.DownloadState.PAUSED, message = "تم إيقاف التنزيل مؤقتاً"))
    }

    /** يستأنف تنزيلاً متوقفاً (Paused) أو غير مكتمل — نفس منطق downloadModel بالضبط. */
    @JavascriptInterface
    fun resumeModelDownload(modelId: String) = downloadModel(modelId)

    /** يلغي التنزيل نهائياً ويحذف أي ملف جزئي — بعكس pauseModelDownload لا يمكن استئنافه بعدها. */
    @JavascriptInterface
    fun cancelModelDownload(modelId: String) {
        modelManager.cancelDownload(modelId)
        sendModelDownloadState(com.comictrans.engine.DownloadStatus(modelId, com.comictrans.engine.DownloadState.NONE, message = "أُلغي التنزيل"))
    }

    private fun onModelDownloadUpdate(modelId: String, displayName: String, status: com.comictrans.engine.DownloadStatus) {
        sendModelDownloadState(status)
        // نحافظ على توافق الأحداث القديمة (onModelProgress/onModelStatus) حتى لا تنكسر أي
        // شاشة تعتمد عليها فقط، بجانب الحدث الجديد onModelDownloadState الأغنى بالحالة.
        when (status.state) {
            com.comictrans.engine.DownloadState.DOWNLOADING, com.comictrans.engine.DownloadState.VERIFYING ->
                sendModelProgress(modelId, status.progressPct)
            com.comictrans.engine.DownloadState.COMPLETED ->
                sendModelStatus(modelId, true, status.message ?: "تم تنزيل $displayName بنجاح")
            com.comictrans.engine.DownloadState.FAILED ->
                sendModelStatus(modelId, false, status.message ?: "فشل التنزيل")
            else -> {}
        }
    }

    private fun sendModelDownloadState(status: com.comictrans.engine.DownloadStatus) {
        val json = JSONObject().apply {
            put("id", status.modelId)
            put("state", status.state.name)
            put("progress", status.progressPct)
            put("message", status.message ?: "")
        }
        sendToWebView("onModelDownloadState", json.toString())
    }

    @JavascriptInterface
    fun deleteModel(modelId: String) {
        val mlkitInfo = mlkitModelManager.languages.find { it.code == modelId }
        if (mlkitInfo != null) {
            (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
                val result = mlkitModelManager.delete(mlkitInfo)
                result.fold(
                    onSuccess = { sendModelStatus(modelId, true, "تم حذف ${mlkitInfo.displayName}") },
                    onFailure = { err -> sendModelStatus(modelId, false, err.message ?: "فشل الحذف") }
                )
            }
            return
        }
        val model = modelManager.availableModels.find { it.id == modelId } ?: return
        modelManager.delete(model)
        sendModelStatus(modelId, true, "تم حذف ${model.displayName}")
    }

    @JavascriptInterface
    fun setModelUrl(modelId: String, url: String) {
        modelManager.setCustomUrl(modelId, url)
        listModels()
    }

    private fun sendModelProgress(modelId: String, pct: Int) {
        val json = JSONObject().apply { put("id", modelId); put("progress", pct) }
        sendToWebView("onModelProgress", json.toString())
    }

    private fun sendModelStatus(modelId: String, success: Boolean, message: String) {
        val json = JSONObject().apply {
            put("id", modelId); put("success", success); put("message", message)
        }
        sendToWebView("onModelStatus", json.toString())
    }

    // Performance architecture: CBZ pages are extracted once by Kotlin and served from
    // the local comic.local URL. startProcessing receives only the page index + settings;
    // the page Bitmap is decoded directly from the native cache.
    @JavascriptInterface
    fun isNativeFileImportEnabled(): Boolean = true

    /** Native CBZ/ZIP reader. JavaScript only renders the pages; it never unpacks the archive. */
    fun loadComicFromUri(uri: Uri, displayName: String) {
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            try {
                val root = File(context.cacheDir, "comic_pages")
                root.deleteRecursively()
                root.mkdirs()
                processedPageRoot.deleteRecursively()
                processedPageRoot.mkdirs()
                val extracted = ArrayList<Pair<String, File>>()
                var totalBytes = 0L
                context.contentResolver.openInputStream(uri)?.use { input ->
                    ZipInputStream(input.buffered(128 * 1024)).use { zip ->
                        var entry = zip.nextEntry
                        while (entry != null) {
                            if (!entry.isDirectory && isImageEntry(entry.name)) {
                                val safeName = "page_${extracted.size.toString().padStart(6, '0')}_${safeExtension(entry.name)}"
                                val outFile = File(root, safeName)
                                var written = 0L
                                outFile.outputStream().buffered(128 * 1024).use { out ->
                                    val buffer = ByteArray(128 * 1024)
                                    while (true) {
                                        val n = zip.read(buffer)
                                        if (n <= 0) break
                                        written += n
                                        totalBytes += n
                                        if (totalBytes > 512L * 1024L * 1024L) throw IllegalStateException("CBZ كبير جداً (الحد 512MB)")
                                        out.write(buffer, 0, n)
                                    }
                                }
                                if (written > 0) extracted.add(entry.name to outFile)
                            }
                            zip.closeEntry()
                            entry = zip.nextEntry
                        }
                    }
                } ?: throw IllegalStateException("تعذرت قراءة ملف CBZ")

                val sorted = extracted.sortedWith { p1, p2 -> compareByNatural(p1.first, p2.first) }
                nativePageFiles = sorted.map { it.second }
                nativeComicTitle = displayName
                if (nativePageFiles.isEmpty()) throw IllegalStateException("لم يتم العثور على صور داخل CBZ")
                // بصمة خفيفة (اسم الملف + عدد الصفحات + الحجم الكلي) بدل هاش SHA256 كامل
                // للملف — تجنّباً لقراءة كل الـ512MB مرة إضافية فقط للتجزئة، مع بقاء البصمة
                // مميّزة عملياً بما يكفي للتفريق بين كوميكسات مختلفة بنفس الاسم تقريباً.
                nativeComicHash = java.security.MessageDigest.getInstance("SHA-256")
                    .digest("$displayName|${nativePageFiles.size}|$totalBytes".toByteArray())
                    .joinToString("") { "%02x".format(it) }

                val json = JSONObject().apply {
                    put("title", nativeComicTitle)
                    put("count", nativePageFiles.size)
                    put("baseUrl", "https://comic.local/page/")
                }
                sendToWebView("onNativeComicLoaded", json.toString())
            } catch (e: Exception) {
                val err = errorManager.handle(e, com.comictrans.error.ErrorCategory.CBZ, "فشل فتح ملف الكوميك")
                sendError(-1, err.userMessage)
            }
        }
    }

    private fun isImageEntry(name: String): Boolean =
        !name.contains("__MACOSX", ignoreCase = true) &&
            name.substringAfterLast('/').matches(Regex("(?i).+\\.(jpg|jpeg|png|webp|gif|bmp)$"))

    private fun safeExtension(name: String): String {
        val ext = name.substringAfterLast('.', "jpg").lowercase(Locale.ROOT)
        return if (ext in setOf("jpg", "jpeg", "png", "webp", "gif", "bmp")) ext else "jpg"
    }

    private fun compareByNatural(a: String, b: String): Int {
        val pattern = Regex("\\d+")
        val at = pattern.findAll(a).toList()
        val bt = pattern.findAll(b).toList()
        var posA = 0
        var posB = 0
        val parts = maxOf(at.size, bt.size)
        for (i in 0 until parts) {
            val aNum = at.getOrNull(i)?.value?.toLongOrNull()
            val bNum = bt.getOrNull(i)?.value?.toLongOrNull()
            if (aNum != null && bNum != null && aNum != bNum) return aNum.compareTo(bNum)
            val aText = if (i < at.size) a.substring(posA, at[i].range.first) else a.substring(posA)
            val bText = if (i < bt.size) b.substring(posB, bt[i].range.first) else b.substring(posB)
            val textCmp = aText.compareTo(bText, ignoreCase = true)
            if (textCmp != 0) return textCmp
            if (i < at.size) posA = at[i].range.last + 1
            if (i < bt.size) posB = bt[i].range.last + 1
        }
        return a.substring(posA).compareTo(b.substring(posB), ignoreCase = true)
    }

    fun getNativePageFile(index: Int): File? = nativePageFiles.getOrNull(index)

    fun getProcessedPageFile(index: Int): File? {
        val file = File(processedPageRoot, "page_${index}.jpg")
        return file.takeIf { it.exists() && it.isFile && it.length() > 0L }
    }

    @JavascriptInterface
    fun startProcessing(pageIndex: Int, settingsJson: String) {
        if (isProcessing) return
        isProcessing = true
        shouldStop = false
        val settings = gson.fromJson(settingsJson, SettingsData::class.java)
        val file = nativePageFiles.getOrNull(pageIndex)
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            if (file == null || !file.exists()) {
                sendError(pageIndex, "صورة الصفحة غير متوفرة")
                isProcessing = false
                return@launch
            }
            processPage(pageIndex, file, settings)
        }
    }

    @JavascriptInterface
    fun stopProcessing() {
        shouldStop = true
        isProcessing = false
    }

    // يُستدعى من MainActivity.onDestroy لتحرير جلسة ONNX/مفسّر TFLite المُخزَّنين مؤقتاً،
    // ولإلغاء أي تنزيل نماذج لا يزال جارياً (بدون حذف ملفاته الجزئية — تُستأنف لاحقاً).
    fun releaseResources() {
        erasureEngine.close()
        modelManager.release()
    }

    @JavascriptInterface
    fun logFromJS(message: String) {
        Log.d("ComicJS", message)
    }

    /** آخر أسطر السجل الموحّد (ErrorManager) — يفيد لعرض سجل تشخيصي داخل التطبيق عند الحاجة. */
    @JavascriptInterface
    fun getRecentLogs(): String = errorManager.recentLogsText()

    // ================= بند 7: قاموس مصطلحات الكوميكس (Comic Dictionary) =================

    /** يطلب قاموس المصطلحات الخاص بالكوميكس المفتوح حالياً — الرد يصل عبر onComicDictionary(json). */
    @JavascriptInterface
    fun requestComicDictionary() {
        if (nativeComicHash.isBlank()) { sendToWebView("onComicDictionary", "[]"); return }
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            val json = try {
                gson.toJson(db.dictionaryDao().getAll(nativeComicHash).map {
                    mapOf("term" to it.term, "translation" to it.translation)
                })
            } catch (e: Exception) {
                errorManager.handle(e, com.comictrans.error.ErrorCategory.FILE, "فشل تحميل قاموس المصطلحات")
                "[]"
            }
            sendToWebView("onComicDictionary", json)
        }
    }

    /** يضيف/يحدّث مصطلحاً ثابتاً للكوميكس المفتوح حالياً — يُستخدَم في كل طلب ترجمة تالٍ عبر PromptManager. */
    @JavascriptInterface
    fun setDictionaryTerm(term: String, translation: String) {
        if (nativeComicHash.isBlank() || term.isBlank()) return
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            try {
                db.dictionaryDao().upsert(com.comictrans.db.DictionaryEntity(comicHash = nativeComicHash, term = term.trim(), translation = translation.trim()))
            } catch (e: Exception) {
                errorManager.handle(e, com.comictrans.error.ErrorCategory.FILE, "فشل حفظ مصطلح القاموس")
            }
        }
    }

    @JavascriptInterface
    fun deleteDictionaryTerm(term: String) {
        if (nativeComicHash.isBlank()) return
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            try {
                db.dictionaryDao().delete(nativeComicHash, term.trim())
            } catch (e: Exception) {
                errorManager.handle(e, com.comictrans.error.ErrorCategory.FILE, "فشل حذف مصطلح القاموس")
            }
        }
    }

    // ================= خلفية المجتمع (مزامنة ذاكرة الترجمة) =================

    @JavascriptInterface
    fun pushMemorySync(backend: String, config: String) {
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            try {
                if (backend == "local") {
                    val entries = db.translationDao().getAll()
                    val json = gson.toJson(entries)
                    withContext(Dispatchers.Main) {
                        (context as MainActivity).exportJsonToFile(json, "comictrans_memory.json")
                    }
                    return@launch
                }
                val entries = db.translationDao().getAll()
                val json = gson.toJson(entries)
                val result = syncEngine.push(backend, config, json)
                result.fold(
                    onSuccess = { msg -> sendSyncResult(true, msg) },
                    onFailure = { err -> sendSyncResult(false, err.message ?: "فشل غير معروف") }
                )
            } catch (e: Exception) {
                val err = errorManager.handle(e, com.comictrans.error.ErrorCategory.NETWORK, "فشلت مزامنة الذاكرة")
                sendSyncResult(false, err.userMessage)
            }
        }
    }

    @JavascriptInterface
    fun pullMemorySync(backend: String, config: String) {
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            try {
                if (backend == "local") {
                    withContext(Dispatchers.Main) { (context as MainActivity).importJsonFromFile() }
                    return@launch
                }
                val result = syncEngine.pull(backend, config)
                result.fold(
                    onSuccess = { json -> importEntriesAndReport(json) },
                    onFailure = { err -> sendSyncResult(false, err.message ?: "فشل غير معروف") }
                )
            } catch (e: Exception) {
                val err = errorManager.handle(e, com.comictrans.error.ErrorCategory.NETWORK, "فشلت مزامنة الذاكرة")
                sendSyncResult(false, err.userMessage)
            }
        }
    }

    // يُستدعى من MainActivity بعد نجاح/فشل تصدير أو استيراد ملف محلي (Local Sync، بدون إنترنت)
    fun onLocalSyncResult(success: Boolean, message: String, importedJson: String?) {
        (context as MainActivity).lifecycleScope.launch(Dispatchers.IO) {
            if (success && importedJson != null) {
                importEntriesAndReport(importedJson)
            } else {
                sendSyncResult(success, message)
            }
        }
    }

    private suspend fun importEntriesAndReport(json: String) {
        try {
            val type = object : TypeToken<List<TranslationEntity>>() {}.type
            val entries: List<TranslationEntity> = gson.fromJson(json, type) ?: emptyList()
            // نصفّر id عشان autoGenerate يعطي معرفات جديدة محلياً، ونعتمد على unique index
            // (sourceText+sourceLang+targetLang+engine) لمنع التكرار بدل تصادم PK.
            // ملفات JSON قديمة (مُصدَّرة قبل إضافة عمود engine) لا تحوي هذا الحقل إطلاقاً —
            // Gson قد يضعه null فعلياً رغم أن النوع في Kotlin غير قابل للـnull، فنؤمّنه هنا
            // صراحة بدل السماح لصف null بالوصول لعمود NOT NULL في قاعدة البيانات.
            val cleaned = entries.map { it.copy(id = 0, engine = it.engine ?: "unknown") }
            db.translationDao().insertAll(cleaned)
            sendSyncResult(true, "تم استيراد ${cleaned.size} عبارة إلى الذاكرة الذكية بنجاح")
        } catch (e: Exception) {
            sendSyncResult(false, "فشل تفسير البيانات المستوردة: ${e.message}")
        }
    }

    private fun sendSyncResult(success: Boolean, message: String) {
        val json = JSONObject().apply {
            put("success", success)
            put("message", message)
        }
        sendToWebView("onSyncResult", json.toString())
    }

    private suspend fun processPage(pageIndex: Int, imageFile: File, settings: SettingsData) {
        val fingerprint = pageSettingsFingerprint(settings)
        try {
            // Cache (بند 5): تفادي إعادة معالجة نفس الصفحة (OCR+ترجمة+طمس) لو سبق معالجتها
            // بنفس الكوميك ونفس رقم الصفحة ونفس بصمة إعدادات المعالجة بالضبط.
            if (nativeComicHash.isNotBlank()) {
                val cached = db.pageCacheDao().find(nativeComicHash, pageIndex, fingerprint)
                if (cached != null && serveFromCache(pageIndex, cached, settings)) return
            }

            // 1. OCR
            sendStatus(pageIndex, "ocr", 0)
            // *** إصلاح جذري: "لو الملف كبير لا يترجم" ***
            // كان هنا BitmapFactory.decodeFile(path) بدون أي حد لأبعاد الصورة — يفك الترميز
            // بالحجم الأصلي بالكامل في الذاكرة (عرض×ارتفاع×4 بايت لكل بكسل بصيغة ARGB_8888).
            // صفحة كوميك ممسوحة ضوئياً بدقة عالية (300dpi فأعلى) أو صورة webtoon طويلة جداً
            // يسهل أن تتجاوز 4000×6000 بكسل = ~96MB لنسخة واحدة فقط، قبل أي نسخ إضافية
            // (تعزيز/OCR/طمس OpenCV تنشئ نسخاً موازية). هذا يستنزف حد الذاكرة المسموح للتطبيق
            // (عادة 256-512MB) ويرمي OutOfMemoryError — وأحياناً يقتل نظام أندرويد العملية
            // بالكامل مباشرة (low-memory killer) قبل أن يصل الاستثناء لأي catch، فتبدو النتيجة
            // للمستخدم وكأن التطبيق "لا يترجم" بصمت. الحل: decodeBitmapBounded() تفحص الأبعاد
            // أولاً (inJustDecodeBounds) بدون تحميل أي بيانات فعلية، ثم تفك الترميز بعامل تصغير
            // (inSampleSize) يحصر أطول بعد عند MAX_PAGE_DIMENSION — كافٍ جداً لجودة OCR/طمس
            // ممتازة، ويقي من OOM على أي جهاز عملياً.
            val bitmap = decodeBitmapBounded(imageFile) ?: run {
                sendError(pageIndex, "تعذر قراءة صورة الصفحة (قد تكون تالفة أو كبيرة جداً على ذاكرة الجهاز)")
                return
            }

            // تعزيز الصورة قبل OCR (اختياري) — يُستخدم فقط لتحسين دقة القراءة، والصورة
            // الأصلية تبقى كما هي لخطوات الطمس والعرض لاحقاً.
            val enhanceResult = if (settings.enhanceImage) {
                sendStatus(pageIndex, "enhance", 0)
                val r = imageEnhanceEngine.enhance(bitmap, settings.enhanceMethod)
                sendStatus(pageIndex, "enhance", 100)
                r
            } else null
            val ocrBitmap = enhanceResult?.bitmap ?: bitmap
            val enhanceScale = enhanceResult?.scale ?: 1f

            val rawBlocks = when (settings.ocrEngine) {
                "paddle_lite" -> ocrEngine.recognizePaddleLite(ocrBitmap)
                "mlkit" -> ocrEngine.recognizeMLKit(ocrBitmap)
                "tesseract" -> ocrEngine.recognizeTesseract(ocrBitmap)
                "ocrspace" -> ocrEngine.recognizeOCRSpace(ocrBitmap, settings.ocrSpaceKey)
                "cloud" -> ocrEngine.recognizeCloud(ocrBitmap, settings.cloudApiUrl)
                else -> ocrEngine.recognizeMLKit(ocrBitmap)
            }
            // لو التعزيز كبّر أبعاد الصورة (وضع AI)، نرجّع إحداثيات الكتل لمقياس الصورة الأصلية
            val blocks = if (enhanceScale != 1f) {
                rawBlocks.map {
                    it.copy(
                        x = (it.x / enhanceScale).toInt(),
                        y = (it.y / enhanceScale).toInt(),
                        width = (it.width / enhanceScale).toInt(),
                        height = (it.height / enhanceScale).toInt()
                    )
                }
            } else rawBlocks

            // *** إصلاح إضافي: تسريب isProcessing عند التوقف اليدوي ***
            // نقطتا الخروج المبكر هذي (shouldStop=true) كانتا تنسيان تصفير isProcessing —
            // لو المستخدم ضغط "إيقاف" لحظة وصول الكود لإحدى هاتين النقطتين بالضبط، يبقى
            // isProcessing=true للأبد ويرفض startProcessing() أي صفحة جديدة حتى إعادة
            // تشغيل التطبيق. الآن نصفّره بكل نقاط الخروج المبكر بجانب المسارين الأساسيين
            // (النجاح والخطأ) بالأسفل.
            if (shouldStop) { sendStopped(pageIndex); isProcessing = false; return }
            sendStatus(pageIndex, "ocr", 100)

            // بند 7: نظام Prompts + Comic Dictionary — يُبنى مرة واحدة فقط لكل صفحة (وليس
            // لكل فقاعة نص) لتفادي استعلام قاعدة البيانات المتكرر، ويُمرَّر لكل محركات LLM.
            val dictionary = if (nativeComicHash.isNotBlank()) {
                db.dictionaryDao().getAll(nativeComicHash).associate { it.term to it.translation }
            } else emptyMap()
            val targetLangName = if (settings.targetLang == "ar") "Arabic" else settings.targetLang
            val systemPrompt = com.comictrans.engine.PromptManager.buildSystemPrompt(settings.comicType, settings.seriesName, dictionary, targetLangName)

            // 2. Translation (بند 6: سياق الصفحة/Batch لمحركات LLM، مع رجوع تلقائي لفقاعة-فقاعة)
            sendStatus(pageIndex, "translate", 0)
            val warnedThisPage = java.util.concurrent.atomic.AtomicBoolean(false)
            val translatedBlocks = translatePageBlocks(pageIndex, blocks, settings, systemPrompt, warnedThisPage)

            if (shouldStop) { sendStopped(pageIndex); isProcessing = false; return }

            // 3. Erasure
            sendStatus(pageIndex, "erasure", 0)
            val erasureData = when (settings.erasureMode) {
                "fill", "blur" -> {
                    // HTML handles these simple modes
                    translatedBlocks.map { block ->
                        JSONObject().apply {
                            put("x", block.x)
                            put("y", block.y)
                            put("width", block.width)
                            put("height", block.height)
                            put("translatedText", block.translatedText)
                            put("mode", settings.erasureMode)
                            put("type", "block_coords")
                        }
                    }
                }
                "opencv", "ai_lite", "ai_pro" -> {
                    // Native processing returns a Bitmap. Store it in cache and expose only a
                    // local WebView URL, never a multi-megabyte Base64 string over the JS bridge.
                    val processed = erasureEngine.processBitmap(bitmap, translatedBlocks, settings.erasureMode, settings.bubbleAwareErasure)
                    val processedFile = File(processedPageRoot, "page_${pageIndex}.jpg")
                    if (processed != null) {
                        processedFile.outputStream().buffered(128 * 1024).use { out ->
                            if (!processed.compress(android.graphics.Bitmap.CompressFormat.JPEG, 92, out)) {
                                throw IllegalStateException("تعذر حفظ الصورة المعالجة")
                            }
                        }
                        processed.recycle()
                    }
                    val textData = translatedBlocks.map { block ->
                        JSONObject().apply {
                            put("x", block.x)
                            put("y", block.y)
                            put("width", block.width)
                            put("height", block.height)
                            put("translatedText", block.translatedText)
                        }
                    }
                    listOf(JSONObject().apply {
                        put("type", "full_page")
                        put("processedUrl", "https://comic.local/processed/$pageIndex?v=${System.currentTimeMillis()}")
                        put("textBlocks", JSONArray(textData))
                        put("mode", settings.erasureMode)
                    })
                }
                else -> emptyList()
            }
            sendStatus(pageIndex, "erasure", 100)

            // 4. Send result back to HTML
            val result = JSONObject().apply {
                put("pageIndex", pageIndex)
                put("blocks", JSONArray(translatedBlocks.map { gson.toJson(it) }))
                put("erasureData", JSONArray(erasureData))
                put("settings", gson.toJson(settings))
            }

            sendToWebView("onPageReady", result.toString())
            isProcessing = false

            // كتابة نتيجة هذه الصفحة في الكاش (غير حرجة — فشلها لا يوقف عرض الصفحة، لأننا
            // بالفعل أرسلنا onPageReady فوق قبل هذه الخطوة).
            if (nativeComicHash.isNotBlank()) {
                try {
                    val persistedImagePath = if (settings.erasureMode in setOf("opencv", "ai_lite", "ai_pro")) {
                        val persistDir = File(context.filesDir, "page_cache_images").apply { mkdirs() }
                        val persisted = File(persistDir, "${nativeComicHash}_${pageIndex}_${fingerprint.hashCode()}.jpg")
                        val src = File(processedPageRoot, "page_${pageIndex}.jpg")
                        if (src.exists()) { src.copyTo(persisted, overwrite = true); persisted.absolutePath } else null
                    } else null
                    db.pageCacheDao().insert(
                        com.comictrans.db.PageCacheEntity(
                            comicHash = nativeComicHash,
                            pageNumber = pageIndex,
                            settingsFingerprint = fingerprint,
                            blocksJson = result.getJSONArray("blocks").toString(),
                            erasureDataJson = result.getJSONArray("erasureData").toString(),
                            processedImagePath = persistedImagePath
                        )
                    )
                    db.pageCacheDao().trimOld()
                } catch (e: Exception) {
                    errorManager.handle(e, com.comictrans.error.ErrorCategory.FILE, "فشل حفظ الصفحة في الكاش (غير حرج)")
                }
            }

        } catch (e: Throwable) {
            val err = errorManager.handle(e, com.comictrans.error.ErrorCategory.UNKNOWN, "فشلت معالجة الصفحة")
            sendError(pageIndex, err.userMessage)
            isProcessing = false
        }
    }

    // ================= بند 6: ترجمة الصفحة بسياق واحد (Batch) مع رجوع تلقائي لفقاعة-فقاعة =================
    // محركات LLM (gemini/openai/openrouter/custom) تدعم إرسال كل فقاعات الصفحة المعلّقة
    // بطلب واحد (سياق الحوار الكامل بالصفحة → ترجمة أدق من فقاعة بمعزل عن البقية، وطلب
    // شبكي واحد بدل N). محركات الترجمة التقليدية (mlkit/google/deepl) لا تدعم System
    // Prompt/سياقاً أصلاً فتبقى دائماً على المسار فقاعة-فقاعة. لو فشل الـbatch (استثناء
    // شبكة، أو رد لا يطابق تنسيق JSON المطلوب، أو عدد عناصر مختلف عن عدد النصوص المُرسَلة)
    // نرجع تلقائياً لنفس منطق فقاعة-فقاعة القديم (متوازي عبر Semaphore) بدل فشل الصفحة كاملة.
    private val BATCH_CAPABLE_ENGINES = setOf("gemini", "openai", "openrouter", "custom")

    private suspend fun translatePageBlocks(
        pageIndex: Int,
        blocks: List<BlockData>,
        settings: SettingsData,
        systemPrompt: String,
        warnedThisPage: java.util.concurrent.atomic.AtomicBoolean
    ): List<BlockData> {
        if (blocks.isEmpty()) return blocks

        data class Pending(val index: Int, val block: BlockData)
        // ذاكرة الترجمة أولاً (بحث تسلسلي — قراءات محلية من Room سريعة جداً، لا تحتاج توازي)
        // — نفس القيد القديم: مقيَّدة بنفس محرك الترجمة الحالي حتى لا تُستخدَم ترجمة قديمة
        // من محرك مختلف بصمت بدل استدعاء المحرك المختار فعلياً الآن.
        val resolved = java.util.concurrent.ConcurrentHashMap<Int, String>()
        val pending = ArrayList<Pending>()
        blocks.forEachIndexed { idx, block ->
            val memoryResult = if (settings.useMemory) {
                db.translationDao().findExact(block.text.trim(), settings.sourceLang, settings.targetLang, settings.translateEngine)
            } else null
            if (memoryResult != null) resolved[idx] = memoryResult.translatedText else pending.add(Pending(idx, block))
        }

        if (pending.isEmpty()) {
            sendStatus(pageIndex, "translate", 100)
            return blocks.mapIndexed { idx, block -> block.copy(translatedText = resolved[idx] ?: block.text) }
        }

        // Batch حقيقي — فقط لمحركات LLM ولو فيه أكثر من فقاعة معلّقة واحدة (batch لفقاعة
        // وحيدة لا فائدة منه، ويكفي المسار الفردي).
        var batchSucceeded = false
        if (settings.translateEngine in BATCH_CAPABLE_ENGINES && pending.size > 1) {
            try {
                sendStatus(pageIndex, "translate", 15)
                val texts = pending.map { it.block.text }
                val results = when (settings.translateEngine) {
                    "gemini" -> translateEngine.translateBatchGemini(texts, settings.targetLang, systemPrompt, settings.geminiKey, settings.geminiModel)
                    "openai" -> translateEngine.translateBatchOpenAIStyle(texts, settings.targetLang, systemPrompt, "https://api.openai.com/v1/chat/completions", settings.openaiKey, settings.openaiModel)
                    "openrouter" -> translateEngine.translateBatchOpenAIStyle(texts, settings.targetLang, systemPrompt, "https://openrouter.ai/api/v1/chat/completions", settings.openrouterKey, settings.openrouterModel, mapOf("X-Title" to "Comic Translator"))
                    "custom" -> {
                        if (settings.customApiUrl.isBlank()) throw IllegalArgumentException("Local LLM: رابط API فارغ")
                        translateEngine.translateBatchOpenAIStyle(texts, settings.targetLang, systemPrompt, settings.customApiUrl, settings.customApiKey, settings.customModel)
                    }
                    else -> throw IllegalStateException("محرك غير مدعوم لـbatch")
                }
                pending.forEachIndexed { i, p ->
                    resolved[p.index] = results[i]
                    if (settings.useMemory && results[i].isNotBlank()) {
                        db.translationDao().insert(
                            com.comictrans.db.TranslationEntity(
                                sourceText = p.block.text.trim(), translatedText = results[i].trim(),
                                sourceLang = settings.sourceLang, targetLang = settings.targetLang, engine = settings.translateEngine
                            )
                        )
                    }
                }
                batchSucceeded = true
                sendStatus(pageIndex, "translate", 100)
            } catch (e: Throwable) {
                Log.w("ComicApp", "فشل batch الترجمة (${settings.translateEngine}) — رجوع لفقاعة-فقاعة: ${e.message}")
            }
        }

        // المسار الفردي (فقاعة-فقاعة، متوازٍ عبر Semaphore) — إما لأن المحرك أصلاً لا يدعم
        // batch، أو فقاعة معلّقة واحدة فقط، أو الـbatch فشل فعلياً بالأعلى.
        if (!batchSucceeded) {
            val translateSemaphore = Semaphore(5)
            val completedCount = java.util.concurrent.atomic.AtomicInteger(0)
            coroutineScope {
                pending.map { p ->
                    async(Dispatchers.IO) {
                        if (shouldStop) return@async
                        val translated = try {
                            translateSemaphore.withPermit {
                                when (settings.translateEngine) {
                                    "mlkit" -> translateEngine.translateMLKit(p.block.text, settings.sourceLang, settings.targetLang)
                                    "google" -> translateEngine.translateGoogle(p.block.text, settings.sourceLang, settings.targetLang)
                                    "gemini" -> translateEngine.translateGemini(p.block.text, settings.sourceLang, settings.targetLang, settings.geminiKey, settings.geminiModel, systemPrompt)
                                    "openai" -> translateEngine.translateOpenAI(p.block.text, settings.sourceLang, settings.targetLang, settings.openaiKey, settings.openaiModel, systemPrompt)
                                    "openrouter" -> translateEngine.translateOpenRouter(p.block.text, settings.sourceLang, settings.targetLang, settings.openrouterKey, settings.openrouterModel, systemPrompt)
                                    "deepl" -> translateEngine.translateDeepL(p.block.text, settings.sourceLang, settings.targetLang, settings.deeplKey)
                                    "custom" -> translateEngine.translateCustom(p.block.text, settings.sourceLang, settings.targetLang, settings.customApiUrl, settings.customApiKey, settings.customModel, systemPrompt)
                                    else -> translateEngine.translateGoogle(p.block.text, settings.sourceLang, settings.targetLang)
                                }
                            }
                        } catch (e: Throwable) {
                            Log.e("ComicApp", "فشلت الترجمة (${settings.translateEngine})", e)
                            if (warnedThisPage.compareAndSet(false, true)) {
                                sendWarning(pageIndex, "⚠️ فشلت الترجمة (${settings.translateEngine}): ${e.message ?: "خطأ غير معروف"} — سيُعرض النص الأصلي")
                            }
                            p.block.text // رجوع للنص الأصلي كحل احتياطي بدل إيقاف الصفحة كاملة
                        }

                        if (settings.useMemory && translated.isNotBlank()) {
                            db.translationDao().insert(
                                com.comictrans.db.TranslationEntity(
                                    sourceText = p.block.text.trim(), translatedText = translated.trim(),
                                    sourceLang = settings.sourceLang, targetLang = settings.targetLang, engine = settings.translateEngine
                                )
                            )
                        }

                        resolved[p.index] = translated
                        val done = completedCount.incrementAndGet()
                        sendStatus(pageIndex, "translate", (done * 100 / pending.size.coerceAtLeast(1)))
                    }
                }.forEach { it.await() }
            }
        }

        return blocks.mapIndexed { idx, block -> block.copy(translatedText = resolved[idx] ?: block.text) }
    }

    /** بصمة إعدادات المعالجة — أي فرق فيها يعني أن نتيجة الكاش القديمة لم تعد صالحة لهذه الصفحة. */
    private fun pageSettingsFingerprint(settings: SettingsData): String =
        "${settings.ocrEngine}|${settings.translateEngine}|${settings.erasureMode}|" +
            "${settings.sourceLang}|${settings.targetLang}|${settings.enhanceImage}|${settings.enhanceMethod}|" +
            "${settings.comicType}|${settings.seriesName}|${settings.bubbleAwareErasure}"

    /**
     * يحاول تلبية طلب صفحة كاملاً من الكاش بدل أي OCR/ترجمة/طمس فعلي. يرجع false (بدون
     * إرسال أي حدث للواجهة) لو الملف المُخزَّن مفقود من القرص — عندها يكمل processPage
     * المسار العادي كأن الكاش غير موجود أصلاً.
     */
    private fun serveFromCache(pageIndex: Int, cached: com.comictrans.db.PageCacheEntity, settings: SettingsData): Boolean {
        return try {
            if (cached.processedImagePath != null) {
                val src = File(cached.processedImagePath)
                if (!src.exists()) return false
                src.copyTo(File(processedPageRoot, "page_${pageIndex}.jpg"), overwrite = true)
            }
            sendStatus(pageIndex, "ocr", 100)
            sendStatus(pageIndex, "translate", 100)
            sendStatus(pageIndex, "erasure", 100)
            val result = JSONObject().apply {
                put("pageIndex", pageIndex)
                put("blocks", JSONArray(cached.blocksJson))
                put("erasureData", JSONArray(cached.erasureDataJson))
                put("settings", gson.toJson(settings))
            }
            sendToWebView("onPageReady", result.toString())
            isProcessing = false
            true
        } catch (e: Exception) {
            errorManager.handle(e, com.comictrans.error.ErrorCategory.FILE, "فشل استرجاع الصفحة من الكاش")
            false
        }
    }

    // أقصى بعد (عرض أو ارتفاع) مسموح لصورة الصفحة بعد فك الترميز. رقم كبير بما يكفي للحفاظ
    // على نص واضح للـOCR والطمس، وصغير بما يكفي لتفادي OutOfMemoryError على أي جهاز.
    private val MAX_PAGE_DIMENSION = 3000

    // *** إصلاح: احترام دوران EXIF قبل تمرير الصورة لـ OCR ***
    // لو الصفحة صورة التُقطت بكاميرا هاتف (بعض تطبيقات المسح الضوئي تحفظ EXIF بدل تدوير
    // البكسلات فعلياً)، BitmapFactory.decodeFile() يتجاهل هذا الوسم تماماً ويرجع البكسلات
    // كما هي بالملف — أي أن الصورة قد تصل لمحرك OCR مقلوبة/مائلة 90/180/270 درجة رغم أنها
    // تظهر معتدلة بصرياً في أي عارض يحترم EXIF (المتصفح/معرض الصور). محرك OCR (نص بزاوية
    // خاطئة) يخطئ بأحرف/كلمات كثيرة بدون أي فشل واضح — بالضبط عرض "بعض الكلمات تُقرأ غلط".
    private fun exifRotationDegrees(file: File): Int {
        return try {
            val exif = androidx.exifinterface.media.ExifInterface(file.absolutePath)
            when (exif.getAttributeInt(
                androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION,
                androidx.exifinterface.media.ExifInterface.ORIENTATION_NORMAL
            )) {
                androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90
                androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180
                androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
        } catch (e: Exception) {
            0 // لا EXIF أو فشل قراءته — الغالبية العظمى من صفحات الكوميك بدون هذا الوسم أصلاً
        }
    }

    private fun decodeBitmapBounded(file: File): android.graphics.Bitmap? {
        return try {
            val boundsOpts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeFile(file.absolutePath, boundsOpts)
            val (w, h) = boundsOpts.outWidth to boundsOpts.outHeight
            if (w <= 0 || h <= 0) return null // ملف تالف أو غير صورة فعلياً

            var inSampleSize = 1
            if (w > MAX_PAGE_DIMENSION || h > MAX_PAGE_DIMENSION) {
                val halfW = w / 2
                val halfH = h / 2
                while ((halfW / inSampleSize) >= MAX_PAGE_DIMENSION || (halfH / inSampleSize) >= MAX_PAGE_DIMENSION) {
                    inSampleSize *= 2
                }
            }

            val decodeOpts = android.graphics.BitmapFactory.Options().apply {
                this.inSampleSize = inSampleSize
                inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
            }
            var decoded = android.graphics.BitmapFactory.decodeFile(file.absolutePath, decodeOpts)
            if (decoded != null && inSampleSize > 1) {
                Log.d("ComicApp", "صفحة كبيرة (${w}x$h) — تم تصغيرها لـ ${decoded.width}x${decoded.height} (inSampleSize=$inSampleSize) لتفادي نفاد الذاكرة")
            }
            val rotation = if (decoded != null) exifRotationDegrees(file) else 0
            if (decoded != null && rotation != 0) {
                val matrix = android.graphics.Matrix().apply { postRotate(rotation.toFloat()) }
                val rotated = android.graphics.Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
                if (rotated != decoded) decoded.recycle()
                Log.d("ComicApp", "تم تصحيح دوران EXIF للصفحة ($rotation°)")
                decoded = rotated
            }
            decoded
        } catch (e: OutOfMemoryError) {
            // احتياط أخير: لو حتى بعد التصغير الأولي حصل OOM (جهاز ضعيف جداً بالذاكرة)،
            // نحاول مرة إضافية بعامل تصغير أكبر بدل الفشل الكامل.
            Log.e("ComicApp", "OOM أثناء فك ترميز الصورة — إعادة محاولة بحجم أصغر", e)
            try {
                val decodeOpts = android.graphics.BitmapFactory.Options().apply {
                    inSampleSize = 8
                    inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
                }
                android.graphics.BitmapFactory.decodeFile(file.absolutePath, decodeOpts)
            } catch (e2: Throwable) {
                Log.e("ComicApp", "فشلت المحاولة الاحتياطية أيضاً", e2)
                null
            }
        } catch (e: Throwable) {
            errorManager.handle(e, com.comictrans.error.ErrorCategory.FILE, "فشل فك ترميز صورة الصفحة")
            null
        }
    }

    private fun sendStatus(pageIndex: Int, stage: String, progress: Int) {
        val json = JSONObject().apply {
            put("pageIndex", pageIndex)
            put("stage", stage)
            put("progress", progress)
        }
        sendToWebView("onStatusUpdate", json.toString())
    }

    private fun sendError(pageIndex: Int, message: String) {
        val json = JSONObject().apply {
            put("pageIndex", pageIndex)
            put("error", message)
        }
        sendToWebView("onError", json.toString())
    }

    private fun sendWarning(pageIndex: Int, message: String) {
        val json = JSONObject().apply {
            put("pageIndex", pageIndex)
            put("warning", message)
        }
        sendToWebView("onWarning", json.toString())
    }

    private fun sendStopped(pageIndex: Int) {
        val json = JSONObject().apply {
            put("pageIndex", pageIndex)
            put("stopped", true)
        }
        sendToWebView("onStopped", json.toString())
    }

    private fun sendToWebView(functionName: String, data: String) {
        (context as MainActivity).runOnUiThread {
            // JSONObject.quote() ينتج نص JS/JSON آمن (يهرب الاقتباسات والأسطر الجديدة وغيرها)
            // بدل تضمين data مباشرة داخل اقتباس أحادي، لتفادي انكسار الاستدعاء لو النص يحتوي على '
            val safeData = JSONObject.quote(data)
            webView.evaluateJavascript("window.$functionName($safeData)", null)
        }
    }
}
