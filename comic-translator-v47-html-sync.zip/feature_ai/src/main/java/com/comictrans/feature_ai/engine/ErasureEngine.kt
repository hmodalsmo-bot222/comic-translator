package com.comictrans.feature_ai.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.util.Log
import com.comictrans.engine.ModelManager
import com.comictrans.engine.OpenCVStatus
import com.comictrans.engine.contracts.IErasureEngine
import com.comictrans.model.BlockData
import org.json.JSONObject
import org.opencv.android.Utils
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo
import org.tensorflow.lite.Interpreter
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

// حجم مُدخل نموذج LaMa (ONNX من Carve/LaMa-ONNX، ونفترض نفس المقاس لـ TFLite ما لم
// يوفّر المستخدم نموذجاً بمقاس مختلف — راجع ModelManager.kt لتفاصيل مصدر النموذج).
private const val MODEL_INPUT_SIZE = 512

class ErasureEngine(
    private val context: Context,
    private val modelManager: ModelManager
) : IErasureEngine {

    private val TAG = "ErasureEngine"

    // تحميل نموذج AI Pro (ONNX)/AI Lite (TFLite) من الملف وتحسين الرسم البياني (graph
    // optimization) عملية مكلفة تاخذ وقتاً حقيقياً — كان الكود قبلاً يعيد هذا التحميل من
    // جديد مع كل صفحة (حتى لو نفس الملف)، وهذا كان السبب الأساسي لبطء وضع AI Pro. نحتفظ
    // هنا بجلسة/مفسّر واحد مُحمَّل مسبقاً، ونعيد استخدامه طالما مسار ملف النموذج نفسه لم
    // يتغيّر (يتغيّر فقط لو المستخدم حمّل نسخة نموذج مختلفة).
    private var cachedOnnxEnv: OrtEnvironment? = null
    private var cachedOnnxSession: OrtSession? = null
    private var cachedOnnxModelPath: String? = null

    private var cachedTfliteInterpreter: Interpreter? = null
    private var cachedTfliteModelPath: String? = null

    private fun getOrCreateOnnxSession(modelPath: String): Pair<OrtEnvironment, OrtSession> {
        if (cachedOnnxSession != null && cachedOnnxModelPath == modelPath) {
            return cachedOnnxEnv!! to cachedOnnxSession!!
        }
        try { cachedOnnxSession?.close() } catch (_: Exception) {}
        val env = cachedOnnxEnv ?: OrtEnvironment.getEnvironment().also { cachedOnnxEnv = it }
        val options = OrtSession.SessionOptions().apply {
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceAtLeast(1))
            // نموذج LaMa (~208MB) يحتوي طبقات Fourier ثقيلة الحساب، وتشغيله على CPU فقط لكل
            // فقاعة نص على حدة (512×512 لكل استدعاء) هو السبب الحقيقي لبطء "AI Pro" — وليس
            // خطأً في التخزين المؤقت (كان مُصلَحاً مسبقاً، انظر التعليق أعلى الكلاس). نحاول
            // تفعيل NNAPI (تسريع عتادي عبر DSP/GPU/NPU متى توفّر على الجهاز) وإلا نستمر على
            // CPU بصمت — بعض العمليات (خصوصاً FFT/irfft المستخدمة في LaMa) قد لا يدعمها
            // NNAPI فيرجع ONNX Runtime تلقائياً لـ CPU لتلك العقد فقط دون فشل كامل.
            try {
                addNnapi()
                Log.d(TAG, "AI Pro: تم تفعيل تسريع NNAPI (لو الجهاز يدعمه)")
            } catch (e: Throwable) {
                Log.w(TAG, "AI Pro: NNAPI غير متاح على هذا الجهاز — استمرار على CPU فقط", e)
            }
        }
        val session = env.createSession(modelPath, options)
        cachedOnnxSession = session
        cachedOnnxModelPath = modelPath
        return env to session
    }

    private fun getOrCreateTfliteInterpreter(file: File): Interpreter {
        if (cachedTfliteInterpreter != null && cachedTfliteModelPath == file.absolutePath) {
            return cachedTfliteInterpreter!!
        }
        try { cachedTfliteInterpreter?.close() } catch (_: Exception) {}
        val buffer = loadModelFile(file)
        val threads = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        // 🔍 (2026-08-15) طلب المستخدم صراحة تفعيل تسريع GPU/NNAPI لـTFLite — سلسلة محاولات
        // آمنة: GPU Delegate أولاً (الأسرع لو مدعوم فعلياً على الجهاز)، وإلا NNAPI (DSP/NPU
        // عبر أندرويد)، وإلا CPU متعدد الخيوط فقط (السلوك القديم بالضبط). كل مستوى مغلَّف
        // بـtry/catch منفصل — فشل GPU لا يمنع محاولة NNAPI، وفشل الاثنين يرجع لـCPU بأمان
        // تام، بلا انهيار إطلاقاً. ⚠️ لم يُختبَر فعلياً أي من المستويين (GPU/NNAPI) على جهاز
        // حقيقي — النموذج (LaMa) يحتوي عمليات FFT/irfft قد لا يدعمها GPU Delegate كلياً؛
        // TFLite الحديث يدعم "partial delegation" (يشغّل العقد المدعومة على GPU والباقي على
        // CPU تلقائياً بنفس الجلسة) فمن المفترض ألا يفشل بالكامل حتى لو دعم جزئي فقط، لكن
        // هذا افتراض نظري من توثيق TFLite العام، غير مؤكَّد لهذا النموذج تحديداً.
        val interpreter = try {
            val gpuDelegate = org.tensorflow.lite.gpu.GpuDelegate()
            val opts = Interpreter.Options().apply { addDelegate(gpuDelegate); setNumThreads(threads) }
            Interpreter(buffer, opts).also { Log.d(TAG, "AI Lite: تم تفعيل GPU Delegate") }
        } catch (e: Throwable) {
            Log.w(TAG, "AI Lite: فشل تفعيل GPU Delegate — محاولة NNAPI", e)
            try {
                val opts = Interpreter.Options().apply { setUseNNAPI(true); setNumThreads(threads) }
                Interpreter(buffer, opts).also { Log.d(TAG, "AI Lite: تم تفعيل NNAPI") }
            } catch (e2: Throwable) {
                Log.w(TAG, "AI Lite: فشل تفعيل NNAPI أيضاً — استمرار على CPU متعدد الخيوط فقط", e2)
                val opts = Interpreter.Options().apply { setNumThreads(threads) }
                Interpreter(buffer, opts)
            }
        }
        cachedTfliteInterpreter = interpreter
        cachedTfliteModelPath = file.absolutePath
        return interpreter
    }

    // يُستدعى عند إغلاق التطبيق لتحرير الجلسة/المفسّر المُخزَّنين مؤقتاً (native resources).
    override fun close() {
        try { cachedOnnxSession?.close() } catch (_: Exception) {}
        try { cachedTfliteInterpreter?.close() } catch (_: Exception) {}
        cachedOnnxSession = null
        cachedTfliteInterpreter = null
    }

    // OpenCV Inpaint — works now if OpenCV is loaded
    // بند 3 (كشف فقاعات الكلام): بارامتر [bubbleAware] جديد، افتراضي false — لا يغيّر أي
    // سلوك قديم إطلاقاً ما لم يُفعَّله المتصل صراحة (راجع AppInterface/SettingsData
    // bubbleAwareErasure). لو true، نحاول قناع طمس أدق عبر BubbleDetector.buildBubbleMask()
    // بدل مستطيلات النص الخام؛ أي بلوك يفشل كشف فقاعته فردياً يرجع لمستطيل خام تلقائياً
    // (راجع BubbleDetector.buildBubbleMask نفسها)، فلا يمكن لهذا الخيار أن "يفشل" الصفحة
    // كاملة — أسوأ حالة هي نفس نتيجة false تماماً بلوك ببلوك.
    fun inpaintOpenCV(bitmap: Bitmap, blocks: List<BlockData>, bubbleAware: Boolean = false): Bitmap {
        if (!OpenCVStatus.isAvailable) {
            Log.w(TAG, "OpenCV غير محمّلة على هذا الجهاز — رجوع لطمس بسيط (مربع أبيض)")
            return fallbackErase(bitmap, blocks)
        }
        return try {
            // Convert Bitmap to Mat — Utils.bitmapToMat() على بتمابات ARGB_8888 ينتج دائماً
            // Mat بـ4 قنوات (CV_8UC4 / RGBA)، بما فيها قناة الشفافية.
            val srcRgba = Mat()
            Utils.bitmapToMat(bitmap, srcRgba)

            // *** الإصلاح الجذري لتعليق/انهيار "OpenCV Inpaint" ***
            // Photo.inpaint() في OpenCV يقبل فقط CV_8UC1 (رمادي) أو CV_8UC3 (RGB/BGR) —
            // وهذا موثّق صراحة في مصدر OpenCV (modules/photo/src/inpaint.cpp:
            // CV_Assert(src.type() == CV_8UC1 || src.type() == CV_8UC3)). كان الكود هنا يمرر
            // srcMat بـ4 قنوات مباشرة (ناتج Utils.bitmapToMat) بدون تحويل. فشل CV_Assert هذا
            // يحصل داخل الكود الأصلي (native) عبر JNI، وفي حزمة OpenCV الرسمية لأندرويد لا
            // يتحول دائماً لاستثناء Kotlin قابل للالتقاط بـ try/catch — غالباً يظهر كتجمّد
            // مؤقت (native abort) ثم إنهاء كامل للعملية (crash) بدل استثناء عادي. هذا هو
          // السبب الحقيقي وراء "OpenCV Inpaint يعلق ويخرج التطبيق"، وهو نفس السبب اللي كان
            // يفشّل أوضاع AI Lite/AI Pro أيضاً (يرجعان لـ inpaintOpenCV عند أي خطأ). ملاحظة:
            // ImageEnhanceEngine.kt كان يحوّل RGBA→RGB بشكل صحيح قبل معالجات OpenCV الأخرى —
            // هذا التحويل كان ناقصاً هنا تحديداً في مسار الطمس (inpaint).
            val srcRgb = Mat()
            Imgproc.cvtColor(srcRgba, srcRgb, Imgproc.COLOR_RGBA2RGB)

            // Create mask (black image, white where text is) — بنفس مقاس الصورة بـ3 قنوات.
            // بند 3: لو bubbleAware=true نحاول قناع دقيق بحدود الفقاعة الفعلية، وإلا (أو لو
            // فشل الكشف بالكامل بشكل غير متوقَّع) نرجع لمنطق المستطيلات الخام القديم بالضبط.
            val maskMat = if (bubbleAware) {
                try {
                    BubbleDetector.buildBubbleMask(bitmap, blocks)
                } catch (e: Throwable) {
                    Log.w(TAG, "فشل بناء قناع فقاعات الكلام — رجوع لقناع المستطيلات الخام", e)
                    buildRectMask(srcRgb, bitmap, blocks)
                }
            } else {
                buildRectMask(srcRgb, bitmap, blocks)
            }

            // Inpaint using Telea algorithm (يتطلب الآن CV_8UC3 فقط — تم التأكد أعلاه)
            val resultRgb = Mat()
            Photo.inpaint(srcRgb, maskMat, resultRgb, 3.0, Photo.INPAINT_TELEA)

            // نعيد قناة الشفافية قبل التحويل النهائي لـ Bitmap (ARGB_8888)
            val resultRgba = Mat()
            Imgproc.cvtColor(resultRgb, resultRgba, Imgproc.COLOR_RGB2RGBA)

            // Convert back to Bitmap
            val resultBitmap = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(resultRgba, resultBitmap)

            // Release mats
            srcRgba.release()
            srcRgb.release()
            maskMat.release()
            resultRgb.release()
            resultRgba.release()

            resultBitmap
        } catch (e: Throwable) {
            Log.e(TAG, "OpenCV inpaint failed", e)
            // Fallback: return original with white boxes
            fallbackErase(bitmap, blocks)
        }
    }

    /** قناع المستطيلات الخام القديم (السلوك الافتراضي قبل بند 3، ولا يزال الافتراضي الآن). */
    private fun buildRectMask(srcRgb: Mat, bitmap: Bitmap, blocks: List<BlockData>): Mat {
        val maskMat = Mat.zeros(srcRgb.size(), CvType.CV_8UC1)
        for (block in blocks) {
            val x1 = block.x.coerceIn(0, bitmap.width - 1)
            val y1 = block.y.coerceIn(0, bitmap.height - 1)
            val x2 = (block.x + block.width).coerceIn(0, bitmap.width)
            val y2 = (block.y + block.height).coerceIn(0, bitmap.height)
            Imgproc.rectangle(
                maskMat,
                Point(x1.toDouble(), y1.toDouble()),
                Point(x2.toDouble(), y2.toDouble()),
                Scalar(255.0), // White = inpaint this area
                -1 // Filled
            )
        }
        return maskMat
    }

    // AI Lite (TFLite) — يتطلب نموذج .tflite محمّل مسبقاً عبر قائمة النماذج (ModelManager).
    // نفترض نفس بنية مُدخلات/مُخرجات LaMa الموثّقة (صورة + قناع → صورة)، وهي البنية الشائعة
    // لنماذج inpainting المُصدَّرة لـ TFLite. لو المستخدم زوّد نموذجاً ببنية مختلفة، سيفشل
    // التنفيذ بخطأ واضح ونرجع تلقائياً لـ OpenCV بدل تعطّل التطبيق.
    fun inpaintTFLite(bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val model = modelManager.availableModels.find { it.id == "ai_lite" }
        if (model == null || !modelManager.isDownloaded(model)) {
            Log.w(TAG, "AI Lite model not downloaded — falling back to OpenCV")
            return inpaintOpenCV(bitmap, blocks)
        }
        return try {
            val interpreter = getOrCreateTfliteInterpreter(modelManager.modelFile(model))
            inpaintPerBlockTFLite(interpreter, bitmap, blocks)
        } catch (e: Throwable) {
            Log.e(TAG, "TFLite inpaint failed — falling back to OpenCV", e)
            inpaintOpenCV(bitmap, blocks)
        }
    }

    // AI Pro (ONNX) — يتطلب نموذج .onnx محمّل مسبقاً (افتراضياً LaMa من Carve/LaMa-ONNX،
    // انظر ModelManager.kt). المُدخلات: image float32[N,3,512,512] RGB مقسومة على 255،
    // mask float32[N,1,512,512] (1=امسح النص، 0=أبقِ). المُخرج: صورة RGB جاهزة [0..255].
    // 🔍 (2026-08-15) طلب المستخدم صراحة: معالجة الصفحة كاملة "دفعة" (batch) واحدة بدل
    // فقاعة فقاعة — كان الكود القديم يستدعي session.run() منفصلة لكل بلوك (N استدعاء كامل
    // لنموذج LaMa الثقيل، أبطأ بكثير من استدعاء واحد بمحور دفعة N). الآن: كل صناديق الصفحة
    // (أو دفعات فرعية من MAX_BATCH كحد أقصى، لتفادي استهلاك ذاكرة مفرط بصفحات فيها فقاعات
    // كثيرة جداً) تُبنى كـtensor واحد بمحور دفعة N، وسEssion.run() تُستدعى مرة واحدة فقط لكل
    // دفعة فرعية بدل مرة لكل بلوك — تسريع حقيقي بتقليل عدد استدعاءات الجلسة نفسها (كل
    // استدعاء له تكلفة ثابتة إضافية غير قليلة على نموذج بحجم LaMa، بصرف النظر عن حجم الدُفعة).
    private val MAX_ONNX_BATCH = 8

    fun inpaintONNX(bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val model = modelManager.availableModels.find { it.id == "ai_pro" }
        if (model == null || !modelManager.isDownloaded(model)) {
            Log.w(TAG, "AI Pro model not downloaded — falling back to OpenCV")
            return inpaintOpenCV(bitmap, blocks)
        }
        return try {
            val (env, session) = getOrCreateOnnxSession(modelManager.modelFile(model).absolutePath)
            inpaintBatchONNX(env, session, bitmap, blocks)
        } catch (e: Throwable) {
            Log.e(TAG, "ONNX inpaint failed — falling back to OpenCV", e)
            inpaintOpenCV(bitmap, blocks)
        }
    }

    private fun inpaintBatchONNX(env: OrtEnvironment, session: OrtSession, bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val result = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        if (blocks.isEmpty()) return result
        val canvas = Canvas(result)
        val size = MODEL_INPUT_SIZE
        for (chunk in blocks.chunked(MAX_ONNX_BATCH)) {
            try {
                val n = chunk.size
                val crops = chunk.map { paddedCropRect(it, bitmap.width, bitmap.height) }
                val plane = size * size
                val imgArr = FloatArray(n * 3 * plane)
                val maskArr = FloatArray(n * plane)
                for (idx in 0 until n) {
                    val singleImg = cropToNCHWFloatArray(bitmap, crops[idx], size)
                    val singleMask = blockMaskFloatArray(chunk[idx], crops[idx], size)
                    System.arraycopy(singleImg, 0, imgArr, idx * 3 * plane, 3 * plane)
                    System.arraycopy(singleMask, 0, maskArr, idx * plane, plane)
                }
                val imgTensor = OnnxTensor.createTensor(env, FloatBufferOf(imgArr), longArrayOf(n.toLong(), 3, size.toLong(), size.toLong()))
                val maskTensor = OnnxTensor.createTensor(env, FloatBufferOf(maskArr), longArrayOf(n.toLong(), 1, size.toLong(), size.toLong()))
                try {
                    val inputs = mapOf("image" to imgTensor, "mask" to maskTensor)
                    session.run(inputs).use { results ->
                        val outValue = results.get("output").orElseGet { results.iterator().next().value }
                        val outBatch = outValue.value as Array<*> // نتوقع [N,3,S,S]
                        for (idx in 0 until n) {
                            val flatOut = flattenSingleCHW(outBatch[idx] as Array<*>, size)
                            val outBmp = outputArrayToBitmap(flatOut, size)
                            val crop = crops[idx]
                            val scaledBack = Bitmap.createScaledBitmap(outBmp, crop.width(), crop.height(), true)
                            canvas.drawBitmap(scaledBack, crop.left.toFloat(), crop.top.toFloat(), null)
                            outBmp.recycle(); scaledBack.recycle()
                        }
                    }
                } finally {
                    imgTensor.close(); maskTensor.close()
                }
            } catch (e: Throwable) {
                // 🔍 شبكة أمان: لو فشل الاستدلال الدُفعي لهذه الدفعة الفرعية تحديداً (مثلاً
                // النموذج لا يدعم محور دفعة >1 فعلياً رغم التوقع)، نرجع لمعالجة بلوك ببلوك
                // **فقط لهذه الدفعة الفرعية**، لا للصفحة كاملة — يحافظ على الجودة/الصحة
                // حتى لو الدُفعة فشلت، بدل السقوط الكامل لـOpenCV.
                Log.e(TAG, "ONNX batch inference failed for a sub-batch — falling back to per-block for it", e)
                for (block in chunk) {
                    try {
                        val crop = paddedCropRect(block, bitmap.width, bitmap.height)
                        val imgArr = cropToNCHWFloatArray(bitmap, crop, size)
                        val maskArr = blockMaskFloatArray(block, crop, size)
                        val imgTensor = OnnxTensor.createTensor(env, FloatBufferOf(imgArr), longArrayOf(1, 3, size.toLong(), size.toLong()))
                        val maskTensor = OnnxTensor.createTensor(env, FloatBufferOf(maskArr), longArrayOf(1, 1, size.toLong(), size.toLong()))
                        try {
                            session.run(mapOf("image" to imgTensor, "mask" to maskTensor)).use { results ->
                                val outValue = results.get("output").orElseGet { results.iterator().next().value }
                                val flatOut = flattenOnnxOutput(outValue.value as Array<*>, size)
                                val outBmp = outputArrayToBitmap(flatOut, size)
                                val scaledBack = Bitmap.createScaledBitmap(outBmp, crop.width(), crop.height(), true)
                                canvas.drawBitmap(scaledBack, crop.left.toFloat(), crop.top.toFloat(), null)
                                outBmp.recycle(); scaledBack.recycle()
                            }
                        } finally { imgTensor.close(); maskTensor.close() }
                    } catch (e2: Throwable) {
                        Log.e(TAG, "ONNX per-block fallback also failed — using border-color fallback", e2)
                        val paint = Paint().apply { color = averageBorderColor(bitmap, block) }
                        canvas.drawRect(Rect(block.x, block.y, block.x + block.width, block.y + block.height), paint)
                    }
                }
            }
        }
        return result
    }

    // ============ منطق مشترك: نقصّ حول كل فقاعة نص (مع هامش سياق)، نصغّر القصاصة
    // لمقاس مُدخل النموذج، نشغّل الاستدلال، ثم نعيد النتيجة لمقاسها الأصلي ونلصقها
    // في مكانها بالصورة الكاملة — بدل تصغير الصفحة كاملة لـ 512×512 (جودة أفضل بكثير
    // لصفحة كومك كاملة الدقة، وأقرب لكيفية عمل تطبيقات الترجمة الاحترافية) ============

    private fun paddedCropRect(block: BlockData, bmpW: Int, bmpH: Int): Rect {
        val padX = (block.width * 0.4f).toInt().coerceAtLeast(16)
        val padY = (block.height * 0.4f).toInt().coerceAtLeast(16)
        val x1 = (block.x - padX).coerceIn(0, bmpW - 1)
        val y1 = (block.y - padY).coerceIn(0, bmpH - 1)
        val x2 = (block.x + block.width + padX).coerceIn(x1 + 1, bmpW)
        val y2 = (block.y + block.height + padY).coerceIn(y1 + 1, bmpH)
        return Rect(x1, y1, x2, y2)
    }

    // مصفوفة float NCHW [1,3,S,S] RGB/255 من قصاصة مُصغّرة لمقاس النموذج
    private fun cropToNCHWFloatArray(bitmap: Bitmap, crop: Rect, size: Int): FloatArray {
        val cropped = Bitmap.createBitmap(bitmap, crop.left, crop.top, crop.width(), crop.height())
        val resized = Bitmap.createScaledBitmap(cropped, size, size, true)
        val pixels = IntArray(size * size)
        resized.getPixels(pixels, 0, size, 0, 0, size, size)
        val out = FloatArray(3 * size * size)
        val plane = size * size
        for (i in 0 until plane) {
            val p = pixels[i]
            out[i] = ((p shr 16) and 0xFF) / 255f            // R
            out[plane + i] = ((p shr 8) and 0xFF) / 255f      // G
            out[2 * plane + i] = (p and 0xFF) / 255f          // B
        }
        if (cropped !== bitmap) cropped.recycle()
        resized.recycle()
        return out
    }

    // قناع [1,1,S,S]: 1.0 داخل مستطيل الفقاعة الأصلي (بعد تحويله لمقاس القصاصة المُصغّرة)، 0 خارجه
    private fun blockMaskFloatArray(block: BlockData, crop: Rect, size: Int): FloatArray {
        val mask = FloatArray(size * size)
        val sx = size.toFloat() / crop.width()
        val sy = size.toFloat() / crop.height()
        val mx1 = (((block.x - crop.left) * sx).toInt()).coerceIn(0, size)
        val my1 = (((block.y - crop.top) * sy).toInt()).coerceIn(0, size)
        val mx2 = (((block.x + block.width - crop.left) * sx).toInt()).coerceIn(0, size)
        val my2 = (((block.y + block.height - crop.top) * sy).toInt()).coerceIn(0, size)
        for (y in my1 until my2) {
            for (x in mx1 until mx2) mask[y * size + x] = 1f
        }
        return mask
    }

    private fun outputArrayToBitmap(output: FloatArray, size: Int): Bitmap {
        val plane = size * size
        val pixels = IntArray(plane)
        for (i in 0 until plane) {
            val r = output[i].toInt().coerceIn(0, 255)
            val g = output[plane + i].toInt().coerceIn(0, 255)
            val b = output[2 * plane + i].toInt().coerceIn(0, 255)
            pixels[i] = Color.rgb(r, g, b)
        }
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        bmp.setPixels(pixels, 0, size, 0, 0, size, size)
        return bmp
    }


    private fun inpaintPerBlockTFLite(interpreter: Interpreter, bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val result = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)
        val size = MODEL_INPUT_SIZE
        for (block in blocks) {
            try {
                val crop = paddedCropRect(block, bitmap.width, bitmap.height)
                val imgArr = cropToNCHWFloatArray(bitmap, crop, size)
                val maskArr = blockMaskFloatArray(block, crop, size)

                val imgBuf = ByteBuffer.allocateDirect(imgArr.size * 4).order(ByteOrder.nativeOrder())
                imgArr.forEach { imgBuf.putFloat(it) }
                imgBuf.rewind()
                val maskBuf = ByteBuffer.allocateDirect(maskArr.size * 4).order(ByteOrder.nativeOrder())
                maskArr.forEach { maskBuf.putFloat(it) }
                maskBuf.rewind()

                val outputBuf = ByteBuffer.allocateDirect(3 * size * size * 4).order(ByteOrder.nativeOrder())
                interpreter.runForMultipleInputsOutputs(arrayOf(imgBuf, maskBuf), mapOf(0 to outputBuf))

                outputBuf.rewind()
                val plane = size * size
                val rawOut = FloatArray(3 * plane)
                for (i in rawOut.indices) rawOut[i] = outputBuf.float

                // 🔍 (2026-08-15) إصلاح خلل التطبيع اللي أبلغ عنه المستخدم (خلفية تالفة/ألوان
                // غريبة بوضع AI Lite). الكود القديم كان يفترض دائماً أن مخرج النموذج بمقياس
                // [0,1] ويضربه ×255 بشكل أعمى (بلا أي تحقق) — لو النموذج الفعلي يُخرِج فعلاً
                // بمقياس [-1,1] أو [0,255] أصلاً، هذا الضرب الأعمى ينتج قيماً خارج المدى
                // تُقص عشوائياً (coerceIn) فتظهر كخلفية تالفة/بقع لونية غريبة — بالضبط ما
                // وصفه المستخدم. بدون جهاز حقيقي لتأكيد المقياس الدقيق لهذا الملف بالذات،
                // أفضل حل ممكن هو اكتشاف المدى فعلياً من القيم الحقيقية وقت التشغيل بدل
                // افتراض ثابت أعمى:
                val minV = rawOut.min(); val maxV = rawOut.max()
                val flatOut = when {
                    // مخرج بمقياس [0,1] تقريباً → تحويل لـ[0,255]
                    minV >= -0.05f && maxV <= 1.05f -> FloatArray(rawOut.size) { rawOut[it] * 255f }
                    // مخرج بمقياس [-1,1] تقريباً (شائع بنماذج GAN/inpainting بعد Tanh) → [0,255]
                    minV >= -1.05f && maxV <= 1.05f -> FloatArray(rawOut.size) { (rawOut[it] + 1f) * 127.5f }
                    // غير ذلك: القيم أصلاً تتجاوز [-1,1] بوضوح — الأرجح أن المخرج بمقياس
                    // [0,255] (أو قريب منه) أصلاً ولا حاجة لأي تحويل إضافي.
                    else -> rawOut
                }
                val outBmp = outputArrayToBitmap(flatOut, size)
                val scaledBack = Bitmap.createScaledBitmap(outBmp, crop.width(), crop.height(), true)
                canvas.drawBitmap(scaledBack, crop.left.toFloat(), crop.top.toFloat(), null)
                outBmp.recycle(); scaledBack.recycle()
            } catch (e: Throwable) {
                Log.e(TAG, "TFLite block inference failed for block, using border-color fallback (بند 4)", e)
                val paint = Paint().apply { color = averageBorderColor(bitmap, block) }
                canvas.drawRect(Rect(block.x, block.y, block.x + block.width, block.y + block.height), paint)
            }
        }
        return result
    }

    private fun FloatBufferOf(arr: FloatArray): java.nio.FloatBuffer {
        val buf = ByteBuffer.allocateDirect(arr.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        buf.put(arr); buf.rewind()
        return buf
    }

    // مخرجات ONNX Runtime لـ Java تجي كمصفوفات متداخلة — هذه تُسطِّح عنصراً واحداً بشكل
    // [3,S,S] (بعد إزالة محور الدفعة، سواء استُخرِج من نتيجة مفردة أو من دفعة).
    @Suppress("UNCHECKED_CAST")
    private fun flattenSingleCHW(channel3: Array<*>, size: Int): FloatArray {
        val plane = size * size
        val result = FloatArray(3 * plane)
        for (c in 0 until 3) {
            val channel = channel3[c] as Array<*>     // [S,S] (FloatArray rows)
            for (y in 0 until size) {
                val row = channel[y] as FloatArray
                System.arraycopy(row, 0, result, c * plane + y * size, size)
            }
        }
        return result
    }

    // مخرجات ONNX Runtime لـ Java تجي كمصفوفات متداخلة (Array<Array<Array<FloatArray>>>)
    // لشكل [1,3,S,S] — نسطّحها لنفس ترتيب NCHW المستخدم في outputArrayToBitmap
    @Suppress("UNCHECKED_CAST")
    private fun flattenOnnxOutput(out: Array<*>, size: Int): FloatArray =
        flattenSingleCHW(out[0] as Array<*>, size)

    // Main entry point called from AppInterface
    /**
     * Native erasure entry point. Returns the processed page Bitmap directly.
     * The caller stores it in the local cache and serves it to WebView by URL;
     * no Base64 payload is created for the WebView bridge.
     *
     * بند 3: [bubbleAware] (افتراضي false) يُمرَّر فقط لوضع "opencv" حالياً — أوضاع
     * ai_lite/ai_pro تعتمد أصلاً على قصّ مُوسَّع حول كل بلوك (paddedCropRect) وليس قناع
     * مستطيل/فقاعة، فلا ينطبق عليها هذا الخيار بنفس الطريقة.
     */
    override fun processBitmap(bitmap: Bitmap, blocks: List<BlockData>, mode: String, bubbleAware: Boolean): Bitmap? {
        return when (mode) {
            "opencv" -> inpaintOpenCV(bitmap, blocks, bubbleAware)
            "ai_lite" -> inpaintTFLite(bitmap, blocks)
            "ai_pro" -> inpaintONNX(bitmap, blocks)
            else -> null
        }
    }

    private fun fallbackErase(bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val result = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)
        for (block in blocks) {
            val paint = Paint().apply { color = averageBorderColor(bitmap, block) }
            canvas.drawRect(
                Rect(block.x, block.y, block.x + block.width, block.y + block.height),
                paint
            )
        }
        return result
    }

    /**
     * بند 4: بدل تعبئة أبيض ثابت في كل مسارات الطمس الاحتياطية (fallback — سواء فشل الصفحة
     * كاملة أو بلوك واحد فقط داخل AI Lite/AI Pro)، نأخذ متوسط لون البكسلات على حلقة حدودية
     * حول منطقة النص (خارجها مباشرة، لا داخلها) ونملأ بذلك اللون. هذا أقرب بصرياً لخلفية
     * الفقاعة الفعلية (أبيض/كريمي/رمادي فاتح حسب أسلوب الرسم) من أبيض ثابت يبرز بوضوح فوق
     * أي خلفية ليست بيضاء تماماً. نعيّن الحلقة الحدودية تحديداً (لا منطقة عشوائية من الصفحة)
     * لأنها الأقرب فعلياً للون خلفية الفقاعة المباشر حول النص المطموس.
     */
    private fun averageBorderColor(bitmap: Bitmap, block: BlockData): Int {
        val ringWidth = maxOf((minOf(block.width, block.height) * 0.15f).toInt(), 4)
        val ox1 = (block.x - ringWidth).coerceIn(0, bitmap.width - 1)
        val oy1 = (block.y - ringWidth).coerceIn(0, bitmap.height - 1)
        val ox2 = (block.x + block.width + ringWidth).coerceIn(ox1 + 1, bitmap.width)
        val oy2 = (block.y + block.height + ringWidth).coerceIn(oy1 + 1, bitmap.height)
        val ix1 = block.x.coerceIn(ox1, ox2)
        val iy1 = block.y.coerceIn(oy1, oy2)
        val ix2 = (block.x + block.width).coerceIn(ix1, ox2)
        val iy2 = (block.y + block.height).coerceIn(iy1, oy2)

        var sumR = 0L; var sumG = 0L; var sumB = 0L; var count = 0L
        // نمسح كل بكسلات المستطيل الخارجي (ox1..ox2 × oy1..oy2) ونستبعد المستطيل الداخلي
        // (منطقة النص نفسها ix1..ix2 × iy1..iy2) — يعطينا هذا فقط "الحلقة" المحيطة بالنص.
        val step = 2 // نقفز كل بكسلين لتسريع الحساب بدون خسارة دقة ملموسة على منطقة صغيرة
        var y = oy1
        while (y < oy2) {
            val insideRow = y in iy1 until iy2
            var x = ox1
            while (x < ox2) {
                if (!(insideRow && x in ix1 until ix2)) {
                    val p = bitmap.getPixel(x, y)
                    sumR += (p shr 16) and 0xFF
                    sumG += (p shr 8) and 0xFF
                    sumB += p and 0xFF
                    count++
                }
                x += step
            }
            y += step
        }
        if (count == 0L) return Color.WHITE // حلقة فارغة (بلوك يملأ الصفحة تقريباً) — أبيض كحل أخير معقول
        return Color.rgb((sumR / count).toInt(), (sumG / count).toInt(), (sumB / count).toInt())
    }

    private fun loadModelFile(file: File): MappedByteBuffer {
        val stream = FileInputStream(file)
        val channel = stream.channel
        return channel.map(FileChannel.MapMode.READ_ONLY, 0, file.length())
    }

}
