package com.comictrans.engine.contracts

import android.content.Context
import android.graphics.Bitmap
import com.comictrans.engine.ModelManager
import com.comictrans.model.BlockData

/**
 * بند 11 (Module Split) — عقود (Interfaces) لمحركات AI الثقيلة (OpenCV / TFLite / ONNX /
 * PaddleOCR) بعد نقل تنفيذها الفعلي لموديول feature_ai (Dynamic Feature Module).
 *
 * ليه Interfaces بدل الاعتماد المباشر؟ AGP يمنع أي اعتماد وقت-ترجمة (compile-time) من
 * الموديول الأساسي app باتجاه أي Dynamic Feature Module تابع له — الاتجاه المسموح
 * فقط عكسي (feature_ai يعتمد على app). لذلك app يعرف فقط "الشكل" (هذه الملفات)،
 * والتنفيذ الفعلي موجود بـ feature_ai ويُحمَّل وقت التشغيل عبر Reflection
 * (راجع FeatureAiLoader.kt بجانب هذا الملف).
 *
 * ⚠️ لا تحقق تلقائي من التطابق بين هذه التوقيعات وتنفيذها الفعلي بـ feature_ai —
 * أي تعديل هنا يتطلب تعديلاً يدوياً مطابقاً بالملفات المقابلة تحت
 * feature_ai/src/main/java/com/comictrans/feature_ai/engine/ (كل ملفات Kotlin هناك)
 * وإلا سينكسر التحميل وقت التشغيل بصمت (ClassCastException) رغم نجاح البناء.
 */

interface IOcrEngine {
    suspend fun recognizeMLKit(bitmap: Bitmap): List<BlockData>
    suspend fun recognizePaddleLite(bitmap: Bitmap): List<BlockData>
    /**
     * 🔍 (2026-08-20) [detectorId] يختار كاشف الصناديق المستخدَم قبل قراءة Tesseract لكل
     * صندوق — "auto" (افتراضي) يجرّب EAST-640 ثم CRAFT Mobile ثم EAST-320 ثم EAST-1280
     * بالترتيب، أول واحد منزَّل فعلياً يُستخدم. "det_east_320"/"det_east_640"/
     * "det_east_1280"/"det_craft_mobile" يفرض كاشفاً محدَّداً بذاته (لو غير منزَّل، رجوع
     * لسلوك "الصفحة كصندوق واحد" بدل الفشل). راجع resolveTesseractDetectorBoxes بـ
     * OCREngine.kt للتفاصيل الكاملة.
     */
    suspend fun recognizeTesseract(bitmap: Bitmap, detectorId: String = "auto"): List<BlockData>
    /**
     * 🔍 (استبدال OCR.space) محرك OCR محلي متوافق مع OpenAI Chat Completions Vision API —
     * Ollama/LM Studio/أي سيرفر آخر بنفس التنسيق، بشرط أن يكون النموذج المحدَّد نموذج رؤية
     * (Vision) فعلياً (مثل qwen2.5-vl أو llava أو gpt-4o-mini). يُرسِل الصورة كـbase64 مع
     * تعليمة تطلب استخراج كل سطر نص مع موقعه (x/y/width/height بالبكسل) بصيغة JSON — نفس
     * شكل JSON المستخدم بـrecognizeCloud (results/words/texts). لو النموذج رجّع نصاً عادياً
     * بدون JSON صالح (شائع مع نماذج رؤية أضعف)، نتعامل معه كنص صفحة كاملة (بلوك واحد) بدل
     * فشل كامل — راجع تعليق التنفيذ الكامل بـOCREngine.kt.
     */
    suspend fun recognizeLocalLlm(bitmap: Bitmap, apiUrl: String, apiKey: String, model: String): List<BlockData>
    suspend fun recognizeCloud(bitmap: Bitmap, apiUrl: String): List<BlockData>

    /**
     * كاشف CRAFT Mobile (character-region + affinity) — **كشف فقط**، لا قراءة نص. هذه الدالة
     * بذاتها (كشف + قراءة كل صندوق عبر ML Kit) غير مُستدعاة من أي مسار حالياً — لكن منطق
     * الكشف الداخلي (runCraftDetection بـOCREngine.kt) صار مُستخدَماً فعلياً عبر
     * settings.tesseractDetector = "det_craft_mobile" (أو "auto") كأحد كواشف الصناديق
     * الممكنة لمسار Tesseract — راجع resolveTesseractDetectorBoxes.
     */
    suspend fun recognizeCraftMobile(bitmap: Bitmap): List<BlockData>

    suspend fun recognizeEast(bitmap: Bitmap, modelId: String): List<BlockData>

    suspend fun recognizeEasyOCR(bitmap: Bitmap): List<BlockData>
}

interface IErasureEngine {
    fun processBitmap(bitmap: Bitmap, blocks: List<BlockData>, mode: String, bubbleAware: Boolean = false): Bitmap?
    /** يحرر جلسة ONNX/مفسّر TFLite المُخزَّنين مؤقتاً — يُستدعى فقط لو الموديول كان مُهيَّأً فعلاً. */
    fun close()
}

/** نسخة مستقلة عن الكلاس الأصلي — كانت nested data class داخل ImageEnhanceEngine قبل النقل. */
data class EnhanceResult(val bitmap: Bitmap, val scale: Float)

interface IImageEnhanceEngine {
    fun enhance(bitmap: Bitmap, method: String): EnhanceResult
}

// ================= Factories (تُنشَأ فعلياً داخل feature_ai عبر Reflection) =================

interface IOcrEngineFactory {
    fun create(context: Context, modelManager: ModelManager): IOcrEngine
}

interface IErasureEngineFactory {
    fun create(context: Context, modelManager: ModelManager): IErasureEngine
}

interface IImageEnhanceEngineFactory {
    fun create(context: Context, modelManager: ModelManager): IImageEnhanceEngine
}

/** يهيّئ مكتبة OpenCV الأصلية — التنفيذ الفعلي بـ feature_ai لأن مكتبة org.opencv انتقلت هناك. */
interface IOpenCvInitializer {
    /** يرجع true لو نجحت التهيئة. يحدّث OpenCVStatus.isAvailable داخلياً بنفس الاستدعاء. */
    fun initialize(): Boolean
}
