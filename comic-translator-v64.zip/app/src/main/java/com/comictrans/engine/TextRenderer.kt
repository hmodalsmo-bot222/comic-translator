package com.comictrans.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.util.Log
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import com.comictrans.model.BlockData
import com.comictrans.model.SettingsData
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * ⚠️ جديد بهذه الدفعة (نقل مسار رسم النص من JavaScript/HTML5 Canvas إلى Kotlin الأصلي —
 * أول تفعيل فعلي لخيار "Android Canvas + Paint (مدمج)" بـ`SettingsData.textRendererEngine`،
 * الذي كان موجوداً بالإعدادات منذ فترة طويلة لكن **لا يوجد أي كود Kotlin يقرأه إطلاقاً**
 * (تحقّقتُ بـgrep قبل كتابة هذا الملف — نفس الفجوة الموثَّقة سابقاً بـHANDOFF_NEXT_ASSISTANT.md).
 *
 * لماذا Android Canvas + Paint تحديداً (لا Skia عبر Skiko، ولا FreeType+HarfBuzz عبر NDK):
 * - إطار عمل أندرويد نفسه (`android.text.StaticLayout` + `Minikin`، محرك تخطيط النص
 *   الداخلي لأندرويد منذ Lollipop) **يستخدم أصلاً HarfBuzz لتشكيل الحروف (glyph shaping)
 *   وFreeType/Skia لرسمها** — هذه ليست مكتبة بديلة نضيفها، بل نفس التقنية المطلوبة، متوفرة
 *   مجاناً كجزء من إطار العمل نفسه بدون أي اعتمادية Gradle جديدة ولا بناء NDK/CMake. لهذا
 *   السبب بالذات "تفعيل" هذا الخيار يحل عملياً معظم ما كان مطلوباً من FreeType+HarfBuzz.
 * - Skia عبر `org.jetbrains.skiko` يبقى بديلاً حقيقياً ممكناً مستقبلاً (نفس تقييم الجلسة
 *   السابقة) لكنه يضيف مكتبة ثقيلة جديدة لحل مشكلة إطار العمل أصلاً يحلّها مجاناً — لم يُنفَّذ
 *   هذه الدفعة لعدم وجود حاجة فعلية مؤكَّدة له بعد اختبار هذا المسار أولاً.
 *
 * ⚠️ **لم يُختبَر فعلياً على جهاز حقيقي** (نفس القيد البيئي التاريخي لكل جلسات هذا المشروع
 * — لا Android SDK/جهاز هنا). تحقَّقتُ فقط من توازن الأقواس ببرمجية وقراءة يدوية دقيقة
 * لتوثيق StaticLayout/TextPaint الرسمي (developer.android.com) للتأكد من توقيعات الدوال.
 */
object TextRenderer {

    // 🔍 (2026-08-18) إصلاح للقيد الموثَّق سابقاً بتعليق resolveTypeface أدناه ("لا يحمّل أي
    // ملف خط مخصَّص من الأصول"): AppInterface.kt يضبط هذا المسار مرة واحدة عند إنشاء
    // AppInterface (نفس مجلد ModelManager.modelFile() — راجع "🎨 محرك الرسم" بـindex.html
    // لسياق القرار الكامل: بدل محاولة تفعيل محركات رسم NDK غير آمنة، أُضيف تحميل خط عربي
    // حقيقي فعلي بدل الاعتماد فقط على تخمين اسم خط نظام). null افتراضياً (لو AppInterface
    // لم يضبطه لأي سبب) — resolveTypeface يرجع صامتاً لمنطق مطابقة الاسم القديم بهذه الحالة،
    // لا كراش.
    var fontsDir: java.io.File? = null

    // كاش بسيط لتجنب Typeface.createFromFile() المتكرر (عملية قراءة قرص) لكل صندوق نص —
    // نفس الخط يُعاد استخدامه عبر مئات الصناديق بنفس الصفحة عادةً.
    private val fileTypefaceCache = java.util.concurrent.ConcurrentHashMap<String, Typeface?>()

    /**
     * يرسم كل فقاعات النص المترجم مباشرة على [bitmap] (يُعدَّل في مكانه — mutable لازم
     * يكون true، استدعِها دائماً على bitmap ناتج من `.copy(Bitmap.Config.ARGB_8888, true)`
     * لو غير متأكد من قابلية التعديل، لأن نسخ OpenCV/TFLite/ONNX أحياناً ترجع bitmaps غير
     * قابلة للتعديل). يُعيد نفس الـ[bitmap] (نفس المرجع) للراحة بسلاسل استدعاء.
     *
     * منطق "الحجم الذكي" هنا **نسخة طبق الأصل معمارياً** من `fitTextToBox`/`wrapText` بـ
     * index.html (نفس عتبة الحد الأدنى 8px، نفس نسبة ارتفاع السطر 1.3×)، لكن بدل القياس
     * اليدوي حرفاً-حرفاً (`ctx.measureText` بحلقة JS)، يستخدم `StaticLayout` الرسمي —
     * أدق وأسرع لأنه يفهم فعلياً التفاف الكلمات وقواعد كسر الأسطر العربية (bidi) بدل تقريب
     * JS العام بكل اللغات.
     */
    fun drawTranslatedText(bitmap: Bitmap, blocks: List<BlockData>, settings: SettingsData): Bitmap {
        if (!bitmap.isMutable) return bitmap // شبكة أمان — لو استُدعيت خطأً على bitmap غير قابل للتعديل، لا نكسر الصفحة، فقط لا نرسم شيئاً
        val canvas = Canvas(bitmap)
        val typeface = resolveTypeface(settings.fontFamily)
        val fontSizeScale = if (settings.fontSizeScale > 0f) settings.fontSizeScale else 1f
        val lineSpacingScale = if (settings.lineSpacingScale > 0f) settings.lineSpacingScale else 1f
        val textWidthRatio = if (settings.textWidthRatio > 0f) settings.textWidthRatio else 0.9f
        val textColor = try {
            Color.parseColor(settings.textColor.ifBlank { "#000000" })
        } catch (e: IllegalArgumentException) {
            Color.BLACK // لون غير صالح (نادر، مثلاً استُدخل يدوياً بخطأ) — أسود احتياطي بدل تعطّل الرسم كله
        }

        for (block in blocks) {
            val translated = block.translatedText
            if (translated.isBlank()) continue

            val x = block.x.toFloat()
            val y = block.y.toFloat()
            val w = block.width.toFloat()
            val h = block.height.toFloat()
            if (w <= 1f || h <= 1f) continue // صندوق تافه الحجم — لا مجال لرسم أي نص مقروء بداخله

            // خلفية النص المترجم الجديد (إعداد "textBackground" مستقل عن خطوة مسح النص القديم،
            // نفس المنطق الموجود بـJS بالضبط — راجع drawTextBlocks بـindex.html).
            if (settings.textBackground == "box") {
                val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
                canvas.drawRect(x - 2f, y - 2f, x + w + 2f, y + h + 2f, bgPaint)
            }

            val maxWidth = max(1, (w * textWidthRatio).roundToInt())
            val maxHeight = max(1, (h * 0.9f).roundToInt())

            val fit = if (settings.smartFontSize) {
                fitTextToBox(translated, maxWidth, maxHeight, typeface, lineSpacingScale)
            } else {
                val fixedSize = max(min(h * 0.35f, w * 0.15f) * fontSizeScale, 10f)
                FitResult(fixedSize, buildLayout(translated, fixedSize, typeface, maxWidth, lineSpacingScale))
            }

            val layout = fit.layout
            val totalTextHeight = layout.height.toFloat()
            val startY = y + h / 2f - totalTextHeight / 2f

            canvas.save()
            canvas.translate(x + w / 2f - layout.width / 2f, startY)
            layout.paint.color = textColor
            layout.draw(canvas)
            canvas.restore()
        }
        return bitmap
    }

    private data class FitResult(val fontSize: Float, val layout: StaticLayout)

    /** يبحث عن أكبر حجم خط يجعل النص المترجم (بعد الالتفاف) يتلائم داخل [maxWidth]x[maxHeight] —
     * نفس خوارزمية `fitTextToBox` بـJS بالضبط (تنازل تدريجي 1px حتى حد أدنى 8px).
     *
     * 🔍 (2026-08-20) إصلاح لبلاغ "الخط صغير جداً ويتكرر كثيراً": لو النص لا يزال لا يتلائم
     * حتى عند [minSize] (يحدث غالباً الآن نتيجة نص طويل من بلوك دُمج خطأً من فقاعتين —
     * راجع الإصلاح الجذري بـOCREngine.mergeIntoComicBlocks لمعالجة السبب الجذري نفسه —
     * لكن نُبقي هذا كشبكة أمان ثانية مستقلة، لأي حالة أخرى تنتج نصاً أطول من مساحة الفقاعة
     * فعلياً)، كان الكود القديم يرجع أياً كان `layout` الناتج عند `minSize` بدون أي حد أقصى
     * لعدد الأسطر — فيفيض النص فعلياً خارج حدود الفقاعة بعدد كبير من الأسطر الصغيرة جداً،
     * ويظهر بصرياً وكأن "الخط يتكرر". الآن: لو النص ما زال لا يتلائم عمودياً حتى بعد الوصول
     * لـminSize، نعيد بناء التخطيط بحد أقصى لعدد الأسطر (`setMaxLines` = أكبر عدد أسطر يدخل
     * فعلياً داخل [maxHeight]) مع `TruncateAt.END` (نقاط "…") بدل الفيضان — نفس المبدأ
     * المطبَّق بالمتصفحات لـ`text-overflow: ellipsis` لكن متعدد الأسطر.
     */
    private fun fitTextToBox(text: String, maxWidth: Int, maxHeight: Int, typeface: Typeface, lineSpacingScale: Float): FitResult {
        val minSize = 8f
        var size = max(min(maxHeight * 0.6f, maxWidth * 0.25f), minSize)
        var layout = buildLayout(text, size, typeface, maxWidth, lineSpacingScale)
        while (size > minSize) {
            val fitsHeight = layout.height <= maxHeight
            val widestLine = (0 until layout.lineCount).maxOfOrNull { layout.getLineWidth(it) } ?: 0f
            val fitsWidth = widestLine <= maxWidth
            if (fitsHeight && fitsWidth) break
            size -= 1f
            layout = buildLayout(text, size, typeface, maxWidth, lineSpacingScale)
        }
        if (layout.height > maxHeight) {
            val lineH = size * 1.3f * max(0.1f, lineSpacingScale)
            val maxLines = max(1, (maxHeight / lineH).toInt())
            if (layout.lineCount > maxLines) {
                layout = buildLayout(text, size, typeface, maxWidth, lineSpacingScale, maxLines)
            }
        }
        return FitResult(size, layout)
    }

    private fun buildLayout(text: String, fontSizePx: Float, typeface: Typeface, maxWidth: Int, lineSpacingScale: Float, maxLines: Int? = null): StaticLayout {
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            this.typeface = typeface
            this.textSize = fontSizePx
            this.isFakeBoldText = true // نفس "bold" بـJS (ctx.font = `bold ...`) — الخطوط هنا افتراضية بلا وزن Bold حقيقي مضمون بكل الأجهزة
        }
        val width = max(1, maxWidth)
        val builder = StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setLineSpacing(0f, max(0.1f, lineSpacingScale * 1.3f)) // 1.3× نفس مضاعف ارتفاع السطر بـJS (lineH = fontSize * 1.3 * lineSpacingScale)
            .setIncludePad(false)
            // النص المترجم عربي غالباً بهذا المشروع (targetLang افتراضي "ar") — الأولوية RTL،
            // نفس "ctx.direction = 'rtl'" بـJS. FIRSTSTRONG يسمح أيضاً بفقرات إنجليزية سليمة
            // لو المستخدم غيّر اللغة الهدف مستقبلاً، بعكس فرض RTL ثابت دائماً.
            .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_RTL)
        if (maxLines != null) {
            builder.setEllipsize(android.text.TextUtils.TruncateAt.END).setEllipsizedWidth(width).setMaxLines(maxLines)
        }
        return builder.build()
    }

    /** خرائط تقريبية من قوائم CSS font-stack المستخدمة بـJS (`fontFamily` بـindex.html) إلى
     * أقرب Typeface أصلي بأندرويد. ⚠️ **قيد صادق مهم**: الخطوط المخصَّصة المذكورة بالقائمة
     * (Noto Naskh Arabic، إلخ) هي خطوط نظام أندرويد عادية لو وُجدت فعلاً على الجهاز — هذا
     * الكود لا يحمّل أي ملف خط مخصَّص (`.ttf`/`.otf`) من الأصول (assets)، فقط يطابق الاسم
     * تقريبياً بمنطق `Typeface.create(name, style)` (يرجع للخط الافتراضي صامتاً لو الاسم غير
     * موجود بالجهاز، سلوك أندرويد الرسمي، لا كراش). لا حاجة للقلق من العربية تحديداً: نظام
     * أندرويد نفسه يطبّق fallback تلقائي لخط عربي مناسب (Noto Sans Arabic أو ما يعادله) لأي
     * Typeface افتراضي عند رسم نص بحروف عربية — هذا سلوك Minikin الداخلي، لا كود إضافي هنا. */
    private fun resolveTypeface(cssFontFamily: String): Typeface {
        val lower = cssFontFamily.lowercase()
        val style = Typeface.BOLD
        // 🔍 (2026-08-18) لو المستخدم نزّل خط Amiri فعلياً عبر مركز التحميل (font_amiri_regular/
        // font_amiri_bold بـModelManager) ونص index.html المطلوب يذكر "amiri" أو "naskh"،
        // نحمّله من الملف الحقيقي مباشرة (Typeface.createFromFile) بدل تخمين اسم خط نظام —
        // هذا يعمل حتى لو الجهاز لا يملك أي خط عربي مخصَّص مثبَّت أصلاً كنظام. لو لم يُنزَّل
        // بعد، أو fontsDir غير مضبوط، يرجع صامتاً لمنطق المطابقة القديم بالأسفل (سلوك مطابق
        // تماماً لما كان قبل هذه الدفعة، لا كسر رجعي).
        if (lower.contains("naskh") || lower.contains("amiri") || lower.contains("kufi")) {
            val dir = fontsDir
            if (dir != null) {
                val fileName = if (style == Typeface.BOLD) "Amiri-Bold.ttf" else "Amiri-Regular.ttf"
                val cached = fileTypefaceCache.getOrPut(fileName) {
                    try {
                        val f = java.io.File(dir, fileName)
                        if (f.exists() && f.length() > 0L) Typeface.createFromFile(f) else null
                    } catch (e: Exception) {
                        Log.w("TextRenderer", "تعذّر تحميل خط Amiri من الملف المُنزَّل (سيُستخدم أقرب خط نظام بدلاً منه): ${e.message}")
                        null
                    }
                }
                if (cached != null) return cached
            }
        }
        return when {
            lower.contains("monospace") -> Typeface.create(Typeface.MONOSPACE, style)
            lower.contains("serif") && !lower.contains("sans-serif") -> Typeface.create(Typeface.SERIF, style)
            lower.contains("naskh") || lower.contains("kufi") || lower.contains("amiri") -> {
                // أسماء خطوط عربية شائعة بقائمة index.html — نحاول مطابقة اسم نظام مباشر
                // (يعمل لو الجهاز فعلاً يحوي خطاً بهذا الاسم بالضبط)، وإلا الرجوع الصامت
                // الرسمي لأندرويد لـTypeface الافتراضي (لا استثناء، هذا موثَّق بـAPI نفسه).
                val familyName = cssFontFamily.substringBefore(',').trim('"', ' ')
                Typeface.create(familyName, style)
            }
            else -> Typeface.create(Typeface.DEFAULT, style)
        }
    }

    /** يحسب متوسط لون البكسلات على حلقة حدودية حول مستطيل النص (نفس `sampleEdgeColor` بـJS
     * بالضبط) — يُستخدَم بوضع "fill" الأصلي الآن بعد نقله لـKotlin (راجع AppInterface.kt). */
    fun averageEdgeColor(bitmap: Bitmap, block: BlockData): Int {
        val pad = 2
        val sx = max(0, block.x - pad)
        val sy = max(0, block.y - pad)
        val sw = min(bitmap.width - sx, block.width + pad * 2)
        val sh = min(bitmap.height - sy, block.height + pad * 2)
        if (sw <= 0 || sh <= 0) return Color.WHITE
        return try {
            val rect = Rect(sx, sy, sx + sw, sy + sh)
            var r = 0L; var g = 0L; var b = 0L; var n = 0L
            val step = 2
            var px = 0
            while (px < sw) {
                for (py in intArrayOf(0, sh - 1)) {
                    val pixel = bitmap.getPixel(rect.left + px, rect.top + py)
                    r += Color.red(pixel); g += Color.green(pixel); b += Color.blue(pixel); n++
                }
                px += step
            }
            var py = 0
            while (py < sh) {
                for (px2 in intArrayOf(0, sw - 1)) {
                    val pixel = bitmap.getPixel(rect.left + px2, rect.top + py)
                    r += Color.red(pixel); g += Color.green(pixel); b += Color.blue(pixel); n++
                }
                py += step
            }
            if (n == 0L) Color.WHITE else Color.rgb((r / n).toInt(), (g / n).toInt(), (b / n).toInt())
        } catch (e: IllegalArgumentException) {
            Color.WHITE // إحداثيات خارج حدود الصورة (نادر، حافة صفحة) — أبيض احتياطي بدل تعطّل
        }
    }

    /** وضع "fill": يمسح كل صندوق نص قديم بلون حواف الفقاعة الحقيقي (لا أبيض ثابت)، ثم يرسم
     * النص المترجم فوقه — الآن بالكامل بـKotlin بدل الاعتماد على JS Canvas (نفس منطق
     * `drawTextBlocks`+`sampleEdgeColor` بـindex.html، منقول حرفياً). */
    fun eraseAndDrawFill(original: Bitmap, blocks: List<BlockData>, settings: SettingsData): Bitmap {
        val out = original.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        for (block in blocks) {
            if (block.translatedText.isBlank()) continue
            fillPaint.color = averageEdgeColor(original, block)
            canvas.drawRect(
                block.x - 2f, block.y - 2f,
                (block.x + block.width + 2).toFloat(), (block.y + block.height + 2).toFloat(),
                fillPaint
            )
        }
        return drawTranslatedText(out, blocks, settings)
    }
}
