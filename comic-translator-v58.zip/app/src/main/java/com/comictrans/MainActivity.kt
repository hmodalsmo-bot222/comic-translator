package com.comictrans

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JsPromptResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.widget.EditText
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.FileInputStream

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var appInterface: AppInterface

    // callback الذي يطلبه WebView لتسليم مسار الملف المُختار للصفحة
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        val results: Array<Uri>? = if (result.resultCode == RESULT_OK && data != null) {
            WebChromeClient.FileChooserParams.parseResult(result.resultCode, data)
        } else {
            null
        }
        fileChooserCallback?.onReceiveValue(results)
        fileChooserCallback = null
        val nativeUri = results?.firstOrNull()
        if (result.resultCode == RESULT_OK && nativeUri != null && ::appInterface.isInitialized) {
            val displayName = nativeUri.lastPathSegment?.substringAfterLast('/') ?: "comic.cbz"
            appInterface.loadComicFromUri(nativeUri, displayName)
        }
    }

    // 🔍 (2026-08-19) حُذفت "خلفية المجتمع" (مزامنة الذاكرة) بالكامل بطلب المستخدم —
    // أُزيلت معها launchers تصدير/استيراد JSON المحلية (exportJsonToFile/importJsonFromFile)
    // ودوال AppInterface المرتبطة بها وملف SyncEngine.kt كاملاً.

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // تهيئة OpenCV — بند 11: مكتبة org.opencv انتقلت لموديول feature_ai (Dynamic Feature)،
        // فـapp ما يقدر يعتمد عليها مباشرة وقت الترجمة بعد الآن. التهيئة الفعلية تصير عبر
        // Reflection (راجع FeatureAiLoader.initializeOpenCV() — التنفيذ الحقيقي بـ
        // feature_ai/.../engine/OpenCvInitializer.kt). OpenCVStatus.isAvailable يُحدَّث
        // داخلياً بنفس الاستدعاء (ضمن FeatureAiLoader/OpenCvInitializer)، فلا حاجة لتعيينه هنا يدوياً.
        if (com.comictrans.engine.contracts.FeatureAiLoader.initializeOpenCV()) {
            android.util.Log.d("OpenCV", "OpenCV loaded successfully")
        } else {
            android.util.Log.e("OpenCV", "OpenCV initialization failed — falling back to simple erase")
        }

        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        setupWebView()

        appInterface = AppInterface(this, webView)
        webView.addJavascriptInterface(appInterface, "AndroidBridge")

        webView.loadUrl("file:///android_asset/index.html")

        // 🔍 (2026-08-19) دعم فتح ملفات CBZ/ZIP مباشرة من أي تطبيق خارجي (مدير الملفات،
        // "فتح بواسطة"، مشاركة ملف) — راجع intent-filter الجديد بـAndroidManifest.xml.
        handleIncomingComicIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingComicIntent(intent)
    }

    /** يفتح ملف كوميكس واصل من تطبيق خارجي (ACTION_VIEW) مباشرة في القارئ. */
    private fun handleIncomingComicIntent(intent: Intent?) {
        if (intent?.action != Intent.ACTION_VIEW) return
        val uri = intent.data ?: return
        if (!::appInterface.isInitialized) return
        val displayName = uri.lastPathSegment?.substringAfterLast('/') ?: "comic.cbz"
        appInterface.loadComicFromUri(uri, displayName)
    }

    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            // مُعطَّل عمداً: تكبير WebView المدمج (native pinch-zoom) كان يتصادم مع
            // تكبير القارئ المخصّص في JS (initReaderZoom في index.html). Android WebView
            // كان يعالج لفتتين الأصابع كإيماءة تكبير "بصرية" خاصة به (مستوى الـ compositor)،
            // فيبدو الأمر وكأنه تكبير فعلي أثناء إبقاء الأصابع، لكن فور رفعها كان WebView
            // يعيد ضبط/تخطيط الصفحة لمقاسها الطبيعي (لأن أبعاد المحتوى الفعلية ما تغيّرت)،
            // فيرجع كل شي "زي ما كان" — وهذا بالضبط العطل المُبلّغ عنه. تعطيل التكبير المدمج
            // هنا يسلّم التحكم بالكامل لكود JS (initReaderZoom) اللي يطبّق transform يدوي
            // ثابت لا يُلغى إلا بنقرة مزدوجة أو بتصفير صريح.
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val url = request?.url ?: return super.shouldInterceptRequest(view, request)
                if (url.scheme == "https" && url.host == "comic.local") {
                    val kind = url.pathSegments.firstOrNull()
                    val index = url.pathSegments.getOrNull(1)?.toIntOrNull() ?: return null
                    val file = if (::appInterface.isInitialized) {
                        when (kind) {
                            "page" -> appInterface.getNativePageFile(index)
                            "processed" -> appInterface.getProcessedPageFile(index)
                            else -> null
                        }
                    } else null
                    if (file != null && file.exists()) {
                        val mime = when (file.extension.lowercase()) {
                            "jpg", "jpeg" -> "image/jpeg"
                            "png" -> "image/png"
                            "webp" -> "image/webp"
                            "gif" -> "image/gif"
                            "bmp" -> "image/bmp"
                            else -> "application/octet-stream"
                        }
                        return try {
                            WebResourceResponse(
                                mime, null, 200, "OK",
                                mapOf("Access-Control-Allow-Origin" to "*"),
                                FileInputStream(file)
                            )
                        } catch (_: Exception) { null }
                    }
                }
                return super.shouldInterceptRequest(view, request)
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback
                // 🔍 (2026-08-19) إصلاح جذري لدعم CBZ المباشر: fileChooserParams.createIntent()
                // يبني فلتر الأنواع من accept=".cbz,.zip" بـindex.html — لكن ".cbz" ليس نوع
                // MIME مسجلاً لدى أندرويد إطلاقاً، فكثير من مدراء الملفات كانوا يُخفون ملفات
                // CBZ تماماً من منتقي الملفات (لا يمكن اختيارها أصلاً رغم أن التطبيق يدعمها
                // فعلياً بفك الضغط). الحل: نطلب "*/*" دائماً ونضيف أنواع MIME الشائعة للأرشيف
                // كتلميح إضافي — التحقق من الامتداد يحصل أصلاً بـJS (handleFile) وبـKotlin
                // (isImageEntry)، فلا مخاطرة من قبول ملفات أخرى هنا.
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                    putExtra(
                        Intent.EXTRA_MIME_TYPES,
                        arrayOf(
                            "application/zip",
                            "application/x-cbz",
                            "application/vnd.comicbook+zip",
                            "application/octet-stream"
                        )
                    )
                }
                return try {
                    fileChooserLauncher.launch(intent)
                    true
                } catch (e: Exception) {
                    fileChooserCallback = null
                    false
                }
            }

            // *** إصلاح جذري: window.prompt() في index.html كان لا يعمل إطلاقاً ***
            // بمجرد تعيين WebChromeClient مخصّص (كما هنا لأجل onShowFileChooser)، تتوقف
            // معالجة WebView الافتراضية لحوارات JS (alert/confirm/prompt) — الكلاس الأساس
            // WebChromeClient لا ينفّذ أي حوار فعلي لهذه الدوال ما لم يُطلب صراحة override،
            // فتُستدعى prompt() في JS وترجع null فوراً بدون عرض أي حوار للمستخدم إطلاقاً.
            // هذا بالضبط سبب "أضع الرابط ولا يتم التنزيل" عند تنزيل نموذج AI/Paddle مخصّص:
            // كود JS (index.html) يستدعي `prompt(...)`، يرجع null دائماً، فيتوقف الكود عند
            // `if (!url) return;` قبل أي استدعاء لـ AndroidBridge.setModelUrl/downloadModel.
            override fun onJsPrompt(
                view: WebView?,
                url: String?,
                message: String?,
                defaultValue: String?,
                result: JsPromptResult?
            ): Boolean {
                val ctx = view?.context ?: this@MainActivity
                val input = EditText(ctx).apply {
                    setText(defaultValue ?: "")
                    setSelection(text.length)
                }
                AlertDialog.Builder(ctx)
                    .setTitle(message ?: "")
                    .setView(input)
                    .setCancelable(true)
                    .setPositiveButton("موافق") { _, _ -> result?.confirm(input.text.toString()) }
                    .setNegativeButton("إلغاء") { _, _ -> result?.cancel() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            // نفس المشكلة تنطبق على confirm()/alert() لو استُخدمت لاحقاً في index.html —
            // نضيفها احتياطاً حتى لا يتكرر نفس العطل الصامت مستقبلاً.
            override fun onJsConfirm(
                view: WebView?,
                url: String?,
                message: String?,
                result: android.webkit.JsResult?
            ): Boolean {
                val ctx = view?.context ?: this@MainActivity
                AlertDialog.Builder(ctx)
                    .setMessage(message ?: "")
                    .setCancelable(true)
                    .setPositiveButton("موافق") { _, _ -> result?.confirm() }
                    .setNegativeButton("إلغاء") { _, _ -> result?.cancel() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            override fun onJsAlert(
                view: WebView?,
                url: String?,
                message: String?,
                result: android.webkit.JsResult?
            ): Boolean {
                val ctx = view?.context ?: this@MainActivity
                AlertDialog.Builder(ctx)
                    .setMessage(message ?: "")
                    .setCancelable(true)
                    .setPositiveButton("موافق") { _, _ -> result?.confirm() }
                    .setOnCancelListener { result?.confirm() }
                    .show()
                return true
            }
        }
    }

    fun sendToWebView(functionName: String, data: String) {
        runOnUiThread {
            webView.evaluateJavascript("window.$functionName($data)", null)
        }
    }

    override fun onDestroy() {
        if (::appInterface.isInitialized) {
            appInterface.releaseResources()
        }
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("AndroidBridge")
            webView.stopLoading()
            webView.loadUrl("about:blank")
            webView.destroy()
        }
        super.onDestroy()
    }
}
