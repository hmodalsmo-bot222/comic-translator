package com.comictrans.translation

import com.comictrans.model.BlockData

/**
 * Manages translation prompts based on comic type and context.
 */
object PromptManager {

    enum class ComicType {
        MANGA,      // Japanese right-to-left
        MANHWA,     // Korean vertical/webtoon
        WESTERN     // American/European left-to-right
    }

    /**
     * Comic-specific dictionary for consistent terminology.
     */
    data class ComicDictionary(
        val seriesName: String = "",
        val characterNames: Map<String, String> = emptyMap(),  // original -> translated
        val specialTerms: Map<String, String> = emptyMap(),    // original -> translated
        val recurringPhrases: Map<String, String> = emptyMap(),
        val notes: String = ""
    ) {
        fun toPromptSection(): String {
            val sections = mutableListOf<String>()

            if (seriesName.isNotEmpty()) {
                sections.add("Series: $seriesName")
            }

            if (characterNames.isNotEmpty()) {
                sections.add("Character Names:")
                characterNames.forEach { (orig, trans) ->
                    sections.add("  - $orig -> $trans")
                }
            }

            if (specialTerms.isNotEmpty()) {
                sections.add("Special Terms:")
                specialTerms.forEach { (orig, trans) ->
                    sections.add("  - $orig -> $trans")
                }
            }

            if (notes.isNotEmpty()) {
                sections.add("Notes: $notes")
            }

            return sections.joinToString("\n")
        }
    }

    /**
     * Page context for batch translation.
     */
    data class PageContext(
        val seriesName: String = "",
        val chapterNumber: Int = 0,
        val pageNumber: Int = 0,
        val previousSummary: String = "",
        val charactersPresent: List<String> = emptyList(),
        val comicType: ComicType = ComicType.MANGA,
        val dictionary: ComicDictionary = ComicDictionary()
    )

    /**
     * Build system prompt based on comic type.
     */
    fun buildSystemPrompt(type: ComicType, dictionary: ComicDictionary): String {
        val base = "You are a professional comic translator. Your task is to translate text from speech bubbles while preserving:\n" +
                "- Character personalities and speech patterns\n" +
                "- Emotional tone and emphasis\n" +
                "- Cultural references (adapted appropriately)\n" +
                "- Sound effects (translated or described)\n" +
                "- Honorifics and formality levels"

        val typeSpecific = when (type) {
            ComicType.MANGA -> "\n\nThis is a Japanese manga (read right-to-left).\n" +
                    "- Preserve Japanese honorifics (-san, -kun, -chan, -sama) when culturally relevant\n" +
                    "- Adapt sound effects (onomatopoeia) to English equivalents\n" +
                    "- Maintain vertical text flow indicators where needed\n" +
                    "- Keep Japanese names in Romaji unless dictionary specifies otherwise"

            ComicType.MANHWA -> "\n\nThis is a Korean manhwa/webtoon (read left-to-right, vertical scroll).\n" +
                    "- Preserve Korean honorifics (-ssi, -nim) when relevant\n" +
                    "- Adapt webtoon-style sound effects\n" +
                    "- Consider vertical scrolling context for text length\n" +
                    "- Keep Korean names in standard romanization"

            ComicType.WESTERN -> "\n\nThis is a Western comic (read left-to-right).\n" +
                    "- Maintain superhero/comic book terminology\n" +
                    "- Preserve alliteration and wordplay where possible\n" +
                    "- Adapt cultural references for target audience\n" +
                    "- Keep character names as established in canon"
        }

        val dictSection = if (dictionary.characterNames.isNotEmpty() || dictionary.specialTerms.isNotEmpty()) {
            "\n\nUSE THE FOLLOWING DICTIONARY (do not deviate from these translations):\n" + dictionary.toPromptSection()
        } else ""

        return base + typeSpecific + dictSection
    }

    /**
     * Build batch translation prompt for all bubbles in a page.
     */
    fun buildBatchPrompt(
        blocks: List<BlockData>,
        context: PageContext,
        targetLanguage: String
    ): String {
        val bubbleTexts = blocks.mapIndexed { index, block ->
            "[Bubble ${index + 1}]\n${block.text}"
        }.joinToString("\n\n")

        val contextInfo = buildString {
            if (context.seriesName.isNotEmpty()) appendLine("Series: ${context.seriesName}")
            if (context.chapterNumber > 0) appendLine("Chapter: ${context.chapterNumber}")
            if (context.pageNumber > 0) appendLine("Page: ${context.pageNumber}")
            if (context.previousSummary.isNotEmpty()) appendLine("Previous Events: ${context.previousSummary}")
            if (context.charactersPresent.isNotEmpty()) appendLine("Characters Present: ${context.charactersPresent.joinToString(", ")}")
        }

        val contextSection = if (contextInfo.isNotEmpty()) {
            "Context:\n$contextInfo\n\n"
        } else ""

        return "Translate the following speech bubbles from this comic page into $targetLanguage.\n\n" +
                contextSection +
                "Text to translate:\n" +
                bubbleTexts +
                "\n\nInstructions:\n" +
                "1. Translate each bubble maintaining the original meaning and tone\n" +
                "2. Keep character names consistent with the dictionary\n" +
                "3. Adapt cultural references naturally\n" +
                "4. Maintain appropriate text length for speech bubbles\n" +
                "5. Return ONLY the translations in this exact format:\n" +
                "   [Bubble 1] Translated text here\n" +
                "   [Bubble 2] Translated text here\n" +
                "   etc."
    }

    /**
     * Parse batch translation response.
     */
    fun parseBatchResponse(response: String, blockCount: Int): List<String> {
        val translations = mutableListOf<String>()
        val pattern = Regex("""\[Bubble\s*(\d+)\]\s*(.+)""")

        val matches = pattern.findAll(response).toList()

        // Create array sized to blockCount
        val result = Array(blockCount) { "" }

        matches.forEach { match ->
            val index = match.groupValues[1].toInt() - 1
            val text = match.groupValues[2].trim()
            if (index in 0 until blockCount) {
                result[index] = text
            }
        }

        return result.toList()
    }

    /**
     * Build single bubble prompt (fallback mode).
     */
    fun buildSinglePrompt(
        text: String,
        context: PageContext,
        targetLanguage: String,
        bubbleIndex: Int = 0,
        totalBubbles: Int = 1
    ): String {
        val position = if (totalBubbles > 1) " ($bubbleIndex/$totalBubbles)" else ""

        return "Translate this comic speech bubble$position into $targetLanguage:\n\n" +
                ""$text"\n\n" +
                "Context: ${context.seriesName.ifEmpty { "Comic page" }}, characters: ${context.charactersPresent.joinToString(", ").ifEmpty { "unknown" }}\n\n" +
                "Translate naturally while preserving tone and character voice."
    }
}
