# V17 — إصلاح تعليق OpenCV Inpaint + بطء AI Pro + وهم "Paddle مضمّن"

## 1) OpenCV Inpaint يعلّق ويُخرج التطبيق (السبب الجذري)
**الملف:** `app/src/main/java/com/comictrans/engine/ErasureEngine.kt` — `inpaintOpenCV()`

كانت الدالة تمرر `Mat` بـ4 قنوات (RGBA، ناتج `Utils.bitmapToMat()` المباشر) إلى
`Photo.inpaint()`، رغم أن هذه الدالة في OpenCV تتطلب صراحة `CV_8UC1` أو `CV_8UC3` فقط
(`CV_Assert` داخل `modules/photo/src/inpaint.cpp`). فشل هذا التأكيد يحدث على المستوى
الأصلي (native) عبر JNI ولا يتحوّل دائمًا لاستثناء Kotlin قابل للالتقاط — في الغالب يظهر
كتجمّد ثم انهيار كامل للعملية، وهو بالضبط العرض المُبلَّغ عنه. بما أن AI Lite وAI Pro
يرجعان تلقائيًا لـ `inpaintOpenCV()` عند أي فشل، فهذا نفس السبب وراء ظهور AI Pro وكأنه
"لا يمحو شيئًا" أحيانًا.

**الإصلاح:** تحويل الصورة RGBA→RGB (`Imgproc.cvtColor`) قبل `inpaint()`، ثم تحويل الناتج
مرة أخرى RGB→RGBA قبل بناء الـ Bitmap النهائي.

## 2) بطء AI Pro (ONNX)
**الملف:** `ErasureEngine.kt` — `getOrCreateOnnxSession()`

تم التحقق من تطابق مدخلات/مخرجات الجلسة (`image`/`mask`/`output`، 512×512) مع نموذج
Carve/LaMa-ONNX الفعلي — سليمة. البطء أصيل في تشغيل نموذج ثقيل (~208MB، طبقات Fourier)
على المعالج فقط، لكل فقاعة نص على حدة. تمت إضافة محاولة تفعيل **NNAPI** (تسريع عتادي عبر
DSP/GPU/NPU متى توفّر) مع رجوع آمن وصامت لـCPU إن لم يُدعم على الجهاز.

## 3) "PaddleOCR Lite مضمّن مع التطبيق" لم يكن صحيحًا
**الملفات:** `ModelManager.kt`, `OCREngine.kt`, `AppInterface.kt`, `index.html`,
`assets/paddle/README.md`

مجلد `assets/paddle/` لا يحتوي فعليًا det.nb/rec.nb/cls.nb/dict، ولا يوجد أي
`.github/workflows` في الحزمة لجلبها وقت البناء كما كان README القديم يفترض. رغم ذلك،
كانت واجهة `index.html` تعرض شارة "✅ مضمّن مع التطبيق" بشكل ثابت (hardcoded) بدون أي
تحقق فعلي.

**الإصلاح:**
- `ModelManager`: أُضيفت 4 مداخل حقيقية (`paddle_det`, `paddle_rec`, `paddle_cls`,
  `paddle_dict`) قابلة للتنزيل/الحذف بنفس آلية AI Lite/AI Pro، مع تخزينها في مجلد فرعي
  `models/paddle/`.
- `OCREngine.buildPaddleConfig()`: يتحقق أولاً من وجود الملفات الأربعة فعليًا في
  `assets/paddle`، وإلا يستخدم أي نسخة نزّلها المستخدم من تخزين الجهاز، وإلا يرجع بوضوح
  لـ ML Kit (بدل الفشل الصامت أو الادعاء الكاذب).
- `AppInterface.listModels()`: يرسل الآن حالة `bundled`/`downloaded` الحقيقية بعد فحص
  فعلي لمحتوى `assets/paddle`.
- `index.html`: أُزيل الافتراض الثابت `bundled: id.startsWith('paddle_')`، وأصبح لكل ملف
  (DET/REC/CLS/القاموس) زر "⬇️ تنزيل" مستقل يعمل فعليًا إن لم يكن الملف موجودًا.
- لم يُوضع رابط تنزيل افتراضي لملفات `.nb` لأنها مرتبطة بإصدار Paddle-Lite، وملف غير
  متوافق قد يسبب انهيارًا عند التحميل (مشكلة معروفة في مستودع PaddleOCR الرسمي). وُضع
  رابط رسمي آمن فقط لملف القاموس النصي (`ppocr_keys_v1.txt`) لأنه غير مرتبط بإصدار.
