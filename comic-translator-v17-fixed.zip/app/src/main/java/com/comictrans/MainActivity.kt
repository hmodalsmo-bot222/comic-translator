package com.comictrans

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.FileInputStream

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var appInterface: AppInterface

    // callback الذي يطلبه WebView لتسليم مسار الملف المُختار للصفحة
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        val results: Array<Uri>? = if (result.resultCode == RESULT_OK && data != null) {
            WebChromeClient.FileChooserParams.parseResult(result.resultCode, data)
        } else {
            null
        }
        fileChooserCallback?.onReceiveValue(results)
        fileChooserCallback = null
        val nativeUri = results?.firstOrNull()
        if (result.resultCode == RESULT_OK && nativeUri != null && ::appInterface.isInitialized) {
            val displayName = nativeUri.lastPathSegment?.substringAfterLast('/') ?: "comic.cbz"
            appInterface.loadComicFromUri(nativeUri, displayName)
        }
    }

    // "خلفية المجتمع" — Local Sync: تصدير/استيراد ذاكرة الترجمة كملف JSON بدون إنترنت،
    // المستخدم يشارك الملف يدوياً بين أجهزته (بلوتوث/تطبيق مشاركة/تخزين سحابي عادي).
    private var pendingExportData: String? = null
    private val exportFileLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        val data = pendingExportData
        pendingExportData = null
        if (uri == null || data == null) {
            appInterface.onLocalSyncResult(false, "تم إلغاء التصدير", null)
            return@registerForActivityResult
        }
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(data.toByteArray(Charsets.UTF_8)) }
            appInterface.onLocalSyncResult(true, "تم تصدير الذاكرة بنجاح إلى الملف المختار", null)
        } catch (e: Exception) {
            appInterface.onLocalSyncResult(false, "فشل الكتابة: ${e.message}", null)
        }
    }

    private val importFileLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) {
            appInterface.onLocalSyncResult(false, "تم إلغاء الاستيراد", null)
            return@registerForActivityResult
        }
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            if (text.isNullOrBlank()) {
                appInterface.onLocalSyncResult(false, "الملف فارغ أو تعذّرت قراءته", null)
            } else {
                appInterface.onLocalSyncResult(true, "تم استيراد الملف بنجاح", text)
            }
        } catch (e: Exception) {
            appInterface.onLocalSyncResult(false, "فشلت القراءة: ${e.message}", null)
        }
    }

    fun exportJsonToFile(data: String, suggestedName: String) {
        pendingExportData = data
        exportFileLauncher.launch(suggestedName)
    }

    fun importJsonFromFile() {
        importFileLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // تهيئة OpenCV — المشروع يستخدم حزمة Maven Central الرسمية (org.opencv:opencv:4.9.0)
        // وهذه الحزمة (منذ إصدار 4.9.0) تتطلب OpenCVLoader.initLocal() للتحميل الصحيح.
        // System.loadLibrary("opencv_java4") القديمة كانت تفشل بصمت مع هذه الحزمة، مما كان
        // يعطّل كل أوضاع الطمس المعتمدة على OpenCV (opencv / ai_lite / ai_pro) ويرجعها تلقائياً
        // لمربع أبيض احتياطي (fallbackErase) بدل الطمس الحقيقي.
        if (org.opencv.android.OpenCVLoader.initLocal()) {
            android.util.Log.d("OpenCV", "OpenCV loaded successfully")
            com.comictrans.engine.OpenCVStatus.isAvailable = true
        } else {
            android.util.Log.e("OpenCV", "OpenCV initialization failed — falling back to simple erase")
            com.comictrans.engine.OpenCVStatus.isAvailable = false
        }

        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        setupWebView()

        appInterface = AppInterface(this, webView)
        webView.addJavascriptInterface(appInterface, "AndroidBridge")

        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            // مُعطَّل عمداً: تكبير WebView المدمج (native pinch-zoom) كان يتصادم مع
            // تكبير القارئ المخصّص في JS (initReaderZoom في index.html). Android WebView
            // كان يعالج لفتتين الأصابع كإيماءة تكبير "بصرية" خاصة به (مستوى الـ compositor)،
            // فيبدو الأمر وكأنه تكبير فعلي أثناء إبقاء الأصابع، لكن فور رفعها كان WebView
            // يعيد ضبط/تخطيط الصفحة لمقاسها الطبيعي (لأن أبعاد المحتوى الفعلية ما تغيّرت)،
            // فيرجع كل شي "زي ما كان" — وهذا بالضبط العطل المُبلّغ عنه. تعطيل التكبير المدمج
            // هنا يسلّم التحكم بالكامل لكود JS (initReaderZoom) اللي يطبّق transform يدوي
            // ثابت لا يُلغى إلا بنقرة مزدوجة أو بتصفير صريح.
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val url = request?.url ?: return super.shouldInterceptRequest(view, request)
                if (url.scheme == "https" && url.host == "comic.local") {
                    val kind = url.pathSegments.firstOrNull()
                    val index = url.pathSegments.getOrNull(1)?.toIntOrNull() ?: return null
                    val file = if (::appInterface.isInitialized) {
                        when (kind) {
                            "page" -> appInterface.getNativePageFile(index)
                            "processed" -> appInterface.getProcessedPageFile(index)
                            else -> null
                        }
                    } else null
                    if (file != null && file.exists()) {
                        val mime = when (file.extension.lowercase()) {
                            "jpg", "jpeg" -> "image/jpeg"
                            "png" -> "image/png"
                            "webp" -> "image/webp"
                            "gif" -> "image/gif"
                            "bmp" -> "image/bmp"
                            else -> "application/octet-stream"
                        }
                        return try {
                            WebResourceResponse(
                                mime, null, 200, "OK",
                                mapOf("Access-Control-Allow-Origin" to "*"),
                                FileInputStream(file)
                            )
                        } catch (_: Exception) { null }
                    }
                }
                return super.shouldInterceptRequest(view, request)
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback
                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                return try {
                    fileChooserLauncher.launch(intent)
                    true
                } catch (e: Exception) {
                    fileChooserCallback = null
                    false
                }
            }
        }
    }

    fun sendToWebView(functionName: String, data: String) {
        runOnUiThread {
            webView.evaluateJavascript("window.$functionName($data)", null)
        }
    }

    override fun onDestroy() {
        if (::appInterface.isInitialized) {
            appInterface.releaseResources()
        }
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("AndroidBridge")
            webView.stopLoading()
            webView.loadUrl("about:blank")
            webView.destroy()
        }
        super.onDestroy()
    }
}
