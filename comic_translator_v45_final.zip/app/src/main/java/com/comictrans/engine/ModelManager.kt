package com.comictrans.engine

import android.content.Context
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

data class ModelInfo(
    val id: String,
    val displayName: String,
    val fileName: String,
    val url: String,
    val approxSizeMB: Int,
    val sha256: String? = null,
    val minValidBytes: Long = 1_000_000L,
    val category: ModelCategory = ModelCategory.GENERAL
)

enum class ModelCategory {
    AI_INPAINT, OCR_DETECTOR, OCR_RECOGNIZER, OCR_FULL, ENHANCEMENT, PADDLE_OCR, GENERAL
}

enum class DownloadState { NONE, DOWNLOADING, PAUSED, VERIFYING, COMPLETED, FAILED }

data class DownloadStatus(
    val modelId: String,
    val state: DownloadState,
    val progressPct: Int = 0,
    val message: String? = null
)

class ModelManager(private val context: Context) {

    private val TAG = "ModelManager"
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    private val modelsDir: File by lazy {
        File(context.getExternalFilesDir(null), "models").apply { mkdirs() }
    }

    val paddleModelsDir: File by lazy {
        File(modelsDir, "paddle").apply { mkdirs() }
    }

    private val prefs by lazy { context.getSharedPreferences("model_urls_v43", Context.MODE_PRIVATE) }

    val availableModels: List<ModelInfo>
        get() = listOf(
            // ═══ AI Inpainting ═══
            ModelInfo(
                id = "ai_pro",
                displayName = "AI Pro — LaMa ONNX (أدق)",
                fileName = "lama-pro.onnx",
                url = prefs.getString("url_ai_pro", DEFAULT_ONNX_URL) ?: DEFAULT_ONNX_URL,
                approxSizeMB = 208,
                sha256 = "1faef5301d78db7dda502fe59966957ec4b79dd64e16f03ed96913c7a4eb68d6",
                category = ModelCategory.AI_INPAINT
            ),
            ModelInfo(
                id = "ai_lite",
                displayName = "AI Lite — LaMa TFLite (أسرع)",
                fileName = "lama-lite.tflite",
                url = prefs.getString("url_ai_lite", DEFAULT_AI_LITE_URL) ?: DEFAULT_AI_LITE_URL,
                approxSizeMB = 183,
                category = ModelCategory.AI_INPAINT
            ),
            // ═══ OCR Detection ═══
            ModelInfo(
                id = "ocr_easyocr_det",
                displayName = "EasyOCR — Detector (كشف)",
                fileName = "easyocr_detector.tflite",
                url = prefs.getString("url_ocr_easyocr_det", DEFAULT_EASYOCR_DET_URL) ?: DEFAULT_EASYOCR_DET_URL,
                approxSizeMB = 17,
                minValidBytes = 5_000_000L,
                category = ModelCategory.OCR_DETECTOR
            ),
            ModelInfo(
                id = "ocr_easyocr_rec",
                displayName = "EasyOCR — Recognizer (قراءة)",
                fileName = "easyocr_recognizer.tflite",
                url = prefs.getString("url_ocr_easyocr_rec", DEFAULT_EASYOCR_REC_URL) ?: DEFAULT_EASYOCR_REC_URL,
                approxSizeMB = 4,
                minValidBytes = 1_000_000L,
                category = ModelCategory.OCR_RECOGNIZER
            ),
            ModelInfo(
                id = "det_craft_mobile",
                displayName = "CRAFT Mobile — كشف النص",
                fileName = "craft_mobile.tflite",
                url = prefs.getString("url_det_craft_mobile", DEFAULT_CRAFT_MOBILE_URL) ?: DEFAULT_CRAFT_MOBILE_URL,
                approxSizeMB = 8,
                minValidBytes = 5_000_000L,
                category = ModelCategory.OCR_DETECTOR
            ),
            ModelInfo(
                id = "det_east_320",
                displayName = "EAST — كشف النص (320x320)",
                fileName = "east_320.tflite",
                url = prefs.getString("url_det_east_320", DEFAULT_EAST_320_URL) ?: DEFAULT_EAST_320_URL,
                approxSizeMB = 25,
                minValidBytes = 20_000_000L,
                category = ModelCategory.OCR_DETECTOR
            ),
            ModelInfo(
                id = "det_east_640",
                displayName = "EAST — كشف النص (640x640)",
                fileName = "east_640.tflite",
                url = prefs.getString("url_det_east_640", DEFAULT_EAST_640_URL) ?: DEFAULT_EAST_640_URL,
                approxSizeMB = 25,
                minValidBytes = 20_000_000L,
                category = ModelCategory.OCR_DETECTOR
            ),
            ModelInfo(
                id = "det_east_1280",
                displayName = "EAST — كشف النص (1280x1280)",
                fileName = "east_1280.tflite",
                url = prefs.getString("url_det_east_1280", DEFAULT_EAST_1280_URL) ?: DEFAULT_EAST_1280_URL,
                approxSizeMB = 25,
                minValidBytes = 20_000_000L,
                category = ModelCategory.OCR_DETECTOR
            ),
            // ═══ PaddleOCR ═══
            ModelInfo(
                id = "paddle_det",
                displayName = "PaddleOCR — Detector",
                fileName = "det.nb",
                url = prefs.getString("url_paddle_det", DEFAULT_PADDLE_DET_URL) ?: DEFAULT_PADDLE_DET_URL,
                approxSizeMB = 3,
                minValidBytes = 50_000L,
                category = ModelCategory.PADDLE_OCR
            ),
            ModelInfo(
                id = "paddle_rec",
                displayName = "PaddleOCR — Recognizer",
                fileName = "rec.nb",
                url = prefs.getString("url_paddle_rec", DEFAULT_PADDLE_REC_URL) ?: DEFAULT_PADDLE_REC_URL,
                approxSizeMB = 10,
                minValidBytes = 50_000L,
                category = ModelCategory.PADDLE_OCR
            ),
            ModelInfo(
                id = "paddle_cls",
                displayName = "PaddleOCR — Classifier",
                fileName = "cls.nb",
                url = prefs.getString("url_paddle_cls", DEFAULT_PADDLE_CLS_URL) ?: DEFAULT_PADDLE_CLS_URL,
                approxSizeMB = 1,
                minValidBytes = 10_000L,
                category = ModelCategory.PADDLE_OCR
            ),
            ModelInfo(
                id = "paddle_dict",
                displayName = "PaddleOCR — قاموس الرموز",
                fileName = "ppocr_keys_v1.txt",
                url = prefs.getString("url_paddle_dict", DEFAULT_PADDLE_DICT_URL) ?: DEFAULT_PADDLE_DICT_URL,
                approxSizeMB = 1,
                minValidBytes = 1_000L,
                category = ModelCategory.PADDLE_OCR
            ),
            // ═══ Enhancement ═══
            ModelInfo(
                id = "enhance_ai",
                displayName = "Real-ESRGAN — تعزيز الصورة (x4)",
                fileName = "realesrgan-x4.tflite",
                url = prefs.getString("url_enhance_ai", DEFAULT_ENHANCE_AI_URL) ?: DEFAULT_ENHANCE_AI_URL,
                approxSizeMB = 67,
                minValidBytes = 50_000_000L,
                category = ModelCategory.ENHANCEMENT
            )
        )

    private val states = ConcurrentHashMap<String, DownloadState>()
    private val activeJobs = ConcurrentHashMap<String, Job>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val locks = ConcurrentHashMap<String, Mutex>()

    fun stateOf(modelId: String): DownloadState = states[modelId] ?: DownloadState.NONE
    fun modelFile(info: ModelInfo): File = File(modelsDir, info.fileName)

    fun isDownloaded(info: ModelInfo): Boolean {
        val file = modelFile(info)
        return file.exists() && file.length() >= info.minValidBytes
    }

    fun isDownloadedById(modelId: String): Boolean {
        val model = availableModels.find { it.id == modelId } ?: return false
        return isDownloaded(model)
    }

    fun setCustomUrl(modelId: String, url: String) {
        prefs.edit().putString("url_$modelId", url).apply()
    }

    fun startDownload(model: ModelInfo, onUpdate: (DownloadStatus) -> Unit = {}) {
        val existing = activeJobs[model.id]
        if (existing?.isActive == true) {
            Log.d(TAG, "تنزيل ${model.id} قيد التقدّم — تجاهل")
            return
        }
        val lock = locks.getOrPut(model.id) { Mutex() }
        val job = scope.launch {
            lock.withLock { downloadInternal(model, onUpdate) }
        }
        activeJobs[model.id] = job
        job.invokeOnCompletion { activeJobs.remove(model.id) }
    }

    private suspend fun downloadInternal(model: ModelInfo, onUpdate: (DownloadStatus) -> Unit) {
        val tmp = File(modelsDir, "${model.fileName}.part")
        val finalFile = modelFile(model)
        try {
            states[model.id] = DownloadState.DOWNLOADING
            val resumeOffset = if (tmp.exists()) tmp.length() else 0L
            val requestBuilder = Request.Builder().url(model.url)
            if (resumeOffset > 0) requestBuilder.header("Range", "bytes=$resumeOffset-")

            val response = client.newCall(requestBuilder.build()).execute()
            if (!response.isSuccessful && response.code != 206) throw IOException("HTTP ${response.code}")

            val body = response.body ?: throw IOException("لا يوجد محتوى")
            val contentLength = body.contentLength()
            val totalBytes = if (response.code == 206 && contentLength > 0) resumeOffset + contentLength
                else if (contentLength > 0) contentLength
                else model.approxSizeMB * 1_000_000L

            val appendMode = response.code == 206
            if (!appendMode && resumeOffset > 0) { tmp.delete() }

            val sink = FileOutputStream(tmp, appendMode).buffered()
            val source = body.byteStream()
            var downloaded = if (appendMode) resumeOffset else 0L
            val buffer = ByteArray(256 * 1024)
            var lastProgress = -1
            var lastUpdateTime = System.currentTimeMillis()

            while (currentCoroutineContext().isActive) {
                val read = source.read(buffer)
                if (read == -1) break
                sink.write(buffer, 0, read)
                downloaded += read
                val now = System.currentTimeMillis()
                val progress = ((downloaded * 100) / totalBytes.coerceAtLeast(1)).toInt()
                if (progress != lastProgress && (now - lastUpdateTime > 500 || progress - lastProgress >= 2)) {
                    lastProgress = progress; lastUpdateTime = now
                    onUpdate(DownloadStatus(model.id, DownloadState.DOWNLOADING, progress, "جارٍ التنزيل... $progress%"))
                }
            }
            sink.flush(); sink.close(); source.close()

            if (!currentCoroutineContext().isActive) {
                states[model.id] = DownloadState.PAUSED
                onUpdate(DownloadStatus(model.id, DownloadState.PAUSED, lastProgress.coerceAtLeast(0), "تم الإيقاف المؤقت"))
                return
            }

            states[model.id] = DownloadState.VERIFYING
            onUpdate(DownloadStatus(model.id, DownloadState.VERIFYING, 100, "جارٍ التحقق..."))

            if (tmp.length() < model.minValidBytes) {
                tmp.delete()
                states[model.id] = DownloadState.FAILED
                onUpdate(DownloadStatus(model.id, DownloadState.FAILED, 0, "الملف أصغر من المتوقع"))
                return
            }

            if (model.sha256 != null) {
                val digest = MessageDigest.getInstance("SHA-256")
                tmp.inputStream().use { ins ->
                    val buf = ByteArray(256 * 1024)
                    while (true) { val n = ins.read(buf); if (n == -1) break; digest.update(buf, 0, n) }
                }
                val hex = digest.digest().joinToString("") { "%02x".format(it) }
                if (!hex.equals(model.sha256, ignoreCase = true)) {
                    tmp.delete()
                    states[model.id] = DownloadState.FAILED
                    onUpdate(DownloadStatus(model.id, DownloadState.FAILED, 0, "فشل التحقق من سلامة الملف"))
                    return
                }
            }

            finalFile.delete()
            if (!tmp.renameTo(finalFile)) {
                tmp.inputStream().use { input ->
                    finalFile.outputStream().use { output -> input.copyTo(output) }
                }
                tmp.delete()
            }

            states[model.id] = DownloadState.COMPLETED
            onUpdate(DownloadStatus(model.id, DownloadState.COMPLETED, 100, "تم التنزيل بنجاح"))

        } catch (e: CancellationException) {
            states[model.id] = DownloadState.PAUSED
            onUpdate(DownloadStatus(model.id, DownloadState.PAUSED,
                ((tmp.length() * 100) / (model.approxSizeMB * 1_000_000L).coerceAtLeast(1)).toInt(),
                "تم الإيقاف المؤقت"))
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "فشل تنزيل ${model.id}", e)
            states[model.id] = DownloadState.FAILED
            onUpdate(DownloadStatus(model.id, DownloadState.FAILED, 0, e.message ?: "فشل التنزيل"))
        }
    }

    fun pauseDownload(modelId: String) { activeJobs[modelId]?.cancel() }
    fun cancelDownload(modelId: String) {
        scope.launch {
            activeJobs[modelId]?.cancelAndJoin()
            val model = availableModels.find { it.id == modelId }
            if (model != null) File(modelsDir, "${model.fileName}.part").delete()
            states[modelId] = DownloadState.NONE
        }
    }
    fun release() { scope.cancel(); activeJobs.values.forEach { it.cancel() } }

    companion object {
        private const val DEFAULT_ONNX_URL = "https://huggingface.co/Carve/LaMa-ONNX/resolve/main/lama_fp32.onnx"
        private const val DEFAULT_AI_LITE_URL = "https://huggingface.co/qualcomm/LaMa-Dilated/resolve/ab898502c9bd764a50eb2719a309694b43eae658/LaMa-Dilated.tflite"
        private const val DEFAULT_ENHANCE_AI_URL = "https://huggingface.co/qualcomm/Real-ESRGAN-x4plus/resolve/5f4491334213711be70a6253a600aa3dad2c6927/Real-ESRGAN-x4plus.tflite"
        private const val DEFAULT_CRAFT_MOBILE_URL = "https://tfhub.dev/tulasiram58827/lite-model/craft-text-detector/dr/1?lite-format=tflite"
        private const val PADDLE_BASE_URL = "https://raw.githubusercontent.com/equationl/paddleocr4android/8f3e2a1c9d4b2e1f0a9c8d7e6b5a4c3d2e1f0a9/app/src/main/assets/models/ch_PP-OCRv4"
        private const val DEFAULT_PADDLE_DET_URL = "$PADDLE_BASE_URL/det.nb"
        private const val DEFAULT_PADDLE_REC_URL = "$PADDLE_BASE_URL/rec.nb"
        private const val DEFAULT_PADDLE_CLS_URL = "$PADDLE_BASE_URL/cls.nb"
        private const val DEFAULT_PADDLE_DICT_URL = "https://raw.githubusercontent.com/PaddlePaddle/PaddleOCR/release/2.7/ppocr/utils/ppocr_keys_v1.txt"
        private const val DEFAULT_EASYOCR_DET_URL = "https://tfhub.dev/sayakpaul/lite-model/east-text-detector/fp16/1?lite-format=tflite"
        private const val DEFAULT_EASYOCR_REC_URL = "https://github.com/tulasiram58827/craft_tflite/raw/main/models/crnn_float16.tflite"
        private const val DEFAULT_EAST_320_URL = "https://github.com/tulasiram58827/craft_tflite/raw/main/models/east/east_float_320.tflite"
        private const val DEFAULT_EAST_640_URL = "https://github.com/tulasiram58827/craft_tflite/raw/main/models/east/east_float_640.tflite"
        private const val DEFAULT_EAST_1280_URL = "https://github.com/tulasiram58827/craft_tflite/raw/main/models/east/east_float_1280.tflite"
    }
}
