package com.comictrans.engine.contracts

import android.content.Context
import android.graphics.Bitmap
import com.comictrans.engine.ModelManager
import com.comictrans.model.BlockData

/**
 * بند 11 (Module Split) — عقود (Interfaces) لمحركات AI الثقيلة.
 * app يعرف فقط "الشكل"، والتنفيذ الفعلي في feature_ai ويُحمَّل وقت التشغيل عبر Reflection.
 */

interface IOcrEngine {
    suspend fun recognizeMLKit(bitmap: Bitmap): List<BlockData>
    suspend fun recognizePaddleLite(bitmap: Bitmap): List<BlockData>
    suspend fun recognizeTesseract(bitmap: Bitmap): List<BlockData>
    suspend fun recognizeOCRSpace(bitmap: Bitmap, apiKey: String): List<BlockData>
    suspend fun recognizeCloud(bitmap: Bitmap, apiUrl: String): List<BlockData>

    /** CRAFT Mobile — كشف فقط، ثم ML Kit للقراءة */
    suspend fun recognizeCraftMobile(bitmap: Bitmap): List<BlockData>

    /** EAST Text Detector — كشف فقط (3 أحجام: 320/640/1280) */
    suspend fun recognizeEast(bitmap: Bitmap, modelId: String): List<BlockData>

    /** ⭐ EasyOCR — كشف + قراءة (مُنفَّذ بالكامل) */
    suspend fun recognizeEasyOCR(bitmap: Bitmap): List<BlockData>
}

interface IErasureEngine {
    fun processBitmap(bitmap: Bitmap, blocks: List<BlockData>, mode: String, bubbleAware: Boolean = false): Bitmap?
    fun close()
}

data class EnhanceResult(val bitmap: Bitmap, val scale: Float)

interface IImageEnhanceEngine {
    fun enhance(bitmap: Bitmap, method: String): EnhanceResult
}

// ================= Factories =================

interface IOcrEngineFactory {
    fun create(context: Context, modelManager: ModelManager): IOcrEngine
}

interface IErasureEngineFactory {
    fun create(context: Context, modelManager: ModelManager): IErasureEngine
}

interface IImageEnhanceEngineFactory {
    fun create(context: Context, modelManager: ModelManager): IImageEnhanceEngine
}

interface IOpenCvInitializer {
    fun initialize(): Boolean
}
