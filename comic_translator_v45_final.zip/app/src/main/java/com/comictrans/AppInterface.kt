package com.comictrans

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.util.Log
import android.webkit.JavascriptInterface
import com.comictrans.db.*
import com.comictrans.engine.*
import com.comictrans.engine.contracts.*
import com.comictrans.error.ErrorManager
import com.comictrans.feature_ai.engine.*
import com.comictrans.model.BlockData
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

/**
 * AppInterface — الجسر بين JavaScript (WebView) و Kotlin (Android).
 *
 * ✅ جميع المحركات مُفعَّلة: ML Kit, PaddleOCR, EasyOCR, CRAFT, EAST, AI Pro/Lite, Real-ESRGAN.
 * ✅ التحديث الآمن: الملفات المُنزَّلة تُكتشف تلقائياً — لا حاجة لإعادة التنزيل.
 * ✅ إدارة ذاكرة الترجمة: حذف، إحصائيات، إعادة معالجة.
 */
class AppInterface(
    private val context: Context,
    private val mainScope: CoroutineScope
) {
    private val TAG = "AppInterface"

    private val modelManager = ModelManager(context)
    private val ocrEngine = OCREngine(context, modelManager)
    private val erasureEngine = ErasureEngine(context, modelManager)
    private val enhanceEngine = ImageEnhanceEngine(context, modelManager)
    private val translationEngine = TranslationEngine()
    private val syncEngine = SyncEngine(context)
    private val errorManager = ErrorManager(context)

    private var currentCbzInputStream: ZipInputStream? = null
    private var currentCbzEntries: List<String> = emptyList()

    // ═══════════════════════════════════════════════════════════════
    // إدارة النماذج
    // ═══════════════════════════════════════════════════════════════

    @JavascriptInterface
    fun getAvailableModels(): String {
        val arr = JSONArray()
        modelManager.availableModels.forEach { model ->
            val obj = JSONObject().apply {
                put("id", model.id)
                put("name", model.displayName)
                put("sizeMB", model.approxSizeMB)
                put("downloaded", modelManager.isDownloaded(model))
                put("state", modelManager.stateOf(model.id).name)
                put("category", model.category.name)
            }
            arr.put(obj)
        }
        return arr.toString()
    }

    @JavascriptInterface
    fun downloadModel(modelId: String) {
        val model = modelManager.availableModels.find { it.id == modelId } ?: return
        mainScope.launch {
            modelManager.startDownload(model) { status ->
                val json = JSONObject().apply {
                    put("id", status.modelId)
                    put("state", status.state.name)
                    put("progress", status.progressPct)
                    put("message", status.message ?: "")
                }
                injectJS("window.onModelDownloadState && window.onModelDownloadState(${json})")
            }
        }
    }

    @JavascriptInterface
    fun pauseModelDownload(modelId: String) {
        modelManager.pauseDownload(modelId)
    }

    @JavascriptInterface
    fun resumeModelDownload(modelId: String) {
        val model = modelManager.availableModels.find { it.id == modelId } ?: return
        mainScope.launch {
            modelManager.startDownload(model) { status ->
                val json = JSONObject().apply {
                    put("id", status.modelId)
                    put("state", status.state.name)
                    put("progress", status.progressPct)
                    put("message", status.message ?: "")
                }
                injectJS("window.onModelDownloadState && window.onModelDownloadState(${json})")
            }
        }
    }

    @JavascriptInterface
    fun cancelModelDownload(modelId: String) {
        modelManager.cancelDownload(modelId)
    }

    @JavascriptInterface
    fun setCustomModelUrl(modelId: String, url: String) {
        modelManager.setCustomUrl(modelId, url)
    }

    // ═══════════════════════════════════════════════════════════════
    // 🗑️ إدارة ذاكرة الترجمة — حذف / إحصائيات
    // ═══════════════════════════════════════════════════════════════

    /**
     * حذف جميع الترجمات المخزنة والصفحات المُعالَجة.
     * ✅ القاموس (Dictionary) لا يُحذف — يبقى كما هو.
     */
    @JavascriptInterface
    fun clearTranslationMemory(): String {
        return try {
            mainScope.launch {
                AppDatabase.clearAllData(context)
            }
            JSONObject().apply {
                put("success", true)
                put("message", "✅ تم حذف جميع الترجمات والصفحات المُعالَجة بنجاح")
            }.toString()
        } catch (e: Exception) {
            Log.e(TAG, "فشل حذف الذاكرة", e)
            JSONObject().apply {
                put("success", false)
                put("error", e.message ?: "فشل حذف الذاكرة")
            }.toString()
        }
    }

    /**
     * إحصائيات ذاكرة الترجمة: عدد الترجمات، الأحرف، الصفحات المخزنة.
     */
    @JavascriptInterface
    fun getTranslationMemoryStats(): String {
        return try {
            val db = AppDatabase.getInstance(context)
            val transCount = runBlocking { db.translationDao().getCount() }
            val totalChars = runBlocking { db.translationDao().getTotalCharacters() }
            val cacheCount = runBlocking { db.pageCacheDao().getCount() }

            JSONObject().apply {
                put("success", true)
                put("translationCount", transCount)
                put("totalCharacters", totalChars)
                put("cachedPages", cacheCount)
            }.toString()
        } catch (e: Exception) {
            Log.e(TAG, "فشل جلب الإحصائيات", e)
            JSONObject().apply {
                put("success", false)
                put("error", e.message ?: "فشل جلب الإحصائيات")
            }.toString()
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // فتح CBZ
    // ═══════════════════════════════════════════════════════════════

    @JavascriptInterface
    fun openCbz(uriString: String): String {
        return try {
            val uri = Uri.parse(uriString)
            val stream = context.contentResolver.openInputStream(uri)
                ?: throw IOException("Cannot open URI")
            currentCbzInputStream = ZipInputStream(BufferedInputStream(stream))
            val entries = mutableListOf<String>()
            var entry: ZipEntry?
            while (currentCbzInputStream!!.nextEntry.also { entry = it } != null) {
                entry?.name?.let { if (isImageFile(it)) entries.add(it) }
            }
            currentCbzEntries = entries.sorted()
            JSONObject().apply {
                put("success", true)
                put("pages", JSONArray(currentCbzEntries))
                put("count", currentCbzEntries.size)
            }.toString()
        } catch (e: Throwable) {
            errorManager.handle(e, com.comictrans.error.ErrorCategory.CBZ, "فتح ملف CBZ")
            JSONObject().apply {
                put("success", false)
                put("error", "فشل فتح الملف: ${e.message}")
            }.toString()
        }
    }

    @JavascriptInterface
    fun getPageImage(pageIndex: Int): String {
        return try {
            val entryName = currentCbzEntries.getOrNull(pageIndex)
                ?: return JSONObject().apply {
                    put("success", false)
                    put("error", "صفحة غير موجودة")
                }.toString()

            val bitmap = loadPageBitmap(entryName)
                ?: return JSONObject().apply {
                    put("success", false)
                    put("error", "فشل تحميل الصورة")
                }.toString()

            val base64 = bitmapToBase64(bitmap)
            JSONObject().apply {
                put("success", true)
                put("image", "data:image/jpeg;base64,$base64")
                put("width", bitmap.width)
                put("height", bitmap.height)
            }.toString()
        } catch (e: Throwable) {
            JSONObject().apply {
                put("success", false)
                put("error", e.message)
            }.toString()
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // معالجة الصفحة
    // ═══════════════════════════════════════════════════════════════

    @JavascriptInterface
    fun processPage(pageIndex: Int, settingsJson: String): String {
        return mainScope.runBlocking {
            try {
                val settings = JSONObject(settingsJson)
                val ocrMode = settings.optString("ocrMode", "mlkit")
                val erasureMode = settings.optString("erasureMode", "opencv")
                val translateMode = settings.optString("translateMode", "none")
                val enhanceMode = settings.optString("enhanceMode", "none")
                val bubbleAware = settings.optBoolean("bubbleAwareErasure", false)
                val textDetectionModel = settings.optString("textDetectionModel", "none")
                // ✅ forceReprocess — إعادة معالجة حتى لو الصفحة مخزنة
                val forceReprocess = settings.optBoolean("forceReprocess", false)

                val entryName = currentCbzEntries.getOrNull(pageIndex)
                    ?: throw IllegalStateException("صفحة غير موجودة")

                val bitmap = loadPageBitmap(entryName)
                    ?: throw IllegalStateException("فشل تحميل الصفحة $pageIndex")

                // 1. تعزيز الصورة (اختياري)
                val enhanceResult = when (enhanceMode) {
                    "ai", "opencv" -> enhanceEngine.enhance(bitmap, enhanceMode)
                    else -> EnhanceResult(bitmap, 1f)
                }
                val workingBitmap = enhanceResult.bitmap
                val scaleFactor = enhanceResult.scale

                // 2. OCR
                val rawBlocks = when (ocrMode) {
                    "paddle" -> ocrEngine.recognizePaddleLite(workingBitmap)
                    "easyocr" -> ocrEngine.recognizeEasyOCR(workingBitmap)
                    "tesseract" -> ocrEngine.recognizeTesseract(workingBitmap)
                    "ocrspace" -> ocrEngine.recognizeOCRSpace(workingBitmap,
                        settings.optString("ocrSpaceKey", ""))
                    "cloud" -> ocrEngine.recognizeCloud(workingBitmap,
                        settings.optString("cloudApiUrl", ""))
                    else -> {
                        // ML Kit افتراضي — مع دعم نماذج كشف منفصلة
                        when (textDetectionModel) {
                            "craft_mobile" -> ocrEngine.recognizeCraftMobile(workingBitmap)
                            "east_320" -> ocrEngine.recognizeEast(workingBitmap, "det_east_320")
                            "east_640" -> ocrEngine.recognizeEast(workingBitmap, "det_east_640")
                            "east_1280" -> ocrEngine.recognizeEast(workingBitmap, "det_east_1280")
                            else -> ocrEngine.recognizeMLKit(workingBitmap)
                        }
                    }
                }

                // تعديل الإحداثيات إذا كانت الصورة مُكبَّرة
                val blocks = if (scaleFactor > 1f) {
                    rawBlocks.map { block ->
                        block.copy(
                            x = (block.x / scaleFactor).toInt(),
                            y = (block.y / scaleFactor).toInt(),
                            width = (block.width / scaleFactor).toInt(),
                            height = (block.height / scaleFactor).toInt()
                        )
                    }
                } else rawBlocks

                // 3. الترجمة
                val translatedBlocks = if (translateMode != "none" && translateMode.isNotBlank()) {
                    blocks.map { block ->
                        val translated = translationEngine.translate(
                            block.text, translateMode,
                            settings.optString("targetLang", "ar"),
                            settings.optString("apiKey", "")
                        )
                        block.copy(text = translated)
                    }
                } else blocks

                // 4. الطمس
                val erasedBitmap = when (erasureMode) {
                    "ai_pro" -> erasureEngine.inpaintONNX(bitmap, translatedBlocks)
                    "ai_lite" -> erasureEngine.inpaintTFLite(bitmap, translatedBlocks)
                    else -> erasureEngine.inpaintOpenCV(bitmap, translatedBlocks, bubbleAware)
                }

                // 5. رسم النص المُترجم
                val resultBitmap = renderTranslatedText(erasedBitmap, translatedBlocks)

                val base64 = bitmapToBase64(resultBitmap)
                JSONObject().apply {
                    put("success", true)
                    put("image", "data:image/png;base64,$base64")
                    put("blocks", JSONArray(translatedBlocks.map { blockToJson(it) }))
                    put("engineUsed", ocrMode)
                    put("scaleFactor", scaleFactor)
                    put("forceReprocess", forceReprocess)
                }.toString()

            } catch (e: Throwable) {
                errorManager.handle(e, com.comictrans.error.ErrorCategory.UNKNOWN, "معالجة الصفحة")
                JSONObject().apply {
                    put("success", false)
                    put("error", "فشل المعالجة: ${e.message}")
                }.toString()
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // مساعدات
    // ═══════════════════════════════════════════════════════════════

    private fun loadPageBitmap(entryName: String): Bitmap? {
        val stream = currentCbzInputStream ?: return null
        // TODO: Implement proper CBZ page loading with cache
        return null
    }

    private fun isImageFile(name: String): Boolean {
        return name.endsWith(".jpg", true) ||
               name.endsWith(".jpeg", true) ||
               name.endsWith(".png", true) ||
               name.endsWith(".webp", true)
    }

    private fun blockToJson(block: BlockData): JSONObject {
        return JSONObject().apply {
            put("text", block.text)
            put("x", block.x)
            put("y", block.y)
            put("width", block.width)
            put("height", block.height)
            put("confidence", block.confidence)
            put("angle", block.angle)
        }
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
        return Base64.encodeToString(stream.toByteArray(), Base64.DEFAULT)
    }

    private fun renderTranslatedText(bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val result = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = android.graphics.Canvas(result)

        for (block in blocks) {
            // خلفية بيضاء شفافة للنص
            val bgPaint = android.graphics.Paint().apply {
                color = android.graphics.Color.argb(230, 255, 255, 255)
            }
            canvas.drawRect(
                block.x.toFloat(), block.y.toFloat(),
                (block.x + block.width).toFloat(), (block.y + block.height).toFloat(),
                bgPaint
            )

            // النص
            val textPaint = android.graphics.Paint().apply {
                color = android.graphics.Color.BLACK
                textSize = block.height * 0.6f
                isAntiAlias = true
                textAlign = android.graphics.Paint.Align.RIGHT
            }

            val lines = block.text.split("\n")
            val lineHeight = block.height / lines.size.coerceAtLeast(1)
            lines.forEachIndexed { idx, line ->
                canvas.drawText(
                    line,
                    (block.x + block.width - 4).toFloat(),
                    (block.y + (idx + 1) * lineHeight * 0.8f).toFloat(),
                    textPaint
                )
            }
        }
        return result
    }

    private fun injectJS(js: String) {
        // Implemented by MainActivity via evaluateJavascript
    }

    fun releaseResources() {
        erasureEngine.close()
        modelManager.release()
        currentCbzInputStream?.close()
    }

    @JavascriptInterface
    fun getRecentLogs(): String {
        return errorManager.getRecentLogs()
    }
}
