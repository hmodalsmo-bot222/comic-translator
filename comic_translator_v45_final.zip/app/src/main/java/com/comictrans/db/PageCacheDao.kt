package com.comictrans.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface PageCacheDao {

    @Query("SELECT * FROM page_cache WHERE comicHash = :comicHash AND pageNumber = :pageNumber AND settingsFingerprint = :fingerprint LIMIT 1")
    suspend fun find(comicHash: String, pageNumber: Int, fingerprint: String): PageCacheEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: PageCacheEntity)

    @Query("DELETE FROM page_cache WHERE comicHash = :comicHash")
    suspend fun clearForComic(comicHash: String)

    // تقليم دوري يمنع نمو قاعدة الكاش للأبد — نفس فكرة TranslationDao.trimOld()، يبقي فقط
    // أحدث 2000 صفحة مُعالَجة عبر كل الكوميكس.
    @Query("DELETE FROM page_cache WHERE id NOT IN (SELECT id FROM page_cache ORDER BY processingDate DESC LIMIT 2000)")
    suspend fun trimOld()

    // ✅ حذف جميع الصفحات المُعالَجة (زر "حذف ذاكرة الترجمة")
    @Query("DELETE FROM page_cache")
    suspend fun deleteAll()

    // ✅ عدد الصفحات المخزنة
    @Query("SELECT COUNT(*) FROM page_cache")
    suspend fun getCount(): Int
}
