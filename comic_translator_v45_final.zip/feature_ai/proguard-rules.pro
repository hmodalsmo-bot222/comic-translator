# ProGuard rules for feature_ai module
# الحفاظ على كلاسات الـ Factories لأنها تُحمَّل عبر Reflection
-keep class com.comictrans.feature_ai.engine.** { *; }
-keepclassmembers class com.comictrans.feature_ai.engine.** { *; }

# الحفاظ على واجهات العقود
-keep interface com.comictrans.engine.contracts.** { *; }
