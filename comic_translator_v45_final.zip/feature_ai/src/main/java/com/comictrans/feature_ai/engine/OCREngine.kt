package com.comictrans.feature_ai.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Log
import com.comictrans.engine.ModelManager
import com.comictrans.engine.OpenCVStatus
import com.comictrans.engine.contracts.IOcrEngine
import com.comictrans.model.BlockData
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.equationl.paddleocr4android.OCR
import com.equationl.paddleocr4android.OcrConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import org.tensorflow.lite.Interpreter
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.max
import kotlin.math.min

class OCREngine(private val context: Context, private val modelManager: ModelManager) : IOcrEngine {

    private val paddleOcr = OCR(context)
    @Volatile private var paddleInitialized = false
    private val paddleLock = Any()
    private val client = OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()

    private val craftLock = Any(); @Volatile private var craftInterpreter: Interpreter? = null
    private val eastLock = Any(); @Volatile private var eastInterpreter: Interpreter? = null; @Volatile private var eastModelSize: Int = 0
    private val easyocrLock = Any(); @Volatile private var easyocrDetInterpreter: Interpreter? = null; @Volatile private var easyocrRecInterpreter: Interpreter? = null

    private val easyocrChars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~ "

    // ═══ ML Kit ═══
    override suspend fun recognizeMLKit(bitmap: Bitmap): List<BlockData> = withContext(Dispatchers.IO) {
        suspendCancellableCoroutine { continuation ->
            val image = InputImage.fromBitmap(bitmap, 0)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    val blocks = visionText.textBlocks.flatMap { block ->
                        block.lines.map { line ->
                            val rect = line.boundingBox
                            BlockData(text = line.text, x = rect?.left ?: 0, y = rect?.top ?: 0,
                                width = rect?.width() ?: 100, height = rect?.height() ?: 30,
                                confidence = line.confidence)
                        }
                    }
                    continuation.resume(mergeIntoComicBlocks(blocks, bitmap.width, bitmap.height))
                    recognizer.close()
                }
                .addOnFailureListener { e -> recognizer.close(); continuation.resumeWithException(e) }
        }
    }

    // ═══ CRAFT Mobile ═══
    override suspend fun recognizeCraftMobile(bitmap: Bitmap): List<BlockData> = withContext(Dispatchers.IO) {
        val modelFile = modelManager.availableModels.find { it.id == "det_craft_mobile" }?.let { modelManager.modelFile(it) }
        if (modelFile == null || !modelFile.exists()) { Log.w("CRAFT", "غير منزّل"); return@withContext recognizeMLKit(bitmap) }
        val boxes = try { runCraftDetection(bitmap, modelFile) } catch (e: Throwable) { Log.e("CRAFT", "فشل", e); null }
        if (boxes.isNullOrEmpty()) return@withContext recognizeMLKit(bitmap)
        val blocks = boxes.mapNotNull { rect ->
            val text = recognizeTextInRegion(bitmap, rect)?.trim()
            if (text.isNullOrBlank()) null else BlockData(text = text, x = rect.left, y = rect.top, width = rect.width(), height = rect.height())
        }
        mergeIntoComicBlocks(blocks, bitmap.width, bitmap.height)
    }

    // ═══ EAST ═══
    override suspend fun recognizeEast(bitmap: Bitmap, modelId: String): List<BlockData> = withContext(Dispatchers.IO) {
        val modelFile = modelManager.availableModels.find { it.id == modelId }?.let { modelManager.modelFile(it) }
        if (modelFile == null || !modelFile.exists()) return@withContext recognizeMLKit(bitmap)
        val boxes = try { runEASTDetection(bitmap, modelFile, modelId) } catch (e: Throwable) { Log.e("EAST", "فشل", e); return@withContext recognizeMLKit(bitmap) }
        if (boxes.isEmpty()) return@withContext recognizeMLKit(bitmap)
        val blocks = boxes.mapNotNull { rect ->
            val text = recognizeTextInRegion(bitmap, rect)?.trim()
            if (text.isNullOrBlank()) null else BlockData(text = text, x = rect.left, y = rect.top, width = rect.width(), height = rect.height())
        }
        mergeIntoComicBlocks(blocks, bitmap.width, bitmap.height)
    }

    // ═══ EasyOCR — مُنفَّذ بالكامل ═══
    override suspend fun recognizeEasyOCR(bitmap: Bitmap): List<BlockData> = withContext(Dispatchers.IO) {
        val detFile = modelManager.availableModels.find { it.id == "ocr_easyocr_det" }?.let { modelManager.modelFile(it) }
        val recFile = modelManager.availableModels.find { it.id == "ocr_easyocr_rec" }?.let { modelManager.modelFile(it) }
        if (detFile == null || !detFile.exists() || recFile == null || !recFile.exists()) {
            Log.w("EasyOCR", "نماذج ناقصة — رجوع لـ ML Kit"); return@withContext recognizeMLKit(bitmap)
        }
        val detInterpreter = synchronized(easyocrLock) {
            easyocrDetInterpreter ?: Interpreter(loadModelFile(detFile)).also { easyocrDetInterpreter = it }
        }
        val recInterpreter = try {
            synchronized(easyocrLock) {
                easyocrRecInterpreter ?: Interpreter(loadModelFile(recFile)).also { easyocrRecInterpreter = it }
            }
        } catch (e: Throwable) { Log.e("EasyOCR", "فشل تحميل Recognizer", e); return@withContext recognizeMLKit(bitmap) }

        try {
            val inputSize = 320
            val resized = Bitmap.createScaledBitmap(bitmap, inputSize, inputSize, true)
            val inputBuffer = ByteBuffer.allocateDirect(4 * inputSize * inputSize * 3).order(ByteOrder.nativeOrder())
            val pixels = IntArray(inputSize * inputSize)
            resized.getPixels(pixels, 0, inputSize, 0, 0, inputSize, inputSize)
            for (y in 0 until inputSize) {
                for (x in 0 until inputSize) {
                    val p = pixels[y * inputSize + x]
                    inputBuffer.putFloat(((p shr 16) and 0xFF) / 255f)
                    inputBuffer.putFloat(((p shr 8) and 0xFF) / 255f)
                    inputBuffer.putFloat((p and 0xFF) / 255f)
                }
            }
            inputBuffer.rewind(); resized.recycle()

            val outputBuffer = ByteBuffer.allocateDirect(4 * inputSize * inputSize).order(ByteOrder.nativeOrder())
            detInterpreter.run(inputBuffer, outputBuffer); outputBuffer.rewind()

            val scoreMap = Array(inputSize) { FloatArray(inputSize) }
            for (y in 0 until inputSize) { for (x in 0 until inputSize) { scoreMap[y][x] = outputBuffer.float } }

            val detBoxes = extractBoxesFromScoreMap(scoreMap, 0.6f, bitmap.width, bitmap.height, inputSize)
            if (detBoxes.isEmpty()) { Log.w("EasyOCR", "لا يوجد نص — رجوع لـ ML Kit"); return@withContext recognizeMLKit(bitmap) }

            val blocks = mutableListOf<BlockData>()
            for (box in detBoxes) {
                val crop = try {
                    Bitmap.createBitmap(bitmap, box.left.coerceIn(0, bitmap.width - 1), box.top.coerceIn(0, bitmap.height - 1),
                        box.width().coerceAtMost(bitmap.width - box.left), box.height().coerceAtMost(bitmap.height - box.top))
                } catch (e: Throwable) { continue }
                val text = recognizeWithCRNN(crop, recInterpreter); crop.recycle()
                if (!text.isNullOrBlank()) blocks.add(BlockData(text = text, x = box.left, y = box.top, width = box.width(), height = box.height(), confidence = 0.85f))
            }
            if (blocks.isEmpty()) return@withContext recognizeMLKit(bitmap)
            mergeIntoComicBlocks(blocks, bitmap.width, bitmap.height)
        } catch (e: Throwable) { Log.e("EasyOCR", "فشل — رجوع لـ ML Kit", e); recognizeMLKit(bitmap) }
    }

    private fun recognizeWithCRNN(crop: Bitmap, interpreter: Interpreter): String? {
        val targetH = 32; val targetW = 100
        val scaled = Bitmap.createScaledBitmap(crop, targetW, targetH, true)
        val inputBuffer = ByteBuffer.allocateDirect(4 * targetH * targetW * 3).order(ByteOrder.nativeOrder())
        val pixels = IntArray(targetW * targetH)
        scaled.getPixels(pixels, 0, targetW, 0, 0, targetW, targetH)
        for (y in 0 until targetH) {
            for (x in 0 until targetW) {
                val p = pixels[y * targetW + x]
                inputBuffer.putFloat(((p shr 16) and 0xFF) / 255f)
                inputBuffer.putFloat(((p shr 8) and 0xFF) / 255f)
                inputBuffer.putFloat((p and 0xFF) / 255f)
            }
        }
        inputBuffer.rewind(); scaled.recycle()
        val outputBuffer = ByteBuffer.allocateDirect(4 * 26 * 37).order(ByteOrder.nativeOrder())
        interpreter.run(inputBuffer, outputBuffer); outputBuffer.rewind()
        val timeSteps = 26; val numClasses = 37; val blankIdx = numClasses - 1
        val result = StringBuilder(); var prevIdx = -1
        for (t in 0 until timeSteps) {
            var maxIdx = 0; var maxVal = Float.NEGATIVE_INFINITY
            for (c in 0 until numClasses) { val v = outputBuffer.float; if (v > maxVal) { maxVal = v; maxIdx = c } }
            if (maxIdx != blankIdx && maxIdx != prevIdx) { if (maxIdx < easyocrChars.length) result.append(easyocrChars[maxIdx]) }
            prevIdx = maxIdx
        }
        return result.toString().trim().takeIf { it.isNotBlank() }
    }

    // ═══ PaddleOCR ═══
    override suspend fun recognizePaddleLite(bitmap: Bitmap): List<BlockData> = withContext(Dispatchers.IO) {
        try {
            synchronized(paddleLock) {
                if (!paddleInitialized) {
                    val config = buildPaddleConfig() ?: throw IllegalStateException("PaddleOCR غير متاح")
                    paddleOcr.initModelSync(config).getOrThrow(); paddleInitialized = true
                }
            }
            val result = paddleOcr.runSync(bitmap).getOrThrow()
            val labels = paddleOcr.getWordLabels()
            result.outputRawResult.mapNotNull { raw ->
                val points = raw.points ?: return@mapNotNull null
                if (points.size < 4) return@mapNotNull null
                val xs = points.map { it.x }; val ys = points.map { it.y }
                val left = xs.minOrNull()?.toInt() ?: return@mapNotNull null
                val top = ys.minOrNull()?.toInt() ?: return@mapNotNull null
                val right = xs.maxOrNull()?.toInt() ?: return@mapNotNull null
                val bottom = ys.maxOrNull()?.toInt() ?: return@mapNotNull null
                val text = raw.wordIndex.joinToString("") { labels.getOrNull(it) ?: "" }.trim()
                if (text.isBlank()) return@mapNotNull null
                BlockData(text = text, x = left.coerceIn(0, bitmap.width - 1), y = top.coerceIn(0, bitmap.height - 1),
                    width = (right - left).coerceAtLeast(1).coerceAtMost(bitmap.width),
                    height = (bottom - top).coerceAtLeast(1).coerceAtMost(bitmap.height),
                    confidence = raw.confidence.toFloat(), angle = if (raw.clsLabel == "180") 180f else 0f)
            }.let { mergeIntoComicBlocks(it, bitmap.width, bitmap.height) }
        } catch (e: Throwable) { Log.e("PaddleOCR", "فشل — رجوع لـ ML Kit", e); recognizeMLKit(bitmap) }
    }

    private fun buildPaddleConfig(): OcrConfig? {
        val requiredAssets = setOf("det.nb", "rec.nb", "cls.nb", "ppocr_keys_v1.txt")
        val bundledInAssets = try { context.assets.list("paddle")?.toSet()?.let { requiredAssets.all { f -> f in it } } ?: false } catch (e: Exception) { false }
        if (bundledInAssets) {
            return OcrConfig().apply { modelPath = "paddle"; labelPath = "paddle/ppocr_keys_v1.txt"; detModelFilename = "det.nb"; recModelFilename = "rec.nb"; clsModelFilename = "cls.nb"; isRunDet = true; isRunCls = true; isRunRec = true; isDrwwTextPositionBox = false }
        }
        val models = modelManager.availableModels
        val det = models.find { it.id == "paddle_det" } ?: return null
        val rec = models.find { it.id == "paddle_rec" } ?: return null
        val cls = models.find { it.id == "paddle_cls" } ?: return null
        val dict = models.find { it.id == "paddle_dict" } ?: return null
        if (!modelManager.isDownloaded(det) || !modelManager.isDownloaded(rec) || !modelManager.isDownloaded(cls) || !modelManager.isDownloaded(dict)) return null
        return OcrConfig().apply { modelPath = modelManager.paddleModelsDir.absolutePath; labelPath = modelManager.modelFile(dict).absolutePath; detModelFilename = det.fileName; recModelFilename = rec.fileName; clsModelFilename = cls.fileName; isRunDet = true; isRunCls = true; isRunRec = true; isDrwwTextPositionBox = false }
    }

    // ═══ Tesseract / Cloud ═══
    override suspend fun recognizeTesseract(bitmap: Bitmap): List<BlockData> { Log.w("OCR", "Tesseract غير متاح"); return recognizeMLKit(bitmap) }
    override suspend fun recognizeOCRSpace(bitmap: Bitmap, apiKey: String): List<BlockData> = withContext(Dispatchers.IO) {
        try {
            val stream = ByteArrayOutputStream(); bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream)
            val requestBody = MultipartBody.Builder().setType(MultipartBody.FORM).addFormDataPart("apikey", apiKey).addFormDataPart("isOverlayRequired", "true").addFormDataPart("OCREngine", "2").addFormDataPart("filetype", "jpg").addFormDataPart("file", "image.jpg", stream.toByteArray().toRequestBody("image/jpeg".toMediaType())).build()
            val response = client.newCall(Request.Builder().url("https://api.ocr.space/parse/image").post(requestBody).build()).execute()
            val body = response.body?.string() ?: return@withContext emptyList()
            val json = JSONObject(body)
            if (json.optBoolean("IsErroredOnProcessing", false)) { Log.e("OCRSpace", json.optString("ErrorMessage")); return@withContext emptyList() }
            val results = json.optJSONArray("ParsedResults") ?: return@withContext emptyList()
            val lines = results.getJSONObject(0).optJSONObject("TextOverlay")?.optJSONArray("Lines") ?: return@withContext emptyList()
            val blocks = mutableListOf<BlockData>()
            for (i in 0 until lines.length()) {
                val line = lines.getJSONObject(i); val words = line.optJSONArray("Words")
                if (words != null && words.length() > 0) {
                    val first = words.getJSONObject(0)
                    val totalWidth = (0 until words.length()).sumOf { words.getJSONObject(it).optInt("Width", 0) }
                    blocks.add(BlockData(text = line.optString("LineText", ""), x = first.optInt("Left", 0), y = first.optInt("Top", 0), width = totalWidth, height = line.optInt("MaxHeight", 30)))
                }
            }
            blocks
        } catch (e: Exception) { Log.e("OCRSpace", "Error", e); emptyList() }
    }
    override suspend fun recognizeCloud(bitmap: Bitmap, apiUrl: String): List<BlockData> = withContext(Dispatchers.IO) {
        try {
            val stream = ByteArrayOutputStream(); bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream)
            val base64 = android.util.Base64.encodeToString(stream.toByteArray(), android.util.Base64.DEFAULT)
            val jsonBody = JSONObject().put("image", "data:image/jpeg;base64,$base64").toString()
            val response = client.newCall(Request.Builder().url(apiUrl).post(jsonBody.toRequestBody("application/json".toMediaType())).build()).execute()
            val body = response.body?.string() ?: return@withContext emptyList()
            val json = JSONObject(body)
            val results = json.optJSONArray("results") ?: json.optJSONArray("words") ?: json.optJSONArray("texts") ?: return@withContext emptyList()
            val blocks = mutableListOf<BlockData>()
            for (i in 0 until results.length()) {
                val item = results.getJSONObject(i)
                blocks.add(BlockData(text = item.optString("text", ""), x = item.optInt("x", 0), y = item.optInt("y", 0), width = item.optInt("width", 100), height = item.optInt("height", 30), confidence = item.optDouble("confidence", 80.0).toFloat()))
            }
            blocks
        } catch (e: Exception) { Log.e("CloudOCR", "Error", e); emptyList() }
    }

    // ═══ Helpers ═══
    private suspend fun recognizeTextInRegion(bitmap: Bitmap, rect: Rect): String? = suspendCancellableCoroutine { continuation ->
        val crop = try { Bitmap.createBitmap(bitmap, rect.left, rect.top, rect.width(), rect.height()) } catch (e: Throwable) { continuation.resume(null); return@suspendCancellableCoroutine }
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(InputImage.fromBitmap(crop, 0))
            .addOnSuccessListener { result -> continuation.resume(result.text); recognizer.close(); crop.recycle() }
            .addOnFailureListener { e -> continuation.resume(null); recognizer.close(); crop.recycle() }
    }

    private fun runCraftDetection(bitmap: Bitmap, modelFile: File): List<Rect> {
        val interpreter = synchronized(craftLock) { craftInterpreter ?: Interpreter(loadModelFile(modelFile)).also { craftInterpreter = it } }
        val inputSize = 1280; val resized = Bitmap.createScaledBitmap(bitmap, inputSize, inputSize, true)
        val mean = floatArrayOf(0.485f, 0.456f, 0.406f); val std = floatArrayOf(0.229f, 0.224f, 0.225f)
        val inputBuffer = ByteBuffer.allocateDirect(4 * 1 * 3 * inputSize * inputSize).order(ByteOrder.nativeOrder())
        val pixels = IntArray(inputSize * inputSize); resized.getPixels(pixels, 0, inputSize, 0, 0, inputSize, inputSize)
        for (c in 0..2) { for (y in 0 until inputSize) { for (x in 0 until inputSize) {
            val p = pixels[y * inputSize + x]
            val v = when (c) { 0 -> (p shr 16) and 0xFF; 1 -> (p shr 8) and 0xFF; else -> p and 0xFF }
            inputBuffer.putFloat((v / 255f - mean[c]) / std[c])
        } } }
        val outH = inputSize / 2; val outW = inputSize / 2
        val regionBuffer = ByteBuffer.allocateDirect(4 * outH * outW).order(ByteOrder.nativeOrder())
        val affinityBuffer = ByteBuffer.allocateDirect(4 * outH * outW).order(ByteOrder.nativeOrder())
        val outputs = HashMap<Int, Any>(); outputs[0] = regionBuffer; outputs[1] = affinityBuffer
        interpreter.runForMultipleInputsOutputs(arrayOf<Any>(inputBuffer), outputs)
        regionBuffer.rewind(); affinityBuffer.rewind()
        val scoreMap = Array(outH) { FloatArray(outW) }
        for (y in 0 until outH) { for (x in 0 until outW) { scoreMap[y][x] = regionBuffer.float + affinityBuffer.float } }
        val boxes = extractBoxesFromScoreMap(scoreMap, 0.7f, bitmap.width, bitmap.height, inputSize)
        resized.recycle(); return boxes
    }

    private fun runEASTDetection(bitmap: Bitmap, modelFile: File, modelId: String): List<Rect> {
        val interpreter = synchronized(eastLock) {
            val expectedSize = when (modelId) { "det_east_320" -> 320; "det_east_640" -> 640; "det_east_1280" -> 1280; else -> 320 }
            if (eastInterpreter != null && eastModelSize != expectedSize) { eastInterpreter?.close(); eastInterpreter = null }
            eastInterpreter ?: Interpreter(loadModelFile(modelFile)).also { eastInterpreter = it; eastModelSize = expectedSize }
        }
        val (inputW, inputH) = when (modelId) { "det_east_320" -> 320 to 320; "det_east_640" -> 640 to 640; "det_east_1280" -> 1280 to 1280; else -> 320 to 320 }
        val origW = bitmap.width; val origH = bitmap.height; val resized = Bitmap.createScaledBitmap(bitmap, inputW, inputH, true)
        val inputBuffer = ByteBuffer.allocateDirect(4 * inputH * inputW * 3).order(ByteOrder.nativeOrder())
        val pixels = IntArray(inputW * inputH); resized.getPixels(pixels, 0, inputW, 0, 0, inputW, inputH)
        val mean = floatArrayOf(0.485f * 255f, 0.456f * 255f, 0.406f * 255f); val std = floatArrayOf(0.229f * 255f, 0.224f * 255f, 0.225f * 255f)
        for (y in 0 until inputH) { for (x in 0 until inputW) { val p = pixels[y * inputW + x]; inputBuffer.putFloat((((p shr 16) and 0xFF) - mean[0]) / std[0]); inputBuffer.putFloat((((p shr 8) and 0xFF) - mean[1]) / std[1]); inputBuffer.putFloat(((p and 0xFF) - mean[2]) / std[2]) } }
        inputBuffer.rewind(); resized.recycle()
        val outH = inputH / 4; val outW = inputW / 4
        val scoreBuffer = ByteBuffer.allocateDirect(4 * outH * outW).order(ByteOrder.nativeOrder())
        val geometryBuffer = ByteBuffer.allocateDirect(4 * outH * outW * 5).order(ByteOrder.nativeOrder())
        val outputs = HashMap<Int, Any>(); outputs[0] = scoreBuffer; outputs[1] = geometryBuffer
        interpreter.runForMultipleInputsOutputs(arrayOf<Any>(inputBuffer), outputs)
        scoreBuffer.rewind(); geometryBuffer.rewind()
        val boxes = ArrayList<EastBox>()
        for (y in 0 until outH) {
            for (x in 0 until outW) {
                val score = scoreBuffer.float
                if (score < 0.5f) { repeat(5) { geometryBuffer.float }; continue }
                val dTop = geometryBuffer.float; val dRight = geometryBuffer.float; val dBottom = geometryBuffer.float; val dLeft = geometryBuffer.float; val angle = geometryBuffer.float
                val cx = (x * 4 + 2).toFloat(); val cy = (y * 4 + 2).toFloat()
                val top = (cy - dTop * inputH).coerceIn(0f, inputH.toFloat()); val right = (cx + dRight * inputW).coerceIn(0f, inputW.toFloat())
                val bottom = (cy + dBottom * inputH).coerceIn(0f, inputH.toFloat()); val left = (cx - dLeft * inputW).coerceIn(0f, inputW.toFloat())
                val scaleX = origW.toFloat() / inputW; val scaleY = origH.toFloat() / inputH
                val ol = (left * scaleX).toInt().coerceIn(0, origW - 1); val ot = (top * scaleY).toInt().coerceIn(0, origH - 1)
                val or_ = (right * scaleX).toInt().coerceIn(ol + 1, origW); val ob = (bottom * scaleY).toInt().coerceIn(ot + 1, origH)
                boxes.add(EastBox(Rect(ol, ot, or_, ob), score, angle))
            }
        }
        boxes.sortByDescending { it.score }
        val result = mutableListOf<Rect>()
        for (box in boxes) { var keep = true; for (kept in result) { if (iou(box.rect, kept) > 0.3f) { keep = false; break } }; if (keep) result.add(box.rect) }
        return result
    }

    private data class EastBox(val rect: Rect, val score: Float, val angle: Float)

    private fun extractBoxesFromScoreMap(scoreMap: Array<FloatArray>, threshold: Float, origW: Int, origH: Int, inputSize: Int): List<Rect> {
        val h = scoreMap.size; val w = scoreMap[0].size; val visited = Array(h) { BooleanArray(w) }; val boxes = mutableListOf<Rect>()
        for (y in 0 until h) {
            for (x in 0 until w) {
                if (scoreMap[y][x] < threshold || visited[y][x]) continue
                val component = mutableListOf<Pair<Int, Int>>(); val queue = ArrayDeque<Pair<Int, Int>>()
                queue.add(x to y); visited[y][x] = true
                while (queue.isNotEmpty()) {
                    val (cx, cy) = queue.removeFirst(); component.add(cx to cy)
                    for (dy in -1..1) { for (dx in -1..1) {
                        val nx = cx + dx; val ny = cy + dy
                        if (nx in 0 until w && ny in 0 until h && !visited[ny][nx] && scoreMap[ny][nx] >= threshold) { visited[ny][nx] = true; queue.add(nx to ny) }
                    } }
                }
                if (component.size < 10) continue
                val minX = component.minOf { it.first }; val maxX = component.maxOf { it.first }
                val minY = component.minOf { it.second }; val maxY = component.maxOf { it.second }
                val scaleX = origW.toFloat() / inputSize; val scaleY = origH.toFloat() / inputSize
                val left = (minX * 2 * scaleX).toInt().coerceIn(0, origW - 1); val top = (minY * 2 * scaleY).toInt().coerceIn(0, origH - 1)
                val right = ((maxX + 1) * 2 * scaleX).toInt().coerceIn(left + 1, origW); val bottom = ((maxY + 1) * 2 * scaleY).toInt().coerceIn(top + 1, origH)
                boxes.add(Rect(left, top, right, bottom))
            }
        }
        return applyNMS(boxes, 0.3f)
    }

    private fun applyNMS(boxes: List<Rect>, threshold: Float): List<Rect> {
        if (boxes.isEmpty()) return emptyList()
        val sorted = boxes.sortedByDescending { it.width() * it.height() }
        val result = mutableListOf<Rect>(); val suppressed = BooleanArray(sorted.size)
        for (i in sorted.indices) {
            if (suppressed[i]) continue
            result.add(sorted[i])
            for (j in i + 1 until sorted.size) { if (suppressed[j]) continue; if (iou(sorted[i], sorted[j]) > threshold) suppressed[j] = true }
        }
        return result
    }

    private fun iou(a: Rect, b: Rect): Float {
        val left = maxOf(a.left, b.left); val top = maxOf(a.top, b.top); val right = minOf(a.right, b.right); val bottom = minOf(a.bottom, b.bottom)
        if (right <= left || bottom <= top) return 0f
        val inter = (right - left) * (bottom - top); val union = a.width() * a.height() + b.width() * b.height() - inter
        return if (union > 0) inter.toFloat() / union else 0f
    }

    private fun mergeIntoComicBlocks(input: List<BlockData>, imageWidth: Int, imageHeight: Int): List<BlockData> {
        if (input.isEmpty()) return emptyList()
        val sorted = input.filter { it.text.isNotBlank() && it.width > 0 && it.height > 0 }.sortedWith(compareBy<BlockData> { it.y }.thenBy { it.x })
        val groups = mutableListOf<MutableList<BlockData>>()
        for (line in sorted) {
            var best: MutableList<BlockData>? = null; var bestScore = Float.NEGATIVE_INFINITY
            for (group in groups) {
                val g = group.reduce { a, b -> mergeGeometry(a, b) }
                val overlapX = horizontalOverlapRatio(line, g)
                val centerDx = kotlin.math.abs((line.x + line.width / 2f) - (g.x + g.width / 2f))
                val centerLimit = maxOf(line.width, g.width) * 0.65f
                val gapY = maxOf(0, maxOf(line.y, g.y) - minOf(line.y + line.height, g.y + g.height))
                val gapLimit = maxOf(14f, maxOf(line.height, g.height) * 1.35f)
                val compatible = (overlapX >= 0.25f || centerDx <= centerLimit) && gapY <= gapLimit
                if (!compatible) continue
                val score = overlapX * 2f + (1f - (gapY / gapLimit).coerceIn(0f, 1f))
                if (score > bestScore) { bestScore = score; best = group }
            }
            if (best != null) best!!.add(line) else groups.add(mutableListOf(line))
        }
        return groups.mapNotNull { group ->
            val box = group.reduce { a, b -> mergeGeometry(a, b) }
            val ordered = group.sortedWith(compareBy<BlockData> { it.y }.thenBy { it.x })
            val text = ordered.joinToString(" ") { it.text.trim() }.replace(Regex("\s+"), " ").trim()
            if (text.isBlank()) null
            else box.copy(text = text, confidence = ordered.map { it.confidence }.filter { it > 0f }.average().takeIf { !it.isNaN() }?.toFloat() ?: box.confidence,
                x = box.x.coerceIn(0, maxOf(0, imageWidth - 1)), y = box.y.coerceIn(0, maxOf(0, imageHeight - 1)),
                width = box.width.coerceAtMost(imageWidth), height = box.height.coerceAtMost(imageHeight))
        }.sortedWith(compareBy<BlockData> { it.y }.thenBy { it.x })
    }

    private fun mergeGeometry(a: BlockData, b: BlockData): BlockData {
        val x1 = minOf(a.x, b.x); val y1 = minOf(a.y, b.y); val x2 = maxOf(a.x + a.width, b.x + b.width); val y2 = maxOf(a.y + a.height, b.y + b.height)
        return a.copy(x = x1, y = y1, width = x2 - x1, height = y2 - y1)
    }

    private fun horizontalOverlapRatio(a: BlockData, b: BlockData): Float {
        val left = maxOf(a.x, b.x); val right = minOf(a.x + a.width, b.x + b.width); val overlap = maxOf(0, right - left); val base = minOf(a.width, b.width).coerceAtLeast(1)
        return overlap.toFloat() / base
    }

    private fun loadModelFile(file: File): MappedByteBuffer {
        FileInputStream(file).use { stream -> val channel = stream.channel; return channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size()) }
    }
}
