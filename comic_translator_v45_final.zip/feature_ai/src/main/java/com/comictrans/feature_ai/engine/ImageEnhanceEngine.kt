package com.comictrans.feature_ai.engine

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.comictrans.engine.ModelManager
import com.comictrans.engine.OpenCVStatus
import com.comictrans.engine.contracts.EnhanceResult
import com.comictrans.engine.contracts.IImageEnhanceEngine
import org.opencv.android.Utils
import org.opencv.core.Mat
import org.opencv.imgproc.Imgproc
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

/**
 * محرك تعزيز الصورة — يدير جميع أوضاع التعزيز:
 * - "none": بدون تعزيز (يرجع الصورة كما هي)
 * - "opencv": تحسين كلاسيكي (CLAHE + شحذ) — يعمل فوراً
 * - "ai": Real-ESRGAN x4 عبر TFLite — تكبير بالذكاء الاصطناعي
 *
 * ✅ إصلاح: النموذج الآن مُسجَّل في ModelManager ويظهر في قائمة التنزيل.
 * ✅ إصلاح: تفعيل GPU Delegate لتسريع AI.
 */
class ImageEnhanceEngine(
    private val context: Context,
    private val modelManager: ModelManager
) : IImageEnhanceEngine {

    private val TAG = "ImageEnhance"

    @Volatile private var cachedInterpreter: Interpreter? = null
    @Volatile private var cachedModelPath: String? = null

    override fun enhance(bitmap: Bitmap, method: String): EnhanceResult {
        return when (method) {
            "ai" -> tryAIEnhance(bitmap) ?: run {
                Log.w(TAG, "نموذج Real-ESRGAN غير منزّل — رجوع لـ OpenCV")
                EnhanceResult(enhanceOpenCV(bitmap), 1f)
            }
            "opencv" -> EnhanceResult(enhanceOpenCV(bitmap), 1f)
            else -> EnhanceResult(bitmap, 1f)
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // OpenCV — تحسين كلاسيكي (سريع، لا يحتاج نماذج)
    // ═══════════════════════════════════════════════════════════════
    private fun enhanceOpenCV(bitmap: Bitmap): Bitmap {
        if (!OpenCVStatus.isAvailable) {
            Log.w(TAG, "OpenCV غير متاح — رجوع للصورة الأصلية")
            return bitmap
        }
        return try {
            val src = Mat()
            Utils.bitmapToMat(bitmap, src)

            val lab = Mat()
            Imgproc.cvtColor(src, lab, Imgproc.COLOR_RGB2Lab)

            val channels = ArrayList<Mat>()
            org.opencv.core.Core.split(lab, channels)
            val lChannel = channels[0]

            val clahe = Imgproc.createCLAHE(2.0, org.opencv.core.Size(8.0, 8.0))
            clahe.apply(lChannel, lChannel)

            org.opencv.core.Core.merge(channels, lab)
            val enhanced = Mat()
            Imgproc.cvtColor(lab, enhanced, Imgproc.COLOR_Lab2RGB)

            val kernel = Mat.zeros(3, 3, org.opencv.core.CvType.CV_32F)
            kernel.put(0, 0, 0f, -1f, 0f, -1f, 5f, -1f, 0f, -1f, 0f)
            val sharpened = Mat()
            Imgproc.filter2D(enhanced, sharpened, -1, kernel)

            val result = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(sharpened, result)

            src.release(); lab.release(); enhanced.release(); sharpened.release()
            channels.forEach { it.release() }
            kernel.release()

            result
        } catch (e: Throwable) {
            Log.e(TAG, "OpenCV enhance failed", e)
            bitmap
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // AI — Real-ESRGAN x4 (TFLite)
    // ═══════════════════════════════════════════════════════════════
    private fun tryAIEnhance(bitmap: Bitmap): EnhanceResult? {
        val model = modelManager.availableModels.find { it.id == "enhance_ai" }
            ?: return null
        val file = modelManager.modelFile(model)
        if (!file.exists() || file.length() < model.minValidBytes) {
            Log.w(TAG, "نموذج Real-ESRGAN غير موجود أو غير كامل")
            return null
        }

        return try {
            val interpreter = getOrCreateInterpreter(file)
            val inputSize = 256 // Real-ESRGAN يقبل أحجام متعددة
            val scale = 4f

            // تحجيم للإدخال
            val resized = Bitmap.createScaledBitmap(bitmap, inputSize, inputSize, true)

            // تطبيع [0,255] → [0,1]
            val inputBuffer = ByteBuffer.allocateDirect(4 * inputSize * inputSize * 3)
                .order(ByteOrder.nativeOrder())
            val pixels = IntArray(inputSize * inputSize)
            resized.getPixels(pixels, 0, inputSize, 0, 0, inputSize, inputSize)

            for (y in 0 until inputSize) {
                for (x in 0 until inputSize) {
                    val p = pixels[y * inputSize + x]
                    inputBuffer.putFloat(((p shr 16) and 0xFF) / 255f)
                    inputBuffer.putFloat(((p shr 8) and 0xFF) / 255f)
                    inputBuffer.putFloat((p and 0xFF) / 255f)
                }
            }
            inputBuffer.rewind()
            resized.recycle()

            // المُخرج
            val outSize = (inputSize * scale).toInt()
            val outputBuffer = ByteBuffer.allocateDirect(4 * outSize * outSize * 3)
                .order(ByteOrder.nativeOrder())

            interpreter.run(inputBuffer, outputBuffer)
            outputBuffer.rewind()

            // تحويل المُخرج لـ Bitmap
            val resultBitmap = Bitmap.createBitmap(outSize, outSize, Bitmap.Config.ARGB_8888)
            val outPixels = IntArray(outSize * outSize)

            for (y in 0 until outSize) {
                for (x in 0 until outSize) {
                    val r = (outputBuffer.float * 255f).coerceIn(0f, 255f).toInt()
                    val g = (outputBuffer.float * 255f).coerceIn(0f, 255f).toInt()
                    val b = (outputBuffer.float * 255f).coerceIn(0f, 255f).toInt()
                    outPixels[y * outSize + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                }
            }

            resultBitmap.setPixels(outPixels, 0, outSize, 0, 0, outSize, outSize)
            EnhanceResult(resultBitmap, scale)

        } catch (e: Throwable) {
            Log.e(TAG, "AI enhance failed", e)
            null
        }
    }

    private fun getOrCreateInterpreter(file: File): Interpreter {
        if (cachedInterpreter != null && cachedModelPath == file.absolutePath) {
            return cachedInterpreter!!
        }
        try { cachedInterpreter?.close() } catch (_: Exception) {}

        val options = Interpreter.Options().apply {
            setNumThreads(Runtime.getRuntime().availableProcessors().coerceAtLeast(1))
            try {
                addDelegate(GpuDelegate())
                Log.d(TAG, "GPU Delegate مُفعَّل")
            } catch (e: Throwable) {
                Log.w(TAG, "GPU Delegate غير متاح")
            }
        }
        val interpreter = Interpreter(loadModelFile(file), options)
        cachedInterpreter = interpreter
        cachedModelPath = file.absolutePath
        return interpreter
    }

    private fun loadModelFile(file: File): MappedByteBuffer {
        FileInputStream(file).use { stream ->
            val channel = stream.channel
            return channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size())
        }
    }
}
