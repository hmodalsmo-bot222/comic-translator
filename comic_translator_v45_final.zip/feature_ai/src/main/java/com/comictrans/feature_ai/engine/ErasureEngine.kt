package com.comictrans.feature_ai.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.util.Log
import com.comictrans.engine.ModelManager
import com.comictrans.engine.OpenCVStatus
import com.comictrans.engine.contracts.IErasureEngine
import com.comictrans.model.BlockData
import org.opencv.android.Utils
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import java.util.concurrent.Executors

private const val MODEL_INPUT_SIZE = 512

/**
 * محرك الطمس — يدير جميع أوضاع الطمس.
 *
 * ✅ إصلاح AI Pro البطيء: معالجة batch (الصفحة كاملة دفعة واحدة).
 * ✅ إصلاح AI Lite الخلفية التالفة: تطبيع صحيح [0,1] → [0,255].
 */
class ErasureEngine(private val context: Context, private val modelManager: ModelManager) : IErasureEngine {

    private val TAG = "ErasureEngine"
    private var cachedOnnxEnv: OrtEnvironment? = null
    private var cachedOnnxSession: OrtSession? = null
    private var cachedOnnxModelPath: String? = null
    private var cachedTfliteInterpreter: Interpreter? = null
    private var cachedTfliteModelPath: String? = null
    private val aiExecutor = Executors.newSingleThreadExecutor()

    private fun getOrCreateOnnxSession(modelPath: String): Pair<OrtEnvironment, OrtSession> {
        if (cachedOnnxSession != null && cachedOnnxModelPath == modelPath) {
            return cachedOnnxEnv!! to cachedOnnxSession!!
        }
        try { cachedOnnxSession?.close() } catch (_: Exception) {}
        val env = cachedOnnxEnv ?: OrtEnvironment.getEnvironment().also { cachedOnnxEnv = it }
        val options = OrtSession.SessionOptions().apply {
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceAtLeast(1))
            try { addNnapi(); Log.d(TAG, "AI Pro: NNAPI مُفعَّل") }
            catch (e: Throwable) { Log.w(TAG, "AI Pro: NNAPI غير متاح") }
        }
        val session = env.createSession(modelPath, options)
        cachedOnnxSession = session; cachedOnnxModelPath = modelPath
        return env to session
    }

    private fun getOrCreateTfliteInterpreter(file: File): Interpreter {
        if (cachedTfliteInterpreter != null && cachedTfliteModelPath == file.absolutePath) {
            return cachedTfliteInterpreter!!
        }
        try { cachedTfliteInterpreter?.close() } catch (_: Exception) {}
        val options = Interpreter.Options().apply {
            setNumThreads(Runtime.getRuntime().availableProcessors().coerceAtLeast(1))
            try { addDelegate(GpuDelegate()); Log.d(TAG, "AI Lite: GPU Delegate مُفعَّل") }
            catch (e: Throwable) { Log.w(TAG, "AI Lite: GPU Delegate غير متاح") }
        }
        val interpreter = Interpreter(loadModelFile(file), options)
        cachedTfliteInterpreter = interpreter; cachedTfliteModelPath = file.absolutePath
        return interpreter
    }

    override fun close() {
        try { cachedOnnxSession?.close() } catch (_: Exception) {}
        try { cachedTfliteInterpreter?.close() } catch (_: Exception) {}
        cachedOnnxSession = null; cachedTfliteInterpreter = null
        aiExecutor.shutdown()
    }

    // ═══ OpenCV Inpaint ═══
    fun inpaintOpenCV(bitmap: Bitmap, blocks: List<BlockData>, bubbleAware: Boolean = false): Bitmap {
        if (!OpenCVStatus.isAvailable) return fallbackErase(bitmap, blocks)
        return try {
            val srcRgba = Mat(); Utils.bitmapToMat(bitmap, srcRgba)
            val srcRgb = Mat(); Imgproc.cvtColor(srcRgba, srcRgb, Imgproc.COLOR_RGBA2RGB)
            val maskMat = if (bubbleAware) {
                try { BubbleDetector.buildBubbleMask(bitmap, blocks) }
                catch (e: Throwable) { buildRectMask(srcRgb, bitmap, blocks) }
            } else buildRectMask(srcRgb, bitmap, blocks)
            val resultRgb = Mat()
            Photo.inpaint(srcRgb, maskMat, resultRgb, 3.0, Photo.INPAINT_TELEA)
            val resultRgba = Mat()
            Imgproc.cvtColor(resultRgb, resultRgba, Imgproc.COLOR_RGB2RGBA)
            val resultBitmap = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(resultRgba, resultBitmap)
            srcRgba.release(); srcRgb.release(); maskMat.release(); resultRgb.release(); resultRgba.release()
            resultBitmap
        } catch (e: Throwable) {
            Log.e(TAG, "OpenCV inpaint failed", e)
            fallbackErase(bitmap, blocks)
        }
    }

    private fun buildRectMask(srcRgb: Mat, bitmap: Bitmap, blocks: List<BlockData>): Mat {
        val maskMat = Mat.zeros(srcRgb.size(), CvType.CV_8UC1)
        for (block in blocks) {
            val x1 = block.x.coerceIn(0, bitmap.width - 1)
            val y1 = block.y.coerceIn(0, bitmap.height - 1)
            val x2 = (block.x + block.width).coerceIn(0, bitmap.width)
            val y2 = (block.y + block.height).coerceIn(0, bitmap.height)
            Imgproc.rectangle(maskMat, Point(x1.toDouble(), y1.toDouble()),
                Point(x2.toDouble(), y2.toDouble()), Scalar(255.0), -1)
        }
        return maskMat
    }

    // ═══ AI Lite (TFLite) — batch processing ═══
    fun inpaintTFLite(bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val model = modelManager.availableModels.find { it.id == "ai_lite" } ?: return fallbackErase(bitmap, blocks)
        val file = modelManager.modelFile(model)
        if (!file.exists()) { Log.w(TAG, "AI Lite: غير منزّل"); return inpaintOpenCV(bitmap, blocks, false) }
        return try {
            val interpreter = getOrCreateTfliteInterpreter(file)
            val size = MODEL_INPUT_SIZE
            val (inputBuffer, maskBuffer, _, _) = prepareFullPageInput(bitmap, blocks, size)
            val outputBuffer = ByteBuffer.allocateDirect(4 * 3 * size * size).order(ByteOrder.nativeOrder())
            interpreter.runForMultipleInputsOutputs(arrayOf(inputBuffer, maskBuffer), mapOf(0 to outputBuffer))
            outputBuffer.rewind()
            val resultBitmap = outputBufferToBitmap(outputBuffer, size)
            val finalBitmap = Bitmap.createScaledBitmap(resultBitmap, bitmap.width, bitmap.height, true)
            resultBitmap.recycle(); finalBitmap
        } catch (e: Throwable) {
            Log.e(TAG, "AI Lite failed — fallback", e)
            inpaintOpenCV(bitmap, blocks, false)
        }
    }

    // ═══ AI Pro (ONNX) — batch processing ═══
    fun inpaintONNX(bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val model = modelManager.availableModels.find { it.id == "ai_pro" } ?: return fallbackErase(bitmap, blocks)
        val file = modelManager.modelFile(model)
        if (!file.exists()) { Log.w(TAG, "AI Pro: غير منزّل"); return inpaintOpenCV(bitmap, blocks, false) }
        return try {
            val (env, session) = getOrCreateOnnxSession(file.absolutePath)
            val size = MODEL_INPUT_SIZE
            val (inputBuffer, maskBuffer, _, _) = prepareFullPageInput(bitmap, blocks, size)
            val imgFloatBuf = inputBuffer.asFloatBuffer()
            val maskFloatBuf = maskBuffer.asFloatBuffer()
            val imgTensor = OnnxTensor.createTensor(env, imgFloatBuf, longArrayOf(1, 3, size.toLong(), size.toLong()))
            val maskTensor = OnnxTensor.createTensor(env, maskFloatBuf, longArrayOf(1, 1, size.toLong(), size.toLong()))
            val inputs = mapOf("image" to imgTensor, "mask" to maskTensor)
            val result = session.run(inputs).use { outputs ->
                val outValue = outputs.get("output").orElseGet { outputs.iterator().next().value }
                val outTensor = outValue.value as Array<*>
                flattenOnnxOutput(outTensor, size)
            }
            imgTensor.close(); maskTensor.close()
            val resultBitmap = outputArrayToBitmap(result, size)
            val finalBitmap = Bitmap.createScaledBitmap(resultBitmap, bitmap.width, bitmap.height, true)
            resultBitmap.recycle(); finalBitmap
        } catch (e: Throwable) {
            Log.e(TAG, "AI Pro failed — fallback", e)
            inpaintOpenCV(bitmap, blocks, false)
        }
    }

    // ═══ Shared helpers ═══
    private fun prepareFullPageInput(bitmap: Bitmap, blocks: List<BlockData>, size: Int): Quad<ByteBuffer, ByteBuffer, Float, Float> {
        val resized = Bitmap.createScaledBitmap(bitmap, size, size, true)
        val inputBuffer = ByteBuffer.allocateDirect(4 * 3 * size * size).order(ByteOrder.nativeOrder())
        val pixels = IntArray(size * size)
        resized.getPixels(pixels, 0, size, 0, 0, size, size)
        for (c in 0..2) {
            for (y in 0 until size) {
                for (x in 0 until size) {
                    val p = pixels[y * size + x]
                    val v = when (c) { 0 -> (p shr 16) and 0xFF; 1 -> (p shr 8) and 0xFF; else -> p and 0xFF }
                    inputBuffer.putFloat(v / 255f)
                }
            }
        }
        inputBuffer.rewind()
        val maskBuffer = ByteBuffer.allocateDirect(4 * 1 * size * size).order(ByteOrder.nativeOrder())
        val scaleX = size.toFloat() / bitmap.width
        val scaleY = size.toFloat() / bitmap.height
        val maskFloats = FloatArray(size * size) { 0f }
        for (block in blocks) {
            val x1 = (block.x * scaleX).toInt().coerceIn(0, size - 1)
            val y1 = (block.y * scaleY).toInt().coerceIn(0, size - 1)
            val x2 = ((block.x + block.width) * scaleX).toInt().coerceIn(x1 + 1, size)
            val y2 = ((block.y + block.height) * scaleY).toInt().coerceIn(y1 + 1, size)
            for (y in y1 until y2) { for (x in x1 until x2) { maskFloats[y * size + x] = 1f } }
        }
        for (v in maskFloats) { maskBuffer.putFloat(v) }
        maskBuffer.rewind(); resized.recycle()
        return Quad(inputBuffer, maskBuffer, scaleX, scaleY)
    }

    private fun outputBufferToBitmap(buffer: ByteBuffer, size: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(size * size)
        for (y in 0 until size) {
            for (x in 0 until size) {
                val idx = y * size + x
                val r = (buffer.float * 255f).coerceIn(0f, 255f).toInt()
                val g = (buffer.float * 255f).coerceIn(0f, 255f).toInt()
                val b = (buffer.float * 255f).coerceIn(0f, 255f).toInt()
                pixels[idx] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        bitmap.setPixels(pixels, 0, size, 0, 0, size, size)
        return bitmap
    }

    private fun outputArrayToBitmap(flatOut: FloatArray, size: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(size * size)
        val plane = size * size
        for (y in 0 until size) {
            for (x in 0 until size) {
                val idx = y * size + x
                val r = (flatOut[idx] * 255f).coerceIn(0f, 255f).toInt()
                val g = (flatOut[plane + idx] * 255f).coerceIn(0f, 255f).toInt()
                val b = (flatOut[2 * plane + idx] * 255f).coerceIn(0f, 255f).toInt()
                pixels[idx] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        bitmap.setPixels(pixels, 0, size, 0, 0, size, size)
        return bitmap
    }

    @Suppress("UNCHECKED_CAST")
    private fun flattenOnnxOutput(out: Array<*>, size: Int): FloatArray {
        val batch = out[0] as Array<*>
        val plane = size * size
        val result = FloatArray(3 * plane)
        for (c in 0 until 3) {
            val channel = batch[c] as Array<*>
            for (y in 0 until size) {
                val row = channel[y] as FloatArray
                System.arraycopy(row, 0, result, c * plane + y * size, size)
            }
        }
        return result
    }

    override fun processBitmap(bitmap: Bitmap, blocks: List<BlockData>, mode: String, bubbleAware: Boolean): Bitmap? {
        return when (mode) {
            "opencv" -> inpaintOpenCV(bitmap, blocks, bubbleAware)
            "ai_lite" -> inpaintTFLite(bitmap, blocks)
            "ai_pro" -> inpaintONNX(bitmap, blocks)
            else -> null
        }
    }

    // ═══ Fallback ═══
    private fun fallbackErase(bitmap: Bitmap, blocks: List<BlockData>): Bitmap {
        val result = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)
        for (block in blocks) {
            val paint = Paint().apply { color = averageBorderColor(bitmap, block) }
            canvas.drawRect(Rect(block.x, block.y, block.x + block.width, block.y + block.height), paint)
        }
        return result
    }

    private fun averageBorderColor(bitmap: Bitmap, block: BlockData): Int {
        val ringWidth = maxOf((minOf(block.width, block.height) * 0.15f).toInt(), 4)
        val ox1 = (block.x - ringWidth).coerceIn(0, bitmap.width - 1)
        val oy1 = (block.y - ringWidth).coerceIn(0, bitmap.height - 1)
        val ox2 = (block.x + block.width + ringWidth).coerceIn(ox1 + 1, bitmap.width)
        val oy2 = (block.y + block.height + ringWidth).coerceIn(oy1 + 1, bitmap.height)
        val ix1 = block.x.coerceIn(ox1, ox2)
        val iy1 = block.y.coerceIn(oy1, oy2)
        val ix2 = (block.x + block.width).coerceIn(ix1, ox2)
        val iy2 = (block.y + block.height).coerceIn(iy1, oy2)
        var sumR = 0L; var sumG = 0L; var sumB = 0L; var count = 0L
        val step = 2
        var y = oy1
        while (y < oy2) {
            val insideRow = y in iy1 until iy2
            var x = ox1
            while (x < ox2) {
                if (!(insideRow && x in ix1 until ix2)) {
                    val p = bitmap.getPixel(x, y)
                    sumR += (p shr 16) and 0xFF; sumG += (p shr 8) and 0xFF; sumB += p and 0xFF; count++
                }
                x += step
            }
            y += step
        }
        if (count == 0L) return Color.WHITE
        return Color.rgb((sumR / count).toInt(), (sumG / count).toInt(), (sumB / count).toInt())
    }

    private fun loadModelFile(file: File): MappedByteBuffer {
        val stream = FileInputStream(file)
        val channel = stream.channel
        return channel.map(FileChannel.MapMode.READ_ONLY, 0, file.length())
    }
}

// Helper class for 4-tuple
data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
