
// CBZ/ZIP Unzipper for Comic Translator
// Supports DEFLATE and STORE methods
(function(global) {
  'use strict';

  function readLE(bytes, off, len) {
    var r = 0;
    for (var i = 0; i < len; i++) r |= bytes[off + i] << (8 * i);
    return r;
  }

  function inflateRaw(data, out) {
    // Simple inflate for standard CBZ (most images are STORE, not DEFLATE)
    // For DEFLATE support, we need a proper inflater
    // This is a minimal implementation - for production use fflate library from CDN
    // For now, we return null to signal we need external library
    return null;
  }

  function unzipCBZ(uint8) {
    var files = {};
    var len = uint8.length;
    var i = 0;

    // Find Central Directory
    var cdOffset = 0;
    var cdSize = 0;
    var numEntries = 0;

    for (i = len - 22; i >= 0; i--) {
      if (readLE(uint8, i, 4) === 0x06054b50) {
        numEntries = readLE(uint8, i + 8, 2);
        cdSize = readLE(uint8, i + 12, 4);
        cdOffset = readLE(uint8, i + 16, 4);
        break;
      }
    }

    if (!cdOffset) return null;

    i = cdOffset;
    var entries = [];

    for (var e = 0; e < numEntries; e++) {
      if (readLE(uint8, i, 4) !== 0x02014b50) break;
      var compMethod = readLE(uint8, i + 10, 2);
      var compSize = readLE(uint8, i + 20, 4);
      var uncompSize = readLE(uint8, i + 24, 4);
      var nameLen = readLE(uint8, i + 28, 2);
      var extraLen = readLE(uint8, i + 30, 2);
      var commentLen = readLE(uint8, i + 32, 2);
      var localOffset = readLE(uint8, i + 42, 4);

      var nameBytes = uint8.subarray(i + 46, i + 46 + nameLen);
      var name = '';
      for (var b = 0; b < nameBytes.length; b++) name += String.fromCharCode(nameBytes[b]);

      entries.push({
        name: name,
        offset: localOffset,
        compSize: compSize,
        uncompSize: uncompSize,
        method: compMethod
      });

      i += 46 + nameLen + extraLen + commentLen;
    }

    // Extract files
    for (var j = 0; j < entries.length; j++) {
      var ent = entries[j];
      if (ent.name.endsWith('/')) continue;

      var off = ent.offset + 30;
      var nameLen2 = readLE(uint8, ent.offset + 26, 2);
      var extraLen2 = readLE(uint8, ent.offset + 28, 2);
      off += nameLen2 + extraLen2;

      var data = uint8.subarray(off, off + ent.compSize);

      if (ent.method === 0) {
        // STORE - no compression
        files[ent.name] = data;
      } else if (ent.method === 8) {
        // DEFLATE - needs proper inflater
        // For now skip or use external library
        console.warn('DEFLATE not supported in basic unzip:', ent.name);
      }
    }

    return files;
  }

  global.CBZUnzip = { unzip: unzipCBZ };
})(window);
