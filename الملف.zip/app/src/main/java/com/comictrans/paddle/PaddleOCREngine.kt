package com.comictrans.paddle

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.comictrans.model.BlockData
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/**
 * High-level PaddleOCR engine
 * Handles model extraction from assets and OCR execution
 */
class PaddleOCREngine(private val context: Context) {

    private val TAG = "PaddleOCREngine"
    private var initialized = false

    companion object {
        // Model file names (must be placed in app/src/main/assets/paddle/)
        const val DET_MODEL = "ch_PP-OCRv4_det.nb"
        const val REC_MODEL = "en_PP-OCRv4_rec.nb"
        const val DICT_FILE = "en_dict.txt"
    }

    fun initialize(): Boolean {
        if (!PaddleOCRNative.isAvailable()) {
            Log.e(TAG, "PaddleOCR native library not available")
            return false
        }

        return try {
            // Extract models from assets to cache directory
            val detPath = extractAsset("paddle/$DET_MODEL", DET_MODEL)
            val recPath = extractAsset("paddle/$REC_MODEL", REC_MODEL)
            val dictPath = extractAsset("paddle/$DICT_FILE", DICT_FILE)

            if (detPath == null || recPath == null || dictPath == null) {
                Log.e(TAG, "Model files not found in assets/paddle/")
                return false
            }

            initialized = PaddleOCRNative.init(detPath, recPath, dictPath)
            Log.d(TAG, "PaddleOCR initialized: $initialized")
            initialized
        } catch (e: Exception) {
            Log.e(TAG, "Initialization failed", e)
            false
        }
    }

    fun recognize(bitmap: Bitmap): List<BlockData> {
        if (!initialized) {
            Log.e(TAG, "Engine not initialized")
            return emptyList()
        }

        return try {
            val jsonResult = PaddleOCRNative.runOCR(bitmap)
            val jsonArray = JSONArray(jsonResult)
            val blocks = mutableListOf<BlockData>()

            for (i in 0 until jsonArray.length()) {
                val item = jsonArray.getJSONObject(i)
                val text = item.getString("text")
                val box = item.getJSONArray("box")
                val score = item.optDouble("score", 0.0)

                // Calculate bounding box from polygon
                val xs = mutableListOf<Int>()
                val ys = mutableListOf<Int>()
                for (j in 0 until box.length()) {
                    val point = box.getJSONArray(j)
                    xs.add(point.getInt(0))
                    ys.add(point.getInt(1))
                }

                val minX = xs.minOrNull() ?: 0
                val minY = ys.minOrNull() ?: 0
                val maxX = xs.maxOrNull() ?: 0
                val maxY = ys.maxOrNull() ?: 0

                blocks.add(BlockData(
                    text = text,
                    x = minX,
                    y = minY,
                    width = maxX - minX,
                    height = maxY - minY,
                    confidence = score.toFloat()
                ))
            }

            blocks
        } catch (e: Exception) {
            Log.e(TAG, "Recognition failed", e)
            emptyList()
        }
    }

    fun destroy() {
        if (initialized) {
            PaddleOCRNative.release()
            initialized = false
        }
    }

    private fun extractAsset(assetPath: String, fileName: String): String? {
        return try {
            val outFile = File(context.cacheDir, "paddle/$fileName")
            outFile.parentFile?.mkdirs()

            if (outFile.exists()) return outFile.absolutePath

            context.assets.open(assetPath).use { input ->
                FileOutputStream(outFile).use { output ->
                    input.copyTo(output)
                }
            }
            outFile.absolutePath
        } catch (e: Exception) {
            Log.e(TAG, "Failed to extract $assetPath", e)
            null
        }
    }
}
