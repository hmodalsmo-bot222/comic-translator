package com.comictrans.paddle

import android.graphics.Bitmap
import android.util.Log

/**
 * JNI Wrapper for PaddleOCR Lite
 *
 * REQUIRED FILES (not included in project - download separately):
 * 1. libpaddle_light_api_shared.so → app/src/main/jniLibs/arm64-v8a/
 * 2. ch_PP-OCRv4_det.nb (detection model) → assets/paddle/
 * 3. en_PP-OCRv4_rec.nb (recognition model) → assets/paddle/
 * 4. en_dict.txt (dictionary) → assets/paddle/
 *
 * Download from: https://github.com/PaddlePaddle/PaddleOCR
 */
object PaddleOCRNative {

    init {
        try {
            System.loadLibrary("paddle_light_api_shared")
            Log.d("PaddleOCR", "Native library loaded")
        } catch (e: UnsatisfiedLinkError) {
            Log.e("PaddleOCR", "Failed to load native library", e)
        }
    }

    /**
     * Initialize the OCR engine
     * @param detModelPath Path to detection model (.nb file)
     * @param recModelPath Path to recognition model (.nb file)
     * @param dictPath Path to dictionary file
     * @return true if initialized successfully
     */
    external fun init(detModelPath: String, recModelPath: String, dictPath: String): Boolean

    /**
     * Run OCR on a bitmap
     * @param bitmap Input image
     * @return JSON string with detected text blocks
     * Format: [{"text":"hello","box":[[x1,y1],[x2,y2],[x3,y3],[x4,y4]],"score":0.95}]
     */
    external fun runOCR(bitmap: Bitmap): String

    /**
     * Release resources
     */
    external fun release()

    @JvmStatic
    fun isAvailable(): Boolean {
        return try {
            System.loadLibrary("paddle_light_api_shared")
            true
        } catch (e: Throwable) {
            false
        }
    }
}
