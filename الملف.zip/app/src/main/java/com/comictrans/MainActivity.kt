package com.comictrans

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Base64
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var appInterface: AppInterface

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize OpenCV (loads libopencv_java4.so)
        try {
            System.loadLibrary("opencv_java4")
            android.util.Log.d("OpenCV", "OpenCV loaded successfully")
        } catch (e: UnsatisfiedLinkError) {
            android.util.Log.e("OpenCV", "Failed to load OpenCV: ${e.message}")
            android.util.Log.e("OpenCV", "Make sure OpenCV native libs are in jniLibs/")
        }

        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        setupWebView()

        appInterface = AppInterface(this, webView)
        webView.addJavascriptInterface(appInterface, "AndroidBridge")

        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
        }
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
    }

    fun sendToWebView(functionName: String, data: String) {
        runOnUiThread {
            webView.evaluateJavascript("window.\$functionName(\$data)", null)
        }
    }

    companion object {
        fun base64ToBitmap(base64Str: String): Bitmap? {
            return try {
                val pureBase64 = base64Str.substringAfter(",")
                val bytes = Base64.decode(pureBase64, Base64.DEFAULT)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            } catch (e: Exception) {
                null
            }
        }
    }
}
