
package com.comictrans.engine

import android.content.Context
import android.util.Log
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class TranslationEngine(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    // 1. ML Kit Translation (works offline after model download)
    suspend fun translateMLKit(text: String, source: String, target: String): String = withContext(Dispatchers.IO) {
        try {
            val options = TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.fromLanguageTag(source) ?: TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.fromLanguageTag(target) ?: TranslateLanguage.ARABIC)
                .build()
            val translator = Translation.getClient(options)

            // Ensure model is downloaded
            suspendCancellableCoroutine { continuation ->
                val conditions = DownloadConditions.Builder().requireWifi().build()
                translator.downloadModelIfNeeded(conditions)
                    .addOnSuccessListener { continuation.resume(Unit) }
                    .addOnFailureListener { continuation.resumeWithException(it) }
            }

            suspendCancellableCoroutine { continuation ->
                translator.translate(text)
                    .addOnSuccessListener { continuation.resume(it) }
                    .addOnFailureListener { continuation.resumeWithException(it) }
            }
        } catch (e: Exception) {
            Log.e("MLKitTrans", "Error", e)
            text
        }
    }

    // 2. Google Translate (free, no key)
    suspend fun translateGoogle(text: String, source: String, target: String): String = withContext(Dispatchers.IO) {
        try {
            val src = if (source == "auto") "auto" else source
            // تم إصلاح خطأ علامة $ هنا
            val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=$src&tl=$target&dt=t&q=${URLEncoder.encode(text, "UTF-8")}"
            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return@withContext text

            // Parse JSON array response
            val jsonArray = org.json.JSONArray(body)
            val sentences = jsonArray.getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until sentences.length()) {
                val sentence = sentences.getJSONArray(i)
                sb.append(sentence.getString(0))
            }
            sb.toString()
        } catch (e: Exception) {
            Log.e("GoogleTrans", "Error", e)
            text
        }
    }

    // 3. Gemini
    suspend fun translateGemini(text: String, source: String, target: String, apiKey: String, model: String): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext text
        try {
            // تم إصلاح خطأ علامة $ هنا
            val prompt = "Translate this comic text into ${if (target == "ar") "Arabic" else target} naturally. Return only the translation:\n\n$text"
            val jsonBody = JSONObject().apply {
                put("contents", org.json.JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", org.json.JSONArray().apply {
                            put(JSONObject().put("text", prompt))
                        })
                    })
                })
            }
            val request = Request.Builder()
                // تم إصلاح خطأ علامة $ هنا
                .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()
            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return@withContext text
            val json = JSONObject(body)
            json.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                .getString("text").trim()
        } catch (e: Exception) {
            Log.e("Gemini", "Error", e)
            text
        }
    }

    // 4. OpenAI
    suspend fun translateOpenAI(text: String, source: String, target: String, apiKey: String, model: String): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext text
        try {
            // تم إصلاح خطأ علامة $ هنا
            val prompt = "Translate this comic text into ${if (target == "ar") "Arabic" else target} naturally. Return only the translation:\n\n$text"
            val jsonBody = JSONObject().apply {
                put("model", model)
                put("messages", org.json.JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "user")
                        put("content", prompt)
                    })
                })
                put("temperature", 0.3)
            }
            val request = Request.Builder()
                .url("https://api.openai.com/v1/chat/completions")
                // تم إصلاح خطأ علامة $ هنا
                .header("Authorization", "Bearer $apiKey")
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()
            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return@withContext text
            val json = JSONObject(body)
            json.getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content").trim()
        } catch (e: Exception) {
            Log.e("OpenAI", "Error", e)
            text
        }
    }

    // 5. DeepL
    suspend fun translateDeepL(text: String, source: String, target: String, apiKey: String): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext text
        try {
            val body = java.net.URLEncoder.encode("text", "UTF-8") + "=" + java.net.URLEncoder.encode(text, "UTF-8") +
                    "&" + java.net.URLEncoder.encode("target_lang", "UTF-8") + "=" + java.net.URLEncoder.encode(target.uppercase(), "UTF-8")
            val request = Request.Builder()
                .url("https://api-free.deepl.com/v2/translate")
                // تم إصلاح خطأ علامة $ هنا
                .header("Authorization", "DeepL-Auth-Key $apiKey")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .post(body.toRequestBody("application/x-www-form-urlencoded".toMediaType()))
                .build()
            val response = client.newCall(request).execute()
            val resBody = response.body?.string() ?: return@withContext text
            val json = JSONObject(resBody)
            json.getJSONArray("translations").getJSONObject(0).getString("text")
        } catch (e: Exception) {
            Log.e("DeepL", "Error", e)
            text
        }
    }
}