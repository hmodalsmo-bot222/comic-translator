package com.comictrans.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface TranslationDao {

    @Query("SELECT * FROM translations WHERE sourceText = :text LIMIT 1")
    suspend fun findExact(text: String): TranslationEntity?

    @Query("SELECT * FROM translations WHERE sourceText LIKE '%' || :text || '%' ORDER BY frequency DESC LIMIT 5")
    suspend fun findSimilar(text: String): List<TranslationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: TranslationEntity)

    @Update
    suspend fun update(entity: TranslationEntity)

    @Query("UPDATE translations SET frequency = frequency + 1, lastUsed = :time WHERE id = :id")
    suspend fun incrementFrequency(id: Long, time: Long = System.currentTimeMillis())

    @Query("SELECT * FROM translations ORDER BY lastUsed DESC LIMIT 100")
    suspend fun getRecent(): List<TranslationEntity>

    @Query("DELETE FROM translations WHERE id NOT IN (SELECT id FROM translations ORDER BY lastUsed DESC LIMIT 5000)")
    suspend fun trimOld()
}
